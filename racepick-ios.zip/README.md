# 開跑推薦（RacePick）iPhone 版

原本 `開跑推薦-決策模型`（Python `server.py`）嘅 iPhone 原生版本。畫面沿用原本網頁介面，後台改用 Swift：

- 每秒（加快模式約 0.25 秒）讀取香港賽馬會賠率（獨贏、位置、連贏、位置Q、二重彩、孖寶）
- 追蹤開跑後賠率變化，交畀 Jev 決策模型（TypeSafe）計「熱錢」同「高風險值得博」
- **只讀，唔會落注**

> ⚠️ 馬會資料只接受香港網絡。請喺香港使用，並關閉 VPN；否則會顯示「馬會拒絕連線（HTTP 403）」。

---

## 1. 下載 IPA

直接下載最新版（每次更新程式都會自動重新建立）：

**https://github.com/xinsonbobo-web/2/releases/download/latest/RacePick.ipa**

或者去 [Releases](https://github.com/xinsonbobo-web/2/releases/tag/latest) 頁面下載 `RacePick.ipa`。

呢個 IPA 係**未簽名**，要用 Sideloadly 以你自己嘅 Apple ID 簽名先裝得到。

## 2. 用 Sideloadly 喺 Windows 安裝

1. 喺 Windows 安裝 **iTunes** 同 **iCloud**（要用 Apple 官網版本，唔好用 Microsoft Store 版本），然後安裝 [Sideloadly](https://sideloadly.io/)。
2. 用 USB 線將 iPhone 接上電腦，iPhone 彈出「信任此電腦？」就撳**信任**。
3. 打開 Sideloadly：
   - **IPA**：拖 `RacePick.ipa` 入去（或者撳 IPA 圖示揀檔案）
   - **Apple ID**：輸入你自己嘅 Apple ID（免費帳戶都得，建議開一個專用 Apple ID）
   - 撳 **Start**，輸入 Apple ID 密碼（如有雙重認證就輸入驗證碼）
4. 顯示 **Done** 就裝好。

## 3. iPhone 設定（第一次）

1. **開啟開發者模式**（iOS 16 或以上）：
   設定 → 私隱與安全性 → 開發者模式 → 開啟 → 重新開機 → 開機後按「開啟」確認。
   （如果見唔到「開發者模式」，先用 Sideloadly 裝一次 app，選項就會出現。）
2. **信任開發者**：
   設定 → 一般 → VPN 與裝置管理 → 喺「開發者 App」揀你嘅 Apple ID → **信任**。
3. 返主畫面打開 **開跑推薦**。

## 4. 輸入 API key

- 第一次打開會彈出設定畫面。可以貼 **多條 TypeSafe API key，每行一條**（第一行係主 key，下面係後備），撳「儲存」。
- Key 只會儲存喺 iPhone 嘅 **Keychain**，唔會放入程式或者呢個 repo。畫面只會顯示用緊第幾條、共幾條、剔走咗幾條，唔會顯示 key 本身。
- 額度用完、伺服器繁忙或者暫時連唔上，會用同一份資料換下一條，並停喺用得嘅嗰條。HTTP 401／403 會剔走，之後唔再試。連續兩次連線失敗就停。如果係送出嘅資料有問題，就唔會換 key。
- 之後想更改或者清除：撳右上角 ⚙️ 齒輪。儲存會取代成個池。
- 冇 key 都可以睇賠率，但熱錢／高風險推薦會顯示「未設定 TypeSafe API key」。

## 5. 使用

- **啟動**：開始讀取馬會同計熱錢、高風險（啟動期間螢幕唔會自動熄）。
- **加快**：讀取由大約每秒一次變成大約 0.25 秒一次；再撳「恢復」。
- **場次按鈕**：揀其他場次（沙田、跑馬地、海外）；**跟返自動**：返回自動揀場。
- 信心 20% 或以上嘅馬先會顯示。

## 6. 每 7 日重新簽名

免費 Apple ID 簽名嘅 app **7 日後會失效**（打開會閃退或者顯示無法使用）。
到時用 Sideloadly 再裝一次同一個 `RacePick.ipa` 就得（Keychain 入面嘅 API key 通常會保留）。
免費 Apple ID 同一時間最多 3 個自簽 app。

---

## 開發者資料

- 原生 Swift（iOS 16+），`WKWebView` 顯示原本 HTML 介面，`racepick://` scheme handler 提供原本嘅 `/api/state`、`/api/arm`、`/api/fast`。
- `RacePick/queries/*.graphql`：馬會 GraphQL 查詢（`info.cld.hkjc.com/graphql/base/`）
- `RacePick/models/*.json`：Jev 模型定義（熱錢 = `jev-signal.json`，高風險值得博 = `jev-value.json`）
- `project.yml`：XcodeGen 專案設定；`.github/workflows/build-ipa.yml`：GitHub Actions（macOS）自動建立未簽名 IPA，上傳 artifact 同更新 `latest` release。
- **永遠唔好提交 `.typesafe_key` 或者任何 API key。**
