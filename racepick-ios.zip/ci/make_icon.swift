// 喺 CI（macOS）生成 1024x1024 App icon：深色底、金色圓圈、「開跑」。
import Foundation
import CoreGraphics
import CoreText
import ImageIO

let size = 1024
let space = CGColorSpaceCreateDeviceRGB()
guard let ctx = CGContext(data: nil, width: size, height: size, bitsPerComponent: 8, bytesPerRow: 0,
                          space: space, bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { exit(1) }
ctx.setFillColor(CGColor(red: 18 / 255, green: 20 / 255, blue: 15 / 255, alpha: 1))
ctx.fill(CGRect(x: 0, y: 0, width: size, height: size))
ctx.setStrokeColor(CGColor(red: 230 / 255, green: 195 / 255, blue: 106 / 255, alpha: 1))
ctx.setLineWidth(28)
ctx.strokeEllipse(in: CGRect(x: 126, y: 126, width: 772, height: 772))
let font = CTFontCreateWithName("PingFangHK-Semibold" as CFString, 290, nil)
let gold = CGColor(red: 242 / 255, green: 212 / 255, blue: 138 / 255, alpha: 1)
for (index, text) in ["開", "跑"].enumerated() {
    let attrs: [NSAttributedString.Key: Any] = [
        NSAttributedString.Key(kCTFontAttributeName as String): font,
        NSAttributedString.Key(kCTForegroundColorAttributeName as String): gold,
    ]
    let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attrs))
    let bounds = CTLineGetBoundsWithOptions(line, .useGlyphPathBounds)
    let centerY: CGFloat = index == 0 ? 675 : 349
    ctx.textPosition = CGPoint(x: (CGFloat(size) - bounds.width) / 2 - bounds.minX,
                               y: centerY - bounds.height / 2 - bounds.minY)
    CTLineDraw(line, ctx)
}
guard let image = ctx.makeImage(),
      let dest = CGImageDestinationCreateWithURL(URL(fileURLWithPath: CommandLine.arguments[1]) as CFURL,
                                                 "public.png" as CFString, 1, nil) else { exit(1) }
CGImageDestinationAddImage(dest, image, nil)
exit(CGImageDestinationFinalize(dest) ? 0 : 1)
