// CI：用 ci/icon-photo.png 做 1024x1024、冇透明嘅 App icon。
import Foundation
import CoreGraphics
import ImageIO

let size = 1024
let srcURL = URL(fileURLWithPath: "ci/icon-photo.png")
guard let source = CGImageSourceCreateWithURL(srcURL as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
    fputs("cannot read ci/icon-photo.png\n", stderr)
    exit(1)
}
let space = CGColorSpaceCreateDeviceRGB()
guard let ctx = CGContext(data: nil, width: size, height: size, bitsPerComponent: 8, bytesPerRow: 0,
                          space: space, bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { exit(1) }
ctx.interpolationQuality = .high
ctx.draw(image, in: CGRect(x: 0, y: 0, width: size, height: size))
guard let out = ctx.makeImage() else { exit(1) }
let dest = URL(fileURLWithPath: CommandLine.arguments[1]) as CFURL
guard let destRef = CGImageDestinationCreateWithURL(dest, "public.png" as CFString, 1, nil) else { exit(1) }
CGImageDestinationAddImage(destRef, out, nil)
guard CGImageDestinationFinalize(destRef) else { exit(1) }
