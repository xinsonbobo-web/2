# 後備：冇 Swift 都可以生成一個簡單 icon（深色底 + 金色圓圈），純 Python。
import struct, sys, zlib

N = 1024
bg, gold = (18, 20, 15), (230, 195, 106)
rows = []
for y in range(N):
    row = bytearray(b"\x00")
    dy = (y - 511.5) ** 2
    for x in range(N):
        d = (dy + (x - 511.5) ** 2) ** 0.5
        row += bytes(gold if 372 <= d <= 400 else bg)
    rows.append(bytes(row))
raw = zlib.compress(b"".join(rows), 9)

def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

with open(sys.argv[1], "wb") as f:
    f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", N, N, 8, 2, 0, 0, 0)) + chunk(b"IDAT", raw) + chunk(b"IEND", b""))
