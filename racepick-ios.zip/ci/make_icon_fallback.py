# 後備：Swift 用唔到時，直接抄 ci/icon-photo.png（已經係 1024、冇透明）。
import shutil, sys
shutil.copyfile("ci/icon-photo.png", sys.argv[1])
