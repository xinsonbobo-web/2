import SwiftUI
import WebKit

@main
struct RacePickApp: App {
    init() {
        Engine.shared.start()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

let pageBackground = Color(red: 0x12 / 255.0, green: 0x14 / 255.0, blue: 0x0f / 255.0)

struct ContentView: View {
    @State private var showSettings = false
    @State private var firstLaunch = false
    @AppStorage("askedForKey") private var askedForKey = false

    var body: some View {
        ZStack(alignment: .topTrailing) {
            pageBackground.ignoresSafeArea()
            RaceWebView()
                .ignoresSafeArea(edges: [.bottom, .horizontal])
            Button {
                firstLaunch = false
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20))
                    .foregroundColor(Color(red: 0.90, green: 0.76, blue: 0.42))
                    .padding(10)
                    .background(Circle().fill(Color.black.opacity(0.35)))
            }
            .accessibilityLabel("設定")
            .padding(.trailing, 12)
            .padding(.top, 6)
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(firstLaunch: firstLaunch)
        }
        .onAppear {
            if !askedForKey && !Keychain.hasKey {
                askedForKey = true
                firstLaunch = true
                showSettings = true
            }
        }
    }
}

struct RaceWebView: UIViewRepresentable {
    final class Coordinator {
        let handler = APISchemeHandler()
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(context.coordinator.handler, forURLScheme: APISchemeHandler.scheme)
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        let bg = UIColor(red: 0x12 / 255.0, green: 0x14 / 255.0, blue: 0x0f / 255.0, alpha: 1)
        web.isOpaque = false
        web.backgroundColor = bg
        web.scrollView.backgroundColor = bg
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = false
        web.load(URLRequest(url: APISchemeHandler.startURL))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct SettingsView: View {
    let firstLaunch: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var hasKey = Keychain.hasKey
    @State private var statusLine = Keychain.status().line
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(firstLaunch
                         ? "歡迎使用馮大師。熱錢同高風險兩個推薦要用 TypeSafe（Jev）API key。每行貼一條（第一行主 key，下面後備），只會儲存喺呢部 iPhone 嘅 Keychain。"
                         : "TypeSafe（Jev）API key 只會儲存喺呢部 iPhone 嘅 Keychain，唔會上載去其他地方。可以一次貼多條，每行一條。")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                Section("TypeSafe API key") {
                    HStack {
                        Text("狀態")
                        Spacer()
                        Text(statusLine.isEmpty ? (hasKey ? "已設定" : "未設定") : statusLine)
                            .foregroundColor(hasKey ? .green : .orange)
                            .multilineTextAlignment(.trailing)
                    }
                    TextEditor(text: $draft)
                        .frame(minHeight: 120)
                        .font(.system(.body, design: .monospaced))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                    Text("每行一條。第一行係主 key，其餘係後備。儲存後呢度會清空，唔會再顯示 key。儲存會取代成個池。")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                    Button("儲存") {
                        let pool = Keychain.parseKeys(draft)
                        guard !pool.isEmpty else {
                            message = "請先輸入 API key（每行一條）。"
                            return
                        }
                        if Keychain.savePool(draft) {
                            draft = ""
                            refresh()
                            message = "已儲存 \(Keychain.status().total) 條。"
                            if firstLaunch { dismiss() }
                        } else {
                            message = "儲存失敗，請再試。"
                        }
                    }
                    .disabled(Keychain.parseKeys(draft).isEmpty)
                    if hasKey {
                        Button("清除全部 API key", role: .destructive) {
                            Keychain.clear()
                            draft = ""
                            refresh()
                            message = "已清除。"
                        }
                    }
                    if !message.isEmpty {
                        Text(message).font(.footnote).foregroundColor(.secondary)
                    }
                }
                Section("說明") {
                    Text("數據只讀香港賽馬會（需要香港網絡，唔好開 VPN）。呢個 app 只係睇賠率同推薦，唔會落注。")
                    Text("啟動：開始每秒讀取同計熱錢、高風險。加快：改為大約 0.25 秒一次。")
                    Text("換 key：額度用完、伺服器繁忙、暫時連唔上（KEY_RETRY_HTTP 401、402、403、408、429、500、502、503、504）會用同一份資料換下一條，之後停喺用得嘅嗰條。被拒絕（KEY_DEAD_HTTP 401、403）會剔走，之後唔再試。連續兩次連線失敗就停，唔會等到成個池。問題出喺送出嘅資料就唔換 key。")
                }
                .font(.footnote)
            }
            .navigationTitle(firstLaunch ? "設定 API key" : "設定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(firstLaunch && !hasKey ? "稍後" : "完成") { dismiss() }
                }
            }
            .onAppear { refresh() }
        }
    }

    private func refresh() {
        let status = Keychain.status()
        hasKey = status.total > 0
        statusLine = status.line
    }
}
