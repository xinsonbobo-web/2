import SwiftUI
import WebKit

@main
struct RacePickApp: App {
    init() {
        Engine.shared.start()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

let pageBackground = Color(red: 0x12 / 255.0, green: 0x14 / 255.0, blue: 0x0f / 255.0)

struct ContentView: View {
    @State private var showSettings = false
    @State private var firstLaunch = false
    @AppStorage("askedForKey") private var askedForKey = false

    var body: some View {
        ZStack(alignment: .topTrailing) {
            pageBackground.ignoresSafeArea()
            RaceWebView()
                .ignoresSafeArea(edges: [.bottom, .horizontal])
            Button {
                firstLaunch = false
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20))
                    .foregroundColor(Color(red: 0.90, green: 0.76, blue: 0.42))
                    .padding(10)
                    .background(Circle().fill(Color.black.opacity(0.35)))
            }
            .accessibilityLabel("設定")
            .padding(.trailing, 12)
            .padding(.top, 6)
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(firstLaunch: firstLaunch)
        }
        .onAppear {
            if !askedForKey && !Keychain.hasKey {
                askedForKey = true
                firstLaunch = true
                showSettings = true
            }
        }
    }
}

struct RaceWebView: UIViewRepresentable {
    final class Coordinator {
        let handler = APISchemeHandler()
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(context.coordinator.handler, forURLScheme: APISchemeHandler.scheme)
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        let bg = UIColor(red: 0x12 / 255.0, green: 0x14 / 255.0, blue: 0x0f / 255.0, alpha: 1)
        web.isOpaque = false
        web.backgroundColor = bg
        web.scrollView.backgroundColor = bg
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = false
        web.load(URLRequest(url: APISchemeHandler.startURL))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct SettingsView: View {
    let firstLaunch: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var reveal = false
    @State private var hasKey = Keychain.hasKey
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(firstLaunch
                         ? "歡迎使用開跑推薦。熱錢同高風險兩個推薦要用 TypeSafe（Jev）API key。請輸入你自己嘅 key，只會儲存喺呢部 iPhone 嘅 Keychain。"
                         : "TypeSafe（Jev）API key 只會儲存喺呢部 iPhone 嘅 Keychain，唔會上載去其他地方。")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                Section("TypeSafe API key") {
                    HStack {
                        Text("狀態")
                        Spacer()
                        Text(hasKey ? "已設定" : "未設定")
                            .foregroundColor(hasKey ? .green : .orange)
                    }
                    Group {
                        if reveal {
                            TextField("貼上新 API key", text: $draft)
                        } else {
                            SecureField("貼上新 API key", text: $draft)
                        }
                    }
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .font(.system(.body, design: .monospaced))
                    Toggle("顯示輸入內容", isOn: $reveal)
                    Button("儲存") {
                        let value = draft.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !value.isEmpty else {
                            message = "請先輸入 API key。"
                            return
                        }
                        if Keychain.save(value) {
                            draft = ""
                            hasKey = true
                            message = "已儲存。"
                            if firstLaunch { dismiss() }
                        } else {
                            message = "儲存失敗，請再試。"
                        }
                    }
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if hasKey {
                        Button("清除 API key", role: .destructive) {
                            Keychain.clear()
                            hasKey = Keychain.hasKey
                            message = "已清除。"
                        }
                    }
                    if !message.isEmpty {
                        Text(message).font(.footnote).foregroundColor(.secondary)
                    }
                }
                Section("說明") {
                    Text("數據只讀香港賽馬會（需要香港網絡，唔好開 VPN）。呢個 app 只係睇賠率同推薦，唔會落注。")
                    Text("啟動：開始每秒讀取同計熱錢、高風險。加快：改為大約 0.25 秒一次。")
                }
                .font(.footnote)
            }
            .navigationTitle(firstLaunch ? "設定 API key" : "設定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(firstLaunch && !hasKey ? "稍後" : "完成") { dismiss() }
                }
            }
        }
    }
}
