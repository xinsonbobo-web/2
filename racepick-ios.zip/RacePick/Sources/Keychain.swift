import Foundation
import CryptoKit
import Security

/// TypeSafe API key 只放喺 iOS Keychain（本機），唔會寫入程式或者 repo。
/// 主 key 在前，後備每行一條。狀態只記第幾條同已剔走嘅指紋，唔會記 key 本身。
enum Keychain {
    private static let service = "com.racepick.app.typesafe"
    private static let legacyAccount = "typesafe_api_key"
    private static let poolAccount = "typesafe_api_keys"
    private static let stateAccount = "typesafe_key_state"
    private static let lock = NSLock()

    struct Status {
        var total: Int
        var using: Int
        var dropped: Int
        /// 唔包含任何 key 字串。
        var line: String
    }

    struct Snapshot {
        var pool: [String]
        var index: Int
        var dead: Set<String>
    }

    private struct PersistedState: Codable {
        var index: Int
        var dead: [String]
    }

    static func fingerprint(_ key: String) -> String {
        let digest = SHA256.hash(data: Data(key.utf8))
        return digest.prefix(8).map { String(format: "%02x", $0) }.joined()
    }

    /// 每行一條。空行同 # 註釋跳過。同一條只留第一次（主 key 在前）。
    static func parseKeys(_ text: String) -> [String] {
        var seen = Set<String>()
        var pool: [String] = []
        for raw in text.split(whereSeparator: \.isNewline) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty || line.hasPrefix("#") { continue }
            if seen.contains(line) { continue }
            seen.insert(line)
            pool.append(line)
        }
        return pool
    }

    static var hasKey: Bool { status().total > 0 }

    static func status() -> Status {
        lock.lock()
        defer { lock.unlock() }
        return statusUnlocked()
    }

    static func snapshot() -> Snapshot {
        lock.lock()
        defer { lock.unlock() }
        let pool = readPoolUnlocked()
        let state = readStateUnlocked()
        let index = normalized(state.index, count: pool.count)
        return Snapshot(pool: pool, index: index, dead: Set(state.dead))
    }

    static func storeState(index: Int, dead: Set<String>) {
        lock.lock()
        defer { lock.unlock() }
        writeStateUnlocked(PersistedState(index: index, dead: dead.sorted()))
    }

    /// 取代成個池。已剔走嘅指紋會保留，所以被拒絕嘅 key 貼返都唔會再試。
    @discardableResult
    static func savePool(_ text: String) -> Bool {
        let pool = parseKeys(text)
        if pool.isEmpty { return clear() }
        guard let data = pool.joined(separator: "\n").data(using: .utf8) else { return false }
        lock.lock()
        defer { lock.unlock() }
        guard writeAccount(poolAccount, data: data) else { return false }
        deleteAccount(legacyAccount)
        let live = Set(pool.map { fingerprint($0) })
        var state = readStateUnlocked()
        state.dead = state.dead.filter { live.contains($0) }.sorted()
        state.index = normalized(state.index, count: pool.count)
        writeStateUnlocked(state)
        return true
    }

    @discardableResult
    static func clear() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        let a = deleteAccount(legacyAccount)
        let b = deleteAccount(poolAccount)
        let c = deleteAccount(stateAccount)
        return a && b && c
    }

    // MARK: - Status

    private static func statusUnlocked() -> Status {
        let pool = readPoolUnlocked()
        let state = readStateUnlocked()
        let dead = Set(state.dead)
        let total = pool.count
        if total == 0 {
            return Status(total: 0, using: 0, dropped: 0, line: "")
        }
        let dropped = pool.reduce(0) { $0 + (dead.contains(fingerprint($1)) ? 1 : 0) }
        if dropped >= total {
            return Status(total: total, using: 0, dropped: dropped,
                          line: "全部 \(total) 條 key 已被拒絕，之後唔會再試")
        }
        let start = normalized(state.index, count: total)
        var using = start + 1
        for offset in 0..<total {
            let i = (start + offset) % total
            if !dead.contains(fingerprint(pool[i])) {
                using = i + 1
                break
            }
        }
        var line = "用緊第 \(using) 條，共 \(total) 條"
        if dropped > 0 { line += "，已剔走 \(dropped) 條" }
        return Status(total: total, using: using, dropped: dropped, line: line)
    }

    private static func normalized(_ index: Int, count: Int) -> Int {
        guard count > 0 else { return 0 }
        let mod = index % count
        return mod >= 0 ? mod : mod + count
    }

    // MARK: - Pool / state

    private static func readPoolUnlocked() -> [String] {
        let multi = readAccount(poolAccount)
        if !multi.isEmpty { return parseKeys(multi) }
        let single = readAccount(legacyAccount)
        if single.isEmpty { return [] }
        return parseKeys(single)
    }

    private static func readStateUnlocked() -> PersistedState {
        let text = readAccount(stateAccount)
        guard let data = text.data(using: .utf8),
              let state = try? JSONDecoder().decode(PersistedState.self, from: data) else {
            return PersistedState(index: 0, dead: [])
        }
        return state
    }

    private static func writeStateUnlocked(_ state: PersistedState) {
        guard let data = try? JSONEncoder().encode(state) else { return }
        _ = writeAccount(stateAccount, data: data)
    }

    // MARK: - Keychain IO

    private static func query(_ account: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
    }

    private static func readAccount(_ account: String) -> String {
        var query = query(account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data,
              let text = String(data: data, encoding: .utf8) else { return "" }
        return text
    }

    private static func writeAccount(_ account: String, data: Data) -> Bool {
        deleteAccount(account)
        var attributes = query(account)
        attributes[kSecValueData as String] = data
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(attributes as CFDictionary, nil) == errSecSuccess
    }

    @discardableResult
    private static func deleteAccount(_ account: String) -> Bool {
        let status = SecItemDelete(query(account) as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
}
