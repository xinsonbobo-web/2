import Foundation

let HKT = TimeZone(identifier: "Asia/Hong_Kong") ?? TimeZone(secondsFromGMT: 8 * 3600)!

enum AppError: LocalizedError {
    case geoBlocked(Int)
    case http(Int)
    case network(String)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .geoBlocked(let code):
            return "馬會拒絕連線（HTTP \(code)）。馬會只接受香港網絡：請確認部 iPhone 喺香港、用香港流動數據或 Wi-Fi，並關閉 VPN。"
        case .http(let code):
            return "馬會回覆 HTTP \(code)，稍後自動再試。"
        case .network(let detail):
            return "連唔到馬會：\(detail)"
        case .badResponse:
            return "馬會回覆唔係 JSON（可能被封鎖或者維護中），稍後自動再試。"
        }
    }
}

func toInt(_ value: Any?) -> Int? {
    if let n = value as? NSNumber { return n.intValue }
    if let s = value as? String {
        let t = s.trimmingCharacters(in: .whitespaces)
        if let i = Int(t) { return i }
        if let d = Double(t), d.isFinite { return Int(d) }
    }
    return nil
}

func toDouble(_ value: Any?) -> Double? {
    if let n = value as? NSNumber { return n.doubleValue }
    if let s = value as? String { return Double(s.trimmingCharacters(in: .whitespaces)) }
    return nil
}

func toStr(_ value: Any?) -> String {
    if let s = value as? String { return s }
    if let n = value as? NSNumber { return n.stringValue }
    return ""
}

/// Python 式 truthiness：None、""、0、[]、{} 都當 false。
func truthy(_ value: Any?) -> Bool {
    guard let value = value else { return false }
    if value is NSNull { return false }
    if let s = value as? String { return !s.isEmpty }
    if let n = value as? NSNumber { return n.doubleValue != 0 }
    if let a = value as? [Any] { return !a.isEmpty }
    if let d = value as? [String: Any] { return !d.isEmpty }
    return true
}

func dict(_ value: Any?) -> [String: Any] { (value as? [String: Any]) ?? [:] }
func list(_ value: Any?) -> [Any] { (value as? [Any]) ?? [] }

func round2(_ x: Double) -> Double { (x * 100).rounded() / 100 }
func round1(_ x: Double) -> Double { (x * 10).rounded() / 10 }
func roundInt(_ x: Double) -> Int { x.isFinite ? Int(x.rounded()) : 0 }

private func makeFormatter(_ format: String) -> DateFormatter {
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.calendar = Calendar(identifier: .gregorian)
    f.timeZone = HKT
    f.dateFormat = format
    return f
}

private let dayFormatter = makeFormatter("yyyy-MM-dd")
private let clockFormatter = makeFormatter("HH:mm:ss")
private let isoOutFormatter = makeFormatter("yyyy-MM-dd'T'HH:mm:ssxxx")
private let naiveFormatters = [
    makeFormatter("yyyy-MM-dd'T'HH:mm:ss.SSSSSS"),
    makeFormatter("yyyy-MM-dd'T'HH:mm:ss.SSS"),
    makeFormatter("yyyy-MM-dd'T'HH:mm:ss"),
    makeFormatter("yyyy-MM-dd HH:mm:ss"),
]
private let formatterLock = NSLock()

func hktDay(_ date: Date) -> String {
    formatterLock.lock(); defer { formatterLock.unlock() }
    return dayFormatter.string(from: date)
}

func hktClock(_ date: Date) -> String {
    formatterLock.lock(); defer { formatterLock.unlock() }
    return clockFormatter.string(from: date)
}

func hktISO(_ date: Date) -> String {
    formatterLock.lock(); defer { formatterLock.unlock() }
    return isoOutFormatter.string(from: date)
}

/// 解析馬會 lastUpdateTime（ISO 8601，有或者冇時區；冇時區當香港時間）。
func parseISODate(_ text: String) -> Date? {
    let s = text.trimmingCharacters(in: .whitespaces)
    if s.isEmpty { return nil }
    let iso = ISO8601DateFormatter()
    iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let d = iso.date(from: s) { return d }
    iso.formatOptions = [.withInternetDateTime]
    if let d = iso.date(from: s) { return d }
    formatterLock.lock(); defer { formatterLock.unlock() }
    for f in naiveFormatters {
        if let d = f.date(from: s) { return d }
    }
    return nil
}

func bundleURL(_ name: String, _ ext: String, _ subdirectory: String?) -> URL? {
    if let sub = subdirectory, let url = Bundle.main.url(forResource: name, withExtension: ext, subdirectory: sub) {
        return url
    }
    return Bundle.main.url(forResource: name, withExtension: ext)
}

func bundleText(_ name: String, _ ext: String, _ subdirectory: String?) -> String {
    guard let url = bundleURL(name, ext, subdirectory),
          let text = try? String(contentsOf: url, encoding: .utf8) else { return "" }
    return text
}
