import Foundation

/// 香港賽馬會賠率。對應原本 hkjc_feed.py。只讀，唔會落注。
struct RaceInfo {
    let id: String
    let venue: String
    let no: Int
    let sell: String
    let postTime: String
    let postAt: String
    let name: String
}

struct OddsSnapshot {
    let recordedAt: Date
    let odds: [Int: Double]
    let investment: [Int: Double]
    let exotic: [String: [[String: Any]]]
    let sell: String
}

struct CardInfo {
    var names: [Int: [Int: String]] = [:]
    var titles: [Int: String] = [:]
}

final class HKJCFeed {
    static let endpoint = URL(string: "https://info.cld.hkjc.com/graphql/base/")!
    static let types = ["WIN", "PLA", "QIN", "QPL", "FCT", "DBL"]
    static let overseas = ["S1", "S2", "S3"]
    static let local = ["ST", "HV"]
    static let notional = 1_000_000.0
    static let poolLabel: [(String, String)] = [
        ("PLA", "place"),
        ("QIN", "quinella"),
        ("QPL", "quinella_place"),
        ("FCT", "forecast"),
        ("DBL", "double"),
    ]
    static let closedRace: Set<String> = ["RESULT", "ABANDONED", "VOID", "CANCELLED", "CLOSED"]

    private let session: URLSession
    private let oddsQuery: String
    private let cardQuery: String
    private var catalog: (at: Date, day: String, races: [RaceInfo]) = (.distantPast, "", [])
    private var cardCache: [String: (at: Date, card: CardInfo)] = [:]

    init() {
        let config = URLSessionConfiguration.default
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil
        config.httpMaximumConnectionsPerHost = 4
        config.timeoutIntervalForRequest = 25
        session = URLSession(configuration: config)
        oddsQuery = bundleText("odds", "graphql", "queries")
        cardQuery = bundleText("card", "graphql", "queries")
    }

    // MARK: - HTTP

    func post(_ query: String, _ variables: [String: Any], timeout: TimeInterval = 20) async throws -> [String: Any] {
        var request = URLRequest(url: HKJCFeed.endpoint, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("HKJC-Money-Flow-Research/0.6", forHTTPHeaderField: "User-Agent")
        request.setValue("https://bet.hkjc.com", forHTTPHeaderField: "Origin")
        request.setValue("https://bet.hkjc.com/", forHTTPHeaderField: "Referer")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["query": query, "variables": variables])
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw AppError.network(error.localizedDescription)
        }
        if let http = response as? HTTPURLResponse {
            if http.statusCode == 403 || http.statusCode == 451 {
                throw AppError.geoBlocked(http.statusCode)
            }
            if !(200..<300).contains(http.statusCode) {
                throw AppError.http(http.statusCode)
            }
        }
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw AppError.badResponse
        }
        return object
    }

    func graphql(day: String, venue: String, raceNo: Int) async throws -> [[String: Any]] {
        let data = try await post(oddsQuery, [
            "date": day,
            "venueCode": venue,
            "raceNo": raceNo,
            "oddsTypes": HKJCFeed.types,
        ])
        if truthy(data["errors"]) { return [] }
        var pools: [[String: Any]] = []
        for meeting in list(dict(data["data"])["raceMeetings"]) {
            for pool in list(dict(meeting)["pmPools"]) {
                if let p = pool as? [String: Any] { pools.append(p) }
            }
        }
        return pools
    }

    static func pricedNodes(_ pool: [String: Any]) -> [(String, Double)] {
        var rows: [(String, Double)] = []
        for item in list(pool["oddsNodes"]) {
            let node = dict(item)
            let raw = node["oddsValue"]
            if raw == nil || raw is NSNull { continue }
            let text = toStr(raw)
            if text.isEmpty || text == "SCR" { continue }
            guard let price = toDouble(raw), price.isFinite, price > 0 else { continue }
            rows.append((toStr(node["combString"]), price))
        }
        return rows
    }

    private static func raceRow(_ venue: String, _ number: Int, _ sell: String, _ postAt: String) -> RaceInfo {
        let chars = Array(postAt)
        let label: String
        if chars.count >= 16 {
            label = String(chars[11..<16])
        } else {
            label = sell == "STOP_SELL" ? "截止" : "開售"
        }
        return RaceInfo(id: "\(venue)-\(number)", venue: venue, no: number, sell: sell,
                        postTime: label, postAt: postAt, name: "馬會 \(venue) 第\(number)場")
    }

    /// 用賽事卡入面嘅 activeMeetings。同一日沙田、跑馬地、海外都會出現。
    private func meetingsFromCard(day: String) async throws -> [RaceInfo] {
        let data: [String: Any]
        do {
            data = try await post(cardQuery, ["date": day, "venueCode": "ST"], timeout: 25)
        } catch AppError.geoBlocked(let code) {
            throw AppError.geoBlocked(code)
        } catch {
            return []
        }
        if truthy(data["errors"]) { return [] }
        var races: [RaceInfo] = []
        for item in list(dict(data["data"])["activeMeetings"]) {
            let meeting = dict(item)
            let date = toStr(meeting["date"])
            if !date.isEmpty && date != day { continue }
            let venue = toStr(meeting["venueCode"])
            if venue.isEmpty { continue }
            for raceItem in list(meeting["races"]) {
                let race = dict(raceItem)
                guard let number = toInt(race["no"]) else { continue }
                let status = toStr(race["status"])
                let sell = HKJCFeed.closedRace.contains(status) ? "STOP_SELL" : "START_SELL"
                races.append(HKJCFeed.raceRow(venue, number, sell, toStr(race["postTime"])))
            }
        }
        races.sort { ($0.postAt, $0.id) < ($1.postAt, $1.id) }
        return races
    }

    /// activeMeetings 空白時先逐個場地問賠率。同一張卡只留第一個場地。
    private func scanVenues(day: String, venues: [String]) async throws -> [RaceInfo] {
        var races: [RaceInfo] = []
        var seenShapes = Set<String>()
        for venue in venues {
            var found: [RaceInfo] = []
            var shape: [String] = []
            var emptyRun = 0
            for number in 1..<15 {
                let pools = try await graphql(day: day, venue: venue, raceNo: number)
                let win = pools.first { toStr($0["oddsType"]) == "WIN" }
                let odds = win.map { HKJCFeed.pricedNodes($0) } ?? []
                guard let winPool = win, !odds.isEmpty else {
                    emptyRun += 1
                    if emptyRun >= 2 { break }
                    continue
                }
                emptyRun = 0
                shape.append("\(number):\(odds.count)")
                let legRaces = list(dict(winPool["leg"])["races"])
                let first = legRaces.first.flatMap { toInt($0) } ?? number
                let sell = toStr(winPool["sellStatus"]) == "STOP_SELL" ? "STOP_SELL" : "START_SELL"
                found.append(HKJCFeed.raceRow(venue, first, sell, ""))
            }
            let signature = shape.joined(separator: ",")
            if found.isEmpty || seenShapes.contains(signature) { continue }
            seenShapes.insert(signature)
            races.append(contentsOf: found)
        }
        return races
    }

    /// 每日自動列出賽馬會當日全部場次，本地同海外都可以揀。
    func discover(day: String) async throws -> [RaceInfo] {
        let races = try await meetingsFromCard(day: day)
        if !races.isEmpty { return races }
        return try await scanVenues(day: day, venues: HKJCFeed.local + HKJCFeed.overseas)
    }

    /// 20 秒內重用場次清單（同 server.py hkjc_races 一樣）。
    func races(day: String) async throws -> [RaceInfo] {
        if catalog.day == day && Date().timeIntervalSince(catalog.at) < 20 && !catalog.races.isEmpty {
            return catalog.races
        }
        let races = try await discover(day: day)
        if !races.isEmpty {
            catalog = (Date(), day, races)
        }
        return races
    }

    /// 場次號碼 -> {馬號: 中文名}，以及場次號碼 -> 賽事中文名。冇中文名先用英文。
    func cardNames(day: String, venue: String) async -> CardInfo {
        let key = "\(day)|\(venue)"
        if let cached = cardCache[key] {
            let ttl: TimeInterval = (cached.card.names.isEmpty && cached.card.titles.isEmpty) ? 20 : 90
            if Date().timeIntervalSince(cached.at) < ttl { return cached.card }
        }
        var card = CardInfo()
        let data = (try? await post(cardQuery, ["date": day, "venueCode": venue], timeout: 25)) ?? [:]
        if !truthy(data["errors"]) {
            for item in list(dict(data["data"])["raceMeetings"]) {
                let meeting = dict(item)
                let code = toStr(meeting["venueCode"])
                if !code.isEmpty && code != venue { continue }
                for raceItem in list(meeting["races"]) {
                    let race = dict(raceItem)
                    guard let raceNo = toInt(race["no"]) else { continue }
                    var title = toStr(race["raceName_ch"]).trimmingCharacters(in: .whitespacesAndNewlines)
                    if title.isEmpty {
                        title = toStr(race["raceName_en"]).trimmingCharacters(in: .whitespacesAndNewlines)
                    }
                    if !title.isEmpty { card.titles[raceNo] = title }
                    var runners: [Int: String] = [:]
                    for horseItem in list(race["runners"]) {
                        let horse = dict(horseItem)
                        let number = toInt(horse["no"]) ?? 0
                        if number <= 0 { continue }
                        var label = toStr(horse["name_ch"]).trimmingCharacters(in: .whitespacesAndNewlines)
                        if label.isEmpty {
                            label = toStr(horse["name_en"]).trimmingCharacters(in: .whitespacesAndNewlines)
                        }
                        if label.isEmpty { continue }
                        if truthy(horse["standbyNo"]) && runners[number] != nil { continue }
                        runners[number] = label
                    }
                    if !runners.isEmpty { card.names[raceNo] = runners }
                }
            }
        }
        cardCache[key] = (Date(), card)
        return card
    }

    func snapshot(day: String, venue: String, raceNo: Int) async throws -> OddsSnapshot {
        let pools = try await graphql(day: day, venue: venue, raceNo: raceNo)
        var byType: [String: [String: Any]] = [:]
        for pool in pools {
            byType[toStr(pool["oddsType"])] = pool
        }
        let win = byType["WIN"] ?? [:]
        var odds: [Int: Double] = [:]
        for (comb, price) in HKJCFeed.pricedNodes(win) {
            if let number = Int(comb.trimmingCharacters(in: .whitespaces)) {
                odds[number] = price
            }
        }
        var weights: [Int: Double] = [:]
        for (horse, price) in odds { weights[horse] = 1 / price }
        var total = weights.values.reduce(0, +)
        if total == 0 { total = 1 }
        var investment: [Int: Double] = [:]
        for (horse, weight) in weights { investment[horse] = HKJCFeed.notional * weight / total }
        var exotic: [String: [[String: Any]]] = [:]
        for (kind, label) in HKJCFeed.poolLabel {
            guard let pool = byType[kind] else { continue }
            var rows: [[String: Any]] = []
            for (comb, price) in HKJCFeed.pricedNodes(pool) {
                var c = comb
                if kind == "QIN" || kind == "QPL" || kind == "FCT" {
                    c = c.replacingOccurrences(of: ",", with: "-")
                }
                rows.append(["comb": c, "odds": price])
            }
            if !rows.isEmpty { exotic[label] = rows }
        }
        let updated = toStr(win["lastUpdateTime"])
        let moment = parseISODate(updated) ?? Date()
        return OddsSnapshot(recordedAt: moment, odds: odds, investment: investment, exotic: exotic,
                            sell: toStr(win["sellStatus"]))
    }
}
