import Foundation
import UIKit

/// 取代原本 server.py 嘅輪詢同狀態。只讀香港賽馬會，Jev 做決定，唔會落注。
private struct HistoryEntry {
    let frame: Frame
    let signature: [Int: Double]
    let exotic: [String: [[String: Any]]]
}

private struct DecisionView {
    var hot: [[String: Any]] = []
    var value: [[String: Any]] = []
    var hotRaw: [String: Any]? = nil
    var hotError = ""
    var valueRaw: [String: Any]? = nil
    var valueError = ""
}

final class Engine {
    static let shared = Engine()

    static let pollNormal: TimeInterval = 1.0
    static let pollFast: TimeInterval = 0.25
    static let hkjcNote = "Source is the Hong Kong Jockey Club odds feed. "
        + "win_investment is each horse's share of a fixed 1000000 notional pool derived from win odds, "
        + "because this feed does not include pool totals."

    private let lock = NSLock()
    // 以下由 lock 保護
    private var state: [String: Any] = [
        "ok": false, "error": "", "updatedAt": NSNull(), "race": NSNull(),
        "phase": "starting", "horses": [], "history": [], "schedule": [],
    ]
    private var pinned: String? = nil
    private var armed = false
    private var fast = false
    private var scheduleRows: [[String: Any]] = []
    private var pickLog: [[String: Any]] = []
    private var decBusy = false
    private var decReady = false
    private var decFingerprint: String? = nil
    private var decGeneration = 0
    private var decView = DecisionView()

    // 只喺輪詢 Task 入面用（一次一個），唔使鎖
    private let feed = HKJCFeed()
    private var hkjcHistory: [String: [HistoryEntry]] = [:]
    private var loopTask: Task<Void, Never>? = nil

    private func sync<T>(_ body: () -> T) -> T {
        lock.lock()
        defer { lock.unlock() }
        return body()
    }

    // MARK: - Lifecycle

    func start() {
        lock.lock()
        defer { lock.unlock() }
        if loopTask != nil { return }
        loopTask = Task.detached(priority: .userInitiated) { [weak self] in
            await self?.loop()
        }
    }

    private func loop() async {
        while !Task.isCancelled {
            let started = Date()
            do {
                try await pollOnce()
            } catch {
                let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                publish(["ok": false, "error": message, "phase": "error", "horses": [], "selected": NSNull()])
            }
            let isFast: Bool = sync { fast }
            let interval = isFast ? Engine.pollFast : Engine.pollNormal
            let delay = interval - Date().timeIntervalSince(started)
            if delay > 0 {
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            }
        }
    }

    // MARK: - API（畀 WebView 用）

    func toggleArm() -> [String: Any] {
        let on: Bool = sync {
            armed.toggle()
            if !armed {
                decView = DecisionView()
                decFingerprint = nil
                decReady = false
                decGeneration += 1
            }
            return armed
        }
        DispatchQueue.main.async {
            UIApplication.shared.isIdleTimerDisabled = on
        }
        return ["armed": on]
    }

    func toggleFast() -> [String: Any] {
        let on: Bool = sync {
            fast.toggle()
            return fast
        }
        return ["fast": on]
    }

    func statePayload(raceParam: String?) -> [String: Any] {
        return sync { () -> [String: Any] in
            if let raw = raceParam {
                if raw.isEmpty || raw == "auto" {
                    pinned = nil
                } else if raw.contains("-") {
                    pinned = raw
                } else if Int(raw) != nil {
                    pinned = raw
                } else {
                    pinned = nil
                }
            }
            var payload = state
            payload["armed"] = armed
            payload["fast"] = fast
            payload["deciding"] = decBusy
            payload["schedule"] = scheduleRows
            if let pin = pinned {
                let showing = toStr(dict(payload["race"])["no"])
                if let match = scheduleRows.first(where: { toStr($0["no"]) == pin }), showing != pin {
                    let post = toStr(match["postTime"])
                    payload["race"] = [
                        "no": pin,
                        "name": match["name"] ?? "",
                        "postTime": post + ":00",
                        "pinned": true,
                    ] as [String: Any]
                    payload["phase"] = "switching"
                    payload["selected"] = NSNull()
                    payload["valuePicks"] = NSNull()
                    payload["horses"] = []
                    payload["jev"] = NSNull()
                    payload["jevError"] = ""
                    payload["secondsToPost"] = NSNull()
                    payload["note"] = "轉去第 \(pin) 場，官方開跑 \(post)。呢場未計完之前，先顯示佢自己嘅開跑時間。"
                }
            }
            return payload
        }
    }

    // MARK: - Publish

    private func publish(_ input: [String: Any]) {
        var fields = input
        fields["updatedAt"] = hktISO(Date())
        sync { () -> Void in
            fields["history"] = Array(pickLog.suffix(180))
            fields["armed"] = armed
            fields["deciding"] = decBusy
            fields["schedule"] = scheduleRows
            state = fields
        }
    }

    // MARK: - Poll

    private func pollOnce() async throws {
        let moment = Date()
        let day = hktDay(moment)
        let races = try await feed.races(day: day)
        if races.isEmpty {
            publish(["ok": false, "error": "馬會未有今日賽事", "phase": "error", "horses": [], "race": NSNull()])
            return
        }
        let pin = sync { pinned }
        var selectedId = pin
        if selectedId == nil || !races.contains(where: { $0.id == selectedId }) {
            let open = races.filter { $0.sell != "STOP_SELL" }
            selectedId = (open.first ?? races[0]).id
        }
        guard let chosen = races.first(where: { $0.id == selectedId }) else { return }

        var cards: [String: CardInfo] = [:]
        for venue in Set(races.map { $0.venue }) {
            cards[venue] = await feed.cardNames(day: day, venue: venue)
        }

        let snap = try await feed.snapshot(day: day, venue: chosen.venue, raceNo: chosen.no)
        let key = "\(day)|\(chosen.id)"
        var history = hkjcHistory[key] ?? []
        let frozen = snap.sell == "STOP_SELL" && !history.isEmpty
        if !snap.odds.isEmpty && !frozen && (history.isEmpty || history[history.count - 1].signature != snap.odds) {
            history.append(HistoryEntry(
                frame: Frame(time: snap.recordedAt, odds: snap.odds, investment: snap.investment),
                signature: snap.odds,
                exotic: snap.exotic))
            hkjcHistory[key] = history
        }
        let card = cards[chosen.venue] ?? CardInfo()
        var titleName = card.titles[chosen.no] ?? ""
        if titleName.isEmpty { titleName = chosen.name }
        let race: [String: Any] = [
            "no": chosen.id,
            "name": titleName,
            "venue": chosen.venue,
            "distance": "",
            "classCode": "",
            "postTime": chosen.postTime,
            "date": day,
            "available": races.map { $0.id },
            "pinned": pin != nil,
            "source": "香港賽馬會",
        ]
        var rows: [[String: Any]] = []
        for item in races {
            var name = cards[item.venue]?.titles[item.no] ?? ""
            if name.isEmpty { name = item.name }
            rows.append(["no": item.id, "postTime": item.postTime, "name": name])
        }
        sync { scheduleRows = rows }

        let closed = snap.sell == "STOP_SELL"
        guard let first = history.first, let last = history.last else {
            publish([
                "ok": true, "error": "",
                "phase": closed ? "closed" : "waiting",
                "race": race, "secondsToPost": 0,
                "selected": NSNull(), "valuePicks": NSNull(), "horses": [],
                "jev": NSNull(), "jevError": "",
                "bettingClosed": closed,
                "note": closed ? "投注已截止，暫時未有賠率。" : "馬會已開售，等緊第一口賠率。",
            ])
            return
        }
        let base = first.frame
        let latest = last.frame
        let poolBase = first.exotic
        let poolNow = last.exotic
        let field = card.names[chosen.no] ?? [:]
        var names: [Int: String] = [:]
        for number in latest.odds.keys { names[number] = field[number] ?? "" }
        let scored = Engine.scoreHorses(base, latest, names)
        let horses = scored.horses.sorted { (toInt($0["no"]) ?? 0) < (toInt($1["no"]) ?? 0) }
        let path = first.signature != last.signature ? [base, latest] : [latest]
        let fingerprint = [
            chosen.id,
            hktISO(latest.time),
            latest.odds.keys.sorted().map { "\($0):\(latest.odds[$0] ?? 0)" }.joined(separator: ","),
            Engine.poolFingerprint(poolNow),
        ].joined(separator: "|")

        if !sync({ armed }) {
            publish([
                "ok": true, "error": "",
                "phase": closed ? "closed" : "idle",
                "race": race, "secondsToPost": 0,
                "sliceTime": hktClock(latest.time),
                "selected": NSNull(), "valuePicks": NSNull(),
                "horses": horses,
                "jev": NSNull(), "jevError": "",
                "bettingClosed": closed,
                "note": closed ? "投注已截止。未啟動，所以未有推薦。" : "未啟動。撳啟動之後先開始每秒讀取同選擇。",
            ])
            return
        }
        let view = startDecisions(race: race, names: names, base: base, path: path,
                                  poolBase: poolBase, poolNow: poolNow, fingerprint: fingerprint)
        publish([
            "ok": true, "error": "",
            "phase": "live",
            "race": race, "secondsToPost": 0,
            "baselineTime": hktClock(base.time),
            "sliceTime": hktClock(latest.time),
            "sliceAge": roundInt(moment.timeIntervalSince(latest.time)),
            "delta": scored.delta,
            "selected": view.hot,
            "valuePicks": view.value,
            "valueError": view.valueError,
            "horses": horses,
            "jev": view.hotRaw.map { $0 as Any } ?? NSNull(),
            "jevError": view.hotError,
            "bettingClosed": closed,
            "note": closed ? "數據來源係香港賽馬會。投注已截止，啟動緊所以繼續推薦。" : "數據來源係香港賽馬會。已啟動，持續推薦。",
        ])
    }

    // MARK: - Decisions

    /// 同一組賠率只做一輪。兩個模型都返到，先一次過換晒過門檻嘅馬。
    private func startDecisions(race: [String: Any], names: [Int: String], base: Frame, path: [Frame],
                                poolBase: [String: [[String: Any]]], poolNow: [String: [[String: Any]]],
                                fingerprint: String) -> DecisionView {
        lock.lock()
        if !armed {
            lock.unlock()
            return DecisionView()
        }
        if decBusy || (decReady && decFingerprint == fingerprint) {
            let view = decView
            lock.unlock()
            return view
        }
        decBusy = true
        decReady = false
        let generation = decGeneration
        let view = decView
        lock.unlock()

        let note = Engine.hkjcNote
        Task.detached(priority: .userInitiated) { [weak self] in
            let (hotRaw, hotError) = await Jev.ask(race: race, names: names, base: base, path: path,
                                                   poolBase: poolBase, poolNow: poolNow,
                                                   profile: "signal", sourceNote: note)
            let (valueRaw, valueError) = await Jev.ask(race: race, names: names, base: base, path: path,
                                                       poolBase: poolBase, poolNow: poolNow,
                                                       profile: "value", sourceNote: note)
            let hot = Jev.recommendations(hotRaw, names)
            let value = Jev.recommendations(valueRaw, names)
            self?.finishDecision(generation: generation, fingerprint: fingerprint, raceId: toStr(race["no"]),
                                 view: DecisionView(hot: hot, value: value, hotRaw: hotRaw, hotError: hotError,
                                                    valueRaw: valueRaw, valueError: valueError))
        }
        return view
    }

    private func finishDecision(generation: Int, fingerprint: String, raceId: String, view: DecisionView) {
        sync { () -> Void in
            defer { decBusy = false }
            guard generation == decGeneration else { return }
            decView = view
            decFingerprint = fingerprint
            decReady = true
            if view.hot.isEmpty && view.value.isEmpty { return }
            func label(_ picks: [[String: Any]]) -> String {
                guard let top = picks.first else { return "" }
                return "\(toStr(top["no"]))號 \(toStr(top["name"]))".trimmingCharacters(in: .whitespaces)
            }
            let entry: [String: Any] = [
                "t": hktClock(Date()),
                "race": raceId,
                "name": label(view.hot),
                "valueName": label(view.value),
            ]
            if let previous = pickLog.last(where: { toStr($0["race"]) == raceId }),
               toStr(previous["name"]) == toStr(entry["name"]),
               toStr(previous["valueName"]) == toStr(entry["valueName"]) {
                return
            }
            pickLog.append(entry)
            if pickLog.count > 3600 { pickLog.removeFirst(pickLog.count - 3600) }
        }
    }

    // MARK: - Math（同 server.py 一樣）

    static func scoreHorses(_ base: Frame, _ latest: Frame, _ names: [Int: String])
        -> (horses: [[String: Any]], delta: Int) {
        let keys = Set(base.odds.keys)
            .intersection(latest.odds.keys)
            .intersection(base.investment.keys)
            .intersection(latest.investment.keys)
            .sorted()
        let basePool = keys.reduce(0.0) { $0 + (base.investment[$1] ?? 0) }
        let latePool = keys.reduce(0.0) { $0 + (latest.investment[$1] ?? 0) }
        let delta = latePool - basePool
        var scored: [[String: Any]] = []
        for horse in keys {
            let share = basePool != 0 ? (base.investment[horse] ?? 0) / basePool : 0
            let added = (latest.investment[horse] ?? 0) - (base.investment[horse] ?? 0)
            let expected = share * delta
            let lift: Double? = expected > 1 ? added / expected : nil
            scored.append([
                "no": horse,
                "name": names[horse] ?? "",
                "oddsAtStart": round2(base.odds[horse] ?? 0),
                "oddsNow": round2(latest.odds[horse] ?? 0),
                "sharePct": round1(share * 100),
                "added": roundInt(added),
                "lift": lift.map { round2($0) as Any } ?? NSNull(),
            ])
        }
        return (scored, roundInt(delta))
    }

    static func poolFingerprint(_ pools: [String: [[String: Any]]]) -> String {
        pools.keys.sorted().map { label -> String in
            let rows = pools[label] ?? []
            let total = rows.reduce(0.0) { $0 + (toDouble($1["odds"]) ?? 0) }
            return "\(label):\(rows.count):\(round1(total))"
        }.joined(separator: ";")
    }
}
