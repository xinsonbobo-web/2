import Foundation

/// Jev 決策模型（api.typesafe.ai）。對應 server.py 嘅 ask_jev / jev_recommendations。
struct Frame {
    let time: Date
    let odds: [Int: Double]
    let investment: [Int: Double]
}

enum Jev {
    static let url = URL(string: "https://api.typesafe.ai/v1/systemone")!
    static let confidenceMin = 0.20

    private static let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil
        config.timeoutIntervalForRequest = 45
        return URLSession(configuration: config)
    }()

    static func compactSlice(_ frame: Frame) -> [String: Any] {
        var horses: [[String: Any]] = []
        for number in frame.odds.keys.sorted() {
            horses.append([
                "horse": number,
                "win_odds": round2(frame.odds[number] ?? 0),
                "win_investment": roundInt(frame.investment[number] ?? 0),
            ])
        }
        return ["time": hktClock(frame.time), "horses": horses]
    }

    static func slicesForJev(_ base: Frame, _ path: [Frame]) -> [Frame] {
        let frames = [base] + path
        if frames.count <= 12 { return frames }
        return Array(frames.prefix(3)) + Array(frames.suffix(9))
    }

    static func loadDecisionFile(_ profile: String) -> [String: Any] {
        let name = profile == "signal" ? "jev-signal" : "jev-value"
        guard let url = bundleURL(name, "json", "models"),
              let data = try? Data(contentsOf: url),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return object
    }

    static func ask(race: [String: Any], names: [Int: String], base: Frame, path: [Frame],
                    poolBase: [String: Any], poolNow: [String: Any], profile: String,
                    sourceNote: String) async -> ([String: Any]?, String) {
        let key = Keychain.load()
        if key.isEmpty { return (nil, "未設定 TypeSafe API key（撳右上角齒輪設定）") }
        if path.isEmpty { return (nil, "未有開跑後切片可以交畀 Jev") }
        var criteria: [String: Any] = [:]
        for number in base.odds.keys.sorted() {
            var label = "\(number)號"
            if let name = names[number], !name.isEmpty { label += name }
            criteria["horse_\(number)"] = label
        }
        if criteria.count < 2 { return (nil, "開跑後未有足夠馬匹可以交畀 Jev") }
        let spec = loadDecisionFile(profile)
        let template = dict(spec["request"])
        if template.isEmpty { return (nil, "模型檔讀唔到（\(profile)）") }
        let templateState = dict(template["state"])
        var questions = dict(template["questions"])
        var strongest = dict(questions["strongest_candidate"])
        strongest["criteria"] = criteria
        questions["strongest_candidate"] = strongest
        var state: [String: Any] = [
            "purpose": templateState["purpose"] ?? "",
            "race_no": race["no"] ?? NSNull(),
            "race_name": race["name"] ?? "",
            "official_post_time": race["postTime"] ?? NSNull(),
            "pools_included": templateState["pools_included"] ?? [],
            "baseline": compactSlice(base),
            "snapshots_after_post": slicesForJev(base, path).dropFirst().map { compactSlice($0) },
            "pool_baseline": poolBase,
            "pool_latest": poolNow,
        ]
        if !sourceNote.isEmpty { state["win_investment_note"] = sourceNote }
        let payload: [String: Any] = [
            "model": template["model"] ?? "jev-latest",
            "state": state,
            "questions": questions,
        ]
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 45)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            return (nil, "Jev 請求整唔到：\(error.localizedDescription)")
        }
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            return (nil, "Jev 連線失敗 \(error.localizedDescription)")
        }
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            let detail = String(String(decoding: data, as: UTF8.self).prefix(240))
            if http.statusCode == 401 || http.statusCode == 403 {
                return (nil, "Jev HTTP \(http.statusCode)：API key 無效或者冇權限，請去設定更新。\(detail)")
            }
            return (nil, "Jev HTTP \(http.statusCode) \(detail)")
        }
        guard let parsed = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return (nil, "Jev 回覆唔係 JSON")
        }
        let answers = dict(parsed["answers"])
        let noul = dict(answers["meaningful_hot_money"])["noul"]
        let score = dict(answers["overall_signal_strength"])
        let choice = dict(answers["strongest_candidate"])
        let choiceId = toStr(choice["choice"])
        var number: Int? = nil
        if choiceId.hasPrefix("horse_") {
            number = Int(choiceId.dropFirst("horse_".count))
        }
        let name = number.flatMap { names[$0] } ?? ""
        let probabilities = dict(choice["probabilities"])
        return ([
            "model": parsed["model"] ?? NSNull(),
            "noul": noul ?? NSNull(),
            "score": score["score"] ?? NSNull(),
            "scoreConfidence": score["confidence"] ?? NSNull(),
            "choice": choiceId,
            "choiceConfidence": choice["confidence"] ?? NSNull(),
            "probabilities": probabilities,
            "no": number.map { $0 as Any } ?? NSNull(),
            "name": name,
        ], "")
    }

    static func recommendations(_ decision: [String: Any]?, _ names: [Int: String]) -> [[String: Any]] {
        guard let decision = decision else { return [] }
        var candidates: [(no: Int, name: String, confidence: Double)] = []
        for (key, probability) in dict(decision["probabilities"]) {
            guard key.hasPrefix("horse_"), let number = Int(key.dropFirst("horse_".count)) else { continue }
            candidates.append((number, names[number] ?? "", round2(toDouble(probability) ?? 0)))
        }
        if candidates.isEmpty, let number = toInt(decision["no"]), number != 0 {
            var name = toStr(decision["name"])
            if name.isEmpty { name = names[number] ?? "" }
            candidates.append((number, name, round2(toDouble(decision["choiceConfidence"]) ?? 0)))
        }
        let picked = candidates
            .filter { $0.confidence >= confidenceMin }
            .sorted { ($0.confidence, -$0.no) > ($1.confidence, -$1.no) }
        return picked.map { ["no": $0.no, "name": $0.name, "confidence": $0.confidence] as [String: Any] }
    }
}
