import Foundation

/// Jev 決策模型（api.typesafe.ai）。對應 server.py 嘅 ask_jev / jev_recommendations。
struct Frame {
    let time: Date
    let odds: [Int: Double]
    let investment: [Int: Double]
}

enum Jev {
    static let url = URL(string: "https://api.typesafe.ai/v1/systemone")!
    static let confidenceMin = 0.20

    private static let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil
        config.timeoutIntervalForRequest = 45
        return URLSession(configuration: config)
    }()

    static func compactSlice(_ frame: Frame) -> [String: Any] {
        var horses: [[String: Any]] = []
        for number in frame.odds.keys.sorted() {
            horses.append([
                "horse": number,
                "win_odds": round2(frame.odds[number] ?? 0),
                "win_investment": roundInt(frame.investment[number] ?? 0),
            ])
        }
        return ["time": hktClock(frame.time), "horses": horses]
    }

    static func slicesForJev(_ base: Frame, _ path: [Frame]) -> [Frame] {
        let frames = [base] + path
        if frames.count <= 12 { return frames }
        return Array(frames.prefix(3)) + Array(frames.suffix(9))
    }

    static func loadDecisionFile(_ profile: String) -> [String: Any] {
        let name = profile == "signal" ? "jev-signal" : "jev-value"
        guard let url = bundleURL(name, "json", "models"),
              let data = try? Data(contentsOf: url),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return object
    }

    static func ask(race: [String: Any], names: [Int: String], base: Frame, path: [Frame],
                    poolBase: [String: Any], poolNow: [String: Any], profile: String,
                    sourceNote: String) async -> ([String: Any]?, String) {
        if !Keychain.hasKey { return (nil, "未設定 TypeSafe API key（撳右上角齒輪設定）") }
        if path.isEmpty { return (nil, "未有開跑後切片可以交畀 Jev") }
        var criteria: [String: Any] = [:]
        for number in base.odds.keys.sorted() {
            var label = "\(number)號"
            if let name = names[number], !name.isEmpty { label += name }
            criteria["horse_\(number)"] = label
        }
        if criteria.count < 2 { return (nil, "開跑後未有足夠馬匹可以交畀 Jev") }
        let spec = loadDecisionFile(profile)
        let template = dict(spec["request"])
        if template.isEmpty { return (nil, "模型檔讀唔到（\(profile)）") }
        let templateState = dict(template["state"])
        var questions = dict(template["questions"])
        var strongest = dict(questions["strongest_candidate"])
        strongest["criteria"] = criteria
        questions["strongest_candidate"] = strongest
        var state: [String: Any] = [
            "purpose": templateState["purpose"] ?? "",
            "race_no": race["no"] ?? NSNull(),
            "race_name": race["name"] ?? "",
            "official_post_time": race["postTime"] ?? NSNull(),
            "pools_included": templateState["pools_included"] ?? [],
            "baseline": compactSlice(base),
            "snapshots_after_post": slicesForJev(base, path).dropFirst().map { compactSlice($0) },
            "pool_baseline": poolBase,
            "pool_latest": poolNow,
        ]
        if !sourceNote.isEmpty { state["win_investment_note"] = sourceNote }
        let payload: [String: Any] = [
            "model": template["model"] ?? "jev-latest",
            "state": state,
            "questions": questions,
        ]
        let body: Data
        do {
            body = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            return (nil, "Jev 請求整唔到：\(error.localizedDescription)")
        }
        let (data, error) = await post(body: body)
        if !error.isEmpty { return (nil, error) }
        guard let data = data else { return (nil, "全部 API key 都接唔到") }
        guard let parsed = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return (nil, "Jev 回覆唔係 JSON")
        }
        let answers = dict(parsed["answers"])
        let noul = dict(answers["meaningful_hot_money"])["noul"]
        let score = dict(answers["overall_signal_strength"])
        let choice = dict(answers["strongest_candidate"])
        let choiceId = toStr(choice["choice"])
        var number: Int? = nil
        if choiceId.hasPrefix("horse_") {
            number = Int(choiceId.dropFirst("horse_".count))
        }
        let name = number.flatMap { names[$0] } ?? ""
        let probabilities = dict(choice["probabilities"])
        return ([
            "model": parsed["model"] ?? NSNull(),
            "noul": noul ?? NSNull(),
            "score": score["score"] ?? NSNull(),
            "scoreConfidence": score["confidence"] ?? NSNull(),
            "choice": choiceId,
            "choiceConfidence": choice["confidence"] ?? NSNull(),
            "probabilities": probabilities,
            "no": number.map { $0 as Any } ?? NSNull(),
            "name": name,
        ], "")
    }

    /// server.py KEY_RETRY_HTTP。呢啲先會換下一條；唔喺呢度嘅 HTTP（payload 問題）唔換 key。
    static let keyRetryHTTP: Set<Int> = [401, 402, 403, 408, 429, 500, 502, 503, 504]
    /// server.py KEY_DEAD_HTTP。剔走，之後唔再試。
    static let keyDeadHTTP: Set<Int> = [401, 403]
    /// 放進 binary，方便對照桌面版規則。唔會顯示 key。
    static let ruleMarker = "KEY_RETRY_HTTP=401,402,403,408,429,500,502,503,504 KEY_DEAD_HTTP=401,403 network_failures>=2 same-payload"

    private static let callLock = AsyncLock()

    /// 一次決策：同一份 body，接唔到就換下一條。對應 server.py post_jev。
    static func post(body: Data) async -> (Data?, String) {
        _ = ruleMarker
        await callLock.lock()
        let result = await postLocked(body: body)
        await callLock.unlock()
        return result
    }

    private static func postLocked(body: Data) async -> (Data?, String) {
        let snap = Keychain.snapshot()
        let pool = snap.pool
        if pool.isEmpty { return (nil, "未設定 TypeSafe API key（撳右上角齒輪設定）") }
        var index = snap.index % pool.count
        var dead = snap.dead
        var lastError = "全部 API key 都接唔到"
        var networkFailures = 0
        var tried = 0
        while tried < pool.count {
            let key = pool[index]
            let fp = Keychain.fingerprint(key)
            if dead.contains(fp) {
                index = (index + 1) % pool.count
                tried += 1
                continue
            }
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 45)
            request.httpMethod = "POST"
            request.httpBody = body
            request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            do {
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else {
                    networkFailures += 1
                    lastError = "Jev 連線失敗 冇 HTTP 回覆"
                    index = (index + 1) % pool.count
                    Keychain.storeState(index: index, dead: dead)
                    tried += 1
                    if networkFailures >= 2 { return (nil, publicJevError(lastError)) }
                    continue
                }
                if (200..<300).contains(http.statusCode) {
                    Keychain.storeState(index: index, dead: dead)
                    return (data, "")
                }
                let detail = publicJevError(String(decoding: data, as: UTF8.self))
                lastError = "Jev HTTP \(http.statusCode) \(detail)".trimmingCharacters(in: .whitespaces)
                if !keyRetryHTTP.contains(http.statusCode) {
                    Keychain.storeState(index: index, dead: dead)
                    return (nil, lastError)
                }
                if keyDeadHTTP.contains(http.statusCode) {
                    dead.insert(fp)
                }
                index = (index + 1) % pool.count
                Keychain.storeState(index: index, dead: dead)
                tried += 1
                continue
            } catch {
                networkFailures += 1
                lastError = "Jev 連線失敗 \(error.localizedDescription)"
                index = (index + 1) % pool.count
                Keychain.storeState(index: index, dead: dead)
                tried += 1
                if networkFailures >= 2 { return (nil, publicJevError(lastError)) }
                continue
            }
        }
        Keychain.storeState(index: index, dead: dead)
        return (nil, publicJevError(lastError))
    }

    /// 對應 server.py public_jev_error：唔好把 key 帶去畫面上。
    private static func publicJevError(_ text: String) -> String {
        let kept = text.split(whereSeparator: { $0.isWhitespace }).filter { token in
            let s = String(token)
            return !s.contains("apikey_") && !s.hasPrefix("sk-")
        }
        return String(kept.joined(separator: " ").prefix(240))
    }

    static func recommendations(_ decision: [String: Any]?, _ names: [Int: String]) -> [[String: Any]] {
        guard let decision = decision else { return [] }
        var candidates: [(no: Int, name: String, confidence: Double)] = []
        for (key, probability) in dict(decision["probabilities"]) {
            guard key.hasPrefix("horse_"), let number = Int(key.dropFirst("horse_".count)) else { continue }
            candidates.append((number, names[number] ?? "", round2(toDouble(probability) ?? 0)))
        }
        if candidates.isEmpty, let number = toInt(decision["no"]), number != 0 {
            var name = toStr(decision["name"])
            if name.isEmpty { name = names[number] ?? "" }
            candidates.append((number, name, round2(toDouble(decision["choiceConfidence"]) ?? 0)))
        }
        let picked = candidates
            .filter { $0.confidence >= confidenceMin }
            .sorted { ($0.confidence, -$0.no) > ($1.confidence, -$1.no) }
        return picked.map { ["no": $0.no, "name": $0.name, "confidence": $0.confidence] as [String: Any] }
    }
}

/// 同 server.py key_lock：同一時間只轉一個 key 池。
private actor AsyncLock {
    private var busy = false
    private var waiters: [CheckedContinuation<Void, Never>] = []

    func lock() async {
        if !busy {
            busy = true
            return
        }
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            waiters.append(cont)
        }
    }

    func unlock() {
        if waiters.isEmpty {
            busy = false
        } else {
            waiters.removeFirst().resume()
        }
    }
}
