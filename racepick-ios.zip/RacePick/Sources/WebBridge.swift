import Foundation
import WebKit

/// 用 racepick://localhost/ 服務原本嘅 HTML 同 /api/state、/api/arm、/api/fast。
/// 取代原本 Python HTTP server，網頁 JS 完全唔使改 fetch 路徑。
final class APISchemeHandler: NSObject, WKURLSchemeHandler {
    static let scheme = "racepick"
    static let startURL = URL(string: "racepick://localhost/")!

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        let method = (urlSchemeTask.request.httpMethod ?? "GET").uppercased()
        let path = url.path.isEmpty ? "/" : url.path
        var status = 200
        var mime = "application/json"
        var body = Data()

        switch (method, path) {
        case (_, "/"), (_, "/index.html"), (_, "/jev"), (_, "/value"):
            mime = "text/html"
            body = Data(bundleText("index", "html", nil).utf8)
        case (_, "/api/state"):
            let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            let race = components?.queryItems?.first(where: { $0.name == "race" }).map { $0.value ?? "" }
            body = APISchemeHandler.json(Engine.shared.statePayload(raceParam: race))
        case ("POST", "/api/arm"):
            body = APISchemeHandler.json(Engine.shared.toggleArm())
        case ("POST", "/api/fast"):
            body = APISchemeHandler.json(Engine.shared.toggleFast())
        default:
            status = 404
            mime = "text/plain"
            body = Data("not found".utf8)
        }

        let headers = [
            "Content-Type": "\(mime); charset=utf-8",
            "Cache-Control": "no-store",
            "Content-Length": "\(body.count)",
            "Access-Control-Allow-Origin": "*",
        ]
        guard let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) else {
            urlSchemeTask.didFailWithError(URLError(.cannotParseResponse))
            return
        }
        urlSchemeTask.didReceive(response)
        urlSchemeTask.didReceive(body)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        // 所有回覆都係即時同步完成，冇嘢要取消。
    }

    static func json(_ object: [String: Any]) -> Data {
        if JSONSerialization.isValidJSONObject(object),
           let data = try? JSONSerialization.data(withJSONObject: object) {
            return data
        }
        return Data("{\"ok\":false,\"error\":\"內部資料格式錯誤\",\"phase\":\"error\"}".utf8)
    }
}
