import Foundation
import WebKit

/// 用 moneyflow://localhost/ 由 app bundle 入面嘅 Web/ 資料夾提供網頁（單一 index.html，JS/CSS 已內嵌）。
/// 用自訂 scheme 而唔用 file://，網頁先有穩定嘅 origin（localStorage 等正常運作）。
final class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    static let scheme = "moneyflow"
    static let startURL = URL(string: "moneyflow://localhost/index.html")!

    private let webRoot: URL? = Bundle.main.url(forResource: "Web", withExtension: nil)

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        let parts = path.split(separator: "/").map(String.init)
        var status = 200
        var mime = "text/plain"
        var body = Data("not found".utf8)

        if let root = webRoot, !parts.contains(".."), !parts.isEmpty {
            let fileURL = parts.reduce(root) { $0.appendingPathComponent($1) }
            if let data = try? Data(contentsOf: fileURL) {
                body = data
                mime = LocalSchemeHandler.mimeType(for: fileURL.pathExtension)
            } else {
                status = 404
            }
        } else {
            status = 404
        }

        let headers = [
            "Content-Type": mime.hasPrefix("text/") || mime.contains("javascript") || mime.contains("json")
                ? "\(mime); charset=utf-8" : mime,
            "Content-Length": "\(body.count)",
            "Cache-Control": "no-store",
        ]
        guard let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1",
                                             headerFields: headers) else {
            urlSchemeTask.didFailWithError(URLError(.cannotParseResponse))
            return
        }
        urlSchemeTask.didReceive(response)
        urlSchemeTask.didReceive(body)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        // 全部同步完成，冇嘢要取消。
    }

    static func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html"
        case "js", "mjs": return "text/javascript"
        case "css": return "text/css"
        case "json": return "application/json"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        default: return "application/octet-stream"
        }
    }
}
