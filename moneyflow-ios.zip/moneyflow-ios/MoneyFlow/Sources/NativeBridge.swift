import Foundation
import UIKit
import WebKit

/// 網頁（src/backend/native.ts）透過 window.webkit.messageHandlers.native.postMessage(msg) 呼叫：
///   {op:"http", url, method, headers, body, timeout}  → {status, body, setCookies:[...]} 或 {status:0, body:"", error}
///   {op:"file", action:"read"|"write"|"append"|"delete"|"list", path, data}
///        read → {data: String|null}；list → {names:[...]}；其他 → {ok:true}
///   {op:"share", name, data}  → 用分享表儲存 / AirDrop 匯出 JSON
///   {op:"info"}               → {platform, version, dataDir}
/// HTTP 由 URLSession 發出，所以唔受 WKWebView 嘅 CORS 限制（馬會 GraphQL 冇 CORS header）。
final class NativeBridge: NSObject, WKScriptMessageHandlerWithReply {
    static let name = "native"
    weak var webView: WKWebView?

    private let io = NativeIO()

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        let reply: (Any?, String?) -> Void = { value, error in
            if Thread.isMainThread {
                replyHandler(value, error)
            } else {
                DispatchQueue.main.async { replyHandler(value, error) }
            }
        }
        guard let msg = message.body as? [String: Any], let op = msg["op"] as? String else {
            reply(nil, "bad native message")
            return
        }
        let io = self.io
        switch op {
        case "http":
            io.http(msg) { result in reply(result, nil) }
        case "file":
            io.fileQueue.async {
                do {
                    reply(try io.file(msg), nil)
                } catch {
                    reply(nil, "file: \(error.localizedDescription)")
                }
            }
        case "share":
            share(msg, reply: reply)
        case "info":
            let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
            reply(["platform": "ios", "version": version, "dataDir": io.dataRoot.path], nil)
        default:
            reply(nil, "unknown op \(op)")
        }
    }

    // MARK: - Share (匯出 replay / raw JSON)

    private func share(_ msg: [String: Any], reply: @escaping (Any?, String?) -> Void) {
        let rawName = (msg["name"] as? String) ?? "moneyflow.json"
        let safeName = rawName.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "..", with: "_")
        let text = (msg["data"] as? String) ?? ""
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName.isEmpty ? "moneyflow.json" : safeName)
        do {
            try Data(text.utf8).write(to: url, options: .atomic)
        } catch {
            reply(nil, "share: \(error.localizedDescription)")
            return
        }
        // WebKit 喺主線程送訊息嚟，所以呢度直接做 UI。
        guard let top = NativeBridge.topViewController() else {
            reply(nil, "share: no view controller")
            return
        }
        let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let pop = sheet.popoverPresentationController {
            let anchor: UIView = webView ?? top.view
            pop.sourceView = anchor
            pop.sourceRect = CGRect(x: anchor.bounds.midX, y: anchor.bounds.midY, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        top.present(sheet, animated: true)
        reply(["ok": true], nil)
    }

    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let window = scenes.flatMap { $0.windows }.first { $0.isKeyWindow } ?? scenes.first?.windows.first
        var top = window?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}

/// 背景線程做嘅 HTTP 同檔案工作（普通 class，唔掛任何 WebKit protocol，所以唔會被推斷成 MainActor）。
final class NativeIO {
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        // Cookie 由網頁自己管理（同 Python 版一樣：warm-up 攞 cookie，之後手動放入 Cookie header）。
        c.httpShouldSetCookies = false
        c.httpCookieAcceptPolicy = .never
        c.httpCookieStorage = nil
        c.urlCache = nil
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.timeoutIntervalForRequest = 30
        c.timeoutIntervalForResource = 60
        c.waitsForConnectivity = false
        c.httpMaximumConnectionsPerHost = 6
        return URLSession(configuration: c)
    }()

    let fileQueue = DispatchQueue(label: "com.racepick.moneyflow.files")

    /// 資料放喺 Application Support/MoneyFlow（唔會出現喺「檔案」app，刪 app 就清走）。
    let dataRoot: URL = {
        let fm = FileManager.default
        let base = (try? fm.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                appropriateFor: nil, create: true))
            ?? fm.temporaryDirectory
        let root = base.appendingPathComponent("MoneyFlow", isDirectory: true)
        try? fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }()

    // MARK: - HTTP

    private static let blockedHeaders: Set<String> = ["accept-encoding", "connection", "content-length", "host"]

    func http(_ msg: [String: Any], completion: @escaping ([String: Any]) -> Void) {
        guard let urlString = msg["url"] as? String, let url = URL(string: urlString),
              let scheme = url.scheme?.lowercased(), scheme == "https" || scheme == "http" else {
            completion(["status": 0, "body": "", "error": "bad url"])
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = ((msg["method"] as? String) ?? "GET").uppercased()
        let timeout = (msg["timeout"] as? NSNumber)?.doubleValue ?? 12
        request.timeoutInterval = max(1, min(timeout, 60))
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.httpShouldHandleCookies = false
        if let headers = msg["headers"] as? [String: Any] {
            for (key, value) in headers {
                if NativeIO.blockedHeaders.contains(key.lowercased()) { continue }
                if let text = value as? String {
                    request.setValue(text, forHTTPHeaderField: key)
                } else if let number = value as? NSNumber {
                    request.setValue(number.stringValue, forHTTPHeaderField: key)
                }
            }
        }
        if let body = msg["body"] as? String, request.httpMethod != "GET" {
            request.httpBody = Data(body.utf8)
        }

        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                let nsError = error as NSError
                let text = nsError.code == NSURLErrorTimedOut ? "timed out" : error.localizedDescription
                completion(["status": 0, "body": "", "error": text])
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(["status": 0, "body": "", "error": "no HTTP response"])
                return
            }
            let text = String(decoding: data ?? Data(), as: UTF8.self)
            var fields: [String: String] = [:]
            for (key, value) in http.allHeaderFields {
                if let k = key as? String, let v = value as? String { fields[k] = v }
            }
            let cookies = HTTPCookie.cookies(withResponseHeaderFields: fields, for: http.url ?? url)
            let setCookies = cookies.map { "\($0.name)=\($0.value)" }
            completion(["status": http.statusCode, "body": text, "setCookies": setCookies])
        }
        task.resume()
    }

    // MARK: - Files

    private enum FileError: LocalizedError {
        case badPath, badAction
        var errorDescription: String? {
            switch self {
            case .badPath: return "bad path"
            case .badAction: return "bad action"
            }
        }
    }

    /// 只容許 dataRoot 之下嘅相對路徑（唔准 ".."、絕對路徑）。
    private func resolve(_ raw: String?) throws -> URL {
        let parts = (raw ?? "").split(separator: "/").map(String.init).filter { !$0.isEmpty && $0 != "." }
        if parts.isEmpty || parts.contains("..") || parts.contains(where: { $0.contains("\0") }) {
            throw FileError.badPath
        }
        return parts.reduce(dataRoot) { $0.appendingPathComponent($1) }
    }

    func file(_ msg: [String: Any]) throws -> [String: Any] {
        let fm = FileManager.default
        let action = msg["action"] as? String ?? ""
        let url = try resolve(msg["path"] as? String)
        let data = Data(((msg["data"] as? String) ?? "").utf8)
        switch action {
        case "read":
            guard let content = try? Data(contentsOf: url) else { return ["data": NSNull()] }
            return ["data": String(decoding: content, as: UTF8.self)]
        case "write":
            try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try data.write(to: url, options: .atomic)
            return ["ok": true]
        case "append":
            try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            if fm.fileExists(atPath: url.path) {
                let handle = try FileHandle(forWritingTo: url)
                defer { try? handle.close() }
                _ = try handle.seekToEnd()
                try handle.write(contentsOf: data)
            } else {
                try data.write(to: url, options: .atomic)
            }
            return ["ok": true]
        case "delete":
            if fm.fileExists(atPath: url.path) { try fm.removeItem(at: url) }
            return ["ok": true]
        case "list":
            let names = (try? fm.contentsOfDirectory(atPath: url.path)) ?? []
            return ["names": names.sorted()]
        default:
            throw FileError.badAction
        }
    }
}
