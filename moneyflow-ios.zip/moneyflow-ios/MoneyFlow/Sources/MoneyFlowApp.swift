import SwiftUI
import UIKit
import WebKit

@main
struct MoneyFlowApp: App {
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
        .onChange(of: scenePhase) { phase in
            // 睇緊賽事時唔好自動鎖機；去咗背景就還原。
            UIApplication.shared.isIdleTimerDisabled = (phase == .active)
        }
    }
}

/// 同網頁底色一致（#0a100c），避免載入時白閃。
let pageBackgroundUIColor = UIColor(red: 0x0a / 255.0, green: 0x10 / 255.0, blue: 0x0c / 255.0, alpha: 1)

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(uiColor: pageBackgroundUIColor).ignoresSafeArea()
            // 網頁自己用 env(safe-area-inset-*) 處理瀏海同 Home bar。
            MoneyFlowWebView()
                .ignoresSafeArea()
        }
    }
}

struct MoneyFlowWebView: UIViewRepresentable {
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let scheme = LocalSchemeHandler()
        let bridge = NativeBridge()

        // 網頁程序俾 iOS 殺咗（例如喺背景太耐）就重新載入。
        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            webView.load(URLRequest(url: LocalSchemeHandler.startURL))
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            let scheme = url.scheme?.lowercased() ?? ""
            if scheme == LocalSchemeHandler.scheme || scheme == "about" || scheme == "blob" || scheme == "data" {
                decisionHandler(.allow)
                return
            }
            // 外部連結（例如馬會網站）交俾 Safari 開。
            if scheme == "http" || scheme == "https" {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
        }

        // target=_blank 之類嘅新視窗：外部網址用 Safari，本地就喺原視窗開。
        func webView(_ webView: WKWebView,
                     createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction,
                     windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                let scheme = url.scheme?.lowercased() ?? ""
                if scheme == "http" || scheme == "https" {
                    UIApplication.shared.open(url)
                }
            }
            return nil
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default) { _ in completionHandler() })
            guard let top = NativeBridge.topViewController() else { completionHandler(); return }
            top.present(alert, animated: true)
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "確定", style: .default) { _ in completionHandler(true) })
            guard let top = NativeBridge.topViewController() else { completionHandler(false); return }
            top.present(alert, animated: true)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: LocalSchemeHandler.scheme)
        // window.webkit.messageHandlers.native.postMessage({...}) → Promise（HTTP / 檔案 / 分享）
        config.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                             contentWorld: .page,
                                                             name: NativeBridge.name)
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        let web = WKWebView(frame: .zero, configuration: config)
        context.coordinator.bridge.webView = web
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = pageBackgroundUIColor
        web.scrollView.backgroundColor = pageBackgroundUIColor
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.bounces = false
        web.allowsBackForwardNavigationGestures = false
        web.allowsLinkPreview = false
        if #available(iOS 16.4, *) {
            // 方便用 Mac Safari「開發」選單除錯（免費 Apple ID 側載都用得）。
            web.isInspectable = true
        }
        web.load(URLRequest(url: LocalSchemeHandler.startURL))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
