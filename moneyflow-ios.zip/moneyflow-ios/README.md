# 資金流（HKJC Money Flow Tool v0.7.4）iPhone 版

原本 `HKJC Money Flow Tool`（v0.7.4；React 前端 + Python `backend/server.py`）嘅 iPhone 版本。

- 畫面：原本嘅 React 介面（`app/page.tsx` + `components/money-flow/*`，Mini 係 `components/mini/*`），連 IBM Plex 字型一齊打包成單一 `index.html` 放入 app（唔使上網載字型）。
- 後台：原本 Python 後台（`sources.py`／`engine.py`／`storage.py`／`server.py`／`postgate.py`）逐條公式移植去 TypeScript，喺 app 入面嘅網頁直接運行。前端照舊 call `/api/...`，只係唔再經網絡，直接喺頁面入面處理。
- 讀馬會：經 Swift（URLSession）發出 HTTP，所以唔會撞到瀏覽器 CORS 限制。
- 記錄：快照／標記／設定存喺 iPhone 本機（app 入面嘅 Application Support/MoneyFlow），重開 app 仍然保留。
- **只讀，唔會落注。**

> ⚠️ 馬會資料只接受香港網絡。請喺香港使用並**關閉 VPN**，否則會顯示連線錯誤／HTTP 403。

---

## 1. 下載 IPA

**https://github.com/xinsonbobo-web/2/releases/download/moneyflow/MoneyFlow.ipa**

或者去 [Releases → moneyflow](https://github.com/xinsonbobo-web/2/releases/tag/moneyflow) 下載 `MoneyFlow.ipa`。
（同 RacePick 分開：RacePick 喺 `latest`，資金流喺 `moneyflow`。）

## 2. 用 Sideloadly 喺 Mac 安裝

1. 安裝 [Sideloadly](https://sideloadly.io/)（Mac 版）。USB 接駁 iPhone，iPhone 撳「信任此電腦」。
2. 打開 Sideloadly：
   - **IPA**：拖 `MoneyFlow.ipa` 入去
   - **Apple ID**：你自己嘅 Apple ID（免費帳戶都得）
   - 撳 **Advanced options**，**Signing Mode 一定要揀「Apple ID Sideload」**
     （**唔好**揀 “Normal install / No-resign”。No-resign 會直接裝未用你 Apple ID 簽過嘅 IPA，
     去到 40%（VerifyingApplication）就會出 `0xe8008014 The executable contains an invalid signature`。）
   - 撳 **Start**，輸入 Apple ID 密碼／驗證碼
3. 顯示 **Done** 就裝好。Log 入面應該見到 “Signing with your Apple ID”，唔應該見到 “No-resign mode”。

## 3. iPhone 設定（第一次）

1. **開發者模式**（iOS 16+）：設定 → 私隱與安全性 → 開發者模式 → 開啟 → 重新開機 → 確認開啟。
2. **信任開發者**：設定 → 一般 → VPN 與裝置管理 → 你嘅 Apple ID → 信任。
3. 返主畫面打開 **資金流**。

## 4. 使用須知

- 用法同原本網頁版一樣：揀日期／場地／場次，撳「連接 LIVE」開始收集，熱錢圖／WQQP% 頻譜／表格會自動更新（每 1 秒讀一次馬會，畫面每 1 秒檢查一次；資料冇變就唔會重畫，同電腦版 ETag／304 一樣）。
- v0.7.4 改動（同電腦版一樣）：表格收窄，拎走「結構／熱錢強度／位置」欄；孖寶冠／亞／全 移到獨贏隔籬，孖上%／孖下% 放最右；
  007 試算預設開啟；熱錢條多咗 **入閘後**（紫紅色）分段——以入閘前最後一張快照做基準，只係分開顯示，數值唔變；LIVE 滾動窗預設 15 秒。
- **只會喺 app 開住（前景）時收集。** 轉去其他 app 或者鎖機，iOS 會暫停網頁，返嚟會自動繼續（中間嗰段冇快照）。
  開住 app 時螢幕唔會自動熄。
- 匯出 replay（頂部 ⤓ 按鈕）／原始資料（「公式與設定」入面嘅 Raw source）會彈出 iOS 分享表，可以「儲存到檔案」或 AirDrop。
- 「匯入 replay」同原本一樣用 JSON 檔。
- 直向（portrait）可用：表格同熱錢圖上下排；打橫會用接近桌面版嘅排版。
- **Mini 版**：右下角「主頁｜Mini」掣隨時切換。Mini 只顯示 馬、獨贏、獨贏前、孖寶冠／亞／全（按獨贏低→高排，每 3 秒更新）；
  獨贏前＝開跑前 15 分鐘凍結嘅獨贏（同主頁「排序基準（開跑前分鐘）」；主頁設定入面「Mini 版（手機）」會帶住你設定嘅分鐘數）。
  App 會記住你上次用開邊個版面，下次打開直接去返嗰度。Mini 同主頁共用同一個收集目標（喺 Mini 揀場次＝喺主頁揀場次）。
- 記錄保留最近 60 場（同原本一樣）；刪除 app 會清走所有記錄。

## 5. 每 7 日重新簽名

免費 Apple ID 簽嘅 app **7 日後失效**。用 Sideloadly 再裝一次同一個 `MoneyFlow.ipa` 就得（用同一個 Apple ID，記錄通常會保留）。
免費 Apple ID 同一時間最多 3 個自簽 app（RacePick + 資金流 = 2 個）。

---

## 開發者資料

```
moneyflow-ios/
├─ project.yml                       XcodeGen 設定（com.racepick.moneyflow，iOS 16+）
├─ MoneyFlow/Sources/
│   ├─ MoneyFlowApp.swift            SwiftUI + WKWebView
│   ├─ LocalSchemeHandler.swift      moneyflow://localhost/ → app bundle 入面嘅 Web/
│   └─ NativeBridge.swift            window.webkit.messageHandlers.native：http / file / share / info
├─ MoneyFlow/Web/index.html          已 build 好嘅前端（JS/CSS 全部內嵌）
├─ MoneyFlow/Assets.xcassets/        App icon（AppIcon.png 已生成；ci/make_icon.py 可重畫）
└─ web-src/                          前端 + TypeScript 後台原始碼（vite）
    ├─ src/main.tsx                  主頁（#/）⇄ Mini（#/mini?base=N）切換，記住上次版面
    ├─ src/components/money-flow/    主頁（原本 components/money-flow，api.ts 改為 call 頁內後台）
    ├─ src/components/mini/          Mini 頁（原本 components/mini，use-mini.ts 同上）
    ├─ src/app/*.css, src/ios.css    原本樣式 + iPhone 補丁（safe-area、底部留位、手機圖表固定高度）
    ├─ src/assets/fonts/             IBM Plex woff2（OFL），build 時內嵌
    └─ src/backend/                  py.ts research.ts engine.ts sources.ts flow007.ts storage.ts postgate.ts service.ts mini.ts client.ts native.ts
```

重新 build 前端（要 Node 20+）：

```
cd web-src && npm ci && npx vite build && cp dist/index.html ../MoneyFlow/Web/index.html
```

喺電腦瀏覽器測試（Node 代替 Swift bridge）：`node devserver.mjs` → http://127.0.0.1:8795/

CI（`.github/workflows/build-moneyflow-ipa.yml`）：XcodeGen → xcodebuild（唔簽名）→ ad-hoc 簽名（`codesign -s -`）→ `MoneyFlow.ipa` → Release `moneyflow`。
