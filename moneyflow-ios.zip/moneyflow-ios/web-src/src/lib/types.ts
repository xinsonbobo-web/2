export type Metric={value:number|null,quality:'DIRECT'|'DERIVED'|'ESTIMATED'|'UNAVAILABLE',reason?:string,source?:string,/** 'GE' = lower bound (HKJC DBL 999 cap) → UI prefixes ≥ */bound?:'GE',raw?:number,cappedCells?:number,cells?:number,/** 孖上/孖下 signed % (dblfix2); drift=true → shown as -- (lengthened/unchanged since T−17) */signed?:number,drift?:boolean,/** 孖下 only (dblfix3, provisional): 0<signed<3.0 → shown as -- */belowFloor?:boolean};
export type PressureState='VALID'|'VALID_UNCHANGED'|'STALE'|'UNAVAILABLE'|'ESTIMATED_EQUAL';
export type Race={id:string,date:string,venue:string,venueKind?:'local'|'overseas',venueLabel?:string,country?:string,no:number,name:string,raceClass:string,distance:Metric,track:string,course:string,going:string,postTime:number,runners:{no:number,name:string,scratched?:boolean,jockey?:string,trainer?:string,draw?:Metric,nameEn?:string,quality?:string}[]};
export type Meeting={date:string,venue:string,venueKind?:'local'|'overseas',venueLabel?:string,country?:string,races:Race[]};
export type Catalog={meetings:Meeting[],recommendedRaceId?:string|null,checkedAt?:number,status?:string,message?:string,schedule?:{date:string,venue:string,status:string,cardAvailable:boolean}[]};
export type Flow={share:Metric,actual:Metric,expected:Metric,excess:Metric,lift:Metric,pressure:Metric,hot_money_3m?:Metric,hot_money_baseline?:Metric,windowSeconds:Metric,grade:string,reason:string,state?:PressureState,estimated_equal?:boolean,health?:{status?:string;reason?:string|null},snapshot_id?:string,calculation_id?:string,source_timestamp?:number,received_timestamp?:number,age_seconds?:number,window_seconds?:number|null,dbl_up_percent?:number|null,dbl_down_percent?:number|null,dbl_signed_momentum?:number|null,dbl_state?:'DIRECT'|'ESTIMATED'|'UNAVAILABLE',dbl_matrix_coverage?:number|null,legPct?:Metric,[key:string]:Metric|string|boolean|number|null|undefined|{status?:string;reason?:string|null}};
export type MoneyFlowStatus={status:string,message:string,readyRunners:number,windowSeconds:number,collectedSeconds:number,calculationTime:number|null,oddsTime:number|null,quoteTime?:number|null,investmentTime?:number|null,alignment?:string,quality:string};
export type Research={A:Metric,B:Metric,C:Metric,Self:Metric,Cross:Metric,H?:Metric};
export type PoolKey='WIN'|'PLA'|'QIN'|'QPL'|'FCT';
export type ShareBarPart={weight:number,quality:string,share:Metric};
export type ShareBar={
  currentShare:Metric;
  baselineShare:Metric;
  barHeight:Metric;
  barHeightDisplay:Metric;
  provisional?:boolean;
  baselineStatus?:'WAITING'|'PROVISIONAL'|'OFFICIAL'|string;
  poolParts?:Partial<Record<PoolKey,ShareBarPart>>;
  /** Engine/UI keep-last: heights copied from an earlier frame when this tick could not compute. */
  keptFromPrior?:boolean;
};
export type ShareBaseline={
  shares?:Record<string,number>;
  provisional?:boolean;
  status?:'WAITING'|'PROVISIONAL'|'OFFICIAL'|string;
  sampleCount?:number;
  window?:number[]|null;
  timestamp?:number|null;
  reason?:string;
  poolParts?:Record<string,unknown>;
};

export type Frame={id:string,timestamp:number,source:string,moneyFlow?:MoneyFlowStatus,runners:Record<string,{winOdds:Metric,placeOdds:Metric}>,pools:Record<string,{total:Metric,reportedTotal?:Metric,complete?:boolean,quality?:string,sourceQuality?:string,unavailableReason?:string|null,reason?:string|null,odds?:Record<string,Metric>,combinations?:Record<string,Metric>,diagnostics?:FctSourceHealth,[key:string]:unknown}>,flows:Record<string,Record<string,Flow>>,tags:Record<string,string[]>,double:Record<string,{pressure:Metric}>,incomingDouble:Record<string,{winner:Metric,runnerUp:Metric,all?:Metric,up?:Metric}>,research?:Record<string,Research>,fctHealth?:FctSourceHealth,raceTotalInvestment?:Metric,shareBars?:Record<string,ShareBar>,/** F-C08 as-of this frame timestamp (回帶 reads this; tip keep-last is state.dblPct). */dblPct?:{up:Record<string,Metric>,down:Record<string,Metric>}};
export type Spectrum=Record<string,{minute:number,start:number,peakId:string|null,layers:Record<string,{grade:string,timestamp:number|null,frameId:string|null,pressure:Metric}>}[]>;
export type Collection={enabled:boolean,autoFollow:boolean,race:Race|null,key:string|null,status:string,error?:string|null};
export type State={mode:string,key?:string,race:Race|null,collection?:Collection,frames:Frame[],marks:string[],spectrum:Spectrum,baseline?:{order:string[],timestamp:number|null,status:string,winOdds?:Record<string,Metric>},dblPct?:{up:Record<string,Metric>,down:Record<string,Metric>},shareBaseline?:ShareBaseline,postGate?:PostGateInfo,health:{status:string,error?:string|null,lastUpdate?:Metric,lastReceived?:Metric,latency?:Metric}};
export type FctSourceHealth={
  quality?:'DIRECT'|'UNAVAILABLE'|string;
  reason?:string|null;
  sourceSeen?:boolean;
  directMatrixSeen?:boolean;
  matrixComplete?:boolean;
  edgeCount?:number;
  expectedEdgeCount?:number;
  totalConserved?:boolean;
  syncSeconds?:number|null;
  pressureCalculable?:boolean;
  fctFlowVerified?:boolean;
};


/** 007式流向（試驗） — dblfix3 2026-09-28. TRIAL / ESTIMATED / NOT LOCKED. Fetched only while the toggle is ON. */
export type FlowTrial={status:'TRIAL',quality?:'ESTIMATED',label:string,version?:string,params?:{lnK:number,alpha:number,kappa:number,w:number},
  cutMin?:number,cutKind?:'local'|'overseas',cutEstimated?:boolean,scheduledPost?:number|null,phase:'PRE_CUT'|'POST_CUT'|'NO_CUT'|'NO_DATA',
  cutTs?:number|null,threeTs?:number|null,flowTs?:number|null,asOf?:number|null,frameId?:string|null,tip?:boolean,stale?:boolean,reason?:string|null,
  runners:Record<string,{pre:Metric,three:Metric,flow:Metric,/** v0.7.2 入閘後: flow value frozen at the gate snapshot */gate?:Metric,postGate?:PostGateSegment|null,/** v0.7.6: max(flow − flow at the frozen gate frame, 0). Not the v0.7.5 minimum after the gate. */rebound?:Metric}>,snapshots?:number,computeMs?:number,postGate?:PostGateInfo};

/** v0.7.2 入閘後 split (display only; backend/postgate.py). Split = scheduled post − offsetMin; baseline = bar value of
 *  the last snapshot at or before the split (≤ maxAgeSec old, never a keep-last copy). */
export type PostGateInfo={label:string,offsetMin:number,maxAgeSec:number,scheduledPost:number|null,splitTs:number|null,
  status:'PENDING'|'FROZEN'|'UNAVAILABLE',active?:boolean,frameId:string|null,timestamp:number|null,reason:string|null,values?:Record<string,number>};
export type PostGateSegment={base:number,cur:number,delta:number,baseShown:number,deltaShown:number,kind:'UP'|'DOWN'|'FLAT',label:string};
