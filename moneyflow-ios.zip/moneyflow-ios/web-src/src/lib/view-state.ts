import type { Frame,Spectrum } from './types';
export function currentFrame(frames:Frame[],selectedId:string|null) {
  return selectedId?frames.find(f=>f.id===selectedId):frames.at(-1);
}
// LIVE expires freshness after 45s, but bars MUST keep last valid heights
// (「無時無刻都有棒形」). Mark STALE + suppress live anomaly; do NOT null Pressure.
// shareBars ride on the frame spread — keep-last heights from the engine survive this age path.
export function visibleFrame(frame:Frame|undefined,mode:string,selectedId:string|null,now:number):Frame|undefined {
  const clock=frame?.moneyFlow?.calculationTime;
  if(!frame||mode!=='live'||selectedId||clock==null||now-clock<=45)return frame;
  const reason='WIN 計算資料已過期，等待新更新（保留上次有效計算）';
  const age=now-clock;
  return {...frame,
    // shareBars intentionally preserved via ...frame (Combined keep-last survives STALE age).
    flows:Object.fromEntries(Object.entries(frame.flows).map(([r,pools])=>[r,{...pools,
      ...Object.fromEntries(Object.entries(pools).map(([poolName,flow])=>{
        if(!flow||typeof flow!=='object'||!('pressure' in flow))return [poolName,flow];
        const hasPressure=flow.pressure?.value!=null;
        return [poolName,{
          ...flow,
          // Keep share/actual/expected/excess/lift/pressure values (last valid).
          grade:'unavailable', // suppress treating as live anomaly
          eligible:false,
          reason:hasPressure?reason:(flow.reason||reason),
          state:(hasPressure?'STALE':'UNAVAILABLE') as 'STALE'|'UNAVAILABLE',
          estimated_equal:false,
          age_seconds:age,
          health:{status:'ERROR',reason:'source_age_exceeded'},
        }];
      })),
    }])),
    // Drop live WIN anomaly tags; keep research / other pools' last valid numbers.
    tags:Object.fromEntries(Object.entries(frame.tags).map(([r,tags])=>[r,tags.filter(t=>t!=='WIN')])),
  };
}
export function replayAt(frames:Frame[],index:number) {return frames[Math.max(0,Math.min(frames.length-1,Math.round(index)))];}
export function toggleMark(marks:string[],runner:string) {return marks.includes(runner)?marks.filter(r=>r!==runner):[...marks,runner];}
export function spectrumTarget(spectrum:Spectrum,runner:string,minuteIndex:number,pool:string) {
  const layer=spectrum[runner]?.[minuteIndex]?.layers[pool];
  return layer?.frameId?{id:layer.frameId,runner}:null;
}
