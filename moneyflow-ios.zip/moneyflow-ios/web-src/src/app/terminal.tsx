'use client';

import { memo, useEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { Activity, ArrowDownToLine, Radio, RefreshCw, CircleHelp, Upload, ChevronLeft, ChevronRight, Filter, Lightbulb, Check, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { currentFrame, visibleFrame, replayAt, spectrumTarget } from '@/lib/view-state';
import type { State, Metric, Flow, Race, Meeting, Catalog, Collection, PressureState, PoolKey, ShareBar, FlowTrial } from '@/lib/types';
import { registerMoneyFlowTools } from '@/lib/webmcp';
import { apiCall, saveApiJson } from '@/backend/client';

const blank: State={mode:'live',race:null,frames:[],marks:[],spectrum:{},health:{status:'ERROR',error:null}};
const poolLabel: Record<string,string>={WIN:'W',QIN:'Q',QPL:'QP'};
type HighlightColor='red'|'yellow'|'blue'|'green';
const HIGHLIGHT_COLORS:HighlightColor[]=['red','yellow','blue','green'];
function cycleHighlight(prev:Record<string,HighlightColor>,runner:string):Record<string,HighlightColor>{
  const current=prev[runner];
  const next=HIGHLIGHT_COLORS[(current?HIGHLIGHT_COLORS.indexOf(current):-1)+1];
  const highlights={...prev};
  if(next)highlights[runner]=next;else delete highlights[runner];
  return highlights;
}
const highlightClass=(color?:HighlightColor)=>color?`highlighted hl-${color}`:'';
const fmt=(m?:Metric,digits=1)=>m?.reason==='POSITIVE_UNBOUNDED'?'∞':m?.reason==='NEGATIVE_UNBOUNDED'?'-∞':m?.value == null?'--':Number(m.value).toLocaleString('en-HK',{maximumFractionDigits:digits});
const tm=(t?:number|null)=>t==null?'--':new Date(t*1000).toLocaleTimeString('en-GB',{timeZone:'Asia/Hong_Kong',hour12:false});
const venueName=(item?:{venue?:string,venueLabel?:string})=>item?.venueLabel||(item?.venue==='ST'?'沙田 ST':item?.venue==='HV'?'跑馬地 HV':item?.venue||'--');
// Local state refresh is independent of the upstream collection cadence.
const stateRefreshMs=3000;

function poolGrandTotal(pools?:Record<string,{total?:Metric,reportedTotal?:Metric}>):Metric{
  if(!pools)return {value:null,quality:'UNAVAILABLE',reason:'未有彩池總額'};
  let sum=0,seen=false;const qualities:Metric['quality'][]=[];
  for(const pool of Object.values(pools)){
    const metricValue=pool.reportedTotal||pool.total;
    if(metricValue?.value==null)continue;
    sum+=metricValue.value;seen=true;qualities.push(metricValue.quality);
  }
  if(!seen)return {value:null,quality:'UNAVAILABLE',reason:'未有彩池總額'};
  const qualityLabel=qualities.includes('UNAVAILABLE')?'UNAVAILABLE':qualities.includes('ESTIMATED')?'ESTIMATED':qualities.includes('DERIVED')?'DERIVED':'DIRECT';
  return {value:sum,quality:qualityLabel,source:'HKJC all pools'};
}

function NumberValue({m,digits=1,suffix='',title}:{m?:Metric,digits?:number,suffix?:string,title?:string}) {
  const tip=title??`${m?.quality||'UNAVAILABLE'} · ${m?.source||''} ${m?.reason||''}`;
  return <span className={'value '+(m?.quality?.toLowerCase()||'unavailable')} title={tip}>
    {m?.value!=null&&m?.bound==='GE'?'≥':''}{fmt(m,digits)}{m?.value!=null?suffix:''}<small className="quality">{({DIRECT:'D',ESTIMATED:'ƒ',DERIVED:'≈',UNAVAILABLE:'—'} as Record<string,string>)[m?.quality||'UNAVAILABLE']}</small>
  </span>;
}


const QUALITY_BADGE:{[k:string]:string}={DIRECT:'D',ESTIMATED:'ƒ',DERIVED:'≈',UNAVAILABLE:'—'};
const STATE_LABEL:Record<PressureState,string>={
  VALID:'LIVE',
  VALID_UNCHANGED:'NO FLOW CHANGE',
  ESTIMATED_EQUAL:'ESTIMATED EQUAL',
  STALE:'STALE',
  UNAVAILABLE:'-- UNAVAILABLE',
};
function pressureStateOf(f?:Flow, flowStale?:boolean):PressureState{
  if(flowStale)return 'STALE';
  const s=f?.state;
  if(s==='VALID'||s==='VALID_UNCHANGED'||s==='ESTIMATED_EQUAL'||s==='STALE'||s==='UNAVAILABLE')return s;
  return f?.pressure?.value==null?'UNAVAILABLE':'VALID';
}
function qualityBadgeOf(f?:Flow):string{
  if(!f||f.pressure?.value==null||f.state==='UNAVAILABLE'||f.state==='STALE')return '—';
  if(f.pressure.quality==='DIRECT')return 'D';
  if(f.pressure.quality==='ESTIMATED'||f.state==='ESTIMATED_EQUAL')return 'ƒ';
  if(f.pressure.quality==='DERIVED')return '≈';
  return QUALITY_BADGE[f.pressure.quality||'UNAVAILABLE']||'—';
}

type PoolTabDef={key:PoolKey;labelZh:string;labelEn:string;mobile:string;wired:boolean};
const POOL_TABS:PoolTabDef[]=[
  {key:'WIN',labelZh:'獨贏',labelEn:'WIN',mobile:'W',wired:true},
  {key:'PLA',labelZh:'位置',labelEn:'PLA',mobile:'P',wired:false},
  {key:'QIN',labelZh:'連贏',labelEn:'QIN',mobile:'Q',wired:true},
  {key:'QPL',labelZh:'位置Q',labelEn:'QPL',mobile:'QP',wired:true},
  {key:'FCT',labelZh:'二重彩',labelEn:'FCT',mobile:'F',wired:true},
];
const POOL_TITLE:Record<PoolKey,string>={WIN:'獨贏 WIN',PLA:'位置 PLA',QIN:'連贏 QIN',QPL:'位置Q QPL',FCT:'二重彩 FCT'};
const POOL_EMPTY_REASON:Partial<Record<PoolKey,string>>={
  PLA:'暫無已驗證 Money Pressure',
};
/** Tab badge: WIN ƒ when estimated; QIN/QPL/FCT D when DIRECT matrix yielded pressure (metric itself ≈ DERIVED); PLA always —. */
function poolTabBadge(pool:PoolKey, frame:State['frames'][number]|undefined, runners:string[]):string{
  if(pool==='PLA')return '—';
  if(!frame||!runners.length)return '—';
  let sawDirect=false,sawEstimated=false,sawDerived=false;
  for(const r of runners){
    const f=frame.flows[r]?.[pool];
    if(!f||f.pressure?.value==null||f.state==='UNAVAILABLE'||f.state==='STALE')continue;
    const q=f.pressure.quality;
    if(q==='DIRECT')sawDirect=true;
    else if(q==='ESTIMATED'||f.state==='ESTIMATED_EQUAL')sawEstimated=true;
    else if(q==='DERIVED')sawDerived=true;
  }
  // QIN/QPL: DERIVED pressure → source badge D.
  // FCT: Pressure itself is ≈ DERIVED from DIRECT matrix (spec §3.9); tooltip carries Source D.
  if(pool==='FCT'){
    if(sawDirect||sawDerived)return '≈';
    if(sawEstimated)return 'ƒ';
    return '—';
  }
  if(pool==='QIN'||pool==='QPL'){
    if(sawDirect||sawDerived)return 'D';
    if(sawEstimated)return 'ƒ';
    return '—';
  }
  if(sawDirect)return 'D';
  if(sawEstimated)return 'ƒ';
  if(sawDerived)return '≈';
  return '—';
}
function poolHasAnyPressure(pool:PoolKey, frame:State['frames'][number]|undefined, runners:string[]):boolean{
  if(pool==='PLA'||!frame)return false;
  return runners.some(r=>{
    const f=frame.flows[r]?.[pool];
    return f!=null&&f.pressure?.value!=null&&f.state!=='UNAVAILABLE'&&f.state!=='STALE';
  });
}

/** Combined Pressure weights (PLA excluded until validated). Missing pool omitted + renormalize. */
const COMBINED_WEIGHTS: Partial<Record<PoolKey, number>> = {WIN:1.0, QIN:0.75, QPL:0.75, FCT:0.75};
type CombinedResult = {
  pressure: Metric|undefined;
  badge: '≈'|'ƒ'|'—';
  grade: string;
  state: PressureState;
  parts: {pool:PoolKey;value:number;weight:number;quality:string}[];
};
function combinedPressureOf(
  frame: State['frames'][number]|undefined,
  runner: string,
  flowStale?: boolean,
): CombinedResult {
  const empty: CombinedResult = {
    pressure: undefined,
    badge: '—',
    grade: 'unavailable',
    state: flowStale ? 'STALE' : 'UNAVAILABLE',
    parts: [],
  };
  // Keep-last-on-STALE: still compute from last valid pool pressures; do not wipe bars.
  if (!frame) return empty;
  let weighted = 0, weightSum = 0;
  let sawEstimated = false, sawUsable = false;
  const parts: CombinedResult['parts'] = [];
  const grades: string[] = [];
  let anyUnchanged = true, anyEstimatedEqual = true, anyValid = false;
  for (const pool of Object.keys(COMBINED_WEIGHTS) as PoolKey[]) {
    const w = COMBINED_WEIGHTS[pool]!;
    const f = frame.flows[runner]?.[pool];
    const pState = pressureStateOf(f, false);
    // UNAVAILABLE (never had / failed calc) omitted; STALE-with-value kept for bar height.
    if (!f || f.pressure?.value == null || pState === 'UNAVAILABLE') continue;
    const v = f.pressure.value;
    weighted += w * v;
    weightSum += w;
    sawUsable = true;
    if (f.pressure.quality === 'ESTIMATED' || pState === 'ESTIMATED_EQUAL') sawEstimated = true;
    parts.push({pool, value: v, weight: w, quality: f.pressure.quality || 'UNAVAILABLE'});
    if (f.grade && f.grade !== 'unavailable') grades.push(f.grade);
    if (pState !== 'VALID_UNCHANGED' && pState !== 'STALE') anyUnchanged = false;
    if (pState !== 'ESTIMATED_EQUAL') anyEstimatedEqual = false;
    if (pState === 'VALID' || pState === 'VALID_UNCHANGED' || pState === 'ESTIMATED_EQUAL' || pState === 'STALE') anyValid = true;
  }
  if (!sawUsable || weightSum <= 0) return empty;
  const value = weighted / weightSum;
  // Combined is always a derived aggregate — never show D.
  const badge: CombinedResult['badge'] = sawEstimated ? 'ƒ' : '≈';
  const gradeRank = ['normal', 'green', 'red', 'brown'];
  const liveGrade = grades.reduce((best, g) => (gradeRank.indexOf(g) > gradeRank.indexOf(best) ? g : best), 'normal');
  // STALE: keep heights but suppress live anomaly hatch/grade.
  const grade = flowStale ? 'unavailable' : liveGrade;
  const state: PressureState = flowStale ? 'STALE'
    : anyUnchanged && anyValid ? 'VALID_UNCHANGED'
    : anyEstimatedEqual && anyValid ? 'ESTIMATED_EQUAL'
    : anyValid ? 'VALID' : 'UNAVAILABLE';
  return {
    pressure: {
      value,
      quality: sawEstimated ? 'ESTIMATED' : 'DERIVED',
      reason: flowStale
        ? 'STALE · Combined Pressure kept from last valid calc (age >45s). Not live anomaly.'
        : 'Combined Pressure = Σ(w_p × Pressure_p) / Σ(w_p) over available pools (PLA excluded); missing omitted+renormalized. Not total stake.',
      source: parts.map(p => p.pool).join('+') || 'combined',
    },
    badge,
    grade,
    state,
    parts,
  };
}
function combinedBadgeOf(frame: State['frames'][number]|undefined, runners: string[], flowStale?: boolean): '≈'|'ƒ'|'—' {
  // Keep last-valid badge on STALE (downgrade is via STALE label / fade, not —).
  if (!frame || !runners.length) return '—';
  let saw = false, sawEstimated = false;
  for (const r of runners) {
    const c = combinedPressureOf(frame, r, flowStale);
    if (c.badge === '—') continue;
    saw = true;
    if (c.badge === 'ƒ') sawEstimated = true;
  }
  if (!saw) return '—';
  return sawEstimated ? 'ƒ' : '≈';
}


function shareBarOf(frame: State['frames'][number]|undefined, runner: string): ShareBar|undefined {
  return frame?.shareBars?.[runner];
}
function shareBarHeight(share?: ShareBar): number|null {
  const display = share?.barHeightDisplay?.value;
  if (display != null && Number.isFinite(display)) return display;
  const raw = share?.barHeight?.value;
  if (raw != null && Number.isFinite(raw)) return Math.max(50, Math.min(200, raw));
  return null;
}
function shareBarBadge(share?: ShareBar): '≈'|'ƒ'|'—' {
  const q = share?.currentShare?.quality || share?.barHeight?.quality;
  if (!share || share.barHeight?.value == null) return '—';
  if (q === 'ESTIMATED') return 'ƒ';
  if (q === 'DIRECT') return '≈'; // combined aggregate never shows D
  if (q === 'DERIVED') return '≈';
  return '—';
}
function frameHasShareHeights(f?: State['frames'][number]): boolean {
  return !!f && Object.values(f.shareBars || {}).some(b => b?.barHeight?.value != null);
}
/** Defense in depth: if LIVE tip lacks heights but an earlier frame has them, merge keep-last for display. Engine is source of truth. */
function mergeKeepLastShareBars(tip: State['frames'][number], frames: State['frames']): State['frames'][number] {
  if (frameHasShareHeights(tip)) return tip;
  const prior = [...frames].reverse().find(f => f.id !== tip.id && frameHasShareHeights(f));
  if (!prior?.shareBars) return tip;
  const merged: Record<string, ShareBar> = {...(tip.shareBars || {})};
  let any = false;
  for (const [r, prev] of Object.entries(prior.shareBars)) {
    if (prev?.barHeight?.value == null) continue;
    if (merged[r]?.barHeight?.value != null) continue;
    const reason = prev.barHeight?.reason || '';
    const keepReason = reason.includes('保留上次有效棒高') ? reason : `保留上次有效棒高（本切片未計出）${reason ? ' · ' + reason : ''}`;
    merged[r] = {
      ...prev,
      keptFromPrior: true,
      barHeight: {...prev.barHeight, reason: keepReason},
      barHeightDisplay: prev.barHeightDisplay ? {...prev.barHeightDisplay, reason: keepReason} : prev.barHeightDisplay,
    };
    any = true;
  }
  return any ? {...tip, shareBars: merged} : tip;
}
function pressureOverlayOf(
  frame: State['frames'][number]|undefined,
  runner: string,
  flowStale?: boolean,
): {text: string; ready: boolean; value: number|null; state: PressureState} {
  const combined = combinedPressureOf(frame, runner, flowStale);
  if (combined.state === 'STALE') {
    return {text: 'STALE', ready: combined.pressure?.value != null, value: combined.pressure?.value ?? null, state: 'STALE'};
  }
  if (combined.pressure?.value == null || combined.state === 'UNAVAILABLE') {
    return {text: '—', ready: false, value: null, state: 'UNAVAILABLE'};
  }
  if (combined.state === 'VALID_UNCHANGED') {
    return {text: 'P≈100', ready: true, value: combined.pressure.value, state: combined.state};
  }
  if (combined.state === 'ESTIMATED_EQUAL') {
    return {text: `P ${combined.pressure.value.toFixed(0)} ƒ`, ready: true, value: combined.pressure.value, state: combined.state};
  }
  return {text: `P ${combined.pressure.value.toFixed(0)}`, ready: true, value: combined.pressure.value, state: combined.state};
}





function drawMetric(h?:{draw?:Metric|number|null}):Metric|undefined{
  if(!h)return undefined;
  const d=h.draw as Metric|number|null|undefined;
  if(d==null)return undefined;
  if(typeof d==='object')return d;
  return {value:Number(d),quality:'DIRECT',source:'card'};
}
function poolMarker(frame:State['frames'][number]|undefined,r:string){
  const qin=frame?.flows[r]?.QIN;const qpl=frame?.flows[r]?.QPL;
  const qHot=qin?.grade&&qin.grade!=='normal'&&qin.grade!=='unavailable';
  const qpHot=qpl?.grade&&qpl.grade!=='normal'&&qpl.grade!=='unavailable';
  const qPress=qin?.pressure?.value;const qpPress=qpl?.pressure?.value;
  if(qHot||(qPress!=null&&Math.abs(qPress-100)>=20))return 'Q';
  if(qpHot||(qpPress!=null&&Math.abs(qpPress-100)>=20))return 'QP';
  return null;
}

function Picker({label,value,options,onChange,compact}:{label:string,value:string,options:{value:string,label:string}[],onChange:(v:string)=>void,compact?:boolean}) {
  return <label className={'picker'+(compact?' compact':'')}>{!compact&&<span>{label}</span>}<Select value={value} onValueChange={v=>v!=null&&onChange(String(v))} items={options}>
    <SelectTrigger aria-label={label}><SelectValue placeholder="選擇" /></SelectTrigger><SelectContent>{options.map(o=><SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
  </Select></label>;
}

// 007式流向（試驗） panel — only mounted while the toggle is ON. Values come from /api/flow-trial (server, shared
// formula backend/flow007_trial.py). Missing → "--"; never copied forward; STALE marked.
type FlowTrialProps={frameId:string|null,stateKey:string|undefined,framesLen:number,tipId:string|undefined,order:string[],highlights:Record<string,HighlightColor>,liveStale:boolean};
// Own state + fetch: a trial response re-renders only this panel (not the terminal). Unmounted when OFF → no fetch/compute/render.
const FlowTrialPanel=memo(function FlowTrialPanel({frameId,stateKey,framesLen,tipId,order,highlights,liveStale}:FlowTrialProps){
  const [trial,setTrial]=useState<FlowTrial|null>(null);
  useEffect(()=>{
    let alive=true;
    const t0=performance.now();
    api<FlowTrial>('flow-trial'+(frameId?`?frame=${encodeURIComponent(frameId)}`:''))
      .then(d=>{if(alive){setTrial(d);(window as unknown as {__flowTrialFetchMs?:number}).__flowTrialFetchMs=performance.now()-t0;}})
      .catch(()=>{if(alive)setTrial(null);});
    return()=>{alive=false;};
  },[frameId,stateKey,framesLen,tipId]);
  const top=200;
  const stale=!!trial?.stale||liveStale;
  const phaseText=!trial?'載入中…':trial.phase==='PRE_CUT'?`截點前（T−${trial.cutMin}）· 流向＝累積`:trial.phase==='POST_CUT'?`截點 ${tm(trial.cutTs)} 後 · 流向＝截點後新資金`:trial.phase==='NO_CUT'?'截點前冇有效快照 · --':'未有快照';
  return <div className={'flow-trial-panel'+(stale?' stale':'')} data-testid="flow-trial-panel" data-frame-id={trial?.frameId??'tip'} data-phase={trial?.phase??'LOADING'} role="region" aria-label="007式流向（試驗）">
    <div className="flow-trial-head"><strong data-testid="flow-trial-label">007式流向（試驗）</strong>
      <span className="trial-badge">試驗 · ESTIMATED · 未鎖定</span>
      <span>{trial?.version||'V1'} A_new · lnK {trial?.params?.lnK??6.238} · α {trial?.params?.alpha??0.805} · κ {trial?.params?.kappa??0.55} · w {trial?.params?.w??0.65}</span>
      <span>截點 T−{trial?.cutMin??16.5}{trial?.cutKind==='overseas'?'（海外 · ESTIMATED）':'（本地）'}</span>
      <span>{phaseText}</span>
      {stale&&<span className="trial-stale" data-testid="flow-trial-stale">STALE</span>}
    </div>
    <div className="flow-trial-bars">
      {order.map(r=>{
        const x=trial?.runners?.[r];const v=x?.flow?.value;
        const h=v==null?0:Math.max(3,56*Math.min(v,top)/top);
        return <div key={r} className={['flow-trial-runner',highlightClass(highlights[r])].filter(Boolean).join(' ')} data-testid={'flow-trial-'+r} title={`#${r} 007式流向（試驗）ESTIMATED\n熱錢前 ${fmt(x?.pre,0)} · 3′ ${fmt(x?.three,0)} · 流向 ${fmt(x?.flow,0)}\n${x?.flow?.value==null?(x?.flow?.reason||'--'):''}`}>
          <span className="ft-val">{fmt(x?.flow,0)}</span>
          <div className="ft-zone"><i className={'ft-bar'+(v==null?' missing':'')+(stale?' stale':'')} style={{height:h}}/></div>
          <b>{r}</b>
          <small>前 {fmt(x?.pre,0)}</small><small>3′ {fmt(x?.three,0)}</small>
        </div>;
      })}
    </div>
  </div>;
},(a,b)=>a.frameId===b.frameId&&a.stateKey===b.stateKey&&a.framesLen===b.framesLen&&a.tipId===b.tipId&&a.liveStale===b.liveStale&&a.highlights===b.highlights&&a.order.join()===b.order.join());

// iOS app: the former Python /api is served in-page (src/backend); HKJC requests go through the native bridge.
async function api<T=State>(path:string,body?:unknown):Promise<T> {
  return apiCall<T>(path,body);
}

export default function Terminal() {
  const [state,setState]=useState<State>(blank);
  const [mode,setMode]=useState('live');
  const [meetings,setMeetings]=useState<Meeting[]>([]);
  const [catalog,setCatalog]=useState<Catalog|null>(null);
  const [autoFollow,setAutoFollow]=useState(true);
  const followRef=useRef(true);const busyRef=useRef(false);
  const [date,setDate]=useState('');const [venue,setVenue]=useState('ST');const [raceId,setRaceId]=useState('');
  const [recordings,setRecordings]=useState<{key:string,mode:string,race:Race}[]>([]);
  const [selectedId,setSelectedId]=useState<string|null>(null);
  const [highlights,setHighlights]=useState<Record<string,HighlightColor>>({});
  const [debug,setDebug]=useState<string|null>(null);
  const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  const [windowSeconds,setWindowSeconds]=useState(15);const [baselineMinutes,setBaselineMinutes]=useState(15);
  const [showSettings,setShowSettings]=useState(false);
  const [showAudit,setShowAudit]=useState(false);
  const [zoom,setZoom]=useState(120);
  const [collection,setCollection]=useState<Collection|null>(null);
  const [,setTick]=useState(0);
  const generation=useRef(0);const file=useRef<HTMLInputElement>(null);
  const chartRef=useRef<HTMLElement>(null);
  const barsMeasureRef=useRef<HTMLDivElement>(null);
  const [barZoneH,setBarZoneH]=useState(110);
  const [barFooterH,setBarFooterH]=useState(72);
  const [chartVisit,setChartVisit]=useState(0);
  const [sortMode,setSortMode]=useState<'number'|'odds'|'baseline'>('odds');
  const [frozenOrder,setFrozenOrder]=useState<string[]>([]);
  // 007式流向（試驗） (dblfix3): default OFF. While OFF nothing is fetched, computed or rendered for it.
  const [flowTrialOn,setFlowTrialOn]=useState(false);
  const controlsRef=useRef({mode,date,venue,raceId});controlsRef.current={mode,date,venue,raceId};
  const viewRef=useRef({state,selectedId});viewRef.current={state,selectedId};
  useEffect(()=>registerMoneyFlowTools(()=>viewRef.current,id=>flushSync(()=>setSelectedId(id))),[]);
  const rawFrame=visibleFrame(currentFrame(state.frames,selectedId),state.mode,selectedId,Date.now()/1000);
  // LIVE tip: engine keep-last is primary; client merge is defense when tip heights are still empty.
  const frame=(!selectedId && rawFrame && !frameHasShareHeights(rawFrame))
    ? mergeKeepLastShareBars(rawFrame, state.frames)
    : rawFrame;
  const race=state.race;
  const trialFrameId=selectedId?(frame?.id??null):null;
  const races=meetings.find(m=>m.date===date&&m.venue===venue)?.races||[];
  const numberOrder=(state.baseline?.order||race?.runners.map(r=>String(r.no))||[]).slice().sort((a,b)=>Number(a)-Number(b));
  const baselineOddsReady=numberOrder.some(r=>state.baseline?.winOdds?.[r]?.value!=null);
  // CRITICAL: do NOT auto re-sort when live odds change. Only reorder when sortMode (or race) changes.
  function computeOrder(mode:'number'|'odds'|'baseline', snapFrame:typeof frame):string[]{
    const base=numberOrder.slice();
    if(mode==='number')return base.sort((a,b)=>Number(a)-Number(b));
    if(mode==='baseline'){
      return base.sort((a,b)=>{
        const oa=state.baseline?.winOdds?.[a]?.value;
        const ob=state.baseline?.winOdds?.[b]?.value;
        if(oa==null&&ob==null)return Number(a)-Number(b);
        if(oa==null)return 1;
        if(ob==null)return -1;
        return oa-ob||Number(a)-Number(b);
      });
    }
    return base.sort((a,b)=>{
      const oa=snapFrame?.runners[a]?.winOdds?.value;
      const ob=snapFrame?.runners[b]?.winOdds?.value;
      if(oa==null&&ob==null)return Number(a)-Number(b);
      if(oa==null)return 1;
      if(ob==null)return -1;
      return oa-ob||Number(a)-Number(b);
    });
  }
  function applySort(mode:'number'|'odds'|'baseline'){
    if(mode==='baseline'&&!baselineOddsReady)return;
    setSortMode(mode);
    setFrozenOrder(computeOrder(mode, frame));
  }
  // Seed / re-seed frozen order when race identity changes (not on live odds tick).
  const raceKey=race?.id||state.key||'';
  const baselineStamp=state.baseline?.timestamp??null;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(()=>{ if(!numberOrder.length){setFrozenOrder([]);return;} setFrozenOrder(computeOrder(sortMode==='baseline'&&!baselineOddsReady?'odds':sortMode, frame)); },[raceKey, baselineStamp, numberOrder.join('|')]);
  const order=frozenOrder.length?frozenOrder:numberOrder;
  const tableOrder=order;
  const chartTop=200;
  const hp=state.health;
  const healthStatus=state.mode==='live'&&hp.status==='LIVE'&&hp.lastUpdate?.value!=null&&Date.now()/1000-hp.lastUpdate.value>45?'STALE':hp.status;
  const flowStatus=frame?.moneyFlow;
  const flowStale=!selectedId&&state.mode==='live'&&flowStatus?.calculationTime!=null&&Date.now()/1000-flowStatus.calculationTime>45;
  const staleAgeSec=flowStale&&flowStatus?.calculationTime!=null?Math.round(Date.now()/1000-flowStatus.calculationTime):null;
  // 回帶: read selected frame dblPct so 孖上/孖下 vary across history.
  // LIVE tip: state.dblPct (server keep-last). Never mask scrub with tip cache.
  const dblPctView=selectedId?(frame?.dblPct??undefined):state.dblPct;
  const hotCircle=order.filter(r=>{
    // STALE keep-last: aged bars stay visible but are not live hot-money anomaly.
    if(flowStale)return state.marks.includes(r);
    const f=frame?.flows[r]?.WIN;const g=f?.grade;
    const p=f?.pressure?.value;
    return state.marks.includes(r)||(g!=null&&g!=='normal'&&g!=='unavailable')||(p!=null&&p>=120);
  });
  const lateFrames=race?state.frames.filter(f=>f.timestamp>=race.postTime-300):[];
  const replayFrames=lateFrames.length?lateFrames:state.frames;
  // Bars use shareBars heights (not WIN Pressure). Button seeks last frame that actually had bar heights.
  const latestReady=state.frames.findLast(f=>Object.values(f.shareBars||{}).some(b=>b?.barHeight?.value!=null));
  const sliderIndex=frame?replayFrames.findIndex(f=>f.id===frame.id):-1;

  useEffect(()=>{
    if(!chartVisit)return;
    const id=requestAnimationFrame(()=>chartRef.current?.scrollIntoView({block:'start',behavior:'instant'}));
    return()=>cancelAnimationFrame(id);
  },[chartVisit]);

  useEffect(()=>{
    const root=barsMeasureRef.current;
    if(!root)return;
    const measure=()=>{
      const zone=root.querySelector('.bar-zone') as HTMLElement|null;
      const runner=root.querySelector('.runner') as HTMLElement|null;
      if(!zone)return;
      // getBoundingClientRect is post-CSS-zoom; style.height is pre-zoom — divide out.
      const zScale=Math.max(0.5,(Number(document.querySelector('.workspace')?.getAttribute('data-zoom')||zoom)||100)/100);
      const zh=Math.round(zone.getBoundingClientRect().height/zScale);
      if(zh>=40){
        setBarZoneH(zh);
        root.style.setProperty('--bar-zone-h', `${zh}px`);
      }
      if(runner){
        const zr=zone.getBoundingClientRect();
        const rr=runner.getBoundingClientRect();
        const fh=Math.round((rr.bottom-zr.bottom)/zScale);
        if(fh>=0)setBarFooterH(fh);
      }
    };
    measure();
    const ro=new ResizeObserver(()=>measure());
    ro.observe(root);
    const zone=root.querySelector('.bar-zone');
    if(zone)ro.observe(zone);
    return ()=>ro.disconnect();
  },[order.length,zoom,chartVisit]);

  function working(value:boolean){busyRef.current=value;setBusy(value);}
  function following(value:boolean){followRef.current=value;setAutoFollow(value);}
  async function toggleFollowing(){
    const next=!followRef.current;following(next);
    try{setCollection(await api<Collection>('follow',{autoFollow:next}));if(next)await loadChoices('live');}
    catch(e){following(!next);setError((e as Error).message);}
  }
  function changeZoom(value:string){setZoom(Number(value));try{localStorage.setItem('hkjc-chart-zoom',value);}catch{/* Optional preference. */}}
  function clearView(nextMode:string){setState({...blank,mode:nextMode});setSelectedId(null);setHighlights({});setDebug(null);}

  async function loadChoices(nextMode:string,filterDate?:string,background=false) {
    if(background&&busyRef.current)return;
    setError('');working(true);const gen=++generation.current;
    try {
      if(nextMode==='replay') {
        const data=await api<{recordings:{key:string,mode:string,race:Race}[]}>('recordings');if(gen!==generation.current)return;setRecordings(data.recordings);
        setRaceId(data.recordings[0]?.key||'');
      } else {
        const data=await api<Catalog>('meetings?mode='+nextMode+(filterDate?'&date='+encodeURIComponent(filterDate):''));
        if(gen!==generation.current)return;
        if(nextMode==='live')setCatalog(data);
        const previous=controlsRef.current;
        setMeetings(old=>{
          // A manually selected meeting remains selectable while discovery
          // moves on to newer cards; automatic mode follows only fresh cards.
          const retained=old.filter(m=>filterDate?m.date!==filterDate:!followRef.current&&m.date===previous.date&&m.venue===previous.venue);
          const merged=[...data.meetings];
          for(const m of retained)if(!merged.some(n=>n.date===m.date&&n.venue===m.venue))merged.push(m);
          return merged.sort((a,b)=>a.date.localeCompare(b.date)||a.venue.localeCompare(b.venue));
        });
        if(nextMode==='live'&&followRef.current&&!filterDate){
          const suggested=data.meetings.flatMap(m=>m.races).find(r=>r.id===data.recommendedRaceId);
          if(suggested){
            setDate(suggested.date);setVenue(suggested.venue);setRaceId(suggested.id);
            const visible=viewRef.current.state;
            if(visible.mode!=='live'||visible.race?.id!==suggested.id)await connect(suggested.id,'live',suggested);
          }else{
            const m=data.meetings[0];setDate(m?.date||'');setVenue(m?.venue||'ST');setRaceId(m?.races[0]?.id||'');
            clearView('live');
          }
        }else if(filterDate||nextMode!=='live'||!previous.raceId){
          const m=data.meetings[0];setDate(m?.date||filterDate||'');setVenue(m?.venue||'ST');setRaceId(m?.races[0]?.id||'');
          if(filterDate&&m?.races[0])await connect(m.races[0].id,'live',m.races[0]);
        }
        if(!data.meetings.length&&filterDate)setError('HKJC 未提供此日期賽事。已保存資料可用 REPLAY 查看。');
      }
    } catch(e) {if(gen===generation.current)setError(String((e as Error).message));}
    finally{if(gen===generation.current)working(false);}
  }
  useEffect(()=>{
    let active=true;
    void (async()=>{try{await api<Collection>('follow',{autoFollow:true});}catch(e){if(active)setError((e as Error).message);}if(active)void loadChoices('live');})();
    const timer=setInterval(()=>{if(controlsRef.current.mode==='live')void loadChoices('live',undefined,true);},60000);
    return()=>{active=false;clearInterval(timer);++generation.current;};
  },[]);
  useEffect(()=>{
    try{const n=Number(localStorage.getItem('hkjc-chart-zoom'));if(n>=60&&n<=120&&n%10===0)setZoom(n);}catch{/* Keep default. */}
    let active=true,pending=false;
    const heartbeat=async()=>{if(pending)return;pending=true;try{const data=await api<Collection>('collection');if(active)setCollection(data);}catch(e){if(active)setError((e as Error).message);}finally{pending=false;}};
    void heartbeat();const timer=setInterval(heartbeat,25000);
    window.addEventListener('focus',heartbeat);document.addEventListener('visibilitychange',heartbeat);
    return()=>{active=false;clearInterval(timer);window.removeEventListener('focus',heartbeat);document.removeEventListener('visibilitychange',heartbeat);};
  },[]);
  useEffect(()=>{const timer=setInterval(()=>setTick(x=>x+1),1000);return()=>clearInterval(timer);},[]);
  useEffect(()=>{
    if(!race||!state.key)return;
    let active=true;let pending=false;
    const refresh=async()=>{
      if(pending)return;pending=true;
      try{const data=await api(`state?window=${windowSeconds}&baseline_minutes=${baselineMinutes}`);
        if(active&&data.collection)setCollection(data.collection);
        if(active&&data.key===state.key)setState(data);
        else if(active&&!busyRef.current&&followRef.current&&controlsRef.current.mode==='live'&&data.mode==='live'&&data.race){
          setState(data);setDate(data.race.date);setVenue(data.race.venue);setRaceId(data.race.id);setSelectedId(null);setHighlights({});setDebug(null);
        }
      }catch(e){if(active)setError((e as Error).message);}finally{pending=false;}
    };
    void refresh();const timer=setInterval(refresh,stateRefreshMs);return()=>{active=false;clearInterval(timer);};
  },[state.key,race?.id,race?.postTime,state.mode,windowSeconds,baselineMinutes]);

  async function connect(id=raceId,nextMode=mode,identity?:Race) {
    if(!id)return;working(true);setError('');const gen=++generation.current;
    const chosen=identity||meetings.flatMap(m=>m.races).find(r=>r.id===id);
    if(chosen){setDate(chosen.date);setVenue(chosen.venue);setRaceId(chosen.id);}
    if(viewRef.current.state.mode!==nextMode||viewRef.current.state.race?.id!==id)clearView(nextMode);
    try{
      const data=await api('select',{mode:nextMode,raceId:id,date:chosen?.date||date||undefined,venue:nextMode==='live'?(chosen?.venue||venue):undefined,autoFollow:nextMode==='live'?followRef.current:undefined,window:windowSeconds,baseline_minutes:baselineMinutes});
      if(gen!==generation.current)return;
      setState(data);setSelectedId(null);setHighlights({});setDebug(null);
      // Ideal layout keeps the dense table on top; do not auto-scroll to chart on connect.
    }catch(e){if(gen===generation.current)setError((e as Error).message);}
    finally{if(gen===generation.current)working(false);}
  }
  async function mark(r:string) {
    try{const data=await api<{marks:string[]}>('mark',{runner:r,key:state.key});setState(prev=>({...prev,marks:data.marks}));}
    catch(e){setError((e as Error).message);}
  }
  function toggleHighlight(r:string){setHighlights(prev=>cycleHighlight(prev,r));}
  function seek(id:string|null,r?:string) {setSelectedId(id);if(r){toggleHighlight(r);setChartVisit(v=>v+1);}}
  async function importReplay(f:File) {
    working(true);following(false);setError('');const gen=++generation.current;
    try{const data=await api('import',JSON.parse(await f.text()));if(gen!==generation.current)return;setState(data);setMode('replay');setSelectedId(null);setHighlights({});}
    catch(e){if(gen===generation.current)setError((e as Error).message);}finally{if(gen===generation.current)working(false);}
  }
  function chooseRace(r?:Race){following(false);if(r)void connect(r.id,mode,r);}
  const selectDate=(v:string)=>chooseRace(meetings.find(m=>m.date===v)?.races[0]);
  const selectVenue=(v:string)=>chooseRace(meetings.find(m=>m.date===date&&m.venue===v)?.races[0]);
  function changeMode(v:string){following(v==='live');setMode(v);setRaceId('');setMeetings([]);clearView(v);void loadChoices(v);}
  function connectLive(){
    following(true);
    setMode('live');
    const id=controlsRef.current.raceId||raceId;
    if(id)void connect(id,'live');
    else void loadChoices('live');
  }

  const raceIndex=races.findIndex(r=>r.id===raceId);
  const prevRace=raceIndex>0?races[raceIndex-1]:undefined;
  const nextRace=raceIndex>=0&&raceIndex<races.length-1?races[raceIndex+1]:undefined;
  const raceInline=race?[venueName(race),`R${race.no}`,race.distance?.value!=null?`${Math.round(Number(race.distance.value))}m`:'--',race.raceClass||'--',[race.track,race.course].filter(Boolean).join(' ')||null].filter(Boolean).join(' · '):'選擇賽事開始監察';
  const raceTip=race?`${race.date} / ${venueName(race)}${race.venueKind==='overseas'?' · 海外':race.venueKind==='local'?' · 本地':''} / 第 ${race.no} 場 / ${race.name} / ${race.raceClass} / ${fmt(race.distance,0)}m / ${race.track} ${race.course} / ${race.going} / 開跑 ${tm(race.postTime)} / 切片 ${tm(frame?.timestamp)} / ${state.frames.length} snapshots`:'選擇賽事開始監察';
  const sourceAge=state.mode==='live'&&hp.lastUpdate?.value!=null?Math.max(0,Math.floor(Date.now()/1000-hp.lastUpdate.value))+'s':'--';
  const sourceTip=[`狀態 ${healthStatus}`,`flowVerified 需真 probe Exit 0（UI 不宣稱）`,flowStale?'WIN 計算 STALE':flowStatus?.status==='READY'?'WIN 計算 READY':'WIN 計算等待',`來源更新 ${tm(hp.lastUpdate?.value)}`,`延遲 ${fmt(hp.latency,0)} ms`,`資料年齡 ${sourceAge}`,hp.error||(!frame&&race?'等待有效 WIN 更新；未有賠率／彩池時顯示 --':state.mode==='live'?'HKJC public feed · 畫面每 3 秒更新 · 右鍵連接 LIVE':'已保存資料，不更新 source clock'),collection?.status==='ERROR'?`收集失敗：${collection.error}`:collection?.status==='COLLECTING'?`收集中 ${collection.race?.venue} R${collection.race?.no}`:collection?.status==='WAITING'?'等待下一場賽事':null,catalog?.message||null].filter(Boolean).join(' · ');
  const flowChip='flow —'; // chrome honesty: never imply probe flowVerified from MOCK/UI readiness
  return <TooltipProvider><main className="ideal-shell chrome-reclaim">
  <div className="chrome-viewport" data-testid="chrome-viewport">
    <header className="compact-header" data-testid="compact-header">
      <div className="brand-inline" title="HKJC Money Flow · Formula-First"><Activity size={16}/><strong>Money Flow</strong><span className="ver">v0.6</span></div>
      <Tooltip>
        <TooltipTrigger render={<button type="button" className="race-inline" data-testid="race-inline" aria-label="賽事摘要">{raceInline}</button>}/>
        <TooltipContent className="formula-tooltip"><p>{raceTip}</p></TooltipContent>
      </Tooltip>
      <Tooltip>
        <TooltipTrigger render={<button type="button" className={'status compact-status '+healthStatus.toLowerCase()} data-testid="chrome-status" aria-label={`來源狀態 ${healthStatus} ${flowChip}`}><i/>{healthStatus}<span className="flow-chip"> · {flowChip}</span></button>}/>
        <TooltipContent className="formula-tooltip"><p>{sourceTip}</p></TooltipContent>
      </Tooltip>
      {state.mode==='mock'&&<span className="chrome-chip mock" data-testid="mock-banner" title="MOCK · 全部數據為合成測試資料，只用於核對公式同操作。">MOCK</span>}
      {state.mode==='replay'&&<span className="chrome-chip replay" title={`REPLAY · 已保存切片 · 原始來源 ${(frame?.source||'--').toUpperCase()} · 唔代表即時更新`}>REPLAY</span>}
      <div className="race-nav" data-testid="race-nav" aria-label="場次導航">
        <button type="button" className="nav-step" aria-label="上一場" disabled={!prevRace||busy} onClick={()=>prevRace&&chooseRace(prevRace)}><ChevronLeft size={14}/></button>
        {mode==='replay'
          ? <Picker compact label="已保存賽事" value={raceId} options={recordings.map(r=>({value:r.key,label:`${r.race.date} ${venueName(r.race)} R${r.race.no} · ${r.mode}`}))} onChange={setRaceId}/>
          : <Picker compact label="場次" value={raceId} options={races.map(r=>({value:r.id,label:`R${r.no} · ${tm(r.postTime).slice(0,5)}`}))} onChange={v=>chooseRace(races.find(r=>r.id===v))}/>}
        <button type="button" className="nav-step" aria-label="下一場" disabled={!nextRace||busy} onClick={()=>nextRace&&chooseRace(nextRace)}><ChevronRight size={14}/></button>
      </div>
      <div className="chrome-controls" data-testid="chrome-controls">
        <Picker compact label="數據來源" value={mode} onChange={changeMode} options={[{value:'live',label:'HKJC LIVE'},{value:'mock',label:'MOCK · 模擬測試'},{value:'replay',label:'REPLAY · 已保存'}]}/>
        {mode!=='replay'&&<>
          <Picker compact label="賽馬日" value={date} options={[...new Set(meetings.map(m=>m.date))].map(d=>({value:d,label:d}))} onChange={selectDate}/>
          <Picker compact label="場地" value={venue} options={[...new Set(meetings.filter(m=>m.date===date).map(m=>m.venue))].map(v=>({value:v,label:venueName(meetings.find(m=>m.date===date&&m.venue===v))}))} onChange={selectVenue}/>
        </>}
        {mode!=='live'&&<button className="primary chrome-connect" disabled={busy||!raceId} onClick={()=>void connect()}>{busy?<RefreshCw className="spin" size={14}/>:<Radio size={14}/>} {mode==='mock'?'開啟模擬測試':'載入 REPLAY'}</button>}
        {mode==='live'&&<button className={'live-button chrome-follow '+(autoFollow?'active':'')} aria-label="自動跟隨賽事" aria-pressed={autoFollow} onClick={()=>void toggleFollowing()}><i/>{autoFollow?'跟隨':'手動'}</button>}
        <button className="plain icon-button" title="刷新可用賽事" aria-label="刷新可用賽事" disabled={busy} onClick={()=>void loadChoices(mode)}><RefreshCw size={14}/></button>
        <button className="plain icon-button" title="匯入" aria-label="匯入" onClick={()=>file.current?.click()}><Upload size={14}/></button>
        <a className={'plain icon-button '+(!race?'disabled':'')} href="#" role="button" onClick={e=>{e.preventDefault();void saveApiJson('export','hkjc-replay.json').catch(err=>setError((err as Error).message));}} aria-label="匯出切片" title="匯出切片"><ArrowDownToLine size={14}/></a>
        <button className="icon-button" title="公式與設定" aria-label="公式與設定" onClick={()=>setShowSettings(!showSettings)}><CircleHelp size={16}/></button>
      </div>
      <input ref={file} type="file" accept="application/json,.json" hidden onChange={e=>{const f=e.target.files?.[0];if(f)void importReplay(f);e.target.value='';}}/>
    </header>
    {error&&<div className="notice error chrome-error" role="alert">{error}</div>}
    <div className="live-surface chrome-body" data-testid="live-surface" onContextMenu={e=>{e.preventDefault();if(!busy)connectLive();}}>
    {/* ========== TOP: dense horse table ========== */}
    <section className="panel ideal-table-panel" data-testid="ideal-table" aria-label="馬匹數據表">
      <div className="ideal-table-title">大戶投注賽圈：{(hotCircle.length?hotCircle:numberOrder).join(' · ')||'—'}<span className="ideal-table-sub" aria-label="質素圖例"><span className="q-chip q-d">D</span> Direct<span className="q-chip q-f">ƒ</span> Estimated<span className="q-chip q-approx">≈</span> Derived<span className="q-chip q-na">—</span> Unavailable</span></div>
      <div className="ideal-table-scroll">
        <table className="ideal-table">
          <thead>
            <tr className="group-row" aria-hidden="true">
              <th colSpan={5} className="grp grp-id">馬匹</th>
              <th colSpan={1} className="grp grp-notes">筆記</th>
              <th colSpan={3} className="grp grp-structure">結構 Structure</th>
              <th colSpan={3} className="grp grp-confirm">確認 Confirmation</th>
              <th colSpan={5} className="grp grp-double">孖寶 Double</th>
            </tr>
            <tr className="col-row">
              <th className="col-rank">名次</th><th className="col-no">馬號</th><th className="col-name">馬名</th><th className="col-sec">練馬師</th><th className="col-sec col-group-end">騎師</th>
              <th className="col-note col-group-end">筆記</th>
              <th className="col-num col-structure" title="B+D 結構位移 · BarHeight = 100×(CurrentCombinedShare+ε)/(FrozenBaseline+ε) · 顯示值不變">結構</th>
              <th className="col-num">獨贏前</th>
              <th className="col-num col-group-end">檔</th>
              <th className="col-num" title="Pressure = 100 × Lift · 100 = on-expectation（符合預期份額／無超額流入），not 「有熱錢」">熱錢強度</th>
              <th className="col-num">獨贏</th><th className="col-num col-group-end">位置</th>
              <th className="col-num" title="ƒ Estimated exposure from inverse-odds; NOT stake % · 孖下＝第一關（本場×下一場孖寶池）· 隱含賠率自本場 T−17（007 切點）起縮短 %；變長／不變 = --">孖下%</th>
              <th className="col-num" title="ƒ Estimated exposure from inverse-odds; NOT stake % · 孖上＝本場做第二關（上一場×本場孖寶池）· 隱含賠率自上一場 T−17（007 切點）起縮短 %；變長／不變 = --">孖上%</th>
              <th className="col-num" title="≈ DBL(上一關冠軍,i) ÷ 上一關冠軍WIN · <10 取 0.1、≥10 取整（對齊 007）· ≥ = DBL 999 封頂">孖寶冠</th><th className="col-num" title="≈ DBL(上一關亞軍,i) ÷ 上一關亞軍WIN · <10 取 0.1、≥10 取整 · ≥ = DBL 999 封頂">孖寶亞</th><th className="col-num" title="≈ 1 ÷ Σⱼ(1/DBL(j,i))（全部上一關馬，含孖寶扣數，對齊 007）· <100 向上取 0.1、≥100 向上取整 · ≥ = 999 封頂令真值更長">孖寶全</th>
            </tr>
          </thead>
          <tbody>
            {tableOrder.map((r,idx)=>{
              const h=race?.runners.find(x=>String(x.no)===r);
              const win=frame?.flows[r]?.WIN;
              const marked=state.marks.includes(r);
              const pState=pressureStateOf(win,flowStale&&!selectedId);
              // Keep last valid 熱錢強度 on STALE; only blank when never had a value.
              const flowVal=pState==='UNAVAILABLE'?undefined:win?.pressure;
              const intensityGrade=(pState==='STALE'||pState==='UNAVAILABLE'||!win?.grade)?'none':(win.grade||'none');
              const dblUp=dblPctView?.up?.[r];
              const dblDown=dblPctView?.down?.[r];
              const share=shareBarOf(frame,r);
              const structH=shareBarHeight(share);
              const structMetric=structH==null
                ?{value:null,quality:'UNAVAILABLE' as const,reason:share?.barHeight?.reason||'未有結構位移'}
                :{value:structH,quality:(share?.barHeightDisplay?.quality||share?.barHeight?.quality||'DERIVED') as Metric['quality'],reason:share?.barHeight?.reason,source:share?.barHeight?.source};
              const focusSync=debug===r?'focus-sync':'';
              return <tr key={r} data-runner={r} className={[focusSync,debug===r?'debug-row':'',highlightClass(highlights[r]),marked?'marked-row':'',pState==='STALE'?'row-stale':''].filter(Boolean).join(' ')} aria-label={`Horse ${r}${highlights[r]?`, ${highlights[r]} highlight`:''}${debug===r?' · focused':''}`} onClick={()=>{setDebug(r);toggleHighlight(r);}} onMouseEnter={()=>setDebug(r)}>
                <td className="rank col-rank">{idx+1}</td>
                <td className="mono col-no primary-num"><b>{r}</b></td>
                <td className="name-cell col-name">{h?.name||'--'}{h?.scratched?' (退出)':''}</td>
                <td className="col-sec">{h?.trainer||'--'}</td>
                <td className="col-sec col-group-end">{h?.jockey||'--'}</td>
                <td className="note-cell col-note col-group-end"><button type="button" className={'note-mark '+(marked?'on':'')} aria-label={`${marked?'取消筆記':'筆記標記'} ${r}號`} aria-pressed={marked} onClick={e=>{e.stopPropagation();void mark(r);}}>{marked?'✓':''}</button></td>
                <td className="mono col-num col-structure structure-cell primary-num" data-testid="structure-cell" title={share?.barHeight?.reason||'B+D 結構位移 · 100 = 凍結基準綜合份額'}><NumberValue m={structMetric} digits={0}/></td>
                <td className="mono col-num primary-num"><NumberValue m={state.baseline?.winOdds?.[r]}/></td>
                <td className="mono col-num col-group-end"><NumberValue m={drawMetric(h)} digits={0}/></td>
                <td className={['mono','col-num','intensity-cell','primary-num',intensityGrade==='none'?'cell-grade-none':`cell-grade-${intensityGrade}`,pState==='STALE'?'cell-stale':''].join(' ')} data-grade={intensityGrade} data-testid="intensity-cell" title={win?.reason||'Pressure = 100 × Lift · 100 = on-expectation（符合預期份額／無超額流入），not 「有熱錢」'}><NumberValue m={flowVal}/>{pState==='STALE'&&flowVal?.value!=null&&<small className="stale-mark" data-testid="stale-mark"> STALE{staleAgeSec!=null?` · ${staleAgeSec}s`:''}</small>}</td>
                <td className="mono col-num primary-num"><NumberValue m={frame?.runners[r]?.winOdds}/></td>
                <td className="mono col-num primary-num col-group-end"><NumberValue m={frame?.runners[r]?.placeOdds}/></td>
                <td className={['mono','col-num',flowStale&&dblUp?.value!=null?'cell-stale':''].filter(Boolean).join(' ')} data-testid="dbl-up" title="ƒ Estimated exposure from inverse-odds; NOT stake %"><NumberValue m={dblUp} suffix="%" digits={1} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/><small className="quality"> ƒ</small>{flowStale&&dblUp?.value!=null&&<small className="stale-mark"> STALE</small>}</td>
                <td className={['mono','col-num',flowStale&&dblDown?.value!=null?'cell-stale':''].filter(Boolean).join(' ')} data-testid="dbl-down" title="ƒ Estimated exposure from inverse-odds; NOT stake %"><NumberValue m={dblDown} suffix="%" digits={1} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/><small className="quality"> ƒ</small>{flowStale&&dblDown?.value!=null&&<small className="stale-mark"> STALE</small>}</td>
                <td className="mono col-num"><NumberValue m={frame?.incomingDouble?.[r]?.winner} digits={1}/></td>
                <td className="mono col-num"><NumberValue m={frame?.incomingDouble?.[r]?.runnerUp} digits={1}/></td>
                <td className="mono col-num"><NumberValue m={frame?.incomingDouble?.[r]?.all} digits={1}/></td>
              </tr>;
            })}
            {!tableOrder.length&&<tr><td colSpan={17} className="empty-row">連接真實賽事，或選擇 MOCK 核對完整操作。</td></tr>}
          </tbody>
        </table>
      </div>
      {debug&&<div className="debug-summary">#{debug} · {frame?.flows[debug]?.WIN?.pressure?.quality||'UNAVAILABLE'} · Window {fmt(frame?.flows[debug]?.WIN?.windowSeconds,0)}s · {frame?.flows[debug]?.WIN?.reason||'Expected = rolling baseline share × ΔPool；Pressure = 100 × Actual / Expected'}</div>}
    </section>

    {/* ========== MIDDLE: action toolbar ========== */}
    <section className="ideal-toolbar" aria-label="功能列" data-testid="ideal-toolbar">
      <div className="ideal-toolbar-actions">
        <button type="button" className={'tool-btn '+(sortMode==='number'?'active':'')} data-testid="sort-number" onClick={()=>applySort('number')}>馬號</button>
        <button type="button" className={'tool-btn '+(sortMode==='odds'?'active':'')} data-testid="sort-odds" onClick={()=>applySort('odds')}>獨贏</button>
        <button type="button" className={'tool-btn '+(sortMode==='baseline'?'active':'')} data-testid="sort-baseline" disabled={!baselineOddsReady} title={baselineOddsReady?'按獨贏前（T−15／Expected baseline）賠率由低至高':'未有獨贏前基準，唔可用'} onClick={()=>applySort('baseline')}>獨贏前</button>
        <button type="button" className="tool-btn icon" title="筆記提示（占位）" aria-label="筆記提示"><Lightbulb size={14}/></button>
        <button type="button" className={'tool-btn icon'+(showAudit?' active':'')} title="數值核對" aria-label="數值核對" aria-pressed={showAudit} onClick={()=>setShowAudit(v=>!v)}><Check size={14}/></button>
        <button type="button" className={'tool-btn icon'+((Object.keys(highlights).length===0)?' is-disabled':'')} data-testid="clear-highlights" disabled={Object.keys(highlights).length===0} title={Object.keys(highlights).length===0?'冇高亮可清除':'清除全部馬匹高亮（唔刪賽事／重播／筆記／數據）'} aria-label="清除全部高亮" onClick={()=>setHighlights({})}><Trash2 size={14}/></button>
        <Picker compact label="圖表比例" value={String(zoom)} options={[60,70,80,90,100,110,120].map(n=>({value:String(n),label:`${n}%`}))} onChange={changeZoom}/>
        <span className="chrome-collect" data-testid="collection-status">{collection?.status==='ERROR'?`連接失敗：${collection.error}`:collection?.status==='COLLECTING'?`收集中 ${collection.race?.venue} R${collection.race?.no}`:collection?.status==='WAITING'?'等待下一場賽事':'待機'}</span>
      </div>
      <div className="hatch-legend" data-testid="hatch-legend" aria-label="異常級別圖例" title="固定異常級別，不代表投注概率">
        <span className="hatch grade-none-hatch"><i/>正常</span>
        <span className="hatch grade-low-hatch"><i/>輕微異常</span>
        <span className="hatch grade-mid-hatch"><i/>異常</span>
        <span className="hatch grade-high-hatch"><i/>非常異常</span>
        <span className="quality-strip" title="資料質素（非 hatch）">ƒ估算 · ≈衍生 · —缺 · 綜合唔顯示 D</span>
      </div>
    </section>

    {/* ========== BOTTOM: chart + spectrum ========== */}
    <section className="workspace" style={{zoom:zoom/100}} data-zoom={zoom}>
      <section className="panel chart-panel" ref={chartRef} aria-label="熱錢棒形圖"><div className="panel-title chart-header-dense"><div className="chart-title-row"><h3 data-testid="hotmoney-title">{race?`R${race.no} 熱錢圖`:'熱錢圖'} <span>100 = 基準結構（凍結綜合份額）</span></h3>
        <div className="chart-pool combined-badge" data-testid="combined-badge" title="綜合壓力質素：≈ 衍生／ƒ 估算／— 缺；永不顯示 D">資料質素 <strong>{combinedBadgeOf(frame, numberOrder, flowStale&&!selectedId)}</strong></div>
        <div className="chart-pool" data-testid="race-total-investment" title="真正總投注金額 = 本場所有 race-scoped poolInvs.investment 之和（含 TCE/TRI/FF/QTT/CWA/…；多關池於本場在 leg list 時計入）。缺則省略；全缺顯示 --。DIRECT when summing reported investments."><span>真正總投注金額</span><strong><NumberValue m={frame?.raceTotalInvestment??{value:null,quality:'UNAVAILABLE',reason:'未有彩池投注總額'}} digits={0}/></strong></div>
        <span className="small-chip">{windowSeconds}s</span>
        <button type="button" className={'small-chip flow-trial-toggle'+(flowTrialOn?' on':'')} data-testid="flow-trial-toggle" aria-pressed={flowTrialOn} title="007式流向（試驗）：V1 A_new · ESTIMATED · 未鎖定（預設關；關閉時唔計算、唔顯示）" onClick={()=>setFlowTrialOn(v=>!v)}>007式流向（試驗）{flowTrialOn?' ▾':' ▸'}</button></div></div>
        <div className={'flow-readiness '+(flowStale?'waiting':flowStatus?.status==='READY'?'ready':'waiting')} role="status" data-testid="flow-readiness">
          <strong>{flowStale?'WIN 計算資料已過期，等待新更新':flowStatus?.message||(race?'已連接賽事，等待首個有效 WIN 更新':'等待連接賽事')}</strong>
          {selectedId&&<strong data-testid="historical-label">歷史切片 · 非即時 · {tm(frame?.timestamp)}</strong>}
          <span>{frame?`切片 ${tm(frame.timestamp)} · `:''}{flowStatus?.calculationTime?`WIN 計算時間 ${tm(flowStatus.calculationTime)} · `:''}{flowStatus?.quality==='ESTIMATED'?'ESTIMATED · 由真彩池與賠率推算':''}</span>
          {flowStatus?.alignment==='OBSERVED_HISTORY'&&<span>已配對之前收到的真賠率（{tm(flowStatus.oddsTime)}）；棒下保留本切片最新 WIN 報價。</span>}
          {flowStatus?.quoteTime!=null&&<span>WIN 報價 {tm(flowStatus.quoteTime)} · WIN 彩池 {tm(flowStatus.investmentTime)} · 有公布彩池總額不代表已有有效資金流。</span>}
          {latestReady&&(latestReady.id!==frame?.id||flowStale)&&<button className="plain ready-replay" onClick={()=>{seek(latestReady.id);setChartVisit(v=>v+1);}}>回看上次有效棒圖 · {tm(latestReady.timestamp)}</button>}
          {flowStatus?.quality==='ESTIMATED'&&<small>逐馬金額由彩池與賠率估算；賠率變化比例相同可令多匹馬棒高相同。棒高按綜合份額相對凍結基準，唔等 Pressure READY。本切片未計出時保留上次有效棒高（LIVE tip 唔使回帶）；STALE 同樣保留並標 STALE；從未有有效份額時才顯示 --。</small>}
          {state.mode==='live'&&<small>Q / QP / DBL 熱錢等待可靠組合金額；目前顯示 --。</small>}
        </div>
        <div className="sort-info" data-testid="sort-info"><span>{sortMode==='number'?'馬號 小 → 大':sortMode==='baseline'?'獨贏前 小 → 大（凍結）':'獨贏 小 → 大（凍結；唔跟即時賠率重排）'}</span><span>棒高 = 綜合份額÷凍結基準 · WIN 1.0 · QIN/QPL/FCT 0.75 · Pressure 僅徽章</span></div>
        <div className="chart-scroll"><div className="chart" style={{minWidth:Math.max(420,order.length*48)}}>
          <div className="chart-scale" style={{height:barZoneH}}><span>{chartTop}</span><span>100</span><span>0</span></div>
          <div className="baseline-rule" style={{bottom:barFooterH+barZoneH*100/chartTop}}><span>100</span></div>
          <div className="bars" ref={barsMeasureRef} data-testid="bars-measure">
          {order.map(r=>{
            const h=race?.runners.find(h=>String(h.no)===r);
            const share=shareBarOf(frame,r);
            const height=shareBarHeight(share);
            const combined=combinedPressureOf(frame,r,flowStale&&!selectedId);
            const pressureBadge=pressureOverlayOf(frame,r,flowStale&&!selectedId);
            const research=frame?.research?.[r];const marked=state.marks.includes(r);
            const isStale=flowStale&&!selectedId || pressureBadge.state==='STALE' || !!share?.keptFromPrior;
            // Bars follow combined-share vs frozen baseline — never clear waiting for Pressure.
            const cleared=height==null;
            const overflow=height!=null&&height>chartTop;
            const qBadge=shareBarBadge(share);
            const baselineStatus=share?.baselineStatus||state.shareBaseline?.status||'WAITING';
            const stateText=isStale?(staleAgeSec!=null?`STALE · ${staleAgeSec}s`:'STALE')
              :cleared?`-- ${baselineStatus==='WAITING'?'NO BASELINE':'UNAVAILABLE'}`
              :share?.provisional||baselineStatus==='PROVISIONAL'?'PROVISIONAL BASELINE'
              : state.mode==='replay'||selectedId?'REPLAY':'LIVE';
            const qualityWord=qBadge==='ƒ'?'Estimated combined share':qBadge==='≈'?'Derived combined share':'Unavailable';
            const marker=(!cleared&&!isStale)?poolMarker(frame,r):null;
            // Hatch still mirrors Pressure grade when ready; otherwise none.
            const hatchClass=!cleared&&!isStale&&pressureBadge.ready&&combined.grade==='brown'?'hatch-strong'
              :!cleared&&!isStale&&pressureBadge.ready&&combined.grade==='red'?'hatch-mid'
              :!cleared&&!isStale&&pressureBadge.ready&&combined.grade==='green'?'hatch-soft':'';
            const partsTip=Object.entries(share?.poolParts||{}).map(([pool,meta])=>{
              const part=meta as {weight?:number;quality?:string;share?:Metric};
              const w=part.weight;
              const q=part.quality;
              const sv=part.share?.value;
              return `${pool}${sv!=null?` ${(sv*100).toFixed(1)}%`:''}×${w??'?'}${q==='ESTIMATED'?' ƒ':''}`;
            }).join(' · ')||'—';
            const heightMetric=cleared
              ?{value:null,quality:'UNAVAILABLE' as const,reason:stateText}
              :{value:height,quality:(share?.barHeightDisplay?.quality||share?.barHeight?.quality||'DERIVED') as Metric['quality'],reason:share?.barHeight?.reason,source:share?.barHeight?.source};
            const uncapped=share?.barHeight?.value;
            return <div key={r} className={['runner',debug===r?'focus-sync':'',highlightClass(highlights[r]),isStale?'runner-stale':''].filter(Boolean).join(' ')} data-runner={r} data-testid={'combined-bar-'+r} data-stale={isStale?'1':'0'} data-baseline={baselineStatus} onMouseEnter={()=>setDebug(r)}>
              <div className="bar-zone" data-testid="win-pressure-bar" data-pool-bar={'combined-bar-'+r} data-active-pool="COMBINED">
                <span className="bar-number"><NumberValue m={heightMetric} digits={0}/>{overflow?' ↑':''}</span>
                <span className="pressure-state" data-testid="pressure-state">{stateText}</span>
                <span className="pressure-overlay" data-testid="pressure-overlay" title={pressureBadge.ready?`Pressure ${pressureBadge.value?.toFixed(1)}（次要）`:'Pressure 未就緒（棒高仍顯示）'}>{pressureBadge.text}</span>
                <span className="quality-badge" data-testid="quality-badge" title={qualityWord}>{qBadge}</span>
                {marker&&<span className="pool-marker" title={`${marker} 異常／偏離`}>{marker}</span>}
                <Tooltip><TooltipTrigger render={<button aria-label={`Horse ${r}, Structure bar ${height??'--'}, baseline ${baselineStatus}, Pressure ${pressureBadge.text}, Quality ${qualityWord}${highlights[r]?`, ${highlights[r]} highlight`:''}`} className={'bar '+(marked?'marked ':'')+(height==null?'missing ':'')+(isStale?'stale ':'')+hatchClass} data-grade={(cleared||isStale||!pressureBadge.ready)?'none':(combined.grade||'none')} data-hatch={hatchClass||'none'} data-stale={isStale?'1':'0'} style={{['--bar-h' as string]:`${height==null?0:Math.max(5,barZoneH*Math.min(height,chartTop)/chartTop)}px`,height:'var(--bar-h)' as string,transformOrigin:'bottom center'}} onClick={()=>{setDebug(r);toggleHighlight(r);}} onMouseEnter={()=>setDebug(r)} onFocus={()=>setDebug(r)} data-testid={'bar-'+r} data-pool-bar={'combined-bar-'+r} key={'bar-btn-'+r}/>}/>
                <TooltipContent className="formula-tooltip"><strong>#{r} {h?.name} · 熱錢圖（綜合份額÷基準） · {stateText} · {share?.barHeight?.quality||'UNAVAILABLE'}</strong><p>BarHeight {cleared?'--':(uncapped!=null?uncapped.toFixed(1):fmt(heightMetric,1))} · 顯示 {cleared?'--':(height!=null?height.toFixed(0):'--')}（clamp 50–200）· 100 = 凍結基準綜合份額（結構位移／not 「有熱錢」／not 總投注）{isStale?' · 保留上次有效高度（非即時）':''}</p><p>Current {(share?.currentShare?.value!=null?(share.currentShare.value*100).toFixed(2)+'%':'--')} · Baseline {(share?.baselineShare?.value!=null?(share.baselineShare.value*100).toFixed(2)+'%':'--')} · ε=0.0025</p><p>池份額：{partsTip}</p><p>Pressure（次要）{pressureBadge.ready?fmt({value:pressureBadge.value,quality:'DERIVED'},1):'—'} · {pressureBadge.text}</p><p>B {fmt(research?.B,3)} · H ln(1+B) {fmt(research?.H,3)}</p><p>{share?.barHeight?.reason||'未有綜合份額棒高'}</p></TooltipContent></Tooltip>
              </div>
              <button className={'mark-button '+(marked?'marked':'')} aria-label={`${marked?'取消':'新增'} ${r}號 +1 標記`} aria-pressed={marked} onClick={()=>void mark(r)}><b>{r}</b><span>{marked?'✓ +1':'+1'}</span></button>
              <div className="odds-line axis-win"><small>獨贏</small><NumberValue m={frame?.runners[r]?.winOdds}/></div>
              <div className={['dbl-line','axis-dbl-up',flowStale?'axis-stale':''].filter(Boolean).join(' ')} data-testid="axis-dbl-up" title="ƒ Estimated exposure from inverse-odds; NOT stake % · 孖下＝第一關（engine dbl_up）"><small>孖下{flowStale&&dblPctView?.up?.[r]?.value!=null?' · STALE':''}</small><NumberValue m={dblPctView?.up?.[r]} suffix="%" digits={0} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/></div>
              <div className={['dbl-line','axis-dbl-down',flowStale?'axis-stale':''].filter(Boolean).join(' ')} data-testid="axis-dbl-down" title="ƒ Estimated exposure from inverse-odds; NOT stake % · 孖上＝本場做第二關（上一場×本場孖寶池）"><small>孖上{flowStale&&dblPctView?.down?.[r]?.value!=null?' · STALE':''}</small><NumberValue m={dblPctView?.down?.[r]} suffix="%" digits={0} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/></div>
            </div>;
          })}</div>
          {!order.length&&<div className="empty">連接真實賽事，或選擇 MOCK 核對完整操作。</div>}
        </div></div>
        {flowTrialOn&&<FlowTrialPanel frameId={trialFrameId} stateKey={state.key} framesLen={state.frames.length} tipId={state.frames.at(-1)?.id} order={order} highlights={highlights} liveStale={flowStale&&!selectedId}/>}
        <div className="replay-control"><div className="replay-heading"><strong>{selectedId||state.mode==='replay'?<span data-testid="replay-badge">REPLAY</span>:'即時'} <span data-testid="snapshot-time">{tm(frame?.timestamp)}</span></strong><div><button className="primary chart-connect" disabled={busy} onClick={connectLive}>{busy?<RefreshCw className="spin" size={16}/>:<Radio size={16}/>} 連接 LIVE</button><button className="icon-button" aria-label="上一切片" disabled={sliderIndex<=0} onClick={()=>seek(replayFrames[sliderIndex-1]?.id)}><ChevronLeft size={17}/></button><button className="icon-button" aria-label="下一切片" disabled={sliderIndex<0||sliderIndex>=replayFrames.length-1} onClick={()=>seek(replayFrames[sliderIndex+1]?.id)}><ChevronRight size={17}/></button><button className={'live-button '+(!selectedId?'active':'')} onClick={()=>{setSelectedId(null);setHighlights({});}}><i/>{state.mode==='live'?'LIVE':'最新'}</button></div></div>
          <Slider aria-label="時間切片" min={0} max={Math.max(1,replayFrames.length-1)} value={[Math.max(0,sliderIndex)]} disabled={!replayFrames.length} onValueChange={v=>{const target=replayAt(replayFrames,Array.isArray(v)?v[0]:v);if(target)seek(target.id);}}/>
          <div className="timeline-label"><span>{lateFrames.length?'T−5':'已收集'} · {lateFrames.length&&race?tm(race.postTime-300):tm(replayFrames[0]?.timestamp)}</span><span>{sliderIndex<0&&selectedId?'歷史切片 · 早於 slider 範圍':`${replayFrames.length} 個已保存切片`}</span><span>{lateFrames.length?'OFF':tm(replayFrames.at(-1)?.timestamp)}</span></div>
        </div>
      </section>
      <aside className="panel spectrum-panel"><div className="panel-title spectrum-header-dense"><div><h3>WQQP%頻譜 <span>−1→15</span></h3></div></div>
        <div className="spectrum-scroll"><div className="spectrum-grid" style={{gridTemplateColumns:'28px repeat(17, minmax(12px, 1fr))'}}>
          <div className="spectrum-label">#</div>{Array.from({length:17},(_,d)=><div key={d} className="minute">{d-1}</div>)}
          {order.flatMap(r=>{
            const horse=race?.runners.find(h=>String(h.no)===r);
            return [<button type="button" className={['horse-row',debug===r?'focus-sync':'',highlightClass(highlights[r])].filter(Boolean).join(' ')} key={r+'name'} aria-label={`Horse ${r}${highlights[r]?`, ${highlights[r]} highlight`:''}${debug===r?' · focused':''}`} title={`Click to cycle highlight for horse ${r}`} onClick={()=>{setDebug(r);toggleHighlight(r);}} onMouseEnter={()=>setDebug(r)}><b>{r}</b></button>,
              ...Array.from({length:17},(_,d)=>{
                const engineIndex=16-d;const mark=d-1;
                const cell=state.spectrum[r]?.[engineIndex];const selected=frame&&cell&&frame.timestamp>=cell.start&&frame.timestamp<cell.start+60;
                return <div className={'spectrum-cell '+(selected?'selected-minute':'')} key={r+'-'+mark}>
                  {['WIN','QIN','QPL'].map(p=>{const layer=cell?.layers[p];return <button key={p} aria-label={`${r}號 T${mark} ${poolLabel[p]} ${layer?.grade||'unavailable'}${highlights[r]?` · ${highlights[r]} highlight`:''}`} title={`${horse?.name} · T${mark} · ${poolLabel[p]} ${layer?.grade||'UNAVAILABLE'}\nPressure ${fmt(layer?.pressure)} · ${tm(layer?.timestamp)}`} className={'band '+(layer?.grade||'unavailable')} disabled={!layer?.frameId} onClick={()=>{const target=spectrumTarget(state.spectrum,r,engineIndex,p);if(target)seek(target.id,target.runner);}}><span>{poolLabel[p]}</span></button>;})}
                </div>;
              })];
          })}
        </div></div>
        {!race&&<div className="empty compact">先選擇賽事，再開始接收分鐘切片。</div>}
        <div className="legend density-legend" data-testid="spectrum-grade-legend" aria-label="頻譜異常級別圖例（非百分比濃度）" title="異常級別 · 不代表投注概率">
          <span><i className="leg-w"/>W</span><span><i className="leg-q"/>Q</span><span><i className="leg-qp"/>QP</span>
          <span><i className="unavailable"/>缺資料</span>
          <span><i className="normal"/>正常</span>
          <span><i className="green"/>輕微異常</span>
          <span><i className="red"/>異常</span>
          <span><i className="brown"/>非常異常</span>
        </div>
        <div className="spectrum-tabs" role="tablist" aria-label="頻譜分頁">
          <button role="tab" type="button" aria-selected={true} className="spectrum-tab active" disabled>WQQP%</button>
        </div>
      </aside>
    </section>

    </div>{/* chrome-body */}
  </div>{/* chrome-viewport */}

    <details className="panel details-panel advanced-audit" open={showAudit} onToggle={e=>setShowAudit((e.target as HTMLDetailsElement).open)}>
      <summary className="panel-title"><div><h3>數值核對 <span>ADVANCED AUDIT</span></h3><p>進階公式欄 · Share / Actual / Expected / Lift / Research · 不影響主表</p></div><span className="quality-key">D Direct <b>·</b> ƒ Estimated <b>·</b> ≈ Derived <b>·</b> — Unavailable</span></summary>
      <Table><TableHeader><TableRow>{['馬匹','獨贏前','WIN','PLA','孖寶冠軍','孖寶亞軍','孖寶全部','孖下%','孖上%','孖寶動量','Share baseline','Actual','Expected','Excess','Lift','Pressure','A 份額點','B log2','H ln(1+B)','C tilt','Self','Cross','DBL Structure Ratio'].map(c=><TableHead key={c}>{c}</TableHead>)}</TableRow></TableHeader><TableBody>
      {numberOrder.map(r=>{const h=race?.runners.find(h=>String(h.no)===r);const f=frame?.flows[r]?.WIN;const research=frame?.research?.[r];return <TableRow key={r} className={[debug===r?'debug-row':'',highlightClass(highlights[r])].filter(Boolean).join(' ')} aria-label={`Horse ${r}${highlights[r]?`, ${highlights[r]} highlight`:''}`} onClick={()=>{setDebug(r);toggleHighlight(r);}}><TableCell><b>#{r}</b> {h?.name}{h?.scratched?' (退出)':''}</TableCell>
        <TableCell><NumberValue m={state.baseline?.winOdds?.[r]}/></TableCell>
        <TableCell><NumberValue m={frame?.runners[r]?.winOdds}/></TableCell><TableCell><NumberValue m={frame?.runners[r]?.placeOdds}/></TableCell>
        <TableCell><NumberValue m={frame?.incomingDouble?.[r]?.winner} digits={1}/></TableCell>
        <TableCell><NumberValue m={frame?.incomingDouble?.[r]?.runnerUp} digits={1}/></TableCell>
        <TableCell><NumberValue m={frame?.incomingDouble?.[r]?.all} digits={1}/></TableCell>
        <TableCell title="ƒ Estimated exposure from inverse-odds; NOT stake %"><NumberValue m={dblPctView?.up?.[r]} suffix="%" digits={1} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/><small className="quality"> ƒ</small></TableCell>
        <TableCell title="ƒ Estimated exposure from inverse-odds; NOT stake %"><NumberValue m={dblPctView?.down?.[r]} suffix="%" digits={1} title="ƒ Estimated exposure from inverse-odds; NOT stake %"/><small className="quality"> ƒ</small></TableCell>
        <TableCell data-testid="dbl-momentum" title={f?.dbl_matrix_coverage!=null?`DBL coverage ${(f.dbl_matrix_coverage*100).toFixed(0)}% · Derived exposure change (not HKD)`:'Derived exposure change (not HKD)'}><details><summary>動量 ≈</summary><NumberValue m={f?.dbl_signed_momentum==null?{value:null,quality:'UNAVAILABLE',reason:'未有孖寶 exposure'}:{value:f.dbl_signed_momentum,quality:'DERIVED',reason:'signed momentum',source:'DBL UP−DOWN Δ'}} digits={0}/></details></TableCell>
        <TableCell><NumberValue m={f?.share?{...f.share,value:f.share.value==null?null:f.share.value*100}:undefined} suffix="%" digits={2}/></TableCell>
        {['actual','expected','excess','lift','pressure'].map(k=><TableCell key={k}><NumberValue m={f?.[k] as Metric} digits={k==='lift'?3:0}/></TableCell>)}
        <TableCell><NumberValue m={research?.A} digits={2}/></TableCell>
        <TableCell><NumberValue m={research?.B} digits={3}/></TableCell>
        <TableCell><NumberValue m={research?.H} digits={3}/></TableCell>
        <TableCell><NumberValue m={research?.C} digits={3}/></TableCell>
        <TableCell><NumberValue m={research?.Self} digits={3}/></TableCell>
        <TableCell><NumberValue m={research?.Cross} digits={1}/></TableCell>
        <TableCell><NumberValue m={frame?.double[r]?.pressure} suffix="×" digits={2}/></TableCell>
      </TableRow>;})}</TableBody></Table>
    </details>
    {showSettings&&<section className="panel settings"><h3>公式與資料設定</h3><div className="settings-controls"><label>Rolling window（秒）<input aria-label="Rolling window 秒" type="number" min="10" max="300" value={windowSeconds} onChange={e=>setWindowSeconds(Math.min(300,Math.max(10,Number(e.target.value))))}/></label><label>排序基準（開跑前分鐘）<input aria-label="排序基準分鐘" type="number" min="1" max="30" value={baselineMinutes} onChange={e=>setBaselineMinutes(Math.min(30,Math.max(1,Number(e.target.value))))}/></label><label>指定其他日期<input type="date" aria-label="指定其他日期" onChange={e=>{if(e.target.value){following(false);setMode('live');void loadChoices('live',e.target.value);}}}/></label><a className="plain" href="#" role="button" onClick={e=>{e.preventDefault();void saveApiJson('raw','hkjc-raw-source.json').catch(err=>setError((err as Error).message));}}><ArrowDownToLine size={16}/>Raw source</a></div>
      <p>棒圖用原本資金壓力 Pressure = 100 × Lift；100 = on-expectation（符合窗口開始時份額／無超額流入），唔等於「有熱錢」。標尺固定 0–200，100 有基準線。v0.3.1 嘅 B／H=ln(1+B) 只放核對表，唔做主棒。</p>
      <p>WIN 只有總彩池與賠率時：Bᵢ = Pool × (1/oddsᵢ) / Σ(1/odds)，所有資金計算標示 ESTIMATED。Q / QP 只接受完整直接組合金額，每對各分一半；不以 QP odds 反推金額。</p>
      <p>異常門檻係 v0.5 固定規則，未經歷史校準：ΔPool ≥ $10,000、Expected ≥ $1,000；綠 Excess ≥ $10,000 且 Lift ≥ 1.2；紅 ≥ $50,000 / 1.5；啡 ≥ $150,000 / 2。低流動性保留 Pressure 原值但不觸發異常。</p>
      <p>DBL Structure Ratio（內部別名 DBLPressure）= 下一孖寶第一關份額 ÷ 同一切片 WIN 份額（1.00× 為中性）；需 DIRECT 矩陣，WIN baseline 可能為 ESTIMATED。冠／亞價格只顯示明確來源；未取得組合 investment 或可靠價格時顯示 --。</p>
    </section>}
    <footer><span>HKJC Money Flow Tool · v0.6 Formula-First Live Prototype</span><span>本地記錄 · 香港時間 · 無自動下注</span></footer>
  </main></TooltipProvider>;
}
