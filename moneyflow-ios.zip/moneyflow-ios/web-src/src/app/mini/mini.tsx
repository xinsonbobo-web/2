'use client';

// /mini (2026-09-28, mini2): 馬、獨贏、獨贏前、孖寶冠／亞／全 only — phone portrait first.
// Reads GET /api/mini (latest stored snapshot of the backend's selected race; 獨贏前 = the main page's
// engine.baseline() at 「排序基準（開跑前分鐘）」, default 15, override with /mini?base=N; no new formula, see
// backend/mini.py and docs/FORMULAS.md §14). Missing → "--"; nothing copied forward; STALE after 45 s.
import { useCallback, useEffect, useRef, useState } from 'react';
import type { Metric, Meeting, Race, Catalog, Collection } from '@/lib/types';
import { apiCall } from '@/backend/client';

type MiniRow={no:number,name:string,scratched:boolean,winOdds:Metric,winOddsBefore:Metric,dblWinner:Metric,dblRunnerUp:Metric,dblAll:Metric};
type MiniRace={id:string,date:string,venue:string,venueKind?:string,venueLabel?:string,no:number,name?:string,raceClass?:string,distance?:Metric,postTime?:number};
type MiniState={mode:string,key?:string|null,race:MiniRace|null,health:{status:string,error?:string|null,lastUpdate?:Metric,lastReceived?:Metric,latency?:Metric},
  collection?:Collection,snapshotCount:number,frame:{id:string,timestamp:number,sourceTimestamp?:number,receivedAt?:number,source?:string}|null,
  baseline?:{status:string,timestamp?:number|null,target?:number|null,minutes:number}|null,freshSeconds:number,rows:MiniRow[]};
type Recording={key:string,mode:string,race:Race};
type MeetingOption={value:string,label:string,mode:'live'|'replay',date:string,venue:string,races:{id:string,no:number,label:string}[]};

// Same cadence as the main page (terminal.tsx stateRefreshMs = 3000; catalog every 60 s).
const REFRESH_MS=3000;
const CATALOG_MS=60000;
const STALE_SECONDS=45;
// Main page default for 「排序基準（開跑前分鐘）」 (terminal.tsx baselineMinutes / backend DEFAULTS = 15).
const DEFAULT_BASE_MINUTES=15;
/** /mini?base=N (1–30, the main page's settings link passes its current value); otherwise 15. */
function baseMinutes(){
  if(typeof window==='undefined')return DEFAULT_BASE_MINUTES;
  // iOS app: hash route #/mini?base=N (single-file bundle); plain ?base=N still accepted.
  const hashQuery=window.location.hash.includes('?')?window.location.hash.slice(window.location.hash.indexOf('?')+1):'';
  const raw=new URLSearchParams(hashQuery).get('base')??new URLSearchParams(window.location.search).get('base');
  const n=raw!=null&&/^\d{1,2}$/.test(raw)?Number(raw):NaN;
  return n>=1&&n<=30?n:DEFAULT_BASE_MINUTES;
}

const venueName=(v?:{venue?:string,venueLabel?:string})=>v?.venueLabel||(v?.venue==='ST'?'沙田':v?.venue==='HV'?'跑馬地':v?.venue||'--');
const hkTime=(t?:number|null,withSeconds=true)=>t==null?'--':new Date(t*1000).toLocaleTimeString('en-GB',{timeZone:'Asia/Hong_Kong',hour12:false,...(withSeconds?{}:{hour:'2-digit',minute:'2-digit'})});
const shortDate=(d?:string)=>d?d.slice(5).replace('-','/'):'--';
const hkDate=(t:number)=>new Date(t*1000).toLocaleDateString('en-CA',{timeZone:'Asia/Hong_Kong'});
/** Age of the source clock: 45s / 12分 / 9小時 (display only). */
const ageText=(s:number)=>s<120?`${s}s`:s<3600?`${Math.floor(s/60)}分`:s<172800?`${Math.floor(s/3600)}小時`:`${Math.floor(s/86400)}日`;

async function api<T>(path:string,body?:unknown):Promise<T>{
  // iOS app: the former Python /api is served in-page (src/backend); HKJC requests go through the native bridge.
  return apiCall<T>(path,body);
}

/** Odds display (display only, value untouched): below 10 always 1 decimal like HKJC (7 → 7.0, 2.3 → 2.3);
 *  10 and above as the main page (integer when whole: 12, 99; otherwise ≤1 decimal: 18.2). */
export function oddsText(value?:number|null){
  if(value==null||!Number.isFinite(value))return '--';
  return value<10?value.toLocaleString('en-HK',{minimumFractionDigits:1,maximumFractionDigits:1})
    :value.toLocaleString('en-HK',{maximumFractionDigits:1});
}
function tip(m?:Metric,extra=''){return [m?.quality||'UNAVAILABLE',m?.source,m?.reason,extra].filter(Boolean).join(' · ');}

function Cell({m,kind,testid}:{m?:Metric,kind:'odds'|'before'|'dbl',testid:string}){
  const missing=!m||m.value==null;
  const ge=!missing&&m?.bound==='GE';
  const text=missing?'--':oddsText(m!.value);
  const extra=ge?'≥：HKJC DBL 999 封頂，真值可能更長':'';
  return <td className={`mini-num mini-${kind}${missing?' is-missing':''}`} data-testid={testid} title={tip(m,extra)}>
    {ge&&<span className="mini-ge">≥</span>}{text}
  </td>;
}

export default function Mini(){
  const [state,setState]=useState<MiniState|null>(null);
  const [meetings,setMeetings]=useState<Meeting[]>([]);
  const [recommended,setRecommended]=useState<string|null>(null);
  const [catalogMessage,setCatalogMessage]=useState('');
  const [recordings,setRecordings]=useState<Recording[]>([]);
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  const [,setTick]=useState(0);
  const booted=useRef(false);
  const busyRef=useRef(false);
  const rootRef=useRef<HTMLDivElement>(null);
  const headRef=useRef<HTMLElement>(null);
  // Sticky table header sits right under the sticky page header (height varies with banner / wrap).
  useEffect(()=>{
    const head=headRef.current,root=rootRef.current;
    if(!head||!root)return;
    const set=()=>root.style.setProperty('--mini-head-h',`${Math.round(head.getBoundingClientRect().height)}px`);
    set();const ro=new ResizeObserver(set);ro.observe(head);return()=>ro.disconnect();
  },[]);

  const refresh=useCallback(async()=>{
    try{const data=await api<MiniState>(`mini?baseline_minutes=${baseMinutes()}`);setState(data);setError('');return data;}
    catch(e){setError((e as Error).message);return null;}
  },[]);
  const loadCatalog=useCallback(async()=>{
    try{const data=await api<Catalog>('meetings?mode=live');setMeetings(data.meetings||[]);setRecommended(data.recommendedRaceId||null);setCatalogMessage(data.message||'');return data;}
    catch{return null;}
  },[]);
  const loadRecordings=useCallback(async()=>{
    try{const data=await api<{recordings:Recording[]}>('recordings');setRecordings(data.recordings||[]);}catch{/* optional list */}
  },[]);

  useEffect(()=>{
    let active=true;
    void (async()=>{
      const [first,catalog]=await Promise.all([refresh(),loadCatalog()]);
      void loadRecordings();
      // Nothing selected yet (fresh start): behave like the main page and follow the recommended race.
      if(active&&!booted.current&&first&&!first.race){
        booted.current=true;
        try{
          const id=catalog?.recommendedRaceId;
          const race=catalog?.meetings.flatMap(m=>m.races).find(r=>r.id===id);
          if(race)await api('select',{mode:'live',raceId:race.id,date:race.date,venue:race.venue,autoFollow:true});
          else await api('follow',{autoFollow:true});
          await refresh();
        }catch(e){setError((e as Error).message);}
      }
      booted.current=true;
    })();
    const timer=setInterval(()=>{if(!busyRef.current)void refresh();},REFRESH_MS);
    const cat=setInterval(()=>void loadCatalog(),CATALOG_MS);
    const clock=setInterval(()=>setTick(x=>x+1),1000);
    const wake=()=>{if(document.visibilityState==='visible')void refresh();};
    document.addEventListener('visibilitychange',wake);
    return()=>{active=false;clearInterval(timer);clearInterval(cat);clearInterval(clock);document.removeEventListener('visibilitychange',wake);};
  },[refresh,loadCatalog,loadRecordings]);

  async function select(body:Record<string,unknown>){
    busyRef.current=true;setBusy(true);setError('');
    try{await api('select',body);await refresh();}
    catch(e){setError((e as Error).message);}
    finally{busyRef.current=false;setBusy(false);}
  }

  // Meeting options: live catalog first, then saved REPLAY recordings grouped by date + venue.
  const options:MeetingOption[]=[];
  for(const m of meetings){
    options.push({value:`live|${m.date}|${m.venue}`,label:`${shortDate(m.date)} ${venueName(m)}`,mode:'live',date:m.date,venue:m.venue,
      races:m.races.map(r=>({id:r.id,no:r.no,label:`R${r.no} · ${hkTime(r.postTime,false)}`}))});
  }
  const replayGroups=new Map<string,MeetingOption>();
  for(const rec of recordings){
    const value=`replay|${rec.race.date}|${rec.race.venue}`;
    if(!replayGroups.has(value))replayGroups.set(value,{value,label:`${shortDate(rec.race.date)} ${venueName(rec.race)} · 已保存`,mode:'replay',date:rec.race.date,venue:rec.race.venue,races:[]});
    replayGroups.get(value)!.races.push({id:rec.key,no:rec.race.no,label:`R${rec.race.no} · ${rec.mode==='live'?'LIVE 記錄':rec.mode==='imported'?'匯入':rec.mode.toUpperCase()}`});
  }
  const replayOptions=[...replayGroups.values()].sort((a,b)=>b.date.localeCompare(a.date)||a.venue.localeCompare(b.venue));
  for(const g of replayOptions)g.races.sort((a,b)=>a.no-b.no||a.label.localeCompare(b.label));

  const race=state?.race||null;
  const mode=state?.mode||'live';
  const currentMeeting=race?(mode==='live'||mode==='mock'?`live|${race.date}|${race.venue}`:`replay|${race.date}|${race.venue}`):'';
  const currentRaceId=mode==='live'||mode==='mock'?race?.id||'':state?.key||'';
  const allOptions=[...options,...replayOptions];
  const meeting=allOptions.find(o=>o.value===currentMeeting);
  const raceChoices=meeting?.races||[];
  const raceIndex=raceChoices.findIndex(r=>r.id===currentRaceId);

  function chooseRace(opt:MeetingOption|undefined,id:string|undefined){
    if(!opt||!id)return;
    if(opt.mode==='live')void select({mode:'live',raceId:id,date:opt.date,venue:opt.venue,autoFollow:false});
    else void select({mode:'replay',raceId:id});
  }
  function chooseMeeting(value:string){
    const opt=allOptions.find(o=>o.value===value);
    chooseRace(opt,opt?.races[0]?.id);
  }
  async function follow(){
    const all=meetings.flatMap(m=>m.races);
    const target=all.find(r=>r.id===recommended);
    if(target)await select({mode:'live',raceId:target.id,date:target.date,venue:target.venue,autoFollow:true});
    else{busyRef.current=true;setBusy(true);try{await api('follow',{autoFollow:true});await refresh();}catch(e){setError((e as Error).message);}finally{busyRef.current=false;setBusy(false);}}
  }

  const now=Date.now()/1000;
  const hp=state?.health;
  const lastUpdate=hp?.lastUpdate?.value??null;
  const age=lastUpdate!=null?Math.max(0,Math.floor(now-lastUpdate)):null;
  // Same rule as the main page: LIVE turns STALE when the source clock is older than 45 s.
  // No race selected (no meeting today / waiting for card) is idle, not a source error.
  const status=!state?'CONNECTING':!state.race&&!error?'IDLE':mode==='live'&&hp?.status==='LIVE'&&age!=null&&age>STALE_SECONDS?'STALE':hp?.status||'ERROR';
  const stale=status==='STALE';
  const following=!!state?.collection?.autoFollow&&mode==='live';
  const rows=state?.rows||[];
  const statusText=status==='IDLE'?'等待':status==='CONNECTING'?'連接中':status;
  const bl=state?.baseline;
  // URL is read only on the client (inside refresh) so SSR and hydration render the same text.
  const beforeMinutes=bl?.minutes??DEFAULT_BASE_MINUTES;
  const beforeTitle=`獨贏前：開跑前 ${beforeMinutes} 分鐘凍結嘅獨贏（同完整版「排序基準（開跑前分鐘）」）`+
    (bl?.status==='LOCKED'&&bl.timestamp?` · 已鎖定 ${hkTime(bl.timestamp)}`:bl?.status==='LATE'?' · 目標時間附近冇快照，顯示 --':' · 未到時間，顯示 --');

  let banner:{kind:string,text:string}|null=null;
  if(error)banner={kind:'error',text:error};
  else if(!state)banner={kind:'info',text:'連接中…'};
  else if(!race)banner={kind:'info',text:`等待可用賽事${catalogMessage?`：${catalogMessage}`:''}。可喺上面揀已公布或已保存嘅場次。`};
  else if(status==='ERROR')banner={kind:'error',text:`來源錯誤：${hp?.error||'未知'}（顯示最後收到數值；缺資料顯示 --）`};
  else if(stale)banner={kind:'stale',text:`STALE · 來源 ${ageText(age??0)} 未更新（>45s）· 以下係最後收到數值，唔係即時`};
  else if(!state.frame)banner={kind:'info',text:'未有賠率快照（未開售或等待更新），全部顯示 --'};
  else if(mode==='replay')banner={kind:'replay',text:`REPLAY · 已保存切片 ${hkTime(state.frame.timestamp)} · 非即時`};
  else if(mode==='mock')banner={kind:'replay',text:'MOCK · 合成測試資料，唔係 HKJC 真數'};

  return <div ref={rootRef} className={`mini-root${stale?' is-stale':''}`} data-testid="mini-root" data-status={status}>
    <header ref={headRef} className="mini-head" data-testid="mini-head">
      <div className="mini-bar">
        <a className="mini-brand" href="#/" title="返回完整版">獨贏<span>・</span>孖寶</a>
        <span className={`mini-status st-${status.toLowerCase()}`} data-testid="mini-status"><i/>{statusText}</span>
        <span className="mini-updated" data-testid="mini-updated" title={`來源時間（香港）${hkTime(lastUpdate)} · 收到 ${hkTime(hp?.lastReceived?.value)} · ${state?.snapshotCount??0} 個快照`}>
          {lastUpdate!=null&&hkDate(lastUpdate)!==hkDate(now)&&<small>{shortDate(hkDate(lastUpdate))}</small>}<b>{hkTime(lastUpdate)}</b>{age!=null&&mode==='live'&&<small>{ageText(age)}</small>}
        </span>
      </div>
      <div className="mini-pick">
        <button type="button" className="mini-step" aria-label="上一場" disabled={busy||raceIndex<=0} onClick={()=>chooseRace(meeting,raceChoices[raceIndex-1]?.id)}>‹</button>
        <select aria-label="賽馬日／場地" data-testid="mini-meeting" value={meeting?currentMeeting:''} disabled={busy} onChange={e=>chooseMeeting(e.target.value)}>
          {!meeting&&<option value="">{race?`${shortDate(race.date)} ${venueName(race)}`:'賽馬日'}</option>}
          {options.length>0&&<optgroup label="HKJC LIVE">{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</optgroup>}
          {replayOptions.length>0&&<optgroup label="REPLAY · 已保存">{replayOptions.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</optgroup>}
        </select>
        <select aria-label="場次" data-testid="mini-race" value={raceIndex>=0?currentRaceId:''} disabled={busy||!raceChoices.length} onChange={e=>chooseRace(meeting,e.target.value)}>
          {raceIndex<0&&<option value="">{race?`R${race.no}`:'場次'}</option>}
          {raceChoices.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}
        </select>
        <button type="button" className="mini-step" aria-label="下一場" disabled={busy||raceIndex<0||raceIndex>=raceChoices.length-1} onClick={()=>chooseRace(meeting,raceChoices[raceIndex+1]?.id)}>›</button>
        <button type="button" className={`mini-follow${following?' on':''}`} data-testid="mini-follow" aria-pressed={following} disabled={busy} onClick={()=>void follow()} title="自動跟隨今日／下一場賽事">{following?'跟隨中':'跟隨'}</button>
      </div>
      {race&&<div className="mini-race-line" data-testid="mini-race-line">R{race.no} · {venueName(race)} · 開跑 {hkTime(race.postTime,false)}{race.distance?.value!=null?` · ${Math.round(race.distance.value)}m`:''}{race.raceClass?` · ${race.raceClass}`:''}</div>}
      {banner&&<div className={`mini-banner b-${banner.kind}`} data-testid={banner.kind==='stale'?'mini-stale-banner':'mini-banner'} role="status">{banner.text}</div>}
    </header>
    <table className="mini-table" data-testid="mini-table">
      <thead>
        <tr className="mini-group"><th rowSpan={2} className="mini-h-horse">馬</th><th rowSpan={2}>獨贏</th><th rowSpan={2} className="mini-h-before" data-testid="mini-before-head" data-status={bl?.status||''} title={beforeTitle}>獨贏前<small>T−{beforeMinutes}</small></th><th colSpan={3} className="mini-h-dbl" title="≈ 由 HKJC 孖寶組合賠率推算（上一關×本關）">孖寶 <small>≈</small></th></tr>
        <tr className="mini-sub"><th>冠</th><th>亞</th><th>全</th></tr>
      </thead>
      <tbody>
        {rows.map(row=><tr key={row.no} data-testid="mini-row" data-runner={row.no} className={row.scratched?'is-scratched':''}>
          <td className="mini-horse"><b>{row.no}</b><span>{row.scratched?'退出':row.name}</span></td>
          <Cell m={row.winOdds} kind="odds" testid="mini-odds"/>
          <Cell m={row.winOddsBefore} kind="before" testid="mini-before"/>
          <Cell m={row.dblWinner} kind="dbl" testid="mini-dbl-w"/>
          <Cell m={row.dblRunnerUp} kind="dbl" testid="mini-dbl-r"/>
          <Cell m={row.dblAll} kind="dbl" testid="mini-dbl-a"/>
        </tr>)}
        {!rows.length&&<tr><td colSpan={6} className="mini-empty">--</td></tr>}
      </tbody>
    </table>
    <footer className="mini-foot">
      <p data-testid="mini-foot-note">獨贏前＝開跑前 {beforeMinutes} 分鐘凍結嘅獨贏（同完整版「排序基準」；冇合適快照顯示 --）。孖寶冠／亞／全 ≈ 由組合賠率推算；≥＝999 封頂下限。按獨贏低→高排；每 3 秒更新；香港時間。</p>
      <a href="#/">完整版 ›</a>
    </footer>
  </div>;
}
