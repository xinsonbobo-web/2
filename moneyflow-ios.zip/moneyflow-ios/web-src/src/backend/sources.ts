// TypeScript port of backend/sources.py (transport + strict normalization of HKJC public read-only GraphQL).
// Research-only helpers (observe_fct_public_fields, classify_fct_research_field,
// ordered_combination_independence) are intentionally not ported: they never feed the engine or the UI.
/* eslint-disable @typescript-eslint/no-explicit-any */
import { metric, val } from './engine';
import { httpRequest, OSError } from './native';
import { QUERIES } from './queries';
import { sha256Hex } from './sha256';
import {
  type Dict, get, has, isDict, isDigit, isFiniteNum, maxBy, minBy, monotonic, nowSeconds, pyDumps, pyEq, pyFloat, pyInt,
  pyRound, pyStr, PyValueError, sortedBy, truthy, fmtG, pyFloatSum, sum as pySum,
} from './py';

export const ENDPOINT = 'https://info.cld.hkjc.com/graphql/base/';
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export class GraphQLClient {
  cookie = '';
  warmedAt = 0;
  private warming: Promise<void> | null = null;
  headers(forPost = true): Record<string, string> {
    // Accept-Encoding / Connection are managed by the native HTTP stack (URLSession decompresses gzip itself).
    const h: Record<string, string> = {
      'User-Agent': BROWSER_UA,
      'Accept-Language': 'zh-HK,zh;q=0.9,en-US;q=0.8,en;q=0.7',
      Origin: 'https://bet.hkjc.com',
      Referer: 'https://bet.hkjc.com/',
      'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
    };
    if (forPost) Object.assign(h, { 'Content-Type': 'application/json', Accept: 'application/json, text/plain, */*', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-site' });
    else h.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
    if (this.cookie) h.Cookie = this.cookie;
    return h;
  }
  ingestCookies(setCookies: string[] | undefined): void {
    const parts = (setCookies || []).map((v) => v.split(';', 1)[0]).filter(Boolean);
    if (!parts.length) return;
    const existing = new Map<string, string>();
    for (const p of this.cookie.split('; ')) if (p) existing.set(p.split('=', 1)[0], p);
    for (const p of parts) existing.set(p.split('=', 1)[0], p);
    this.cookie = [...existing.values()].join('; ');
  }
  /** One-shot GET bet.hkjc.com for browser-like cookies (best-effort). Python re-warms per worker thread;
   * here one warm-up is shared by all requests and renewed every 10 minutes or after an error. */
  async warmup(): Promise<void> {
    if (this.warmedAt && Date.now() - this.warmedAt < 600_000) return;
    if (!this.warming) {
      this.warming = (async () => {
        try {
          const r = await httpRequest('https://bet.hkjc.com/', 'GET', this.headers(false), null, 8);
          this.ingestCookies(r.setCookies);
        } catch { /* best effort */ }
        this.warmedAt = Date.now();
      })().finally(() => { this.warming = null; });
    }
    await this.warming;
  }
  async post(payload: string): Promise<Dict> {
    let last: unknown = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        await this.warmup();
        const r = await httpRequest(ENDPOINT, 'POST', this.headers(true), payload, 12);
        this.ingestCookies(r.setCookies);
        if (r.status >= 400) throw new OSError(`HKJC HTTP ${r.status}`);
        return JSON.parse(r.body);
      } catch (exc) {
        last = exc;
        this.warmedAt = 0;
      }
    }
    if (last) throw last instanceof OSError ? last : new OSError((last as Error).message || String(last));
    throw new OSError('HKJC GraphQL unreachable');
  }
}

const ISO_RE = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2})(?::?(\d{2})(?::?(\d{2})(?:[.,](\d+))?)?)?)?(?:([+-])(\d{2}):?(\d{2})(?::?(\d{2}))?)?$/;
export function timestamp(value: any): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string' || !value) return null;
  const m = ISO_RE.exec(value.replace('Z', '+00:00'));
  if (!m) return null;
  const [, y, mo, d, hh = '0', mi = '0', ss = '0', frac = '', sign, oh, om, os] = m;
  const Y = +y, MO = +mo, D = +d, H = +hh, MI = +mi, S = +ss;
  if (MO < 1 || MO > 12 || D < 1 || D > new Date(Date.UTC(Y, MO, 0)).getUTCDate() || H > 23 || MI > 59 || S > 59) return null;
  const micro = frac ? Math.floor(Number(('0.' + frac).slice(0, 8)) * 1e6 + 1e-6) : 0;
  let offset = 8 * 3600; // naive → Hong Kong time (Python appends +08:00)
  if (sign) offset = (sign === '-' ? -1 : 1) * (+oh * 3600 + +om * 60 + (os ? +os : 0));
  const epoch = Date.UTC(Y, MO - 1, D, H, MI, S) / 1000 - offset;
  return epoch + micro / 1e6;
}
export function number(value: any, positive = false): number | null {
  const n = pyFloat(value);
  if (n === undefined || !Number.isFinite(n) || n < 0 || (positive && n <= 0)) return null;
  return n;
}
export function direct(value: any, reason = 'HKJC 未提供此值', source = 'HKJC'): Dict {
  return metric(value, 'DIRECT', value === null || value === undefined ? reason : '', source);
}
export const LOCAL_VENUES = new Set(['ST', 'HV']);
const s = (v: any): string => (v === null || v === undefined ? '' : String(v));
export function classifyVenue(code: any, countryCh: any = null, countryEn: any = null, countryCode: any = null, meetingType: any = null): Dict | null {
  const c = s(code).trim();
  if (!c) return null;
  const mt = s(meetingType).toUpperCase();
  const cc = s(countryCode).toUpperCase();
  const overseasHint = mt.includes('OVERSEA') || mt.includes('SIMUL') || (cc !== '' && !['HK', 'HKG', ''].includes(cc));
  const local = LOCAL_VENUES.has(c) && !overseasHint;
  let label: string, kind: string;
  const country = (truthy(countryCh) ? s(countryCh) : truthy(countryEn) ? s(countryEn) : '').trim();
  if (local) { label = c === 'ST' ? '沙田 ST' : c === 'HV' ? '跑馬地 HV' : c; kind = 'local'; }
  else { label = ('海外 ' + (country ? country + ' ' : '') + c).trim(); kind = 'overseas'; }
  return { venue: c, venueKind: kind, venueLabel: label, country };
}
const or = (a: any, b: any) => (truthy(a) ? a : b);
export function normalizeCards(data: Dict): Dict[] {
  if (truthy(get(data, 'errors'))) throw new PyValueError('HKJC GraphQL: ' + JSON.stringify(data.errors).slice(0, 500));
  const meetings: Dict[] = [];
  for (const m of get(get(data, 'data', {}) || {}, 'raceMeetings', []) || []) {
    const rawCountry = get(m, 'country');
    let country: Dict;
    if (Array.isArray(rawCountry)) country = rawCountry.length && isDict(rawCountry[0]) ? rawCountry[0] : {};
    else country = isDict(rawCountry) ? rawCountry : {};
    const raceCountry = (get(m, 'races') || []).find((r: Dict) => truthy(get(r, 'country_ch')) || truthy(get(r, 'country_en'))) || {};
    const info = classifyVenue(get(m, 'venueCode'), or(get(country, 'namech'), get(raceCountry, 'country_ch')),
      or(get(country, 'nameen'), get(raceCountry, 'country_en')), get(country, 'code'), get(m, 'meetingType'));
    if (!info) continue;
    const races: Dict[] = [];
    for (const r of get(m, 'races', []) || []) {
      const post = timestamp(get(r, 'postTime'));
      if (post === null) continue;
      const runners: Dict[] = [];
      for (const h of get(r, 'runners', []) || []) {
        const no = pyStr(get(h, 'no', ''));
        if (!isDigit(no) || parseInt(no, 10) <= 0 || truthy(get(h, 'standbyNo'))) continue;
        runners.push({
          no: parseInt(no, 10), name: or(get(h, 'name_ch'), or(get(h, 'name_en'), '--')), nameEn: get(h, 'name_en'),
          scratched: s(get(h, 'status', '')).toLowerCase().includes('scrat'),
          jockey: truthy(get(h, 'jockey')) ? get(h.jockey, 'name_ch', '--') : '--',
          trainer: truthy(get(h, 'trainer')) ? get(h.trainer, 'name_ch', '--') : '--',
          draw: direct(number(get(h, 'barrierDrawNumber'))), quality: 'DIRECT',
        });
      }
      races.push({
        id: `${m.date}_${info.venue}_${pyStr(r.no)}`, date: m.date, venue: info.venue, venueKind: info.venueKind, venueLabel: info.venueLabel,
        country: info.country, no: r.no, name: or(get(r, 'raceName_ch'), or(get(r, 'raceName_en'), '--')),
        raceClass: or(get(r, 'raceClass_ch'), '--'), distance: direct(number(get(r, 'distance'))),
        track: get(get(r, 'raceTrack') || {}, 'description_ch', '--'), course: get(get(r, 'raceCourse') || {}, 'displayCode', ''),
        going: or(get(r, 'go_ch'), '--'), postTime: post, status: get(r, 'status'), runners, quality: 'DIRECT',
      });
    }
    meetings.push({ date: m.date, venue: info.venue, venueKind: info.venueKind, venueLabel: info.venueLabel, country: info.country, currentRace: get(m, 'currentNumberOfRace'), races });
  }
  return meetings;
}
export const hkDate = (t: number): string => new Date((t + 8 * 3600) * 1000).toISOString().slice(0, 10);
const FINISHED = new Set(['FINISHED', 'COMPLETED', 'RESULT', 'RESULTS', 'FINAL', 'OFFICIAL', 'PAYOUT', 'CLOSED', 'VOID', 'CANCELLED', 'CANCELED', 'ABANDONED', 'RACEOVER', 'WEIGHEDIN']);
const RUNNING = new Set(['RACING', 'RUNNING', 'STARTED', 'INPROGRESS', 'RACESTARTED']);
export function recommendRace(meetings: Dict[], now: number | null = null): string | null {
  const t = now === null ? nowSeconds() : now;
  const today = hkDate(t);
  const current: Dict[] = [], near: Dict[] = [], future: Dict[] = [];
  for (const meeting of meetings) {
    if (!truthy(get(meeting, 'venue')) || s(get(meeting, 'date', '')) < today) continue;
    for (const race of get(meeting, 'races', []) || []) {
      const state = s(or(get(race, 'status'), '')).toUpperCase().replace(/[_\- ]/g, '');
      const post = timestamp(get(race, 'postTime'));
      if (FINISHED.has(state) || post === null || !(get(race, 'runners', []) || []).some((r: Dict) => !truthy(get(r, 'scratched')))) continue;
      if (post >= t) future.push(race);
      else if (get(meeting, 'date') === today) {
        const age = t - post;
        const isCurrent = pyStr(get(race, 'no')) === pyStr(get(meeting, 'currentRace'));
        const running = RUNNING.has(state);
        if (isCurrent && (age <= 1800 || (running && age <= 7200))) current.push(race);
        else if (age <= 900) near.push(race);
      }
    }
  }
  if (current.length) return maxBy(current, (r) => r.postTime)!.id;
  if (near.length) return maxBy(near, (r) => r.postTime)!.id;
  return future.length ? minBy(future, (r) => r.postTime)!.id : null;
}
/** DBL combination key "first,second" (Python returns a tuple). */
export function dblComboKey(comb: any): string | null {
  const bits = s(or(comb, '')).replace(/,/g, '/').split('/');
  if (bits.length !== 2 || !isDigit(bits[0]) || !isDigit(bits[1])) return null;
  const a = parseInt(bits[0], 10), b = parseInt(bits[1], 10);
  if (a <= 0 || b <= 0) return null;
  return `${a},${b}`;
}
export const splitKey = (k: string): [string, string] => k.split(',') as [string, string];
export type DblMatrix = Map<string, number>;
export function parseDblOdds(pool: Dict): DblMatrix {
  const matrix: DblMatrix = new Map();
  for (const node of get(pool, 'oddsNodes') || []) {
    const key = dblComboKey(get(node, 'combString'));
    if (!key) continue;
    const value = number(get(node, 'oddsValue'), true);
    if (value === null) continue;
    if (matrix.has(key)) throw new PyValueError('HKJC 重複 DBL 組合 ' + pyStr(get(node, 'combString')));
    matrix.set(key, value);
  }
  return matrix;
}
export function placedHorses(meeting: Dict, raceNo: number): [string | null, string | null, string | null] {
  const card = (get(meeting, 'races') || []).find((it: Dict) => get(it, 'no') === raceNo);
  if (!card) return [null, null, '上一關賽事未在賽事卡'];
  const first: [string, boolean][] = [], second: [string, boolean][] = [];
  for (const horse of get(card, 'runners') || []) {
    const no = pyStr(get(horse, 'no', ''));
    if (!isDigit(no)) continue;
    const place = pyInt(get(horse, 'finalPosition'));
    if (place === undefined) continue;
    const n = String(parseInt(no, 10));
    if (place === 1) first.push([n, truthy(get(horse, 'deadHeat'))]);
    else if (place === 2) second.push([n, truthy(get(horse, 'deadHeat'))]);
  }
  if (!first.length) return [null, null, '上一關賽果未有冠軍名次（HKJC 未回傳）'];
  if (first.length !== 1 || first[0][1]) return [null, null, '上一關冠軍死熱／非獨贏'];
  const winner = first[0][0];
  if (!second.length) return [winner, null, '上一關賽果未有亞軍名次（HKJC 未回傳）'];
  if (second.length !== 1 || second[0][1]) return [winner, null, '上一關亞軍死熱／非獨得'];
  return [winner, second[0][0], null];
}
export const DBL_ODDS_CAP = 999.0;
export const DBL_CAP_BOUND_RATIO = 1.02;
export function fitDblOdds(value: number | null): number | null {
  if (value === null || value === undefined) return null;
  if (value < 10) return Math.floor(value * 10 + 1e-9) / 10;
  return Math.floor(value + 1e-9);
}
export function fitDblAll(value: number | null): number | null {
  if (value === null || value === undefined) return null;
  if (value < 100) return Math.ceil(value * 10 - 1e-9) / 10;
  return Math.ceil(value - 1e-9);
}
export const dblCapped = (odds: number | null): boolean => odds !== null && odds !== undefined && odds >= DBL_ODDS_CAP - 1e-9;
export function dblAllPrice(column: (number | null)[]): [number | null, number | null, number] {
  const values = column.filter((v): v is number => v !== null && v !== undefined && v > 0);
  if (!values.length) return [null, null, 0];
  const t = pyFloatSum([...values].map((v) => 1 / v));
  const lo = 1 / t;
  const free = values.filter((v) => !dblCapped(v));
  const t2 = pyFloatSum([...free].map((v) => 1 / v));
  const hi = free.length ? 1 / t2 : Infinity;
  return [lo, hi, values.length - free.length];
}
export function winOddsMap(pools: Dict[], raceNo: number): Map<string, number> {
  const out = new Map<string, number>();
  for (const pool of pools) {
    if (get(pool, 'oddsType') !== 'WIN' || !pyEq(get(get(pool, 'leg') || {}, 'races'), [raceNo])) continue;
    for (const node of get(pool, 'oddsNodes') || []) {
      let key = s(or(get(node, 'combString'), ''));
      if (isDigit(key)) key = String(parseInt(key, 10));
      const value = number(get(node, 'oddsValue'), true);
      if (value !== null) out.set(key, value);
    }
  }
  return out;
}
const legRaces = (pool: Dict) => get(get(pool, 'leg') || {}, 'races');
export function deriveDblPrices(meeting: Dict, race: Dict, dblPools: Dict[], allOdds: Dict[]): Dict {
  const ids = race.runners.map((h: Dict) => pyStr(h.no));
  const SRC = 'HKJC DBL odds';
  const blank = (reason: string) => ({ winner: metric(null, 'DERIVED', reason, SRC), runnerUp: metric(null, 'DERIVED', reason, SRC), all: metric(null, 'DERIVED', reason, SRC), up: metric(null, 'DERIVED', reason, SRC) });
  const fill = (reason: string) => Object.fromEntries(ids.map((r: string) => [r, blank(reason)]));
  const prev = race.no - 1;
  if (prev < 1) return fill('第一場沒有上一關孖寶');
  const incoming = dblPools.find((p) => pyEq(legRaces(p), [prev, race.no]));
  if (!incoming) return fill('未取得上一關×本關孖寶池（HKJC 未回傳）');
  const matrix = parseDblOdds(incoming);
  if (!matrix.size) return fill('孖寶組合賠率仍未開出');
  const [winner, runnerUp, why] = placedHorses(meeting, prev);
  const prevWin = winOddsMap(allOdds, prev);
  const outgoing = dblPools.find((p) => pyEq(legRaces(p), [race.no, race.no + 1]));
  const upMatrix: DblMatrix = outgoing ? parseDblOdds(outgoing) : new Map();
  let upInvAll = 0;
  if (upMatrix.size) upInvAll = pyFloatSum([...upMatrix.values()].map((o) => 1 / o));
  const result: Dict = {};
  let firstsAll = sortedBy([...new Set([...matrix.keys()].map((k) => splitKey(k)[0]))], (x) => (isDigit(x) ? parseInt(x, 10) : 0));
  if (prevWin.size) firstsAll = firstsAll.filter((h) => prevWin.has(h));
  const placedPrice = (horse: string | null, runner: string, label: string): Dict | null => {
    if (!horse || !truthy(prevWin.get(horse))) return null;
    const combo = matrix.get(`${horse},${runner}`);
    if (combo === undefined) return null;
    const raw = combo / prevWin.get(horse)!;
    const capped = dblCapped(combo);
    const out = metric(fitDblOdds(raw), 'DERIVED', capped ? `≥：HKJC DBL 組合 ${horse + '-' + runner} 封頂 999，實際賠率更長` : '', `DBL組合 ÷ 上一關${label}WIN`);
    out.raw = raw;
    if (capped) out.bound = 'GE';
    return out;
  };
  for (const runner of ids) {
    const champ = placedPrice(winner, runner, '冠軍');
    const second = placedPrice(runnerUp, runner, '亞軍');
    const column = firstsAll.filter((h) => matrix.has(`${h},${runner}`)).map((h) => matrix.get(`${h},${runner}`)!);
    let entire: Dict | null = null;
    if (column.length >= 2) {
      const [lo, hi, ncap] = dblAllPrice(column);
      if (lo !== null) {
        const bound = !Number.isFinite(hi!) || hi! / lo > DBL_CAP_BOUND_RATIO;
        let note = '';
        if (ncap) {
          note = `${ncap}/${column.length} 格 DBL 999 封頂`;
          note += bound ? `；≥：真值介乎 ${fmtG(fitDblAll(lo)!)}–${!Number.isFinite(hi!) ? '∞' : fmtG(fitDblAll(hi)!)}` : '；影響 <2%';
        }
        entire = metric(fitDblAll(lo), 'DERIVED', note, '1 ÷ Σⱼ(1/DBL組合ⱼᵢ)（全部上一關馬，含孖寶扣數）');
        entire.raw = lo; entire.cappedCells = ncap; entire.cells = column.length;
        if (bound) entire.bound = 'GE';
      }
    }
    let upOdds: number | null = null;
    if (upInvAll) {
      const rowTerms: number[] = [];
      for (const [k, o] of upMatrix) if (splitKey(k)[0] === runner) rowTerms.push(1 / o);
      const row = pyFloatSum(rowTerms);
      if (row) upOdds = upInvAll / row;
    }
    result[runner] = {
      winner: champ || metric(null, 'DERIVED', why || '未有上一關冠軍獨贏賠率／組合', 'DBL組合 ÷ 上一關冠軍WIN'),
      runnerUp: second || metric(null, 'DERIVED', why || '未有上一關亞軍獨贏賠率／組合', 'DBL組合 ÷ 上一關亞軍WIN'),
      all: entire || metric(null, 'DERIVED', '未有足夠上一關組合計孖寶全部', '1 ÷ Σⱼ(1/DBL組合ⱼᵢ)'),
      up: metric(upOdds, 'DERIVED', upOdds !== null ? '' : '未有本場作第一關嘅孖寶組合', '本場第一關孖寶隱含賠率'),
    };
  }
  return result;
}
export function extractDblMatrix(body: Dict, legs: number[]): DblMatrix {
  const matrix: DblMatrix = new Map();
  for (const meeting of get(get(body, 'data') || {}, 'raceMeetings') || []) {
    for (const pool of get(meeting, 'pmPools') || []) {
      if (get(pool, 'oddsType') !== 'DBL' || !pyEq(legRaces(pool), legs)) continue;
      for (const node of get(pool, 'oddsNodes') || []) {
        const key = dblComboKey(get(node, 'combString'));
        if (!key) continue;
        const value = number(get(node, 'oddsValue'), true);
        if (value === null) continue;
        matrix.set(key, value);
      }
    }
  }
  return matrix;
}
export function extractDblStatus(body: Dict, legs: number[]): any {
  for (const meeting of get(get(body, 'data') || {}, 'raceMeetings') || [])
    for (const pool of get(meeting, 'pmPools') || [])
      if (get(pool, 'oddsType') === 'DBL' && pyEq(legRaces(pool), legs)) return or(get(pool, 'status'), get(pool, 'sellStatus'));
  return null;
}
export function dblImpliedOdds(matrix: DblMatrix, ids: any[], axis: number): Dict {
  if (!matrix || !matrix.size) return {};
  const weight = pyFloatSum([...matrix.values()].map((o) => 1 / o));
  const out: Dict = {};
  for (const runner of ids) {
    const terms: number[] = [];
    for (const [k, o] of matrix) { const [a, b] = splitKey(k); if ((axis === 1 ? b : a) === runner) terms.push(1 / o); }
    const part = pyFloatSum(terms);
    out[pyStr(runner)] = part ? weight / part : null;
  }
  return out;
}
export function dblShortenPct(old: number | null, nw: number | null): number | null {
  if (old === null || nw === null || old === undefined || nw === undefined || old <= 0) return null;
  return 100 * Math.abs(old - nw) / old;
}
export function dblSignedShortenPct(old: number | null, nw: number | null): number | null {
  if (old === null || nw === null || old === undefined || nw === undefined || old <= 0 || nw <= 0) return null;
  return 100 * (old - nw) / old;
}
export function estimateDblLegPool(pool: Dict, inv: Dict, axis: number, runnerIds: string[]): Dict | null {
  const totalV = number(get(inv, 'investment'), true);
  const matrix = parseDblOdds(pool);
  if (!totalV || !matrix.size) return null;
  const weight = pyFloatSum([...matrix.values()].map((o) => 1 / o));
  if (weight <= 0) return null;
  const sums = new Map<string, number>(runnerIds.map((r) => [r, 0.0]));
  for (const [k, o] of matrix) {
    const [a, b] = splitKey(k);
    const horse = axis === 0 ? a : b;
    if (sums.has(horse)) sums.set(horse, sums.get(horse)! + totalV * (1 / o) / weight);
  }
  const ot = timestamp(get(pool, 'lastUpdateTime')), it = timestamp(get(inv, 'lastUpdateTime'));
  const reported = direct(totalV, undefined, 'HKJC DBL poolInvs.investment');
  let usable: Dict, amounts: Dict;
  if (ot === null || it === null || Math.abs(ot - it) > 15) {
    usable = metric(null, 'DERIVED', '孖寶賠率／彩池時間缺失或差距超過15秒');
    amounts = Object.fromEntries(runnerIds.map((r) => [r, metric(null, 'DERIVED', '孖寶時間未配對')]));
  } else {
    usable = reported;
    amounts = Object.fromEntries([...sums].map(([r, v]) => [r, metric(v, 'ESTIMATED', 'DBL 彩池 × 組合賠率倒數歸一', 'HKJC DBL pool + odds')]));
  }
  return { total: usable, reportedTotal: reported, updatedAt: ot !== null && it !== null ? Math.max(ot, it) : ot, oddsUpdatedAt: ot, investmentUpdatedAt: it, amounts, complete: false, status: get(pool, 'status') };
}
export function mergeOddsPools(oddsData: Dict, extraData: Dict | null, oddsTypes: string[] | null = null): Dict {
  const extra: Dict[] = [];
  for (const meeting of get(get(extraData || {}, 'data', {}) || {}, 'raceMeetings', []) || [])
    for (const pool of get(meeting, 'pmPools') || [])
      if (oddsTypes === null || oddsTypes.includes(get(pool, 'oddsType'))) extra.push(pool);
  if (!extra.length) return oddsData;
  if (!isDict(oddsData.data)) oddsData.data = {};
  if (!has(oddsData.data, 'raceMeetings')) oddsData.data.raceMeetings = [];
  const meetings = oddsData.data.raceMeetings;
  if (!truthy(meetings)) { oddsData.data.raceMeetings = [{ pmPools: extra }]; return oddsData; }
  if (!has(meetings[0], 'pmPools')) meetings[0].pmPools = [];
  const existing = meetings[0].pmPools;
  const seen = new Set(existing.map((p: Dict) => get(p, 'id')));
  for (const pool of extra) if (!seen.has(get(pool, 'id'))) { existing.push(pool); seen.add(get(pool, 'id')); }
  return oddsData;
}

// --- FCT DIRECT ordered-matrix ingest ------------------------------------------------------
export const FCT_SYNC_TOLERANCE_SECONDS = 15;
const INV_FIELDS = ['investment', 'inv', 'amount', 'investmentValue', 'betInvestment'];
const BAD = '__bad__|'; // no NUL: a raw U+0000 in the inlined <script> would become U+FFFD when the HTML is parsed
export function fctOrderedKey(comb: any): [string, string] | null {
  const raw = s(or(comb, '')).trim().replace(/-/g, '/').replace(/,/g, '/');
  const bits = raw.split('/').filter((b) => b !== '');
  if (bits.length !== 2) return null;
  const a = bits[0].trim(), b = bits[1].trim();
  if (!isDigit(a) || !isDigit(b)) return null;
  const f = parseInt(a, 10), sc = parseInt(b, 10);
  if (f <= 0 || sc <= 0 || f === sc) return null;
  return [String(f), String(sc)];
}
function explicitNodeInvestment(node: any): number | null {
  if (!isDict(node)) return null;
  for (const field of INV_FIELDS) {
    if (has(node, field) && node[field] !== null && node[field] !== '') {
      const n = pyFloat(node[field]);
      if (n === undefined || !Number.isFinite(n) || n < 0) return null;
      return n;
    }
  }
  return null;
}
type Edges = Map<string, number | null>;
export function extractFctInvestmentEdges(pool: any): [Edges, Dict] {
  const meta: Dict = { oddsSeen: false, directFieldSeen: false, sourceKind: null };
  const edges: Edges = new Map();
  if (!isDict(pool)) return [edges, meta];
  const combos = get(pool, 'combinations');
  if (isDict(combos) && truthy(combos)) {
    for (const [key, raw] of Object.entries(combos)) {
      const ordered = fctOrderedKey(key);
      if (!ordered) { edges.set(BAD + key, null); meta.directFieldSeen = true; meta.sourceKind = meta.sourceKind || 'combinations'; continue; }
      const k = ordered.join(',');
      if (isDict(raw)) {
        const q = get(raw, 'quality'), v = get(raw, 'value');
        if (q === 'DIRECT' && v !== null) {
          const n = pyFloat(v);
          edges.set(k, n !== undefined && Number.isFinite(n) && n >= 0 ? n : null);
          meta.directFieldSeen = true; meta.sourceKind = 'combinations';
        } else if (q === 'ESTIMATED' || q === 'DERIVED') meta.oddsSeen = true;
      } else {
        const n = raw !== null ? number(raw) : null;
        if (n !== null) { edges.set(k, n); meta.directFieldSeen = true; meta.sourceKind = 'combinations'; }
      }
    }
    if (meta.directFieldSeen) return [edges, meta];
  }
  const putEdge = (ordered: [string, string] | null, inv: number | null, label: string) => {
    if (!ordered) { edges.set(BAD + label, null); meta.duplicateOrBad = true; return; }
    const k = ordered.join(',');
    if (edges.has(k)) { edges.set(BAD + `dup:${ordered[0]},${ordered[1]}`, null); meta.duplicateOrBad = true; return; }
    edges.set(k, inv);
  };
  for (const node of get(pool, 'investmentNodes') || []) {
    const ordered = fctOrderedKey(or(get(node, 'combString'), or(get(node, 'combination'), get(node, 'key'))));
    const inv = explicitNodeInvestment(node);
    meta.directFieldSeen = true; meta.sourceKind = 'investmentNodes';
    putEdge(ordered, inv, pyStr(get(node, 'combString')));
  }
  if (meta.directFieldSeen) return [edges, meta];
  const oddsNodes = get(pool, 'oddsNodes') || [];
  if (oddsNodes.length) meta.oddsSeen = true;
  for (const node0 of oddsNodes) {
    const node = isDict(node0) ? node0 : {};
    const inv = explicitNodeInvestment(node0);
    const anyField = INV_FIELDS.some((f) => has(node, f));
    if (inv === null && !anyField) continue;
    meta.directFieldSeen = true; meta.sourceKind = 'oddsNodes.investment';
    const ordered = fctOrderedKey(get(node, 'combString'));
    putEdge(ordered, inv === null && anyField ? null : inv, pyStr(get(node, 'combString')));
  }
  return [edges, meta];
}
export function validateFctDirectMatrix(edges: Edges, activeRunners: any[] | null, declaredTotal: number | null = null, matrixTs: number | null = null, poolTs: number | null = null,
  opts: { odds?: Dict | null; status?: any; source?: string; extractMeta?: Dict | null } = {}): Dict {
  const extractMeta = opts.extractMeta || {};
  const source = opts.source ?? 'HKJC';
  const odds = opts.odds ?? null;
  const status = opts.status ?? null;
  const active = (activeRunners || []).map((r) => pyStr(r));
  const activeSet = new Set(active);
  const n = activeSet.size;
  const expected = n >= 2 ? n * (n - 1) : 0;
  const diagnostics: Dict = {
    sourceSeen: true, directMatrixSeen: truthy(get(extractMeta, 'directFieldSeen')) || edges.size > 0, matrixComplete: false, edgeCount: 0,
    expectedEdgeCount: expected, totalConserved: false, syncSeconds: null, oddsSeen: truthy(get(extractMeta, 'oddsSeen')) || truthy(odds), sourceKind: get(extractMeta, 'sourceKind'),
  };
  const base: Dict = {
    amounts: {}, combinations: {}, complete: false, status, activeRunners: active, odds: or(odds, {}), quality: 'UNAVAILABLE', unavailableReason: null,
    sourceQuality: 'UNAVAILABLE', diagnostics, edgeCount: 0, expectedEdgeCount: expected, matrixUpdatedAt: matrixTs, updatedAt: null,
  };
  const fail = (reason: string) => { base.unavailableReason = reason; base.reason = reason; return base; };
  const times = () => [matrixTs, poolTs].filter((t): t is number => t !== null);
  if (matrixTs !== null && poolTs !== null) {
    diagnostics.syncSeconds = Math.abs(matrixTs - poolTs);
    if (Math.abs(matrixTs - poolTs) > FCT_SYNC_TOLERANCE_SECONDS) { base.updatedAt = Math.max(matrixTs, poolTs); return fail('fct_timestamp_mismatch'); }
  }
  if (n < 2) return fail('runner_set_mismatch');
  if (!edges.size && !truthy(get(extractMeta, 'directFieldSeen'))) {
    fail('direct_matrix_missing');
    if (matrixTs !== null || poolTs !== null) base.updatedAt = Math.max(...times());
    return base;
  }
  const clean = new Map<string, number>();
  for (const [key, amount] of edges) {
    if (key.startsWith(BAD)) { diagnostics.edgeCount = edges.size; return fail('matrix_incomplete'); }
    const [i, j] = splitKey(key);
    if (i === j) return fail('matrix_incomplete');
    if (!activeSet.has(i) || !activeSet.has(j)) { diagnostics.edgeCount = edges.size; return fail('runner_set_mismatch'); }
    if (clean.has(key) || amount === null) return fail('matrix_incomplete');
    const v = pyFloat(amount);
    if (v === undefined || !Number.isFinite(v) || v < 0) return fail('matrix_incomplete');
    clean.set(key, v);
  }
  diagnostics.edgeCount = clean.size; base.edgeCount = clean.size;
  if (clean.size !== expected) {
    fail('matrix_incomplete');
    if (matrixTs !== null || poolTs !== null) base.updatedAt = Math.max(...times());
    return base;
  }
  const edgeSum = pyFloatSum(clean.values());
  if (declaredTotal !== null) {
    const tol = Math.max(1.0, declaredTotal * 1e-6);
    if (Math.abs(edgeSum - declaredTotal) > tol) {
      diagnostics.totalConserved = false;
      fail('fct_total_mismatch');
      base.reportedTotal = direct(declaredTotal, undefined, `${source} FCT poolInvs.investment`);
      base.total = metric(null, 'DERIVED', 'fct_total_mismatch');
      if (matrixTs !== null || poolTs !== null) base.updatedAt = Math.max(...times());
      return base;
    }
    diagnostics.totalConserved = true;
  } else {
    diagnostics.totalConserved = true;
    declaredTotal = edgeSum;
  }
  diagnostics.matrixComplete = true;
  const combinations: Dict = {};
  for (const [k, v] of clean) combinations[k] = direct(v, undefined, `${source} FCT DIRECT combination`);
  const totalM = direct(declaredTotal, undefined, `${source} FCT poolInvs.investment`);
  const updated = matrixTs !== null && poolTs !== null ? Math.max(matrixTs, poolTs) : matrixTs !== null ? matrixTs : poolTs;
  return {
    total: totalM, reportedTotal: totalM, combinations, amounts: {}, complete: true, status, activeRunners: active, odds: or(odds, {}),
    quality: 'DIRECT', sourceQuality: 'DIRECT', unavailableReason: null, reason: null, diagnostics, edgeCount: clean.size, expectedEdgeCount: expected,
    matrixUpdatedAt: matrixTs, updatedAt: updated, oddsUpdatedAt: matrixTs, investmentUpdatedAt: poolTs,
  };
}
export function parseFctDirectMatrix(payload: any, activeRunners: any[] | null, declaredTotal: number | null = null, matrixTs: number | null = null, poolTs: number | null = null,
  opts: { odds?: Dict | null; status?: any; source?: string } = {}): Dict {
  const source = opts.source ?? 'HKJC';
  let odds = opts.odds ?? null;
  let edges: Edges, meta: Dict;
  if (payload === null || payload === undefined) { edges = new Map(); meta = { directFieldSeen: false, oddsSeen: truthy(odds) }; }
  else if (isDict(payload) && (has(payload, 'oddsNodes') || has(payload, 'investmentNodes') || has(payload, 'combinations') || has(payload, 'oddsType'))) {
    [edges, meta] = extractFctInvestmentEdges(payload);
    if (odds === null && isDict(get(payload, 'odds'))) odds = payload.odds;
    if (odds === null && truthy(get(payload, 'oddsNodes'))) {
      odds = {};
      for (const node of payload.oddsNodes) {
        const key = fctOrderedKey(get(node, 'combString'));
        if (!key) continue;
        const ov = number(get(node, 'oddsValue'), true);
        if (ov !== null) { odds[`${key[0]},${key[1]}`] = direct(ov, undefined, `${source} FCT oddsNodes.oddsValue`); meta.oddsSeen = true; }
      }
    }
  } else if (isDict(payload)) [edges, meta] = extractFctInvestmentEdges({ combinations: payload });
  else { edges = new Map(); meta = { directFieldSeen: false, oddsSeen: false }; }
  return validateFctDirectMatrix(edges, activeRunners, declaredTotal, matrixTs, poolTs, { odds, status: opts.status ?? null, source, extractMeta: meta });
}

export function snapshotId(snapshot: Dict): string {
  const hook = (globalThis as any).__MF_SNAPSHOT_ID__; // verification harness only (Python ids hash 1.0 vs 1 differently)
  if (typeof hook === 'function') return hook(snapshot);
  const content: Dict = {};
  for (const [k, v] of Object.entries(snapshot)) if (!['id', 'receivedAt', 'latency'].includes(k)) content[k] = v;
  return sha256Hex(pyDumps(content, true)).slice(0, 24);
}
export function raceTotalInvestment(meeting: Dict, raceNo: number): Dict {
  let total = 0.0, seen = 0;
  for (const inv of get(meeting, 'poolInvs') || []) {
    const legs0 = get(get(inv, 'leg') || {}, 'races') || [];
    const legs = legs0.map((x: any) => pyInt(x));
    if (legs.some((x: any) => x === undefined)) continue;
    if (!legs.includes(pyInt(raceNo))) continue;
    const amount = number(get(inv, 'investment'));
    if (amount === null) continue;
    total += amount; seen += 1;
  }
  if (!seen) return metric(null, 'DERIVED', '未有彩池投注總額', 'HKJC poolInvs.investment');
  return direct(total, undefined, 'HKJC poolInvs.investment sum (all race-scoped pools)');
}
export function normalizeSnapshot(race: Dict, cardData: Dict, oddsData: Dict, receivedAt: number, latency: number): Dict {
  if (truthy(get(oddsData, 'errors')) || truthy(get(cardData, 'errors')))
    throw new PyValueError('HKJC GraphQL query error: ' + JSON.stringify(or(get(oddsData, 'errors'), get(cardData, 'errors'))).slice(0, 400));
  const meetings = get(get(cardData, 'data', {}) || {}, 'raceMeetings', []) || [];
  const meeting = meetings.find((m: Dict) => get(m, 'date') === race.date && get(m, 'venueCode') === race.venue);
  if (!meeting || !(get(meeting, 'races', []) || []).some((r: Dict) => r.no === race.no)) throw new PyValueError('HKJC 未回傳所選日期／場地／場次，拒絕使用其他賽事資料');
  const invs = new Map<any, Dict>();
  for (const p of get(meeting, 'poolInvs', []) || []) if (pyEq(get(get(p, 'leg', {}) || {}, 'races'), [race.no])) invs.set(p.id, p);
  const allOdds: Dict[] = [];
  for (const m of get(get(oddsData, 'data', {}) || {}, 'raceMeetings', []) || []) for (const p of get(m, 'pmPools', []) || []) allOdds.push(p);
  const selected = allOdds.filter((p) => invs.has(get(p, 'id')) && pyEq(get(get(p, 'leg', {}) || {}, 'races'), [race.no]));
  if (!selected.length) throw new PyValueError('HKJC 未回傳符合所選賽事嘅彩池 ID');
  const runners: Dict = {};
  for (const r of race.runners) runners[pyStr(r.no)] = { winOdds: metric(), placeOdds: metric() };
  const pools: Dict = {};
  for (const p of selected) {
    const name = get(p, 'oddsType');
    if (!['WIN', 'PLA', 'QIN', 'QPL', 'FCT'].includes(name)) continue;
    const inv = invs.get(p.id)!;
    const ot = timestamp(get(p, 'lastUpdateTime')), it = timestamp(get(inv, 'lastUpdateTime'));
    const total = direct(number(get(inv, 'investment'), true), undefined, 'HKJC poolInvs.investment');
    const usableTotal = ot === null || it === null || Math.abs(ot - it) > 15 ? metric(null, 'DERIVED', '賠率／彩池時間缺失或差距超過15秒') : total;
    const odds: Dict = {};
    for (const nd of get(p, 'oddsNodes', []) || []) {
      let key = pyStr(get(nd, 'combString'));
      if ((name === 'WIN' || name === 'PLA') && isDigit(key)) key = String(parseInt(key, 10));
      if (has(odds, key)) throw new PyValueError('HKJC 重複 runner / combination odds ID');
      odds[key] = direct(number(get(nd, 'oddsValue'), true), undefined, 'HKJC oddsNodes.oddsValue');
    }
    pools[name] = { total: usableTotal, reportedTotal: total, updatedAt: ot !== null && it !== null ? Math.max(ot, it) : ot, oddsUpdatedAt: ot, investmentUpdatedAt: it, amounts: {}, combinations: {}, complete: false, status: get(p, 'status'), odds };
    if (name === 'WIN' || name === 'PLA') for (const [key, value] of Object.entries(odds)) if (has(runners, key)) runners[key][name === 'WIN' ? 'winOdds' : 'placeOdds'] = value;
    if (name === 'WIN') {
      const active = race.runners.filter((h: Dict) => !truthy(get(h, 'scratched'))).map((h: Dict) => pyStr(h.no));
      pools[name].activeRunners = active;
      if (active.length && active.every((r: string) => val(get(odds, r)) !== null) && val(usableTotal) !== null) {
        const reciprocal = active.map((r: string) => [r, 1 / val(odds[r])] as [string, number]);
        const denom = pyFloatSum(reciprocal.map(([, v]: [string, number]) => v));
        pools[name].amounts = Object.fromEntries(reciprocal.map(([r, v]: [string, number]) => [r, metric(val(usableTotal) * v / denom, 'ESTIMATED', 'WIN pool × normalized reciprocal odds；報價取整／更新延遲可產生誤差', 'HKJC WIN pool + odds')]));
      }
    }
    if (name === 'FCT') {
      const active = race.runners.filter((h: Dict) => !truthy(get(h, 'scratched'))).map((h: Dict) => pyStr(h.no));
      const declaredPos = number(get(inv, 'investment'), true);
      const fct = parseFctDirectMatrix(p, active, declaredPos, ot, it, { odds, status: get(p, 'status'), source: 'HKJC' });
      fct.reportedTotal = total; fct.oddsUpdatedAt = ot; fct.investmentUpdatedAt = it;
      if (get(fct, 'updatedAt') === null) fct.updatedAt = ot !== null && it !== null ? Math.max(ot, it) : ot !== null ? ot : it;
      if (!truthy(get(fct, 'complete'))) fct.total = metric(null, 'DERIVED', or(get(fct, 'unavailableReason'), 'direct_matrix_missing'));
      pools[name] = fct;
    }
  }
  const win = get(pools, 'WIN');
  let sourceTime = win ? get(win, 'updatedAt') : null;
  if (sourceTime === null) throw new PyValueError('HKJC 賽事已取得，但 WIN 未開售／沒有有效 lastUpdateTime；不建立假 snapshot');
  for (const p of Object.values(pools)) for (const k of ['updatedAt', 'investmentUpdatedAt', 'oddsUpdatedAt']) if (get(p, k) !== null && p[k] > sourceTime) sourceTime = p[k];
  if (sourceTime > receivedAt + 5) throw new PyValueError('HKJC source timestamp 超前本地時鐘；拒絕未來 snapshot');
  const dblPools = allOdds.filter((p) => get(p, 'oddsType') === 'DBL');
  const incoming = deriveDblPrices(meeting, race, dblPools, allOdds);
  const allInvs = new Map<any, Dict>();
  for (const p of get(meeting, 'poolInvs', []) || []) allInvs.set(p.id, p);
  const ids = race.runners.map((h: Dict) => pyStr(h.no));
  const outgoing = dblPools.find((p) => pyEq(legRaces(p), [race.no, race.no + 1]));
  const incomingPool = dblPools.find((p) => pyEq(legRaces(p), [race.no - 1, race.no]));
  if (outgoing && allInvs.has(get(outgoing, 'id'))) { const up = estimateDblLegPool(outgoing, allInvs.get(outgoing.id)!, 0, ids); if (up) pools.DBL_UP = up; }
  if (incomingPool && allInvs.has(get(incomingPool, 'id'))) { const down = estimateDblLegPool(incomingPool, allInvs.get(incomingPool.id)!, 1, ids); if (down) pools.DBL_DOWN = down; }
  const raceTotal = raceTotalInvestment(meeting, race.no);
  const snap: Dict = { raceId: race.id, source: 'live', timestamp: sourceTime, sourceTimestamp: sourceTime, receivedAt, latency, runners, pools, raceTotalInvestment: raceTotal, incomingDouble: incoming, outgoingDouble: {}, schemaVersion: 1 };
  snap.id = snapshotId(snap);
  return snap;
}

export type RawSink = (rec: Dict) => void;
export class LiveAdapter {
  mode = 'live';
  lastReceived: number | null = null;
  lastLatency: number | null = null;
  quoteHistory = new Map<string, Map<number, Dict>>();
  client = new GraphQLClient();
  constructor(public rawSink: RawSink | null = null) {}
  alignWin(snapshot: Dict): Dict {
    const win = get(snapshot.pools, 'WIN');
    if (!win) return snapshot;
    const ot = get(win, 'oddsUpdatedAt'), it = get(win, 'investmentUpdatedAt');
    if (!this.quoteHistory.has(snapshot.raceId)) this.quoteHistory.set(snapshot.raceId, new Map());
    const history = this.quoteHistory.get(snapshot.raceId)!;
    if (ot !== null) history.set(ot, win.odds);
    const cutoff = snapshot.timestamp - 300;
    for (const clock of [...history.keys()]) if (clock < cutoff) history.delete(clock);
    if (this.quoteHistory.size > 24) { const oldest = this.quoteHistory.keys().next().value!; if (oldest !== snapshot.raceId) this.quoteHistory.delete(oldest); }
    let chosen: number | null = truthy(get(win, 'amounts')) ? ot : null;
    let quotes: Dict | null = chosen !== null ? win.odds : null;
    if (chosen === null && it !== null) {
      const eligible = [...history.keys()].filter((t) => it - t >= 0 && it - t <= 15);
      if (eligible.length) { chosen = Math.max(...eligible); quotes = history.get(chosen)!; }
    }
    const active = [...new Set<string>((has(win, 'activeRunners') ? win.activeRunners : Object.keys(snapshot.runners)).map((r: any) => r))];
    if (chosen !== null && active.length && truthy(quotes) && active.every((r) => truthy(val(get(quotes, r)))) && val(get(win, 'reportedTotal')) !== null) {
      win.total = win.reportedTotal;
      const reciprocal = active.map((r) => [r, 1 / val(quotes![r])] as [string, number]);
      const denom = pyFloatSum(reciprocal.map(([, v]) => v));
      win.amounts = Object.fromEntries(reciprocal.map(([r, v]) => [r, metric(val(win.total) * v / denom, 'ESTIMATED', 'WIN pool × normalized reciprocal odds；已配對真來源時間，仍受報價取整影響', 'HKJC WIN pool + observed odds')]));
      win.amountOdds = quotes; win.amountOddsUpdatedAt = chosen; win.flowUpdatedAt = Math.max(chosen, it);
      win.alignment = chosen === ot ? 'CURRENT' : 'OBSERVED_HISTORY';
    } else { win.flowUpdatedAt = null; win.alignment = 'WAITING'; }
    snapshot.id = snapshotId(snapshot);
    return snapshot;
  }
  async query(name: string, variables: Dict): Promise<[Dict, number]> {
    const payload = JSON.stringify({ query: QUERIES[name], variables });
    const start = monotonic();
    const result = await this.client.post(payload);
    const latency = (monotonic() - start) * 1000;
    const received = nowSeconds();
    this.lastReceived = received; this.lastLatency = latency;
    if (this.rawSink) this.rawSink({ query: name, variables, receivedAt: received, latency, payload: result });
    if (truthy(get(result, 'errors'))) throw new PyValueError('HKJC GraphQL: ' + JSON.stringify(result.errors).slice(0, 500));
    if (!isDict(get(result, 'data'))) throw new PyValueError('HKJC response 缺少 data');
    return [result, latency];
  }
  async meetings(date: string | null = null, venue: string | null = null): Promise<Dict[]> {
    const variables: Dict = {};
    if (date) variables.date = date;
    if (venue) variables.venueCode = venue;
    const [data] = await this.query('card', variables);
    let meetings = normalizeCards(data);
    if (date) meetings = meetings.filter((m) => m.date === date);
    if (venue) meetings = meetings.filter((m) => m.venue === venue);
    return meetings;
  }
  async catalog(now: number | null = null): Promise<Dict> {
    const [data] = await this.query('card', {});
    const K = (d: string, v: string) => `${d}\u0001${v}`;
    const meetings = new Map<string, Dict>();
    for (const m of normalizeCards(data)) meetings.set(K(m.date, m.venue), m);
    const entries = new Map<string, Dict>();
    for (const group of ['raceMeetings', 'activeMeetings'])
      for (const meeting of get(get(data, 'data', {}) || {}, group, []) || [])
        if (truthy(get(meeting, 'venueCode')) && truthy(get(meeting, 'date'))) entries.set(K(meeting.date, meeting.venueCode), meeting);
    const failures: Dict[] = [];
    const reqNos = (entry: Dict) => new Set<string>((get(entry, 'races', []) || []).filter((r: Dict) => get(r, 'no') !== null).map((r: Dict) => pyStr(r.no)));
    for (const [identity, entry] of entries) {
      const published = meetings.get(identity);
      const raceNumbers = new Set<string>(published ? published.races.filter((r: Dict) => truthy(get(r, 'runners'))).map((r: Dict) => pyStr(r.no)) : []);
      const required = reqNos(entry);
      if (published && raceNumbers.size && [...required].every((x) => raceNumbers.has(x))) continue;
      const [d, v] = identity.split('\u0001');
      try { for (const card of await this.meetings(d, v)) meetings.set(identity, card); }
      catch (exc) { failures.push({ date: d, venue: v, error: (exc as Error).message || String(exc) }); }
    }
    const schedule: Dict[] = [];
    for (const identity of [...entries.keys()].sort()) {
      const entry = entries.get(identity)!;
      const [d, v] = identity.split('\u0001');
      const posts = (get(entry, 'races', []) || []).map((r: Dict) => timestamp(get(r, 'postTime'))).filter((t: any) => t !== null) as number[];
      const card = meetings.get(identity);
      const required = reqNos(entry);
      const provided = new Set<string>(card ? card.races.filter((r: Dict) => truthy(get(r, 'runners'))).map((r: Dict) => pyStr(r.no)) : []);
      const full = Boolean(provided.size && [...required].every((x) => provided.has(x)) && card && card.races.every((r: Dict) => truthy(get(r, 'runners'))));
      const c = get(entry, 'country') || {};
      const info = classifyVenue(v, get(c, 'namech'), get(c, 'nameen'), get(c, 'code'), get(entry, 'meetingType')) || {};
      schedule.push({ date: d, venue: v, status: get(entry, 'status'), venueKind: get(info, 'venueKind'), venueLabel: get(info, 'venueLabel'), country: get(info, 'country'),
        firstPostTime: posts.length ? Math.min(...posts) : null, lastPostTime: posts.length ? Math.max(...posts) : null, raceCount: (get(entry, 'races', []) || []).length, cardAvailable: full, quality: 'DIRECT' });
    }
    const resultMeetings = sortedBy([...meetings.values()], (m) => [m.date, m.venue]);
    const checked = now === null ? nowSeconds() : now;
    const recommended = recommendRace(resultMeetings, checked);
    let message: string;
    if (recommended) {
      let race: Dict | null = null;
      for (const m of resultMeetings) for (const r of m.races) if (!race && r.id === recommended) race = r;
      message = `已更新 HKJC 賽事：${race!.date} ${or(get(race, 'venueLabel'), race!.venue)} 第 ${pyStr(race!.no)} 場`;
    } else {
      const pending = schedule.filter((m) => !m.cardAvailable);
      message = pending.length ? 'HKJC 已公布賽程，等待完整排位表及馬匹資料：' + pending.map((m) => m.date + ' ' + m.venue).join(', ') : 'HKJC 暫未提供今日／下一賽日可選賽事；保留已公布賽事供檢視';
    }
    if (failures.length) message += '；部分賽事查詢未成功，稍後會再更新';
    return { meetings: resultMeetings, schedule, recommendedRaceId: recommended, checkedAt: checked, status: recommended ? 'READY' : 'WAITING', message, errors: failures };
  }
  async fetch(race: Dict): Promise<Dict> {
    const variables = { date: race.date, venueCode: race.venue };
    const oddsVars = { ...variables, raceNo: race.no, oddsTypes: ['WIN', 'PLA', 'QIN', 'QPL', 'FCT', 'DBL'] };
    const dblVars = { ...variables, raceNo: 0, oddsTypes: ['DBL'] };
    const start = monotonic();
    const jobs: [string, string, Dict][] = [['card', 'card', variables], ['odds', 'odds', oddsVars], ['dbl', 'odds', dblVars]];
    if (race.no > 1) jobs.push(['prevwin', 'odds', { ...variables, raceNo: race.no - 1, oddsTypes: ['WIN'] }]);
    const box: Dict = {}; const errors: Dict = {};
    await Promise.all(jobs.map(async ([key, name, vars]) => { try { box[key] = await this.query(name, vars); } catch (exc) { errors[key] = exc; } }));
    if (errors.card || errors.odds) throw errors.card || errors.odds;
    const card = box.card[0]; let odds = box.odds[0];
    if (box.dbl && !errors.dbl) odds = mergeOddsPools(odds, box.dbl[0], ['DBL']);
    if (box.prevwin && !errors.prevwin) odds = mergeOddsPools(odds, box.prevwin[0], ['WIN']);
    const wall = (monotonic() - start) * 1000;
    this.lastLatency = wall;
    return this.alignWin(normalizeSnapshot(race, card, odds, nowSeconds(), wall));
  }
}

function assertFiniteJson(x: any): void {
  if (typeof x === 'number') { if (!Number.isFinite(x)) throw new PyValueError('Replay 包含無效 JSON / 非有限數值'); return; }
  if (x === undefined || typeof x === 'function') throw new PyValueError('Replay 包含無效 JSON / 非有限數值');
  if (Array.isArray(x)) { x.forEach(assertFiniteJson); return; }
  if (isDict(x)) for (const v of Object.values(x)) assertFiniteJson(v);
}
export const ReplayAdapter = {
  mode: 'replay',
  validate(document: any): [Dict, Dict[]] {
    assertFiniteJson(document);
    if (!isDict(document) || document.schemaVersion !== 1) throw new PyValueError('Replay 需要 schemaVersion=1');
    const race = get(document, 'race', {});
    if (!isDict(race) || !Array.isArray(get(race, 'runners')) || typeof get(race, 'id') !== 'string' || !race.id || typeof get(race, 'postTime') !== 'number') throw new PyValueError('Replay 賽事資料不完整');
    const snaps = get(document, 'snapshots');
    if (!Array.isArray(snaps) || !(snaps.length > 0 && snaps.length <= 10000)) throw new PyValueError('Replay 必須有 1–10000 個 snapshots');
    const finite = (v: any) => isFiniteNum(v);
    const validMetric = (m: any, positive = false) => {
      if (!isDict(m) || !['DIRECT', 'DERIVED', 'ESTIMATED', 'UNAVAILABLE'].includes(get(m, 'quality'))) throw new PyValueError('Replay metric quality 無效');
      const v = get(m, 'value');
      if ((m.quality === 'UNAVAILABLE' && v !== null) || (v === null && m.quality !== 'UNAVAILABLE')) throw new PyValueError('Replay metric value / quality 不一致');
      if (v !== null && (!finite(v) || v < 0 || (positive && v <= 0))) throw new PyValueError('Replay metric 數值無效');
    };
    if (!finite(race.postTime)) throw new PyValueError('Replay postTime 必須有限');
    const ids = race.runners.filter(isDict).map((r: Dict) => pyStr(get(r, 'no')));
    if (!ids.length || ids.length !== race.runners.length || new Set(ids).size !== ids.length || ids.some((r: string) => !isDigit(r) || parseInt(r, 10) <= 0)) throw new PyValueError('Replay runner IDs 無效或重複');
    const idSet = new Set<string>(ids);
    const active = new Set<string>(race.runners.filter((r: Dict) => !truthy(get(r, 'scratched'))).map((r: Dict) => pyStr(r.no)));
    const isId = (r: any) => typeof r === 'string' || (typeof r === 'number' && Number.isInteger(r));
    const now = nowSeconds();
    for (const sn of snaps) {
      if (!isDict(sn) || get(sn, 'raceId') !== race.id || typeof get(sn, 'timestamp') !== 'number' || !isDict(get(sn, 'pools')) || !isDict(get(sn, 'runners'))) throw new PyValueError('Replay snapshot schema／raceId 不符');
      if (!finite(sn.timestamp) || sn.timestamp > now + 5 || !finite(get(sn, 'sourceTimestamp')) || sn.sourceTimestamp !== sn.timestamp) throw new PyValueError('Replay timestamp / sourceTimestamp 無效或超前');
      const rk = Object.keys(sn.runners);
      if (rk.length !== idSet.size || !rk.every((k) => idSet.has(k))) throw new PyValueError('Replay snapshot runner IDs 不符賽事');
      for (const name of ['receivedAt', 'latency']) if (get(sn, name) !== null && (!finite(sn[name]) || sn[name] < 0)) throw new PyValueError('Replay receipt / latency 無效');
      for (const r of Object.values(sn.runners) as any[]) {
        if (!isDict(r)) throw new PyValueError('Replay runner 無效');
        validMetric(get(r, 'winOdds'), true); validMetric(get(r, 'placeOdds'), true);
      }
      if (!['live', 'mock', 'imported'].includes(get(sn, 'source'))) throw new PyValueError('Replay source 必須係 live/mock/imported');
      for (const pool of Object.values(sn.pools) as any[]) {
        if (!isDict(pool) || !has(pool, 'total')) throw new PyValueError('Replay pool 必須有 total');
        if (['amounts', 'combinations', 'odds'].some((k) => !isDict(get(pool, k, {})))) throw new PyValueError('Replay pool matrix 無效');
        for (const m of [get(pool, 'total', {}), ...Object.values(get(pool, 'amounts', {})), ...Object.values(get(pool, 'combinations', {}))]) validMetric(m);
        for (const name of ['updatedAt', 'oddsUpdatedAt', 'investmentUpdatedAt', 'amountOddsUpdatedAt', 'flowUpdatedAt'])
          if (get(pool, name) !== null && (!finite(pool[name]) || pool[name] > sn.timestamp)) throw new PyValueError('Replay pool timestamp 無效／晚於 snapshot');
        if (has(pool, 'amountOdds')) {
          if (!isDict(pool.amountOdds)) throw new PyValueError('Replay amountOdds 無效');
          for (const m of Object.values(pool.amountOdds)) validMetric(m, true);
        }
        const amounts = get(pool, 'amounts', {});
        let poolActive = active;
        if (has(pool, 'activeRunners')) {
          const hist = pool.activeRunners;
          if (!Array.isArray(hist) || !hist.length || hist.some((r: any) => !isId(r)) || new Set(hist.map(pyStr)).size !== hist.length || !hist.map(pyStr).every((r: string) => idSet.has(r))) throw new PyValueError('Replay activeRunners 無效或重複');
          poolActive = new Set(hist.map(pyStr));
        }
        if (truthy(amounts)) {
          const ak = Object.keys(amounts);
          const vals = Object.values(amounts).map((v) => val(v));
          const bad = ak.length !== poolActive.size || !ak.every((k) => poolActive.has(k)) || vals.some((v) => v === null) || val(pool.total) === null
            || Math.abs(pyFloatSum(vals) - val(pool.total)) > Math.max(1, val(pool.total) * 0.000001);
          if (bad) throw new PyValueError('Replay runner amounts 不完整或不守恆');
        }
      }
      const dbl = get(sn, 'outgoingDouble', {});
      if (!isDict(dbl)) throw new PyValueError('Replay outgoingDouble 無效');
      const second = get(dbl, 'secondLegRunners', []);
      if (!Array.isArray(second) || second.some((r: any) => !isId(r) || !isDigit(pyStr(r)) || parseInt(pyStr(r), 10) <= 0) || new Set(second.map(pyStr)).size !== second.length) throw new PyValueError('Replay DBL 第二關 IDs 無效或重複');
      if (!isDict(get(dbl, 'combinations', {}))) throw new PyValueError('Replay DBL matrix 無效');
      for (const m of Object.values(get(dbl, 'combinations', {}))) validMetric(m);
      if (get(dbl, 'total') !== null) validMetric(dbl.total);
      if (get(dbl, 'updatedAt') !== null && (!finite(dbl.updatedAt) || dbl.updatedAt > sn.timestamp)) throw new PyValueError('Replay DBL timestamp 無效／晚於 snapshot');
      const incoming = get(sn, 'incomingDouble', {});
      if (!isDict(incoming) || !Object.keys(incoming).every((k) => idSet.has(k))) throw new PyValueError('Replay incomingDouble IDs 無效');
      for (const prices of Object.values(incoming) as any[]) {
        if (!isDict(prices)) throw new PyValueError('Replay incomingDouble price 無效');
        for (const name of ['winner', 'runnerUp']) validMetric(get(prices, name), true);
      }
      sn.id = snapshotId(sn);
    }
    if (new Set(snaps.map((x: Dict) => x.timestamp)).size !== snaps.length) throw new PyValueError('Replay 有重複 timestamp；請先整理 source revisions');
    return [race, sortedBy(snaps, (x: Dict) => x.timestamp)];
  },
};

export const MockAdapter = {
  mode: 'mock',
  meetings(): Dict[] { return [{ date: '2026-01-01', venue: 'ST', currentRace: 1, races: [1, 2].map((n) => MockAdapter.race(n)) }]; },
  race(no = 1): Dict {
    const names = ['示範飛躍', '示範星河', '示範追風', '示範赤兔', '示範金駒', '示範青雲', '示範雷霆', '示範朝陽'];
    return { id: `2026-01-01_ST_${no}`, date: '2026-01-01', venue: 'ST', no, name: `模擬資金測試賽 ${no}`, raceClass: '測試班', distance: metric(1200 + 200 * (no - 1), 'DIRECT', '', 'SYNTHETIC'),
      track: '草地', course: 'A', going: '測試', postTime: 1767243600 + (no - 1) * 1800, status: 'MOCK', quality: 'DIRECT',
      runners: names.map((n, i) => ({ no: i + 1, name: no === 1 ? n : n + '二', scratched: false, jockey: '測試', trainer: '測試', draw: metric(i + 1, 'DIRECT', '', 'SYNTHETIC') })) };
  },
  snapshots(race: Dict): Dict[] {
    const SYN = (v: number) => metric(v, 'DIRECT', '', 'SYNTHETIC');
    const amounts = [360000, 230000, 150000, 100000, 70000, 45000, 30000, 15000];
    const pairs = new Map<string, number>();
    for (let i = 1; i < 9; i++) for (let j = i + 1; j < 9; j++) pairs.set(`${i},${j}`, 10000.0);
    const forecast = new Map<string, number>();
    for (let i = 1; i < 9; i++) for (let j = 1; j < 9; j++) if (i !== j) forecast.set(`${i},${j}`, i < j ? 9000.0 : 6000.0);
    const sumArr = pySum;   // Python sum() over the mock's int/float mix (CPython ≥ 3.12 semantics)
    const frames: Dict[] = [];
    for (let step = 0; step < 97; step++) {
      const t = race.postTime - 960 + step * 10;
      if (step) {
        for (let i = 0; i < 8; i++) {
          const normal = amounts[i] / sumArr(amounts) * 45000;
          const burst = i === 5 && step >= 60 && step < 69 ? 48000 : i === 3 && step >= 78 && step < 89 ? 85000 : 0;
          amounts[i] += normal + burst;
        }
        for (const k of pairs.keys()) pairs.set(k, pairs.get(k)! + 1200 + (k.split(',').includes('6') && step >= 56 && step < 65 ? 20000 : 0));
        for (const k of forecast.keys()) {
          const [i, j] = k.split(',');
          forecast.set(k, forecast.get(k)! + 900 + (i === '6' && step >= 56 && step < 65 ? 18000 : 0) + (j === '6' && step >= 56 && step < 65 ? 12000 : 0));
        }
      }
      const total = sumArr(amounts);
      const runners: Dict = {};
      amounts.forEach((a, i) => { runners[String(i + 1)] = { winOdds: SYN(pyRound(0.825 * total / a, 1)), placeOdds: SYN(pyRound(1.2 + i * 0.5 + Math.sin(step * 0.15 + i) * 0.1, 1)) }; });
      const pools: Dict = { WIN: { total: SYN(total), amounts: Object.fromEntries(amounts.map((a, i) => [String(i + 1), SYN(a)])), updatedAt: t } };
      for (const [name, factor] of [['QIN', 1], ['QPL', 0.7]] as [string, number][])
        pools[name] = { total: SYN(sumArr(pairs.values()) * factor), combinations: Object.fromEntries([...pairs].map(([k, v]) => [k, SYN(v * factor)])), complete: true, updatedAt: t };
      if (get(race, 'no') === 1) {
        pools.FCT = { total: SYN(sumArr(forecast.values())), combinations: Object.fromEntries([...forecast].map(([k, v]) => [k, SYN(v)])), complete: true, updatedAt: t,
          activeRunners: ['1', '2', '3', '4', '5', '6', '7', '8'], quality: 'DIRECT', sourceQuality: 'DIRECT', unavailableReason: null, edgeCount: 56, expectedEdgeCount: 56,
          diagnostics: { sourceSeen: true, directMatrixSeen: true, matrixComplete: true, edgeCount: 56, expectedEdgeCount: 56, totalConserved: true, syncSeconds: 0, oddsSeen: false, sourceKind: 'combinations' } };
      }
      const outCombos: Dict = {};
      amounts.forEach((a, i) => { for (const j of [1, 2]) outCombos[`${i + 1},${j}`] = SYN(a * (i === 5 ? 1.8 : 1) * (1 + step * 0.001) * j); });
      const outgoing = { complete: true, secondLegRunners: [1, 2], updatedAt: t, combinations: outCombos };
      const incoming: Dict = {};
      for (let i = 0; i < 8; i++) incoming[String(i + 1)] = { winner: SYN(pyRound(2 + i * 2 + step * 0.002, 2)), runnerUp: SYN(pyRound(3 + i * 2.5 + step * 0.003, 2)) };
      let poolSum = 0.0, poolSeen = 0;
      for (const pp of Object.values(pools) as Dict[]) { const tv = val(or(get(pp, 'total'), get(pp, 'reportedTotal'))); if (tv === null) continue; poolSum += tv; poolSeen += 1; }
      const extras = total * 0.55 + sumArr(pairs.values()) * 0.25;
      const raceTotal = poolSeen ? metric(poolSum + extras, 'DIRECT', '', 'SYNTHETIC poolInvs.investment sum') : metric(null, 'DERIVED', '未有彩池投注總額', 'SYNTHETIC');
      const snap: Dict = { schemaVersion: 1, raceId: race.id, source: 'mock', timestamp: t, sourceTimestamp: t, receivedAt: t, latency: 0, runners, pools, outgoingDouble: outgoing, incomingDouble: incoming, raceTotalInvestment: raceTotal };
      snap.id = snapshotId(snap); frames.push(snap);
    }
    return frames;
  },
};
