// Port of backend/storage.py (SQLite) to an in-memory store with an append-only file persistence driver.
// On iOS the driver is the native bridge (files under Application Support); in a desktop browser it is the
// dev server (/__native) or, as a fallback, nothing (memory only).
/* eslint-disable @typescript-eslint/no-explicit-any */
import { callNative } from './native';
import { type Dict, deepCopy, get, truthy } from './py';
import { type DblMatrix, extractDblMatrix } from './sources';

export interface FileDriver {
  read(path: string): Promise<string | null>;
  write(path: string, text: string): Promise<void>;
  append(path: string, text: string): Promise<void>;
  remove(path: string): Promise<void>;
  list(dir: string): Promise<string[]>;
}
export const nativeFileDriver: FileDriver = {
  read: async (path) => (await callNative<{ data: string | null }>({ op: 'file', action: 'read', path })).data,
  write: async (path, data) => { await callNative({ op: 'file', action: 'write', path, data }); },
  append: async (path, data) => { await callNative({ op: 'file', action: 'append', path, data }); },
  remove: async (path) => { await callNative({ op: 'file', action: 'delete', path }); },
  list: async (dir) => (await callNative<{ names: string[] }>({ op: 'file', action: 'list', path: dir })).names || [],
};
export class MemoryDriver implements FileDriver {
  files = new Map<string, string>();
  async read(p: string) { return this.files.has(p) ? this.files.get(p)! : null; }
  async write(p: string, t: string) { this.files.set(p, t); }
  async append(p: string, t: string) { this.files.set(p, (this.files.get(p) || '') + t); }
  async remove(p: string) { this.files.delete(p); }
  async list(d: string) { return [...this.files.keys()].filter((k) => k.startsWith(d + '/')).map((k) => k.slice(d.length + 1)); }
}

const RAW_RING = 120;                 // full raw HKJC responses kept for /api/raw export (memory only)
const DBL_RETENTION_S = 3 * 86400;    // DBL matrix index retention (dbl_pct looks back ≤ 6 h)
const MAX_RECORDINGS = 60;            // persisted races (oldest pruned with their snapshots)
const MAX_LOADED = 6;                 // race snapshot arrays kept in memory
const volatileKey = (key: string) => key.startsWith('mock:');
const snapPath = (key: string) => 'snaps/' + encodeURIComponent(key) + '.jsonl';
const legsKey = (legs: number[]) => legs.join(',');

type DblRecord = { t: number; d: Map<string, DblMatrix> };
function dumps(x: any): string {
  return JSON.stringify(x, (_k, v) => {
    if (typeof v === 'number' && !Number.isFinite(v)) throw new TypeError('Out of range float values are not JSON compliant');
    return v;
  });
}

export class Store {
  settings = new Map<string, any>();
  racesMap = new Map<string, { key: string; mode: string; race: Dict }>();
  marks = new Map<string, string[]>();
  snaps = new Map<string, Dict[]>();
  private loadOrder: string[] = [];
  private loading = new Map<string, Promise<void>>();
  dbl: DblRecord[] = [];
  private matrixIds = new Map<DblMatrix, number>();
  private matrixBySig = new Map<string, DblMatrix>();
  private nextMatrixId = 1;
  rawRing: string[] = [];
  private metaTimer: any = null;
  private queue: Promise<void> = Promise.resolve();
  constructor(public driver: FileDriver | null = null) {}

  private io(fn: () => Promise<void>): void {
    if (!this.driver) return;
    this.queue = this.queue.then(fn).catch((e) => console.warn('[store] persist failed', e));
  }
  flush(): Promise<void> { if (this.metaTimer) { clearTimeout(this.metaTimer); this.metaTimer = null; this.writeMeta(); } return this.queue; }

  async init(): Promise<void> {
    const d = this.driver;
    if (!d) return;
    try {
      const meta = await d.read('meta.json');
      if (meta) {
        const m = JSON.parse(meta);
        for (const [k, v] of Object.entries(m.settings || {})) this.settings.set(k, v);
        for (const r of m.races || []) this.racesMap.set(r.key, r);
        for (const [k, v] of Object.entries(m.marks || {})) this.marks.set(k, v as string[]);
      }
    } catch (e) { console.warn('[store] meta unreadable', e); }
    // Retention: keep the newest MAX_RECORDINGS persisted recordings; drop orphan snapshot files.
    const keys = [...this.racesMap.keys()];
    const drop = keys.slice(0, Math.max(0, keys.length - MAX_RECORDINGS));
    for (const k of drop) { this.racesMap.delete(k); this.marks.delete(k); }
    const keep = new Set([...this.racesMap.keys()].map((k) => encodeURIComponent(k) + '.jsonl'));
    try { for (const name of await d.list('snaps')) if (!keep.has(name)) await d.remove('snaps/' + name); } catch { /* none */ }
    for (const k of [...this.settings.keys()]) if (k.startsWith('flowTrialPost:') && !this.racesMap.has(k.slice(14))) this.settings.delete(k);
    if (drop.length) this.writeMeta();
    await this.loadDblIndex();
  }
  private writeMeta(): void {
    const races = [...this.racesMap.values()].filter((r) => !volatileKey(r.key));
    const marks = Object.fromEntries([...this.marks].filter(([k]) => !volatileKey(k)));
    const text = dumps({ settings: Object.fromEntries(this.settings), races, marks });
    this.io(() => this.driver!.write('meta.json', text));
  }
  private scheduleMeta(): void {
    if (!this.driver || this.metaTimer) return;
    this.metaTimer = setTimeout(() => { this.metaTimer = null; this.writeMeta(); }, 400);
  }

  setting(key: string, dflt: any = null): any { return this.settings.has(key) ? deepCopy(this.settings.get(key)) : dflt; }
  setSetting(key: string, value: any): void { this.settings.set(key, deepCopy(value)); this.scheduleMeta(); }
  saveRace(key: string, mode: string, race: Dict): void {
    this.racesMap.delete(key); // INSERT OR REPLACE → new rowid (moves to the end)
    this.racesMap.set(key, { key, mode, race: deepCopy(race) });
    if (!volatileKey(key)) this.scheduleMeta();
  }
  races(): Dict[] { return [...this.racesMap.values()].map((r) => ({ key: r.key, mode: r.mode, race: deepCopy(r.race) })); }
  race(key: string): Dict | null { const r = this.racesMap.get(key); return r ? deepCopy(r.race) : null; }

  private touch(key: string): void {
    this.loadOrder = this.loadOrder.filter((k) => k !== key); this.loadOrder.push(key);
    while (this.loadOrder.length > MAX_LOADED) {
      const idx = this.loadOrder.findIndex((k) => !volatileKey(k) && k !== key);
      if (idx < 0) break;
      const [old] = this.loadOrder.splice(idx, 1);
      this.snaps.delete(old);
    }
  }
  async ensureLoaded(key: string): Promise<void> {
    if (this.snaps.has(key)) { this.touch(key); return; }
    if (!this.loading.has(key)) {
      this.loading.set(key, (async () => {
        const list: Dict[] = [];
        if (this.driver && !volatileKey(key)) {
          await this.queue;
          let text: string | null = null;
          try { text = await this.driver.read(snapPath(key)); } catch { text = null; }
          let updates = 0;
          for (const line of (text || '').split('\n')) {
            if (!line.trim()) continue;
            let item: Dict;
            try { item = JSON.parse(line); } catch { continue; }
            if (item.__u !== undefined) {
              const last = list[list.length - 1];
              if (last && last.id === item.__u) { if (item.incomingDouble) last.incomingDouble = item.incomingDouble; last.pools = last.pools || {}; Object.assign(last.pools, item.pools || {}); }
              updates++;
            } else if (!list.length || item.timestamp > list[list.length - 1].timestamp) list.push(item);
            else if (!list.some((x) => x.id === item.id || x.timestamp === item.timestamp)) { list.push(item); list.sort((a, b) => a.timestamp - b.timestamp); }
          }
          if (updates > 50) { const body = list.map((x) => dumps(x) + '\n').join(''); this.io(() => this.driver!.write(snapPath(key), body)); }
        }
        if (!this.snaps.has(key)) this.snaps.set(key, list);
        this.touch(key);
      })().finally(() => this.loading.delete(key)));
    }
    await this.loading.get(key);
  }
  /** Returns false when the snapshot is not newer than the latest stored one (then only the latest row's
   * incomingDouble / DBL_UP / DBL_DOWN are refreshed, exactly as storage.py does). Caller must ensureLoaded. */
  add(key: string, snapshot: Dict): boolean {
    if (!this.snaps.has(key)) this.snaps.set(key, []);
    const list = this.snaps.get(key)!;
    const last = list[list.length - 1];
    if (last && snapshot.timestamp <= last.timestamp) {
      const upd: Dict = { __u: last.id, pools: {} };
      const next: Dict = { ...last, pools: { ...(last.pools || {}) } }; // copy-on-write: cached analyses keep the old object
      let changed = false;
      if (truthy(get(snapshot, 'incomingDouble'))) {
        if (dumps(snapshot.incomingDouble) !== dumps(last.incomingDouble)) changed = true;
        next.incomingDouble = snapshot.incomingDouble; upd.incomingDouble = snapshot.incomingDouble;
      }
      for (const name of ['DBL_UP', 'DBL_DOWN']) {
        if (name in (snapshot.pools || {})) {
          if (dumps(snapshot.pools[name]) !== dumps(get(last.pools, name))) changed = true;
          next.pools[name] = snapshot.pools[name]; upd.pools[name] = snapshot.pools[name];
        }
      }
      if (changed) {
        list[list.length - 1] = next;
        if (this.driver && !volatileKey(key)) { const line = dumps(upd) + '\n'; this.io(() => this.driver!.append(snapPath(key), line)); }
      }
      return false;
    }
    if (list.some((x) => x.id === snapshot.id)) return false; // INSERT OR IGNORE (primary key key,id)
    list.push(snapshot);
    if (this.driver && !volatileKey(key)) { const line = dumps(snapshot) + '\n'; this.io(() => this.driver!.append(snapPath(key), line)); }
    return true;
  }
  /** Bulk insert (import). */
  insertAll(key: string, mode: string, race: Dict, snaps: Dict[]): void {
    if (this.racesMap.has(key)) throw new TypeError('UNIQUE constraint failed: races.key');
    this.racesMap.set(key, { key, mode, race: deepCopy(race) });
    this.snaps.set(key, snaps.slice());
    this.touch(key);
    if (this.driver && !volatileKey(key)) { const body = snaps.map((x) => dumps(x) + '\n').join(''); this.io(() => this.driver!.write(snapPath(key), body)); }
    this.scheduleMeta();
  }
  clearSnapshots(key: string): void {
    this.snaps.set(key, []);
    this.touch(key);
    if (this.driver && !volatileKey(key)) this.io(() => this.driver!.remove(snapPath(key)));
  }
  async snapshots(key: string): Promise<Dict[]> { await this.ensureLoaded(key); return this.snaps.get(key)!.slice(); }

  // ---- raw sources ------------------------------------------------------------------------
  /** storage.raw(): keep the full payload in a small ring (export) and index its DBL matrices (dbl_pct). */
  raw(record: Dict): void {
    const received = typeof record.receivedAt === 'number' ? record.receivedAt : Date.now() / 1000;
    try { this.rawRing.push(JSON.stringify(record)); } catch { /* skip */ }
    if (this.rawRing.length > RAW_RING) this.rawRing.splice(0, this.rawRing.length - RAW_RING);
    const body = get(record, 'payload') || {};
    const legsSeen: number[][] = [];
    for (const meeting of get(get(body, 'data') || {}, 'raceMeetings') || [])
      for (const pool of get(meeting, 'pmPools') || [])
        if (get(pool, 'oddsType') === 'DBL') { const legs = get(get(pool, 'leg') || {}, 'races'); if (Array.isArray(legs) && !legsSeen.some((l) => l.join() === legs.join())) legsSeen.push(legs); }
    if (!legsSeen.length) return;
    const d = new Map<string, DblMatrix>();
    const lines: string[] = [];
    for (const legs of legsSeen) {
      const m = extractDblMatrix(body, legs);
      if (!m.size) continue;
      const [mm, line] = this.intern(m, legsKey(legs));
      if (line) lines.push(line);
      d.set(legsKey(legs), mm);
    }
    if (!d.size) return;
    this.insertDbl({ t: received, d });
    if (this.driver) {
      lines.push(dumps({ t: received, d: Object.fromEntries([...d].map(([k, m]) => [k, this.matrixIds.get(m)])) }));
      const text = lines.map((l) => l + '\n').join('');
      this.io(() => this.driver!.append('dbl.jsonl', text));
    }
  }
  private intern(m: DblMatrix, legs: string): [DblMatrix, string | null] {
    const sig = legs + '|' + [...m].map(([k, v]) => k + '=' + v).join(';');
    const hit = this.matrixBySig.get(sig);
    if (hit) return [hit, null];
    const id = this.nextMatrixId++;
    this.matrixBySig.set(sig, m); this.matrixIds.set(m, id);
    return [m, dumps({ m: id, c: [...m] })];
  }
  private insertDbl(rec: DblRecord): void {
    const a = this.dbl;
    if (!a.length || a[a.length - 1].t <= rec.t) { a.push(rec); return; }
    let i = a.length; while (i > 0 && a[i - 1].t > rec.t) i--; a.splice(i, 0, rec);
  }
  private async loadDblIndex(): Promise<void> {
    let text: string | null = null;
    try { text = await this.driver!.read('dbl.jsonl'); } catch { text = null; }
    if (!text) return;
    const byId = new Map<number, DblMatrix>();
    const cutoff = Date.now() / 1000 - DBL_RETENTION_S;
    let lines = 0;
    for (const line of text.split('\n')) {
      if (!line) continue; lines++;
      let item: Dict; try { item = JSON.parse(line); } catch { continue; }
      if (item.m !== undefined) byId.set(item.m, new Map(item.c));
      else if (typeof item.t === 'number' && item.t >= cutoff) {
        const d = new Map<string, DblMatrix>();
        for (const [legs, id] of Object.entries(item.d || {})) { const m = byId.get(id as number); if (m) d.set(legs, m); }
        if (d.size) this.insertDbl({ t: item.t, d });
      }
    }
    // Re-intern (fresh ids) and compact the file.
    const out: string[] = [];
    for (const rec of this.dbl) {
      const d = new Map<string, DblMatrix>();
      for (const [legs, m] of rec.d) { const [mm, l] = this.intern(m, legs); if (l) out.push(l); d.set(legs, mm); }
      rec.d = d;
      out.push(dumps({ t: rec.t, d: Object.fromEntries([...d].map(([k, m]) => [k, this.matrixIds.get(m)])) }));
    }
    if (out.length < lines) { const body = out.map((l) => l + '\n').join(''); this.io(() => this.driver!.write('dbl.jsonl', body)); }
  }
  private lowerBound(t: number): number {
    let lo = 0, hi = this.dbl.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (this.dbl[mid].t < t) lo = mid + 1; else hi = mid; }
    return lo;
  }
  /** Server._dbl_matrix_near core: largest matrix for `legs` among raw records received in [start,end]. */
  dblLargest(start: number, end: number, legs: number[]): DblMatrix {
    let best: DblMatrix = new Map();
    const k = legsKey(legs);
    for (let i = this.lowerBound(start); i < this.dbl.length && this.dbl[i].t <= end; i++) {
      const m = this.dbl[i].d.get(k);
      if (m && m.size > best.size) best = m;
    }
    return best;
  }
  /** raw_first_matching(start,end, has DBL matrix for legs) → [received, matrix] | null */
  dblFirst(start: number, end: number, legs: number[]): [number, DblMatrix] | null {
    const k = legsKey(legs);
    for (let i = this.lowerBound(start); i < this.dbl.length && this.dbl[i].t <= end; i++) {
      const m = this.dbl[i].d.get(k);
      if (m && m.size) return [this.dbl[i].t, m];
    }
    return null;
  }
  exportRaw(): Dict[] { return this.rawRing.map((x) => JSON.parse(x)); }

  getMarks(key: string): string[] { return (this.marks.get(key) || []).slice(); }
  mark(key: string, runner: string): string[] {
    const cur = this.marks.get(key) || [];
    this.marks.set(key, cur.includes(runner) ? cur.filter((r) => r !== runner) : [...cur, runner]);
    this.scheduleMeta();
    return this.getMarks(key);
  }
}
