// Port of backend/server.py: the Service (collector, selection, state, 孖上／孖下, 007 trial) and the /api router.
// Runs inside the page. HKJC traffic goes through the native bridge (see native.ts); nothing else leaves the device.
/* eslint-disable @typescript-eslint/no-explicit-any */
import { analyze, DEFAULTS, metric, sourceHealth } from './engine';
import * as MINI from './mini';
import * as FT from './flow007';
import * as PG from './postgate';
import { sha256Hex } from './sha256';
import { OSError } from './native';
import { type Dict, deepCopy, fmtF, fmtG, get, isDigit, monotonic, nowSeconds, pyRound, pyStr, PyValueError, truthy } from './py';
import { dblImpliedOdds, dblSignedShortenPct, type DblMatrix, LiveAdapter, LOCAL_VENUES, MockAdapter, ReplayAdapter } from './sources';
import { type FileDriver, Store } from './storage';

// /api/health 'version' — server.py still answers '0.6.0' in v0.7.6 (kept identical for API parity); the app version is 0.7.6.
export const VERSION = '0.6.0';
export const APP_VERSION = '0.7.6';
// v0.7.3: HKJC is polled every 1 s by default (server.py DEFAULT_POLL_SECONDS; the Python HKJC_POLL_SECONDS override
// has no in-app equivalent). Clamp kept as in poll_interval_seconds(); after the scheduled post it is always 1 s.
export const DEFAULT_POLL_SECONDS = 1.0;
export const pollIntervalSeconds = (): number => Math.min(30.0, Math.max(1.0, DEFAULT_POLL_SECONDS));

// v0.7.3 cheap change signal for the 1 s UI poll (server.py content_etag): /api/state and /api/flow-trial carry an ETag
// and answer If-None-Match with 304 (no body) when nothing the screen shows has changed. Receipt telemetry that moves on
// every HKJC poll even when the data is identical is left out of the signal. In-app the "304" skips building/serialising
// the response (and the React setState), exactly like the HTTP version skips the body.
export const ETAG_VERSION = 'v0.7.3-1';
const STATE_VOLATILE_HEALTH = ['lastReceived', 'latency'];
const STATE_VOLATILE_COLLECTION = ['lastReceived', 'catalogCheckedAt'];
const sortedJson = (x: any): string => JSON.stringify(x, (_k, v) => (v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, v[k]])) : v === undefined ? null : typeof v === 'number' && !Number.isFinite(v) ? String(v) : v));
export function contentEtag(...parts: any[]): string {
  return '"' + sha256Hex(sortedJson([ETAG_VERSION, ...parts])).slice(0, 20) + '"';
}
const omit = (o: Dict, keys: string[]) => Object.fromEntries(Object.entries(o).filter(([k]) => !keys.includes(k)));
export const DBL_PCT_CUT_MIN_LOCAL = 17;
export const DBL_PCT_CUT_MIN_OVERSEAS = 13;
export const DBL_PCT_DRIFT_REASON = '--：隱含賠率較基準變長／不變（007 只顯示縮短，呢格留空）';
export const DBL_DOWN_MIN_SHOW_PCT = 3.0;
const floorReason = (signed: number) => `--：縮短 ${fmtF(signed, 1)}% 低於孖下顯示下限 3.0%（暫定，2026-09-28）`;

export function dblPctCutMinutes(race: Dict | null): number {
  const r = race || {};
  const kind = get(r, 'venueKind');
  if (kind === 'local' || kind === 'overseas') return kind === 'local' ? DBL_PCT_CUT_MIN_LOCAL : DBL_PCT_CUT_MIN_OVERSEAS;
  const venue = String(get(r, 'venue') || '').toUpperCase();
  return !venue || LOCAL_VENUES.has(venue) ? DBL_PCT_CUT_MIN_LOCAL : DBL_PCT_CUT_MIN_OVERSEAS;
}
export function dblPctMetric(base: number | null, now: number | null, source: string, note = '', minShow: number | null = null): Dict | null {
  const signed = dblSignedShortenPct(base ?? null, now ?? null);
  if (signed === null) return null;
  const tail = note ? '；' + note : '';
  const reason = 'ESTIMATED exposure concentration; NOT actual betting amount' + tail;
  let out: Dict;
  if (signed > 0 && minShow !== null && pyRound(signed, 1) < minShow) { out = metric(null, 'ESTIMATED', floorReason(signed) + tail, source); out.belowFloor = true; }
  else if (signed > 0) out = metric(signed, 'ESTIMATED', reason, source);
  else { out = metric(null, 'ESTIMATED', DBL_PCT_DRIFT_REASON + tail, source); out.drift = true; }
  out.signed = signed;
  return out;
}
export function schedulePollSeconds(postTime: any, now: number | null = null): number {
  const t = now === null ? nowSeconds() : now;
  if (typeof postTime !== 'number') return 60.0;
  if (postTime - t <= 0) return 1.0;
  return pollIntervalSeconds();
}
function asof(frame: Dict): any {
  const received = get(frame, 'receivedAt'), ts = get(frame, 'timestamp');
  if (typeof received === 'number' && (ts === null || received >= ts)) return received;
  return ts;
}
const isNum = (v: any): v is number => typeof v === 'number';
const newSession = (): Dict => ({ error: null, lastReceived: null, latency: null, polling: false });
const blank = (ids: string[], why: string) => Object.fromEntries(ids.map((r) => [r, metric(null, 'DERIVED', why)]));
const errMsg = (e: unknown) => (e instanceof Error ? e.message : String(e));

export class Service {
  store: Store;
  adapter: LiveAdapter;
  selected: Dict | null = null;
  sessions = new Map<string, Dict>();
  collectorEnabled = false;
  autoFollow = true;
  collector: Dict | null = null;
  catalogCache: Dict | null = null;
  catalogChecked = 0;
  private catalogPending: Promise<Dict> | null = null;
  discoveryChecked = 0;
  collectionError: string | null = null;
  selectionRevision = 0;
  viewerActiveUntil = 0;
  stopping = false;
  private stateCache: Dict | null = null;
  private stateCacheKey: string | null = null;
  private dblPctCache = new Map<string, Dict>();
  private dblPctLastValid = new Map<string, Dict>();
  private dblFirstSeen = new Map<string, [number, DblMatrix]>();
  private meetingRaces = new Map<string, Map<any, any>>();
  private ftConv = new Map<string, Map<string, FT.TrialSnap>>();
  ready: Promise<void>;
  constructor(driver: FileDriver | null) {
    this.store = new Store(driver);
    this.adapter = new LiveAdapter((rec) => this.store.raw(rec));
    this.ready = this.store.init().then(() => {
      const saved = this.store.setting('collector', {}) || {};
      this.collectorEnabled = truthy(get(saved, 'enabled'));
      this.autoFollow = 'autoFollow' in saved ? saved.autoFollow : true;
      this.collector = this.collectorEnabled ? get(saved, 'target') : null;
      if (this.collector) { this.selected = { ...this.collector }; this.sessions.set(this.collector.key, newSession()); }
    });
  }
  saveCollector(): void { this.store.setSetting('collector', { enabled: this.collectorEnabled, autoFollow: this.autoFollow, target: this.collector }); }
  viewerPresent(): void { this.viewerActiveUntil = nowSeconds() + 90; }
  collectionStatus(): Dict {
    const sel = this.collector;
    const session = sel ? this.sessions.get(sel.key) || {} : {};
    return { enabled: this.collectorEnabled, autoFollow: this.autoFollow, race: sel ? sel.race : null, key: sel ? sel.key : null,
      status: !this.collectorEnabled ? 'OFF' : nowSeconds() > this.viewerActiveUntil ? 'PAUSED' : this.collectionError ? 'ERROR' : sel ? 'COLLECTING' : 'WAITING',
      error: this.collectionError, lastReceived: get(session, 'lastReceived'), catalogCheckedAt: this.catalogChecked || null };
  }
  setFollow(enabled: any): Dict {
    if (typeof enabled !== 'boolean') throw new PyValueError('autoFollow must be boolean');
    this.viewerPresent();
    this.autoFollow = enabled;
    if (enabled) { this.collectorEnabled = true; this.discoveryChecked = 0; }
    this.selectionRevision += 1;
    this.saveCollector();
    return this.collectionStatus();
  }
  async catalog(): Promise<Dict> {
    if (this.catalogCache !== null && nowSeconds() - this.catalogChecked < 55) return this.catalogCache;
    if (!this.catalogPending) {
      this.catalogPending = (async () => {
        const result = await this.adapter.catalog();
        this.catalogCache = result; this.catalogChecked = nowSeconds();
        for (const name of ['selected', 'collector'] as const) {
          const sel = this[name];
          if (sel && sel.mode === 'live') {
            let fresh: Dict | null = null;
            for (const m of result.meetings) for (const r of m.races) if (!fresh && r.id === sel.race.id) fresh = r;
            if (fresh) { this.store.saveRace(sel.key, 'live', fresh); this[name] = { ...sel, race: fresh }; }
          }
        }
        return result;
      })().finally(() => { this.catalogPending = null; });
    }
    return this.catalogPending;
  }
  async discover(): Promise<void> {
    const now = nowSeconds();
    if (now > this.viewerActiveUntil || !this.collectorEnabled || !this.autoFollow || now - this.discoveryChecked < 60) return;
    this.discoveryChecked = now;
    const revision = this.selectionRevision;
    try {
      const catalog = await this.catalog();
      let race: Dict | null = null;
      for (const m of catalog.meetings) for (const r of m.races) if (!race && r.id === get(catalog, 'recommendedRaceId')) race = r;
      if (revision !== this.selectionRevision || !this.autoFollow) return;
      this.collectionError = null;
      if (race) {
        const target = { mode: 'live', key: 'live:' + race.id, race };
        this.store.saveRace(target.key, 'live', race);
        if (!this.sessions.has(target.key)) this.sessions.set(target.key, newSession());
        this.collector = target;
        if (!this.selected || this.selected.mode === 'live') this.selected = { ...target };
      } else this.collector = null;
      this.saveCollector();
    } catch (exc) {
      if (revision === this.selectionRevision && this.autoFollow) this.collectionError = errMsg(exc);
    }
  }
  async select(mode: any, raceId: any = null, date: any = null, venue: any = null, autoFollow: any = null, config: Dict | null = null): Promise<Dict> {
    this.viewerPresent();
    if (!['live', 'mock', 'replay'].includes(mode)) throw new PyValueError('Invalid adapter mode');
    for (const [name, value] of [['raceId', raceId], ['date', date], ['venue', venue]] as [string, any][])
      if (value !== null && value !== undefined && typeof value !== 'string') throw new PyValueError(name + ' must be a string');
    if (autoFollow !== null && autoFollow !== undefined && typeof autoFollow !== 'boolean') throw new PyValueError('autoFollow must be boolean');
    this.selectionRevision += 1;
    const revision = this.selectionRevision;
    let race: Dict, key: string;
    if (mode === 'replay') {
      const entry = this.store.races().find((x) => x.key === raceId);
      if (!entry) throw new PyValueError('未有此場已保存 snapshots');
      race = entry.race; key = entry.key;
    } else {
      const meetings = mode === 'mock' ? MockAdapter.meetings() : await this.adapter.meetings(date || null, venue || null);
      const races: Dict[] = meetings.flatMap((m) => m.races);
      for (const r of races) {
        const mk = `${get(r, 'date')}\u0001${get(r, 'venue')}`;
        if (!this.meetingRaces.has(mk)) this.meetingRaces.set(mk, new Map());
        this.meetingRaces.get(mk)!.set(get(r, 'no'), get(r, 'postTime'));
      }
      const found = raceId ? races.find((r) => r.id === raceId) : races[0];
      if (!found) throw new PyValueError('所選賽事未由 HKJC 提供；不會改用另一場');
      race = found; key = mode + ':' + race.id;
      this.store.saveRace(key, mode, race);
      if (mode === 'mock') {
        this.store.clearSnapshots(key);
        for (const s of MockAdapter.snapshots(race)) this.store.add(key, s);
      }
    }
    if (revision !== this.selectionRevision) throw new PyValueError('賽事選擇已更新；忽略較早要求');
    this.selected = { mode, key, race };
    if (!this.sessions.has(key)) this.sessions.set(key, newSession());
    if (mode === 'live') {
      this.collector = { ...this.selected };
      this.collectorEnabled = true;
      if (autoFollow !== null && autoFollow !== undefined) this.autoFollow = autoFollow;
      this.collectionError = null;
      this.saveCollector();
    }
    if (mode === 'live') await this.poll(true);
    return this.state(config);
  }
  async importReplay(document0: any): Promise<Dict> {
    let result: Dict, key: string, race: Dict, snaps: Dict[], session: Dict, sel: Dict;
    try {
      const document = JSON.parse(JSON.stringify(document0, (_k, v) => { if (typeof v === 'number' && !Number.isFinite(v)) throw new PyValueError('Out of range float values are not JSON compliant'); return v; }));
      [race, snaps] = ReplayAdapter.validate(document);
      key = 'imported:' + race.id + ':' + crypto.getRandomValues(new Uint8Array(16)).reduce((a, b) => a + b.toString(16).padStart(2, '0'), '');
      sel = { mode: 'replay', key, race };
      session = newSession();
      result = this.buildState(sel, session, snaps, []);
      JSON.stringify(result, (_k, v) => { if (typeof v === 'number' && !Number.isFinite(v)) throw new PyValueError('Out of range float values are not JSON compliant'); return v; });
      if (new Set(snaps.map((s) => s.id)).size !== snaps.length) throw new PyValueError('Replay contains duplicate snapshot IDs');
    } catch (exc) {
      throw new PyValueError('Invalid replay: ' + errMsg(exc));
    }
    this.store.insertAll(key, 'imported', race, snaps);
    this.sessions.set(key, session);
    this.selected = sel;
    this.selectionRevision += 1;
    return result;
  }
  async poll(force = false): Promise<void> {
    if (!force && nowSeconds() > this.viewerActiveUntil) return;
    const sel = this.collector ? { ...this.collector } : null;
    if (!sel || sel.mode !== 'live') return;
    if (!this.sessions.has(sel.key)) this.sessions.set(sel.key, newSession());
    const session = this.sessions.get(sel.key)!;
    if (session.polling && !force) return;
    session.polling = true;
    try {
      const s = await this.adapter.fetch(sel.race);
      await this.store.ensureLoaded(sel.key);
      this.store.add(sel.key, s);
      Object.assign(session, { error: null, lastReceived: s.receivedAt, latency: s.latency });
      if (this.collector && this.collector.key === sel.key) this.collectionError = null;
    } catch (exc) {
      Object.assign(session, { error: errMsg(exc), lastReceived: this.adapter.lastReceived, latency: this.adapter.lastLatency });
      if (this.collector && this.collector.key === sel.key) this.collectionError = errMsg(exc);
    } finally { session.polling = false; }
  }
  livePollWait(): number {
    const target = this.collector || this.selected;
    const race = target && get(target, 'mode') === 'live' ? get(target, 'race') : null;
    const post = get(race || {}, 'postTime');
    const now = nowSeconds();
    let interval = schedulePollSeconds(post, now);
    if (isNum(post)) {
      const remaining = post - now;
      if (remaining > 300) interval = Math.min(interval, remaining - 300);
      else if (remaining > 0) interval = Math.min(interval, remaining);
    }
    return Math.max(0.05, interval);
  }
  async worker(): Promise<void> {
    await this.ready;
    while (!this.stopping) {
      const started = monotonic();
      try { await this.discover(); await this.poll(); } catch (e) { console.warn('[worker]', e); }
      const wait = this.livePollWait() - (monotonic() - started);
      await new Promise((r) => setTimeout(r, Math.max(0.05, wait) * 1000));
    }
  }
  async state(config: Dict | null = null): Promise<Dict> {
    return (await this.stateWithEtag(config))[0];
  }
  /** server.Service.state_with_etag (v0.7.3): [state, ETag]. The ETag covers the cache identity of the computed frames
   * plus the per-request blocks (health minus receipt telemetry, collection minus receipt telemetry, tip dblPct, postGate). */
  async stateWithEtag(config: Dict | null = null): Promise<[Dict, string]> {
    const sel = this.selected ? { ...this.selected } : null;
    const session = sel ? { ...(this.sessions.get(sel.key) || newSession()) } : {};
    const collection = this.collectionStatus();
    if (!sel) {
      const out = { mode: 'live', race: null, frames: [], spectrum: {}, marks: [], collection, health: sourceHealth(null, null, null, '等待可用賽事', nowSeconds()) };
      return [out, contentEtag('nosel', omit(collection, STATE_VOLATILE_COLLECTION), get(out.health, 'status'), get(out.health, 'error'))];
    }
    const snaps = await this.store.snapshots(sel.key);
    const marks = this.store.getMarks(sel.key);
    const cfg = { ...DEFAULTS, ...(config || {}) };
    const last = snaps[snaps.length - 1];
    // v0.7.3 (same as server.py now): lastReceived/latency do not invalidate the computed frames; only the error text
    // affects the analysis payload. (The trailing DBL part catches an in-place DBL refresh of the same snapshot id.)
    const cacheKey = JSON.stringify([sel.key, sel.mode, sel.race, last ? last.id : null, snaps.length, cfg.window, cfg.baseline_minutes, marks, get(session, 'error'), last ? [last.incomingDouble, last.pools?.DBL_UP, last.pools?.DBL_DOWN] : null]);
    let cached = cacheKey === this.stateCacheKey ? this.stateCache : null;
    if (cached === null) {
      const built = this.buildState(sel, session, snaps, marks, config);
      const frames = (built.frames || []).map((fr: Dict) => ({ ...fr, dblPct: this.dblPct(sel.race, sel.key, asof(fr)) }));
      cached = { ...built, frames };
      this.stateCacheKey = cacheKey; this.stateCache = cached;
    }
    const health = sourceHealth(last ? last.sourceTimestamp : null, get(session, 'lastReceived'), get(session, 'latency'), get(session, 'error'), nowSeconds());
    if (sel.mode !== 'live') health.status = sel.mode.toUpperCase();
    let tipDbl = cached.frames && cached.frames.length ? cached.frames[cached.frames.length - 1].dblPct : this.dblPct(sel.race, sel.key, last ? asof(last) : null);
    tipDbl = this.keepLastDblPct(sel.key, tipDbl, sel.race);
    // v0.7.2 入閘後: frozen gate baseline for the B+D bars (display split only; values unchanged).
    const postGate = PG.mainView(cached.frames || [], PG.frozenPost(this.store, sel.key, sel.race), PG.POST_GATE_OFFSET_MIN, PG.GATE_MAX_AGE_SEC);
    const etag = contentEtag(cacheKey, omit(health, STATE_VOLATILE_HEALTH), omit(collection, STATE_VOLATILE_COLLECTION), tipDbl, postGate);
    return [{ ...cached, collection, health, dblPct: tipDbl, postGate, polling: get(session, 'polling', false) }, etag];
  }
  /** server.Service.mini() (/api/mini, mini2): latest stored snapshot for 獨贏／孖寶; 獨贏前 via engine.baseline()
   * at the main page's 「排序基準（開跑前分鐘）」 (default 15). No analyze(), no HKJC request. */
  async mini(baselineMinutes: number | null = null): Promise<Dict> {
    const minutes = baselineMinutes === null || baselineMinutes === undefined ? DEFAULTS.baseline_minutes : baselineMinutes;
    const sel = this.selected ? { ...this.selected } : null;
    const session = sel ? { ...(this.sessions.get(sel.key) || newSession()) } : {};
    const collection = this.collectionStatus();
    const now = nowSeconds();
    if (!sel) return MINI.view(null, null, 0, sourceHealth(null, null, null, '等待可用賽事', now), collection, { status: 'WAITING', timestamp: null, target: null, minutes, winOdds: {} });
    const snap = await this.store.latestSnapshot(sel.key);
    const race = sel.race; const post = get(race, 'postTime');
    let candidates: Dict[] = [];
    if (typeof post === 'number') candidates = await this.store.baselineCandidates(sel.key, post - minutes * 60, MINI.hasWinOdds);
    const before = MINI.winBefore(race, candidates, minutes);
    const health = sourceHealth(snap ? get(snap, 'sourceTimestamp') : null, get(session, 'lastReceived'), get(session, 'latency'), get(session, 'error'), now);
    if (sel.mode !== 'live') health.status = sel.mode.toUpperCase();
    return MINI.view(sel, snap, await this.store.snapshotCount(sel.key), health, collection, before);
  }
  private dblMatrixNear(centre: number | null, legs: number[], window = 25): DblMatrix {
    if (centre === null || centre === undefined) return new Map();
    return this.store.dblLargest(centre - window, centre + window, legs);
  }
  private prevPostTime(race: Dict | null): number | null {
    const no = get(race || {}, 'no');
    if (!Number.isInteger(no) || no <= 1) return null;
    for (const meeting of get(this.catalogCache || {}, 'meetings') || []) {
      if (get(meeting, 'date') === race!.date && get(meeting, 'venue') === race!.venue) {
        const prev = (get(meeting, 'races') || []).find((r: Dict) => get(r, 'no') === no - 1);
        if (prev && isNum(get(prev, 'postTime'))) return prev.postTime;
      }
    }
    const known = this.meetingRaces.get(`${get(race, 'date')}\u0001${get(race, 'venue')}`)?.get(no - 1);
    if (isNum(known)) return known;
    if (get(race, 'status') === 'MOCK') {
      try { const prev = MockAdapter.race(no - 1); if (prev && prev.date === get(race, 'date')) return prev.postTime; } catch { return null; }
    }
    return null;
  }
  private dblFirstMatrix(key: string, legs: number[], asOf: number, lookback = 6 * 3600): [number, DblMatrix] | null {
    const ck = key + '|' + legs.join(',');
    const hit = this.dblFirstSeen.get(ck);
    if (hit && hit[0] <= asOf) return hit;
    const found = this.store.dblFirst(asOf - lookback, asOf + 25, legs);
    if (!found) return null;
    if (!hit || found[0] < hit[0]) this.dblFirstSeen.set(ck, found);
    return found;
  }
  dblPct(race: Dict | null, key: string, asOfTs: number | null): Dict {
    const ids = (get(race || {}, 'runners') || []).map((h: Dict) => pyStr(h.no));
    if (!race || !ids.length) return { up: {}, down: {} };
    const ck = JSON.stringify([key, asOfTs, get(race, 'no')]);
    const cached = this.dblPctCache.get(ck);
    if (cached) return cached;
    const post = get(race, 'postTime');
    const no = race.no;
    const cut = dblPctCutMinutes(race);
    const baseTs = isNum(post) ? post - cut * 60 : null;
    const nowTs = asOfTs;
    const up: Dict = {};
    if (nowTs !== null && baseTs !== null && nowTs < baseTs - 25) {
      for (const r of ids) up[r] = metric(null, 'DERIVED', `EARLY：未到本場 T−${cut} 基準，孖下% 未計`);
    } else {
      const old = dblImpliedOdds(this.dblMatrixNear(baseTs, [no, no + 1]), ids, 0);
      const nw = nowTs !== null ? dblImpliedOdds(this.dblMatrixNear(nowTs, [no, no + 1]), ids, 0) : {};
      for (const r of ids) {
        const m = dblPctMetric(get(old, r), get(nw, r), `DBL first-leg [本場,下一場] Δimpl/impl_T−${cut}（signed，只顯示縮短；孖下下限 ${fmtF(DBL_DOWN_MIN_SHOW_PCT, 1)}%）`, '', DBL_DOWN_MIN_SHOW_PCT);
        up[r] = m !== null ? m : metric(null, 'DERIVED', `未有本場第一關當時孖寶（T−${cut} 基準或當下切片）`);
      }
    }
    const down = this.dblPctSecondLeg(race, key, nowTs, ids);
    const result = { up, down };
    this.dblPctCache.set(ck, result);
    if (this.dblPctCache.size > 800) this.dblPctCache = new Map([...this.dblPctCache].slice(-400));
    return result;
  }
  private dblPctSecondLeg(race: Dict, key: string, asOf: number | null, ids: string[]): Dict {
    const no = get(race, 'no');
    if (!Number.isInteger(no) || no <= 1) return blank(ids, '第一場沒有上一關孖寶（孖上）');
    if (asOf === null || asOf === undefined) return blank(ids, '未有檢視切片時間');
    const legs = [no - 1, no];
    const curM = this.dblMatrixNear(asOf, legs);
    if (!curM.size) return blank(ids, '此切片未有上一關×本關孖寶組合賠率');
    const prevPost = this.prevPostTime(race);
    const cut = dblPctCutMinutes(race);
    const baseTs = isNum(prevPost) ? prevPost - cut * 60 : null;
    let baseM: DblMatrix = new Map(); let note = '';
    if (baseTs !== null && asOf >= baseTs - 25) {
      baseM = this.dblMatrixNear(baseTs, legs);
      if (!baseM.size) note = `LATE：未有上一關 T−${cut} 孖寶快照，基準＝最早收集快照`;
    } else note = baseTs !== null ? `EARLY：未到上一關 T−${cut}，基準＝最早收集快照` : '未知上一關開跑時間，基準＝最早收集快照';
    if (!baseM.size) { const first = this.dblFirstMatrix(key, legs, asOf); if (first) baseM = first[1]; }
    if (!baseM.size) return blank(ids, '未有上一關×本關孖寶基準快照');
    const old = dblImpliedOdds(baseM, ids, 1), nw = dblImpliedOdds(curM, ids, 1);
    const out: Dict = {};
    for (const r of ids) {
      const m = dblPctMetric(get(old, r), get(nw, r), `DBL second-leg [上一場,本場] Δimpl/impl_上一場T−${cut}（signed，只顯示縮短）`, note);
      out[r] = m !== null ? m : metric(null, 'DERIVED', '此馬未有上一關×本關孖寶組合');
    }
    return out;
  }
  private keepLastDblPct(key: string, current: Dict | null, race: Dict | null): Dict {
    const ids = (get(race || {}, 'runners') || []).map((h: Dict) => pyStr(h.no));
    if (!ids.length) return current || { up: {}, down: {} };
    const prior = this.dblPctLastValid.get(key) || { up: {}, down: {} };
    const up: Dict = {}, down: Dict = {}, freshUp: Dict = {}, freshDown: Dict = {};
    for (const r of ids) {
      const cu = get(get(current || {}, 'up', {}) || {}, r) || {};
      const cd = get(get(current || {}, 'down', {}) || {}, r) || {};
      const pu = get(get(prior, 'up') || {}, r) || {};
      const pd = get(get(prior, 'down') || {}, r) || {};
      if (get(cu, 'value') !== null || truthy(get(cu, 'drift')) || truthy(get(cu, 'belowFloor'))) { up[r] = cu; freshUp[r] = cu; }
      else if (get(pu, 'value') !== null && !truthy(get(pu, 'drift')) && !truthy(get(pu, 'belowFloor')))
        up[r] = metric(pu.value, get(pu, 'quality') || 'ESTIMATED', '保留上次有效孖下%（本切片未計出）', get(pu, 'source') || 'DBL keep-last');
      else up[r] = truthy(cu) ? cu : metric(null, 'DERIVED', '未有當時孖寶');
      if (get(cd, 'value') !== null || truthy(get(cd, 'drift'))) { down[r] = cd; freshDown[r] = cd; }
      else if (get(pd, 'value') !== null && !truthy(get(pd, 'drift')))
        down[r] = metric(pd.value, get(pd, 'quality') || 'ESTIMATED', '保留上次有效孖上%（本切片未計出）', get(pd, 'source') || 'DBL keep-last');
      else down[r] = truthy(cd) ? cd : metric(null, 'DERIVED', '未有當時孖寶');
    }
    if (truthy(freshUp) || truthy(freshDown))
      this.dblPctLastValid.set(key, { up: { ...(get(prior, 'up') || {}), ...freshUp }, down: { ...(get(prior, 'down') || {}), ...freshDown } });
    return { up, down };
  }
  async flowTrial(frameId: string | null = null): Promise<Dict> {
    return (await this.flowTrialWithEtag(frameId))[0]!;
  }
  /** server.Service.flow_trial_with_etag (v0.7.3): [trial or null, ETag]. Returns [null, etag] without evaluating when
   * ifNoneMatch equals the ETag of the current inputs (race, snapshot ids, resolved as-of frame, frozen post times, cut, stale). */
  async flowTrialWithEtag(frameId: string | null = null, ifNoneMatch: string | null = null): Promise<[Dict | null, string]> {
    const t0 = monotonic();
    const sel = this.selected ? { ...this.selected } : null;
    if (!sel) return [{ status: 'TRIAL', label: FT.TRIAL_LABEL, phase: 'NO_DATA', runners: {}, reason: '未選賽事' }, contentEtag('ft-nosel')];
    const race = sel.race, key = sel.key;
    const snaps = await this.store.snapshots(key);
    if (!this.ftConv.has(key)) this.ftConv.set(key, new Map());
    const conv = this.ftConv.get(key)!;
    const canon: FT.TrialSnap[] = [];
    for (const s of snaps) { let c = conv.get(s.id); if (!c) { c = FT.fromToolSnapshot(s, race); conv.set(s.id, c); } canon.push(c); }
    if (this.ftConv.size > 8) for (const k of [...this.ftConv.keys()].slice(0, -8)) this.ftConv.delete(k);
    let post = isNum(get(race, 'postTime')) ? race.postTime : null;
    const pkey = 'flowTrialPost:' + key;
    const frozen = this.store.setting(pkey);
    if (isNum(frozen)) post = frozen;
    else if (post !== null) this.store.setSetting(pkey, post);
    const kind = get(race, 'venueKind') || (LOCAL_VENUES.has(String(get(race, 'venue') || '').toUpperCase()) ? 'local' : 'overseas');
    const cutMin = FT.cutMinutes(kind, get(race, 'venue'));
    let asOf: number | null = null; let tip = true;
    if (frameId) {
      const idx = snaps.findIndex((s) => s.id === frameId);
      if (idx >= 0) { asOf = canon[idx].ts; tip = canon[idx] === canon[canon.length - 1]; }
    }
    const latest = canon.length ? canon[canon.length - 1].ts : null;
    const stale = Boolean(tip && sel.mode === 'live' && latest !== null && nowSeconds() - latest > 45);
    const etag = contentEtag('ft', key, sel.mode ?? null, race, snaps.length ? snaps[snaps.length - 1].id : null, snaps.length, asOf !== null ? frameId : null,
      asOf, tip, post, cutMin, PG.frozenPost(this.store, key, race), stale);
    if (ifNoneMatch !== null && ifNoneMatch === etag) return [null, etag];
    const r = FT.evaluateAsof(canon, post, cutMin, FT.PARAMS[FT.TOOL_VERSION], asOf);
    const ids = (get(race, 'runners') || []).filter((h: Dict) => !truthy(get(h, 'scratched'))).map((h: Dict) => pyStr(h.no));
    const src = '007式流向（試驗）V1 A_new · flow007_trial.py';
    const m = (d: Dict | null, runner: string, why: string | null) => {
      const v = get(d || {}, runner);
      return v !== null ? metric(v, FT.QUALITY, 'TRIAL · ESTIMATED · 未鎖定', src) : metric(null, 'DERIVED', why || '缺輸入', src);
    };
    const pending: Dict = { PRE_CUT: `未到截點（T−${fmtG(cutMin)}）`, NO_CUT: '截點前冇有效快照', NO_DATA: '未有快照' };
    const runners: Dict = {};
    for (const x of ids) runners[x] = { pre: m(get(r, 'pre'), x, get(r, 'preReason') || get(pending, r.phase)), three: m(get(r, 'three'), x, get(r, 'threeReason') || get(pending, r.phase)), flow: m(get(r, 'flow'), x, get(r, 'reason')) };
    const p = FT.PARAMS[FT.TOOL_VERSION];
    const postGate = this.flowTrialPostGate(key, race, snaps, canon, asOf, post, cutMin, r, runners);
    return [{ status: 'TRIAL', quality: FT.QUALITY, label: FT.TRIAL_LABEL, version: FT.TOOL_VERSION, params: p, cutMin, cutKind: cutMin === FT.CUT_MIN_LOCAL ? 'local' : 'overseas',
      cutEstimated: cutMin !== FT.CUT_MIN_LOCAL, scheduledPost: post, phase: r.phase, cutTs: get(r, 'cutTs'), threeTs: get(r, 'threeTs'), flowTs: get(r, 'flowTs'), asOf,
      frameId: asOf !== null ? frameId : null, tip, stale, reason: get(r, 'reason'), runners, snapshots: canon.length, postGate, computeMs: pyRound((monotonic() - t0) * 1000, 3) }, etag];
  }
  /** server.Service._flow_trial_post_gate (v0.7.2 入閘後 split for the 007 bars; display only, flow007 untouched). Gate value =
   * the trial's own flow value evaluated as of the last snapshot whose source timestamp is at or before the split (≤45 s old).
   * Adds runners[x].gate / runners[x].postGate in place. v0.7.6 also adds runners[x].rebound = max(current flow − frozen gate flow, 0).
   * Returns the summary block. */
  private flowTrialPostGate(key: string, race: Dict, snaps: Dict[], canon: FT.TrialSnap[], asOf: number | null, post: number | null, cutMin: number, r: Dict, runners: Dict): Dict {
    const postG = PG.frozenPost(this.store, key, race);
    const split = PG.splitTs(postG, PG.POST_GATE_OFFSET_MIN);
    const out: Dict = { label: PG.LABEL, offsetMin: PG.POST_GATE_OFFSET_MIN, maxAgeSec: PG.GATE_MAX_AGE_SEC, scheduledPost: postG,
      splitTs: split, status: 'PENDING', active: false, frameId: null, timestamp: null, reason: null };
    let idx = -1;
    if (asOf === null) idx = canon.length - 1;
    else canon.forEach((c, i) => { if (c.ts <= asOf) idx = Math.max(idx, i); });
    const curTs = idx >= 0 ? get(snaps[idx], 'timestamp') : null;
    const fill = (why: string | null) => { for (const x of Object.keys(runners)) { runners[x].gate = metric(null, 'DERIVED', why || '', 'formula'); runners[x].postGate = null; runners[x].rebound = metric(null, 'DERIVED', why || '', 'formula'); } };
    if (split === null) { fill('未有表定開跑時間'); return { ...out, status: 'UNAVAILABLE', reason: 'NO_POST_TIME' }; }
    if (typeof curTs !== 'number' || curTs <= split) { fill('未到入閘時間'); return { ...out, reason: 'BEFORE_SPLIT' }; }
    const viewTs = canon[idx].ts;
    const pts: [any, number][] = [];
    snaps.forEach((s, i) => { if (canon[i].ts <= viewTs) pts.push([get(s, 'timestamp'), i]); });
    const [gts, gi, why] = PG.pickGate<number>(pts, split, PG.GATE_MAX_AGE_SEC);
    if (gi === null) {
      const msg: Dict = { GATE_SNAPSHOT_STALE: '入閘前最後快照超過 45 秒，冇基準', NO_SNAPSHOT_BEFORE_SPLIT: '入閘前冇快照' };
      fill(why !== null && why in msg ? msg[why] : why);
      return { ...out, status: 'UNAVAILABLE', active: true, reason: why };
    }
    const rg = FT.evaluateAsof(canon, post, cutMin, FT.PARAMS[FT.TOOL_VERSION], canon[gi].ts);
    if (get(rg, 'phase') !== 'POST_CUT' || get(r, 'phase') !== 'POST_CUT' || get(rg, 'cutTs') !== get(r, 'cutTs')) {
      fill('入閘時間早過 007 截點，唔拆分');
      return { ...out, status: 'UNAVAILABLE', active: true, reason: 'SPLIT_NOT_AFTER_CUT', frameId: get(snaps[gi], 'id'), timestamp: gts };
    }
    const src = '007式流向（試驗）入閘值 · postgate.py';
    for (const x of Object.keys(runners)) {
      const g = get(get(rg, 'flow') || {}, x);
      runners[x].gate = g !== null ? metric(g, FT.QUALITY, '入閘時快照嘅流向值（凍結）', src) : metric(null, 'DERIVED', get(rg, 'reason') || '入閘快照冇流向值', src);
      runners[x].postGate = PG.segment(g, get(get(r, 'flow') || {}, x));
    }
    // v0.7.6: third colour = max(current flow − flow at this frozen gate frame, 0). Not the v0.7.5
    // minimum after the gate. Display only. flow / pre / gate / postGate above are unchanged.
    const srcm = '007式流向（試驗）閘後 · 凍結閘口流向';
    for (const x of Object.keys(runners)) {
      const cur = get(get(r, 'flow') || {}, x);
      const g = get(get(rg, 'flow') || {}, x);
      const rb = PG.rebound(cur, g);
      if (rb === null) {
        const whyRb = g === null ? '入閘時冇流向值' : '而家冇流向值';
        runners[x].rebound = metric(null, 'DERIVED', whyRb, 'formula');
      } else {
        runners[x].rebound = metric(rb, FT.QUALITY, 'max(而家流向−入閘嗰下流向, 0)；冇升就係 0，唔會負', srcm);
      }
    }
    return { ...out, status: 'FROZEN', active: true, frameId: get(snaps[gi], 'id'), timestamp: gts };
  }
  buildState(sel: Dict, session: Dict, snaps: Dict[], marks: string[], config: Dict | null = null): Dict {
    const result = analyze(sel.race, snaps, config);
    const last = snaps[snaps.length - 1];
    const health = sourceHealth(last ? last.sourceTimestamp : null, get(session, 'lastReceived'), get(session, 'latency'), get(session, 'error'), nowSeconds());
    if (sel.mode !== 'live') health.status = sel.mode.toUpperCase();
    return { ...result, mode: sel.mode, race: sel.race, key: sel.key, marks, health, polling: get(session, 'polling', false), snapshotCount: snaps.length };
  }
}

// ---------------------------------------------------------------------------------------------
// /api router (same paths, parameters, validation and error semantics as server.py's handler).
export type ApiResult = { status: number; body: any; etag?: string };
/** server.py respond_etag (v0.7.3): 304 (no body) when the client already holds this ETag; otherwise 200 JSON + ETag. */
function respondEtag(obj: Dict | null, etag: string, ifNoneMatch: string | null): ApiResult {
  if (obj === null || (etag && ifNoneMatch === etag)) return { status: 304, body: null, etag };
  return { status: 200, body: toJson(obj), etag };
}
function toJson(obj: any): any {
  return JSON.parse(JSON.stringify(obj, (_k, v) => { if (typeof v === 'number' && !Number.isFinite(v)) throw new PyValueError('Out of range float values are not JSON compliant'); return v; }));
}
function parseQs(query: string): Map<string, string[]> {
  const out = new Map<string, string[]>();
  for (const part of query.split('&')) {
    if (!part) continue;
    const [k, v = ''] = part.split('=');
    const key = decodeURIComponent(k.replace(/\+/g, ' ')), value = decodeURIComponent(v.replace(/\+/g, ' '));
    if (!value) continue; // parse_qs drops blank values
    if (!out.has(key)) out.set(key, []);
    out.get(key)!.push(value);
  }
  return out;
}
const pyIntStrict = (s: string): number => { const t = s.trim().replace(/_/g, ''); if (!/^[+-]?\d+$/.test(t)) throw new PyValueError(`invalid literal for int() with base 10: '${s}'`); return parseInt(t, 10); };
const isAlnum = (s: string) => s.length > 0 && /^[\p{L}\p{N}]+$/u.test(s);

export async function handleApi(service: Service, method: string, pathWithQuery: string, body?: any, ifNoneMatch: string | null = null): Promise<ApiResult> {
  const inm = typeof ifNoneMatch === 'string' && ifNoneMatch.trim() ? ifNoneMatch.trim() : null;
  await service.ready;
  const [path, query = ''] = pathWithQuery.split('?');
  const q = parseQs(query);
  try {
    if (method === 'GET') {
      if (path === 'state') {
        service.viewerPresent();
        const cfg: Dict = {};
        for (const name of ['window', 'baseline_minutes']) if (q.has(name)) cfg[name] = pyIntStrict(q.get(name)![0]);
        if (!(10 <= (cfg.window ?? 60) && (cfg.window ?? 60) <= 300) || !(1 <= (cfg.baseline_minutes ?? 15) && (cfg.baseline_minutes ?? 15) <= 30)) throw new PyValueError('Window / baseline 超出可用範圍');
        const [st, etag] = await service.stateWithEtag(cfg);
        return respondEtag(st, etag, inm);
      }
      if (path === 'mini') {
        service.viewerPresent();
        const minutes = q.has('baseline_minutes') ? pyIntStrict(q.get('baseline_minutes')![0]) : DEFAULTS.baseline_minutes;
        if (!(1 <= minutes && minutes <= 30)) throw new PyValueError('Window / baseline 超出可用範圍');
        return { status: 200, body: toJson(await service.mini(minutes)) };
      }
      if (path === 'meetings') {
        service.viewerPresent();
        const mode = q.get('mode')?.[0] ?? 'live';
        if (!['live', 'mock'].includes(mode)) throw new PyValueError('Invalid meetings adapter mode');
        if (mode === 'live' && !q.has('date') && !q.has('venue')) return { status: 200, body: toJson({ ...(await service.catalog()), collection: service.collectionStatus() }) };
        const meetings = mode === 'mock' ? MockAdapter.meetings() : await service.adapter.meetings(q.get('date')?.[0] ?? null, q.get('venue')?.[0] ?? null);
        return { status: 200, body: toJson({ meetings, recommendedRaceId: null, checkedAt: nowSeconds(), status: meetings.length ? 'READY' : 'WAITING', schedule: [], message: '' }) };
      }
      if (path === 'flow-trial') {
        const frame = q.get('frame')?.[0] ?? null;
        if (frame !== null && (frame.length > 64 || !isAlnum(frame.replace(/-/g, '').replace(/_/g, '')))) throw new PyValueError('Invalid frame id');
        const [ft, etag] = await service.flowTrialWithEtag(frame, inm);
        return respondEtag(ft, etag, inm);
      }
      if (path === 'recordings') return { status: 200, body: toJson({ recordings: service.store.races() }) };
      if (path === 'collection') { service.viewerPresent(); return { status: 200, body: toJson(service.collectionStatus()) }; }
      if (path === 'export') {
        if (!service.selected) throw new PyValueError('未選賽事');
        const s = { ...service.selected };
        return { status: 200, body: toJson({ schemaVersion: 1, race: s.race, snapshots: await service.store.snapshots(s.key) }) };
      }
      if (path === 'raw') return { status: 200, body: toJson({ records: service.store.exportRaw() }) };
      if (path === 'health') return { status: 200, body: { ok: true, version: VERSION, projectRoot: 'ios-app (in-page backend)', pollSeconds: pollIntervalSeconds() } };
      return { status: 404, body: { error: 'Not found' } };
    }
    if (method === 'POST') {
      const b = body === undefined ? {} : body;
      if (b === null || typeof b !== 'object' || Array.isArray(b)) throw new PyValueError('JSON body must be an object');
      if (path === 'select') {
        const mode = 'mode' in b ? b.mode : 'live';
        const cfg: Dict = {};
        for (const name of ['window', 'baseline_minutes']) if (name in b) cfg[name] = b[name];
        if (Object.values(cfg).some((v) => typeof v !== 'number' || !Number.isInteger(v)) || !(10 <= (cfg.window ?? 60) && (cfg.window ?? 60) <= 300) || !(1 <= (cfg.baseline_minutes ?? 15) && (cfg.baseline_minutes ?? 15) <= 30))
          throw new PyValueError('Window / baseline 超出可用範圍');
        return { status: 200, body: toJson(await service.select(mode, b.raceId ?? null, b.date ?? null, b.venue ?? null, b.autoFollow ?? null, cfg)) };
      }
      if (path === 'follow') return { status: 200, body: toJson(service.setFollow(b.autoFollow ?? null)) };
      if (path === 'mark') {
        if (!service.selected || b.key !== service.selected.key) throw new PyValueError('賽事已切換；請重試標記');
        if (!('runner' in b)) throw new PyValueError("'runner'");
        const runner = pyStr(b.runner);
        if (!service.selected.race.runners.map((r: Dict) => pyStr(r.no)).includes(runner)) throw new PyValueError('Unknown runner');
        return { status: 200, body: { marks: service.store.mark(service.selected.key, runner) } };
      }
      if (path === 'import') return { status: 200, body: toJson(await service.importReplay(b)) };
      return { status: 404, body: { error: 'Not found' } };
    }
    return { status: 404, body: { error: 'Not found' } };
  } catch (e) {
    const status = e instanceof OSError ? 502 : e instanceof PyValueError || e instanceof TypeError || e instanceof SyntaxError ? 400 : 502;
    return { status, body: { error: errMsg(e) } };
  }
}
export { deepCopy, isDigit };
