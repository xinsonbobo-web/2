// In-page replacement for the Python HTTP API: the React UI calls apiCall('state?…') exactly like it used to
// call fetch('/api/state?…'). The Service runs its collector loop in this page.
/* eslint-disable @typescript-eslint/no-explicit-any */
import { callNative, isNativeApp } from './native';
import { handleApi, Service } from './service';
import { type FileDriver, nativeFileDriver } from './storage';

let service: Service | null = null;
async function probeDevBridge(): Promise<boolean> {
  try { const r = await fetch('/__native', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'info' }) }); return r.ok; } catch { return false; }
}
let starting: Promise<Service> | null = null;
export function getService(): Promise<Service> {
  if (service) return Promise.resolve(service);
  if (!starting) starting = (async () => {
    const driver: FileDriver | null = isNativeApp() || (await probeDevBridge()) ? nativeFileDriver : null;
    const s = new Service(driver);
    await s.ready;
    void s.worker();
    service = s;
    (globalThis as any).__moneyflow = s; // debugging handle (Safari Web Inspector)
    return s;
  })();
  return starting;
}
export async function apiCall<T = any>(path: string, body?: unknown): Promise<T> {
  const s = await getService();
  const payload = body === undefined ? undefined : JSON.parse(JSON.stringify(body));
  const r = await handleApi(s, body === undefined ? 'GET' : 'POST', path, payload);
  if (r.status !== 200) throw Error((r.body && r.body.error) || '連線失敗');
  return r.body as T;
}
/** Replaces <a href="/api/export" download>: share sheet in the app, Blob download in a browser. */
export async function saveApiJson(path: string, filename: string): Promise<void> {
  const data = await apiCall(path);
  const text = JSON.stringify(data);
  if (isNativeApp()) { await callNative({ op: 'share', name: filename, data: text }); return; }
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
export async function flushStore(): Promise<void> { if (service) await service.store.flush(); }
