// Port of backend/postgate.py (v0.7.2, 2026-09-29): 入閘後 (post-gate) split for the bar views. DISPLAY RULE, no new formula.
//
// HKJC publishes no gate-entry (入閘) timestamp, so the split point is the race's scheduled post time (表定開跑時間) minus a
// configurable offset. The bar value of the last snapshot at or before the split is frozen as the baseline; after the split
// each bar is drawn as baseline (normal colour) + (current − baseline) (入閘後 colour) and labelled e.g. "120+10". Nothing is
// copied forward:
//   * the baseline snapshot must be at or before the split and at most GATE_MAX_AGE_SEC older than it (45 s STALE rule);
//   * a runner whose bar was "--" (or a keep-last copy) in that snapshot has no baseline;
//   * before the split (viewed snapshot time <= split) nothing changes and no segment is drawn.
// Times are snapshot (HKJC source) timestamps. The scheduled post is frozen the first time it is seen.
/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Dict } from './py';
import type { Store } from './storage';

/** Split = scheduled post − POST_GATE_OFFSET_MIN minutes. 0 = at 表定開跑. */
export const POST_GATE_OFFSET_MIN = 0.0;
/** Baseline snapshot may be at most this many seconds older than the split (STALE rule, 45 s). */
export const GATE_MAX_AGE_SEC = 45.0;
export const LABEL = '入閘後';

/** isinstance(x,(int,float)) and not bool and math.isfinite(x) */
const num = (x: any): x is number => typeof x === 'number' && Number.isFinite(x);

export function splitTs(post: any, offsetMin: number = POST_GATE_OFFSET_MIN): number | null {
  return num(post) ? post - offsetMin * 60.0 : null;
}

/** points: iterable of [ts, item]. Returns [ts, item, reason] of the last point with ts <= split, or [null, null, reason]
 *  when none exists or it is older than `maxAge` seconds before the split. */
export function pickGate<T>(points: Iterable<[any, T]>, split: number | null, maxAge: number = GATE_MAX_AGE_SEC): [number | null, T | null, string | null] {
  if (split === null || split === undefined) return [null, null, 'NO_POST_TIME'];
  let best: [number, T] | null = null;
  for (const [ts, item] of points) if (num(ts) && ts <= split && (best === null || ts >= best[0])) best = [ts, item];
  if (best === null) return [null, null, 'NO_SNAPSHOT_BEFORE_SPLIT'];
  if (split - best[0] > maxAge) return [null, null, 'GATE_SNAPSHOT_STALE'];
  return [best[0], best[1], null];
}

/** Display rounding to an integer (half away from zero). `+ 0` turns Python's int 0 case (-0 in JS) into 0. */
export function halfUp(x: number): number {
  return Math.floor(Math.abs(x) + 0.5) * (x >= 0 ? 1 : -1) + 0;
}

/** Split of a bar value `cur` against the frozen `base`. Shrink → 'DOWN'. */
export function segment(base: any, cur: any): Dict | null {
  if (!(num(base) && num(cur))) return null;
  const b = halfUp(base), c = halfUp(cur);
  const d = c - b + 0;
  const kind = d > 0 ? 'UP' : d < 0 ? 'DOWN' : 'FLAT';
  const label = d >= 0 ? `${b}+${d}` : `${b}−${-d}`;
  return { base, cur, delta: cur - base, baseShown: b, deltaShown: d, kind, label };
}

/** Scheduled post frozen at first sight (settings `postGatePost:<key>`); seeded from the 007 trial's frozen post. */
export function frozenPost(store: Store, key: string, race: Dict | null): number | null {
  const pkey = 'postGatePost:' + key;
  const v = store.setting(pkey);
  if (num(v)) return v;
  const seed = store.setting('flowTrialPost:' + key);
  const post = num(seed) ? seed : (race || {}).postTime ?? null;
  if (num(post)) { store.setSetting(pkey, post); return post; }
  return null;
}

/** Displayed B+D bar value (UI shareBarHeight): barHeightDisplay, else raw clamped 50–200. */
export function barDisplay(sb: any): number | null {
  const d = ((sb || {}).barHeightDisplay || {}).value;
  if (num(d)) return d;
  const raw = ((sb || {}).barHeight || {}).value;
  return num(raw) ? Math.max(50.0, Math.min(200.0, raw)) : null;
}

const truthy = (v: any) => !(v === null || v === undefined || v === false || v === 0 || v === '' || (typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === 0) || (Array.isArray(v) && !v.length));

/** B+D main bars: frozen baseline = barHeightDisplay of each runner in the gate frame (never a keep-last copy).
 *  Frozen only once a frame after the split exists. */
export function mainView(frames: Dict[] | null, post: any, offsetMin: number = POST_GATE_OFFSET_MIN, maxAge: number = GATE_MAX_AGE_SEC): Dict {
  const split = splitTs(post, offsetMin);
  const out: Dict = { label: LABEL, offsetMin, maxAgeSec: maxAge, scheduledPost: num(post) ? post : null,
    splitTs: split, status: 'PENDING', frameId: null, timestamp: null, values: {}, reason: null };
  if (split === null) return { ...out, status: 'UNAVAILABLE', reason: 'NO_POST_TIME' };
  const fs = frames || [];
  if (!fs.some((f) => num(f.timestamp) && f.timestamp > split)) return { ...out, reason: 'BEFORE_SPLIT' };
  const [ts, fr, why] = pickGate<Dict>(fs.map((f) => [f.timestamp ?? null, f] as [any, Dict]), split, maxAge);
  if (fr === null) return { ...out, status: 'UNAVAILABLE', reason: why };
  const values: Dict = {};
  for (const [r, sb] of Object.entries((fr.shareBars || {}) as Dict)) {
    const v = barDisplay(sb);
    if (truthy(sb) && !truthy(sb.keptFromPrior) && v !== null) values[r] = v;
  }
  return { ...out, status: 'FROZEN', frameId: fr.id ?? null, timestamp: ts, values };
}
