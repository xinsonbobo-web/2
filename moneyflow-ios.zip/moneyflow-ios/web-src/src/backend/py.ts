// Python-semantics helpers used by the faithful TypeScript port of backend/*.py.
/* eslint-disable @typescript-eslint/no-explicit-any */
export type Any = any;
export type Dict = Record<string, any>;

export const isNum = (v: unknown): v is number => typeof v === 'number';
/** isinstance(v,(int,float)) and not bool */
export const isRealNumber = (v: unknown): v is number => typeof v === 'number';
export const isFiniteNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
export const isDict = (v: unknown): v is Dict => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Python truthiness. */
export function truthy(v: unknown): boolean {
  if (v === null || v === undefined || v === false) return false;
  if (typeof v === 'number') return v !== 0 && !Number.isNaN(v);
  if (typeof v === 'string') return v.length > 0;
  if (Array.isArray(v)) return v.length > 0;
  if (v instanceof Map || v instanceof Set) return v.size > 0;
  if (typeof v === 'object') return Object.keys(v as object).length > 0;
  return true;
}
/** Python `a or b` */
export function or<T, U>(a: T, b: U): T | U { return truthy(a) ? a : b; }

/** dict.get(key) returning undefined→null semantics helper */
export function get(o: any, key: string, dflt: any = null): any {
  if (o === null || o === undefined || typeof o !== 'object') return dflt;
  return Object.prototype.hasOwnProperty.call(o, key) ? o[key] : dflt;
}
export function has(o: any, key: string): boolean {
  return o !== null && o !== undefined && typeof o === 'object' && Object.prototype.hasOwnProperty.call(o, key);
}

const FLOAT_RE = /^[+-]?((\d(_?\d)*)?\.?\d(_?\d)*([eE][+-]?\d(_?\d)*)?|\d(_?\d)*\.([eE][+-]?\d(_?\d)*)?|inf(inity)?|nan)$/i;
/** float(value); throws on ValueError/TypeError (returns undefined instead). */
export function pyFloat(value: unknown): number | undefined {
  if (typeof value === 'number') return value;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (typeof value === 'string') {
    const s = value.trim();
    if (!s || !FLOAT_RE.test(s)) return undefined;
    const low = s.toLowerCase().replace(/_/g, '');
    if (/^[+-]?inf(inity)?$/.test(low)) return low.startsWith('-') ? -Infinity : Infinity;
    if (/^[+-]?nan$/.test(low)) return NaN;
    const n = Number(low);
    return Number.isNaN(n) ? undefined : n;
  }
  return undefined;
}
/** str.isdigit() for ASCII strings */
export const isDigit = (s: unknown): boolean => typeof s === 'string' && /^[0-9]+$/.test(s);
/** int(str) for digit strings / numbers */
export function pyInt(v: unknown): number | undefined {
  if (typeof v === 'number') return Number.isFinite(v) ? Math.trunc(v) : undefined;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string') {
    const s = v.trim().replace(/_/g, '');
    if (!/^[+-]?\d+$/.test(s)) return undefined;
    return parseInt(s, 10);
  }
  return undefined;
}
/** Python str() for primitives commonly used in this code */
export function pyStr(v: unknown): string {
  if (v === null || v === undefined) return 'None';
  if (v === true) return 'True';
  if (v === false) return 'False';
  if (typeof v === 'number') return floatRepr(v);
  if (typeof v === 'string') return v;
  return JSON.stringify(v);
}
/** repr(float) approximation (JS cannot distinguish 1 vs 1.0; integers print without .0). */
export function floatRepr(x: number): string {
  if (Number.isNaN(x)) return 'nan';
  if (x === Infinity) return 'inf';
  if (x === -Infinity) return '-inf';
  return String(x);
}

/** Python round(x, n) — round-half-even on the exact binary value. */
export function pyRound(x: number, n = 0): number {
  if (!Number.isFinite(x)) return x;
  const neg = x < 0;
  const ax = Math.abs(x);
  const exact = ax.toFixed(Math.min(100, n + 40));
  const dot = exact.indexOf('.');
  const tail = exact.slice(dot + 1 + n);
  let r: number;
  if (/^50*$/.test(tail)) {
    // exact tie → half-even
    const base = exact.slice(0, dot + 1 + n).replace(/\.$/, '');
    const digits = base.replace('.', '');
    const lastDigit = Number(digits[digits.length - 1]);
    const down = Number(base);
    if (lastDigit % 2 === 0) r = down;
    else r = Number((down + Math.pow(10, -n)).toFixed(n));
  } else {
    r = Number(ax.toFixed(n));
  }
  return neg ? -r : r;
}

/** '%g' formatting (6 significant digits) */
export function fmtG(x: number, prec = 6): string {
  if (Number.isNaN(x)) return 'nan';
  if (!Number.isFinite(x)) return x > 0 ? 'inf' : '-inf';
  if (x === 0) return Object.is(x, -0) ? '-0' : '0';
  const p = prec === 0 ? 1 : prec;
  const exp = Math.floor(Math.log10(Math.abs(x)));
  let e = Number(Math.abs(x).toExponential(p - 1).split('e')[1]);
  if (Number.isNaN(e)) e = exp;
  if (e < -4 || e >= p) {
    let [m, ee] = x.toExponential(p - 1).split('e');
    if (m.includes('.')) m = m.replace(/0+$/, '').replace(/\.$/, '');
    const en = Number(ee);
    return m + 'e' + (en < 0 ? '-' : '+') + String(Math.abs(en)).padStart(2, '0');
  }
  let s = x.toFixed(Math.max(0, p - 1 - e));
  if (s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
  return s;
}
/** '%.Nf' */
export const fmtF = (x: number, n: number): string => (Number.isFinite(x) ? pyRound(x, n).toFixed(n) : fmtG(x));

export function sum(xs: Iterable<number>): number { let t = 0; for (const x of xs) t += x; return t; }
/** math.fsum — exact (Shewchuk) summation */
export function fsum(xs: Iterable<number>): number {
  const partials: number[] = [];
  for (let x of xs) {
    let i = 0;
    for (let y of partials) {
      if (Math.abs(x) < Math.abs(y)) { const t = x; x = y; y = t; }
      const hi = x + y;
      const lo = y - (hi - x);
      if (lo) partials[i++] = lo;
      x = hi;
    }
    partials.length = i;
    partials.push(x);
  }
  let n = partials.length, hi = 0, lo = 0;
  if (n > 0) {
    hi = partials[--n];
    while (n > 0) {
      const x = hi; const y = partials[--n];
      hi = x + y; const yr = hi - x; lo = y - yr;
      if (lo) break;
    }
    if (n > 0 && ((lo < 0 && partials[n - 1] < 0) || (lo > 0 && partials[n - 1] > 0))) {
      const y = lo * 2; const x = hi + y; const yr = x - hi;
      if (y === yr) hi = x;
    }
  }
  return hi;
}
/** max(iterable, key) → first maximal (Python semantics) */
export function maxBy<T>(xs: T[], key: (x: T) => any): T | undefined {
  let best: T | undefined; let bk: any; let first = true;
  for (const x of xs) { const k = key(x); if (first || cmp(k, bk) > 0) { best = x; bk = k; first = false; } }
  return best;
}
export function minBy<T>(xs: T[], key: (x: T) => any): T | undefined {
  let best: T | undefined; let bk: any; let first = true;
  for (const x of xs) { const k = key(x); if (first || cmp(k, bk) < 0) { best = x; bk = k; first = false; } }
  return best;
}
/** Python comparison for numbers/strings/tuples(arrays) */
export function cmp(a: any, b: any): number {
  if (Array.isArray(a) && Array.isArray(b)) {
    const n = Math.min(a.length, b.length);
    for (let i = 0; i < n; i++) { const c = cmp(a[i], b[i]); if (c) return c; }
    return a.length - b.length;
  }
  if (a === b) return 0;
  return a < b ? -1 : a > b ? 1 : 0;
}
/** sorted(xs, key) — stable */
export function sortedBy<T>(xs: T[], key: (x: T) => any = (x) => x): T[] {
  return xs.map((x, i) => [key(x), i, x] as [any, number, T]).sort((a, b) => cmp(a[0], b[0]) || a[1] - b[1]).map((t) => t[2]);
}
export function range(a: number, b?: number, step = 1): number[] {
  const out: number[] = []; let s = a, e = b;
  if (e === undefined) { e = a; s = 0; }
  for (let i = s; step > 0 ? i < e : i > e; i += step) out.push(i);
  return out;
}
export const setEq = <T>(a: Set<T>, b: Set<T>): boolean => a.size === b.size && [...a].every((x) => b.has(x));
export const subset = <T>(a: Set<T>, b: Set<T>): boolean => [...a].every((x) => b.has(x));
/** deep equality for list/number/string compare as in Python `==` of JSON-like values */
export function pyEq(a: any, b: any): boolean {
  if (a === b) return true;
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => pyEq(x, b[i]));
  if (isDict(a) && isDict(b)) {
    const ka = Object.keys(a); const kb = Object.keys(b);
    return ka.length === kb.length && ka.every((k) => has(b, k) && pyEq(a[k], b[k]));
  }
  return false;
}
/** json.loads(json.dumps(x)) deep copy */
export const deepCopy = <T>(x: T): T => (x === undefined ? x : JSON.parse(JSON.stringify(x)));
/** json.dumps(x, sort_keys=True, ensure_ascii=False) approximation (Python separators). */
export function pyDumps(x: any, sortKeys = false): string {
  if (x === null || x === undefined) return 'null';
  if (x === true) return 'true';
  if (x === false) return 'false';
  if (typeof x === 'number') {
    if (Number.isNaN(x)) return 'NaN';
    if (!Number.isFinite(x)) return x > 0 ? 'Infinity' : '-Infinity';
    return String(x);
  }
  if (typeof x === 'string') return JSON.stringify(x);
  if (Array.isArray(x)) return '[' + x.map((v) => pyDumps(v, sortKeys)).join(', ') + ']';
  const keys = Object.keys(x).filter((k) => x[k] !== undefined);
  if (sortKeys) keys.sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ': ' + pyDumps(x[k], sortKeys)).join(', ') + '}';
}
/** time.time(); tests may install globalThis.__MF_NOW__ to freeze the clock. */
export const nowSeconds = (): number => { const h = (globalThis as any).__MF_NOW__; return typeof h === 'function' ? h() : Date.now() / 1000; };
export const monotonic = (): number => (typeof performance !== 'undefined' ? performance.now() / 1000 : Date.now() / 1000);

export class PyValueError extends Error {}
