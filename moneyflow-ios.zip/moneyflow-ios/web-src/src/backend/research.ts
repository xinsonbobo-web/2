// Port of backend/research_candidates.py (WIN v0.3 research candidates).
import { PyValueError, fsum } from './py';

export function positiveLog(value: number): number {
  if (Number.isNaN(value) || value < 0) throw new PyValueError('Nonnegative finite-or-positive-infinite ratio required.');
  return value > 1 ? Math.log2(value) : 0.0;
}
export function displayHeight(rawB: number | null | undefined): number | null {
  if (rawB === null || rawB === undefined || !Number.isFinite(rawB) || rawB < 0) return null;
  return Math.log1p(rawB);
}
export function ratio(numerator: number, denominator: number): number | null {
  if (denominator === 0) return numerator > 0 ? Infinity : null;
  return numerator / denominator;
}
export type Meas = { A_share_points: number; B_log2_gain: number | null; C_log2_tilt: number; Self_log2_change: number | null; relative_allocation: number | null; Cross_peer_position?: number | null; recent_amount?: number; recent_share?: number; baseline_share?: number; activity?: string };
export function measurements(b: number, q: number, r: number | null = null): Meas {
  if (!(Number.isFinite(b) && Number.isFinite(q) && 0 <= b && b <= 1 && 0 <= q && q <= 1)) throw new PyValueError('Shares must lie in [0,1].');
  const a = ratio(q, b);
  const A = 100 * Math.max(0, q - b);
  const B = a !== null ? positiveLog(a) : null;
  let C: number;
  if (q <= b) C = 0.0;
  else if (b === 0 || q === 1) C = Infinity;
  else C = positiveLog((q * (1 - b)) / (b * (1 - q)));
  let S: number | null;
  if (r !== null) {
    if (!Number.isFinite(r) || !(0 <= r && r <= 1)) throw new PyValueError('Previous incremental share must lie in [0,1].');
    const change = ratio(q, r);
    S = change !== null ? positiveLog(change) : null;
  } else S = null;
  return { A_share_points: A, B_log2_gain: B, C_log2_tilt: C, Self_log2_change: S, relative_allocation: a };
}
export function comparePeers(relative: Map<string, number | null>): Map<string, number | null> {
  const n = relative.size;
  const out = new Map<string, number | null>();
  if (n < 2 || [...relative.values()].some((x) => x === null || !Number.isFinite(x))) {
    for (const k of relative.keys()) out.set(k, null);
    return out;
  }
  for (const [i, v] of relative) {
    let s = 0;
    for (const [j, w] of relative) {
      if (j === i) continue;
      s += (v as number) > (w as number) ? 1 : v === w ? 0.5 : 0;
    }
    out.set(i, (100 * s) / (n - 1));
  }
  return out;
}
/** start/end/previous are Maps (insertion-ordered like Python dicts). */
export function windowFromAmounts(start: Map<string, number>, end: Map<string, number>, previousStart: Map<string, number> | null = null): Map<string, Meas> {
  const sk = [...start.keys()];
  if (start.size !== end.size || !sk.every((k) => end.has(k)) || start.size < 2) throw new PyValueError('Complete equal runner sets required.');
  if ([...start.values(), ...end.values()].some((x) => !Number.isFinite(x) || x < 0)) throw new PyValueError('Amounts must be finite and nonnegative.');
  if (sk.some((k) => (end.get(k) as number) < (start.get(k) as number))) throw new PyValueError('Unreconciled negative runner change; do not clip to zero.');
  const p0 = fsum(start.values()), p1 = fsum(end.values());
  if (p0 <= 0) throw new PyValueError('No positive starting pool.');
  const result = new Map<string, Meas>();
  if (p1 === p0) {
    for (const i of sk) result.set(i, { A_share_points: 0.0, B_log2_gain: 0.0, C_log2_tilt: 0.0, Self_log2_change: null, Cross_peer_position: null, activity: 'CONFIRMED_NO_NEW_ACTIVITY', recent_amount: 0.0, relative_allocation: null });
    return result;
  }
  let previous: Map<string, number> | null = null;
  if (previousStart !== null) {
    if (previousStart.size !== start.size || !sk.every((k) => previousStart.has(k)) || [...previousStart.values()].some((v) => !Number.isFinite(v) || v < 0)) throw new PyValueError('Invalid previous support state.');
    if (sk.some((k) => (start.get(k) as number) < (previousStart.get(k) as number))) throw new PyValueError('Unreconciled change in previous window.');
    const growth = p0 - fsum(previousStart.values());
    if (growth > 0) {
      previous = new Map();
      for (const k of sk) previous.set(k, ((start.get(k) as number) - (previousStart.get(k) as number)) / growth);
    }
  }
  for (const k of sk) {
    const s0 = start.get(k) as number, e1 = end.get(k) as number;
    const q = (e1 - s0) / (p1 - p0);
    const m = measurements(s0 / p0, q, previous ? (previous.get(k) as number) : null);
    m.recent_amount = e1 - s0; m.recent_share = q; m.baseline_share = s0 / p0;
    result.set(k, m);
  }
  const peer = comparePeers(new Map([...result].map(([k, v]) => [k, v.relative_allocation])));
  for (const [k, v] of result) v.Cross_peer_position = peer.get(k) ?? null;
  return result;
}
