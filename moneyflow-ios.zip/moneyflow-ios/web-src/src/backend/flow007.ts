// Port of backend/flow007_trial.py — 007式流向（試驗）. TRIAL / ESTIMATED / NOT LOCKED.
/* eslint-disable @typescript-eslint/no-explicit-any */
import { type Dict, get, isDict, isDigit, maxBy, pyFloat, truthy } from './py';

export const TRIAL_LABEL = '007式流向（試驗）';
export const QUALITY = 'ESTIMATED';
export const PARAMS: Record<string, { lnK: number; alpha: number; kappa: number; w: number }> = {
  V0: { lnK: 6.005, alpha: 0.714, kappa: 0.55, w: 0.65 },
  V1: { lnK: 6.238, alpha: 0.805, kappa: 0.55, w: 0.65 },
  V2: { lnK: 6.284, alpha: 0.824, kappa: 0.521, w: 1.239 },
};
export const TOOL_VERSION = 'V1';
export const CUT_MIN_LOCAL = 16.5;
export const CUT_MIN_OVERSEAS = 13.0;
export const THREE_MIN = 3.0;
export const SHARE_FLOOR = 1e-4;
export const MIN_RUNNERS = 4;

function pos(x: any): number | null {
  if (x === null || x === undefined) return null;
  const v = pyFloat(x);
  return v !== undefined && v > 0 && Number.isFinite(v) ? v : null;
}
type Pairs = Map<string, number>; // "a,b" (unordered pair, as given) → odds
export type TrialSnap = { ts: number; horses: string[]; win: Record<string, number>; qin: Pairs; qpl: Pairs; qin_total: number | null; qpl_total: number | null; valid: boolean; reason: string | null; alignWarn?: boolean };

export function makeSnapshot(ts: number, win: Map<string, any>, qin: Pairs, qpl: Pairs, qinTotal: any, qplTotal: any, extraOk = true, reason: string | null = null): TrialSnap {
  const horses = [...win.entries()].filter(([, o]) => pos(o) !== null).map(([h]) => h).sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
  const valid = truthy(extraOk) && horses.length >= MIN_RUNNERS && qin.size > 0 && qpl.size > 0 && pos(qinTotal) !== null && pos(qplTotal) !== null;
  if (!valid && reason === null) reason = 'INPUT_MISSING';
  const w: Record<string, number> = {};
  for (const h of horses) w[h] = Number(pyFloat(win.get(h)));
  return { ts: Number(ts), horses, win: w, qin, qpl, qin_total: pos(qinTotal), qpl_total: pos(qplTotal), valid, reason: valid ? null : reason };
}
function pairMoney(horses: string[], odds: Pairs, total: number): number[][] | null {
  const ix = new Map(horses.map((h, i) => [h, i]));
  const n = horses.length;
  const inv = Array.from({ length: n }, () => new Array<number>(n).fill(0));
  let tot = 0;
  for (const [k, o] of odds) {
    const v = pos(o);
    const [a, b] = k.split(',');
    if (v === null || !ix.has(a) || !ix.has(b) || a === b) continue;
    const i = ix.get(a)!, j = ix.get(b)!;
    inv[i][j] = inv[j][i] = 1.0 / v;
  }
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) tot += inv[i][j];
  if (tot <= 0) return null;
  return inv.map((row, i) => row.map((_, j) => total * inv[i][j] / tot));
}
export function cumulativeInputs(snap: TrialSnap | null): [string[], number[][], number[][], number[]] | null {
  if (!snap || !snap.valid) return null;
  const hs = snap.horses;
  const MQ = pairMoney(hs, snap.qin, snap.qin_total!);
  const MP = pairMoney(hs, snap.qpl, snap.qpl_total!);
  if (!MQ || !MP) return null;
  const q = hs.map((h) => 1.0 / snap.win[h]);
  let t = 0; for (const x of q) t += x;
  return [hs, MQ, MP, q.map((x) => x / t)];
}
export function predict(MQ: number[][], MP: number[][], p: number[], params: { lnK: number; alpha: number; kappa: number; w: number }): number[] | null {
  const k = params.kappa, w = params.w, n = p.length;
  const pk = p.map((x) => x ** k);
  const A: number[] = [];
  for (let i = 0; i < n; i++) {
    let a = 0;
    for (let j = 0; j < n; j++) if (i !== j) a += (MQ[i][j] + w * MP[i][j]) * (pk[j] / (pk[i] + pk[j]));
    A.push(a);
  }
  let t = 0; for (const a of A) t += a;
  if (!(t > 0)) return null;
  return A.map((a) => Math.exp(params.lnK + params.alpha * Math.log(Math.max(a, SHARE_FLOOR * t) / t)));
}
export function flowValue(cur: TrialSnap | null, base: TrialSnap | null, params: any): [Record<string, number> | null, string | null] {
  const ci = cumulativeInputs(cur);
  if (!ci) return [null, (cur && cur.reason) || 'INPUT_MISSING'];
  let [hs, MQ, MP, p] = ci; // eslint-disable-line prefer-const
  if (base !== null) {
    const bi = cumulativeInputs(base);
    if (!bi) return [null, 'CUT_INVALID'];
    const [bhs, BQ, BP] = bi;
    const bx = new Map(bhs.map((h, i) => [h, i]));
    if (hs.some((h) => !bx.has(h))) return [null, 'RUNNERS_CHANGED_SINCE_CUT'];
    const idx = hs.map((h) => bx.get(h)!);
    const n = hs.length;
    MQ = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => Math.max(MQ[i][j] - BQ[idx[i]][idx[j]], 0.0)));
    MP = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => Math.max(MP[i][j] - BP[idx[i]][idx[j]], 0.0)));
  }
  const y = predict(MQ, MP, p, params);
  if (!y) return [null, 'NO_NEW_MONEY'];
  return [Object.fromEntries(hs.map((h, i) => [h, y[i]])), null];
}
export function cutMinutes(venueKind: any = null, venue: any = null): number {
  if (venueKind === 'local' || venueKind === 'overseas') return venueKind === 'local' ? CUT_MIN_LOCAL : CUT_MIN_OVERSEAS;
  return !truthy(venue) || ['ST', 'HV'].includes(String(venue).toUpperCase()) ? CUT_MIN_LOCAL : CUT_MIN_OVERSEAS;
}
export function lastValidAtOrBefore(snaps: TrialSnap[], t: number): TrialSnap | null {
  let best: TrialSnap | null = null;
  for (const s of snaps) if (s.ts <= t && s.valid && (best === null || s.ts >= best.ts)) best = s;
  return best;
}
export function evaluateAsof(snaps: TrialSnap[], post: number | null, cutMin: number, params: any, asOf: number | null = null): Dict {
  const seen = snaps.filter((s) => asOf === null || s.ts <= asOf);
  if (!seen.length || post === null || post === undefined)
    return { phase: 'NO_DATA', cutTs: null, pre: null, three: null, flow: null, flowTs: null, reason: !seen.length ? 'NO_SNAPSHOT' : 'NO_POST_TIME' };
  const cur = maxBy(seen, (s) => s.ts)!;
  const tCut = post - cutMin * 60.0;
  const out: Dict = { cutTarget: tCut, threeTarget: post - THREE_MIN * 60.0, flowTs: cur.ts };
  if (cur.ts <= tCut) {
    const [v, why] = flowValue(cur, null, params);
    return { ...out, phase: 'PRE_CUT', cutTs: null, pre: null, three: null, flow: v, reason: why };
  }
  const cut = lastValidAtOrBefore(seen, tCut);
  if (!cut) return { ...out, phase: 'NO_CUT', cutTs: null, pre: null, three: null, flow: null, reason: 'NO_VALID_SNAPSHOT_BEFORE_CUT' };
  const [pre, whyPre] = flowValue(cut, null, params);
  const [flow, why] = flowValue(cur, cut, params);
  let three: Record<string, number> | null = null, why3: string | null = 'BEFORE_T_MINUS_3', t3: number | null = null;
  if (cur.ts > post - THREE_MIN * 60.0) {
    const s3 = lastValidAtOrBefore(seen, post - THREE_MIN * 60.0);
    if (s3 && s3.ts > cut.ts) { [three, why3] = flowValue(s3, cut, params); t3 = s3.ts; }
    else why3 = 'NO_VALID_SNAPSHOT_FOR_T_MINUS_3';
  }
  return { ...out, phase: 'POST_CUT', cutTs: cut.ts, pre, three, threeTs: t3, flow, reason: why, preReason: whyPre, threeReason: truthy(three) ? null : why3 };
}
const runnerKey = (k: any): string => { const s = String(k).trim(); return isDigit(s) ? String(parseInt(s, 10)) : s; };
function pairKey(k: any): string | null {
  const parts = String(k).split(',');
  if (parts.length !== 2) return null;
  const a = runnerKey(parts[0]), b = runnerKey(parts[1]);
  return a !== b ? `${a},${b}` : null;
}
function pairs(odds: Dict | null): Pairs {
  const out: Pairs = new Map();
  for (const [k, v] of Object.entries(odds || {})) { const pk = pairKey(k); if (pk !== null && pos(v) !== null) out.set(pk, Number(pyFloat(v))); }
  return out;
}
export function fromRecorderLine(d: Dict, tsEpoch: number): TrialSnap {
  const o = get(d, 'odds') || {};
  const pools: Dict = {};
  for (const [k, v] of Object.entries(get(d, 'pools') || {})) if (isDict(v)) pools[k] = get(v || {}, 'investment');
  const ok = ['WIN', 'QIN', 'QPL'].every((k) => k in o) && ['WIN', 'PLA', 'QIN', 'QPL'].every((k) => truthy(get(pools, k)));
  const win = new Map<string, any>();
  if ('WIN' in o) for (const [h, v] of Object.entries(get(o.WIN, 'odds') || {})) if (typeof v === 'number' && v > 0) win.set(runnerKey(h), v);
  return makeSnapshot(tsEpoch, win, pairs(get(get(o, 'QIN') || {}, 'odds')), pairs(get(get(o, 'QPL') || {}, 'odds')), get(pools, 'QIN'), get(pools, 'QPL'), ok, ok ? null : 'POOL_OR_ODDS_MISSING');
}
const mval = (m: any) => (isDict(m) ? get(m, 'value') : null);
export function fromToolSnapshot(s: Dict, race: Dict | null): TrialSnap {
  const pools = get(s, 'pools') || {};
  const winPool = get(pools, 'WIN') || {}, q = get(pools, 'QIN') || {}, qp = get(pools, 'QPL') || {};
  const active = (get(race || {}, 'runners') || []).filter((r: Dict) => !truthy(get(r, 'scratched'))).map((r: Dict) => String(r.no));
  let win = new Map<string, any>();
  for (const [k, m] of Object.entries(get(winPool, 'odds') || {})) { const v = pos(mval(m)); if (v !== null) win.set(runnerKey(k), v); }
  let ok = active.length > 0 && active.every((a: string) => win.has(a));
  if (active.length) win = new Map([...win].filter(([h]) => active.includes(h)));
  let reason: string | null = ok ? null : 'WIN_ODDS_INCOMPLETE';
  const qo: Dict = {}; for (const [k, m] of Object.entries(get(q, 'odds') || {})) qo[k] = mval(m);
  const qpo: Dict = {}; for (const [k, m] of Object.entries(get(qp, 'odds') || {})) qpo[k] = mval(m);
  const qt = mval(get(q, 'reportedTotal')), qpt = mval(get(qp, 'reportedTotal'));
  if (ok && (qt === null || qpt === null)) { ok = false; reason = 'QIN_QPL_TOTAL_MISSING'; }
  const ts = typeof get(s, 'receivedAt') === 'number' ? s.receivedAt : get(s, 'timestamp');
  const out = makeSnapshot(ts, win, pairs(qo), pairs(qpo), qt, qpt, ok, reason);
  out.alignWarn = mval(get(q, 'total')) === null || mval(get(qp, 'total')) === null;
  return out;
}
