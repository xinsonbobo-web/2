// Faithful TypeScript port of backend/engine.py (pure calculations). HKD amounts; Unix-second timestamps.
import { type Any, type Dict, get, has, isDict, isFiniteNum, maxBy, pyRound, range, sortedBy, sum, truthy, fmtF, PyValueError } from './py';
import { windowFromAmounts, displayHeight } from './research';

export const QUALITIES = ['DIRECT', 'DERIVED', 'ESTIMATED', 'UNAVAILABLE'];
export const STALE_AFTER_SECONDS = 45;
export const SYNC_TOLERANCE_SECONDS = 15;
export const UNCHANGED_PRESSURE_TOLERANCE_PP = 0.5;
export const DEFAULTS: Dict = { window: 60, max_gap: 30, baseline_minutes: 15, min_pool_delta: 10000, min_expected: 1000, green_excess: 10000, red_excess: 50000, brown_excess: 150000, green_lift: 1.2, red_lift: 1.5, brown_lift: 2.0 };
export const HOT_MONEY_3M_WINDOW = 180;
export const SHARE_EPS = 0.0025;
export const BAR_DISPLAY_FLOOR = 50.0;
export const BAR_DISPLAY_CAP = 200.0;
export const BASELINE_SHARE_EARLY_MIN = 17;
export const BASELINE_SHARE_LATE_MIN = 13;
export const PROVISIONAL_STABLE_FRAMES = 3;
export const COMBINED_SHARE_WEIGHTS: [string, number][] = [['WIN', 1.0], ['QIN', 0.75], ['QPL', 0.75], ['FCT', 0.75]];
const GRADES = ['normal', 'green', 'red', 'brown'];
const POOL_NAMES = ['WIN', 'QIN', 'QPL', 'FCT', 'DBL_UP', 'DBL_DOWN'];

export const REASON_CODES: [string, string][] = [
  ['缺少彩池資料', 'source_unavailable'],
  ['等待完整 rolling window / 來源更新間隔過長', 'missing_window'],
  ['缺少可靠 runner / combination investment', 'source_unavailable'],
  ['馬匹金額超出彩池範圍，資料不一致', 'calculation_failed'],
  ['彩池未增長或已退款／重設', 'non_positive_pool_delta'],
  ['彩池更新不同步／過期', 'timestamp_mismatch'],
  ['彩池流量不一致', 'calculation_failed'],
  ['負 Actual：可能退款、報價取整或非同步來源；不輸出 Pressure', 'calculation_failed'],
  ['Expected 為零，Lift 未定義', 'calculation_failed'],
];
export const healthOk = (): Dict => ({ status: 'OK', reason: null });
export const healthError = (code: string): Dict => ({ status: 'ERROR', reason: code });
export function reasonCodeFor(reason: Any, fallback = 'calculation_failed'): string {
  if (!truthy(reason)) return fallback;
  for (const [k, c] of REASON_CODES) if (k === reason) return c;
  for (const [k, c] of REASON_CODES) if (String(reason).includes(k)) return c;
  return fallback;
}
export function metric(value: Any = null, quality = 'DERIVED', reason = '', source = 'formula'): Dict {
  if (value === null || value === undefined || (typeof value === 'number' && !Number.isFinite(value)))
    return { value: null, quality: 'UNAVAILABLE', reason: reason || 'Missing input', source };
  return { value, quality, reason, source };
}
export const M = (o: { value?: Any; quality?: string; reason?: string; source?: string } = {}): Dict => metric(o.value ?? null, o.quality ?? 'DERIVED', o.reason ?? '', o.source ?? 'formula');
export function val(m: Any): Any { return isDict(m) ? (m.value ?? null) : null; }

export function applyPressureFreshness(flow: Dict | null, ageSeconds: number | null = null): Dict {
  const out: Dict = {};
  for (const [k, v] of Object.entries(flow || {})) out[k] = isDict(v) ? { ...v } : v;
  if (ageSeconds !== null) out.age_seconds = ageSeconds;
  if (out.state === 'UNAVAILABLE' || val(out.pressure) === null) {
    out.state = 'UNAVAILABLE';
    if (!has(out, 'health')) out.health = healthError(reasonCodeFor(out.reason));
    out.estimated_equal = false;
    return out;
  }
  if (ageSeconds !== null && ageSeconds > STALE_AFTER_SECONDS) { out.state = 'STALE'; out.health = healthError('source_age_exceeded'); return out; }
  if (ageSeconds !== null && ageSeconds < 0) { out.state = 'UNAVAILABLE'; out.health = healthError('timestamp_mismatch'); return out; }
  return out;
}
export function quality(...metrics: Any[]): string {
  const qs = metrics.map((m) => get(m, 'quality', 'UNAVAILABLE'));
  return qs.includes('UNAVAILABLE') ? 'UNAVAILABLE' : qs.includes('ESTIMATED') ? 'ESTIMATED' : 'DERIVED';
}
const FLOW_KEYS = ['share', 'actual', 'expected', 'excess', 'lift', 'pressure', 'deltaPool', 'windowSeconds', 'hot_money_3m', 'hot_money_baseline'];
export function emptyFlow(reason: string, reasonCode: string | null = null): Dict {
  const code = reasonCode || reasonCodeFor(reason, 'source_unavailable');
  const out: Dict = {};
  for (const k of FLOW_KEYS) out[k] = metric(null, 'DERIVED', reason);
  return Object.assign(out, {
    grade: 'unavailable', eligible: false, reason, state: 'UNAVAILABLE', estimated_equal: false, health: healthError(code),
    snapshot_id: null, calculation_id: null, source_timestamp: null, received_timestamp: null, age_seconds: null, window_seconds: null,
    dbl_signed_momentum: null, dbl_state: 'UNAVAILABLE', dbl_matrix_coverage: null, dbl_up_percent: null, dbl_down_percent: null,
  });
}
const RSRC = 'WIN v0.3 research';
export function researchMetric(value: Any, q: string, reason = ''): Dict {
  if (typeof value === 'number' && (value === Infinity || value === -Infinity))
    return { value: null, quality: q, reason: value > 0 ? 'POSITIVE_UNBOUNDED' : 'NEGATIVE_UNBOUNDED', source: RSRC };
  if (value === null || value === undefined) return metric(null, 'DERIVED', reason || '研究公式未有輸入', RSRC);
  return metric(value, q, reason, RSRC);
}
const RKEYS = ['A', 'B', 'C', 'Self', 'Cross', 'H'];
export function emptyResearch(reason: string, ids: string[]): Dict {
  const out: Dict = {};
  for (const r of ids) { const e: Dict = {}; for (const k of RKEYS) e[k] = metric(null, 'DERIVED', reason, RSRC); out[String(r)] = e; }
  return out;
}
export function poolAmounts(pool: Any, ids: string[]): Map<string, number> | null {
  if (!truthy(pool) || !truthy(get(pool, 'amounts'))) return null;
  const values = new Map<string, number>();
  for (const runner of ids) { const amount = val(get(pool.amounts, String(runner))); if (amount !== null) values.set(String(runner), amount); }
  return values.size >= 2 ? values : null;
}
export function researchFromPools(previousPool: Any, startPool: Any, endPool: Any, ids: string[]): Dict {
  let start = poolAmounts(startPool, ids), end = poolAmounts(endPool, ids);
  if (!start || !end) return emptyResearch('缺少完整逐馬金額', ids);
  const common = [...start.keys()].filter((k) => end!.has(k));
  if (common.length < 2) return emptyResearch('缺少完整逐馬金額', ids);
  start = new Map(common.map((k) => [k, start!.get(k)!]));
  end = new Map(common.map((k) => [k, end!.get(k)!]));
  let previous = truthy(previousPool) ? poolAmounts(previousPool, ids) : null;
  if (previous && previous.size) {
    const p2 = new Map(common.filter((k) => previous!.has(k)).map((k) => [k, previous!.get(k)!]));
    previous = p2.size ? p2 : null;
    if (previous && previous.size !== common.length) previous = null;
  } else previous = null;
  let raw: Map<string, Dict>;
  try { raw = windowFromAmounts(start, end, previous); }
  catch (e) { if (e instanceof PyValueError) return emptyResearch(e.message, ids); throw e; }
  const qualities: Any[] = [];
  for (const pool of [startPool, endPool]) for (const item of Object.values(get(pool, 'amounts') || {})) qualities.push(get(item, 'quality'));
  const ql = qualities.includes('UNAVAILABLE') ? 'UNAVAILABLE' : qualities.includes('ESTIMATED') ? 'ESTIMATED' : 'DERIVED';
  const result: Dict = {};
  for (const runner of ids) {
    const item: Dict = raw.get(String(runner)) || {};
    const b = item.B_log2_gain ?? null;
    result[String(runner)] = {
      A: researchMetric(item.A_share_points ?? null, ql),
      B: researchMetric(b, ql),
      C: researchMetric(item.C_log2_tilt ?? null, ql),
      Self: researchMetric(item.Self_log2_change ?? null, ql, '需要前一個完整窗口先有 Self'),
      Cross: researchMetric(item.Cross_peer_position ?? null, ql),
      H: researchMetric(displayHeight(b), ql, 'H_display=ln(1+B) · v0.3.1 棒高映射'),
    };
  }
  return result;
}
export function flow(previous: Any, current: Any, runner: string, elapsed: number, config: Dict | null = null): Dict {
  const c = { ...DEFAULTS, ...(config || {}) };
  if (!truthy(previous) || !truthy(current)) return emptyFlow('缺少彩池資料');
  if (elapsed < c.window || elapsed > c.window + c.max_gap) return emptyFlow('等待完整 rolling window / 來源更新間隔過長');
  const p0 = previous.total, p1 = current.total;
  const b0 = get(get(previous, 'amounts', {}), String(runner), metric()), b1 = get(get(current, 'amounts', {}), String(runner), metric());
  const q = quality(p0, p1, b0, b1);
  if (q === 'UNAVAILABLE' || val(p0) <= 0) return emptyFlow('缺少可靠 runner / combination investment');
  if (Math.min(val(b0), val(b1)) < 0 || val(b0) > val(p0) || val(b1) > val(p1)) return emptyFlow('馬匹金額超出彩池範圍，資料不一致');
  const delta = val(p1) - val(p0);
  if (delta <= 0) return emptyFlow('彩池未增長或已退款／重設');
  const share = val(b0) / val(p0);
  const actual = val(b1) - val(b0);
  const expected = share * delta;
  const excess = actual - expected;
  const valid = expected > 0 && actual >= 0;
  const overDelta = actual !== null && actual > delta + 0.01;
  const lift = valid ? actual / expected : null;
  const eligible = valid && !overDelta && delta >= c.min_pool_delta && expected >= c.min_expected;
  let grade = 'normal';
  if (eligible) for (const name of ['green', 'red', 'brown']) if (excess >= c[name + '_excess'] && (lift as number) >= c[name + '_lift']) grade = name;
  if (overDelta) grade = 'normal';
  const reason = actual < 0 ? '負 Actual：可能退款、報價取整或非同步來源；不輸出 Pressure'
    : overDelta ? 'Actual 超出 ΔPool，不能作為異常訊號'
    : expected <= 0 ? 'Expected 為零，Lift 未定義'
    : !eligible ? '低流動性：保留公式數值，不產生異常標記' : '';
  const pressurePp = lift !== null ? 100 * lift : null;
  const vals: [string, Any][] = [['share', share], ['actual', actual], ['expected', expected], ['excess', excess], ['lift', lift], ['pressure', pressurePp], ['deltaPool', delta]];
  const result: Dict = {};
  for (const [k, v] of vals) result[k] = metric(v, q, k === 'lift' || k === 'pressure' ? reason : '');
  let state: string, health: Dict;
  if (pressurePp === null) { state = 'UNAVAILABLE'; health = healthError(reasonCodeFor(reason, 'calculation_failed')); }
  else if (delta > 0 && Math.abs(pressurePp - 100) <= UNCHANGED_PRESSURE_TOLERANCE_PP) { state = 'VALID_UNCHANGED'; health = healthOk(); }
  else { state = 'VALID'; health = healthOk(); }
  return Object.assign(result, {
    windowSeconds: metric(elapsed), grade: valid ? grade : 'unavailable', eligible, reason, state, estimated_equal: false, health,
    snapshot_id: null, calculation_id: null, source_timestamp: null, received_timestamp: null, age_seconds: null, window_seconds: elapsed,
    dbl_signed_momentum: null, dbl_state: null, dbl_matrix_coverage: null, dbl_up_percent: null, dbl_down_percent: null,
  });
}
export function anchorBaselineShare(previousPool: Any, runner: string): Dict {
  if (!truthy(previousPool)) return metric(null, 'DERIVED', '無 anchor snapshot');
  const p0 = get(previousPool, 'total', metric());
  const b0 = get(get(previousPool, 'amounts', {}), String(runner), metric());
  if (val(p0) === null || val(p0) <= 0 || val(b0) === null) return metric(null, 'DERIVED', 'anchor 金額／總額缺失');
  if (Math.min(val(b0), val(p0)) < 0 || val(b0) > val(p0)) return metric(null, 'DERIVED', 'anchor 金額超出彩池範圍');
  const q = quality(p0, b0);
  if (q === 'UNAVAILABLE') return metric(null, 'DERIVED', 'anchor 資料不可用');
  return metric(val(b0) / val(p0), q, '熱錢基準 · Anchor snapshot baseline share · 非投注額');
}
export function hotMoney3mFromFlow(flow180: Any): Dict {
  if (!truthy(flow180) || val(get(flow180, 'lift')) === null) {
    const reason = get(flow180 || {}, 'reason') || '180s 窗口無法計算';
    return metric(null, 'DERIVED', reason);
  }
  const lift = val(flow180.lift);
  let q = get(flow180.lift || {}, 'quality') || 'DERIVED';
  if (q === 'DERIVED') q = 'ESTIMATED';
  return metric(lift - 1, q, '熱錢3′ · 180s rolling anomaly · (Actual−Expected)/Expected');
}
export function sourceReceivedSkewInvalid(snapshot: Dict): boolean {
  const src = has(snapshot, 'sourceTimestamp') ? snapshot.sourceTimestamp : get(snapshot, 'timestamp');
  const recv = get(snapshot, 'receivedAt');
  if (src === null || src === undefined || recv === null || recv === undefined) return false;
  return Math.abs(src - recv) > SYNC_TOLERANCE_SECONDS;
}
export function pairAttribution(pool: Any, runners: Any[]): Dict | null {
  if (!truthy(pool) || !truthy(get(pool, 'complete'))) return null;
  const combos: Dict = get(pool, 'combinations', {}) || {};
  const ids = [...new Set(runners.map((r) => String(r)))];
  const idset = new Set(ids);
  const seen = new Set<string>(); const sums: Dict = {}; const edges: Record<string, number[]> = {};
  for (const r of ids) { sums[r] = 0.0; edges[r] = []; }
  for (const [key, m] of Object.entries(combos)) {
    const bits = key.split(',');
    if (bits.length !== 2 || bits[0] === bits[1] || !bits.every((b) => idset.has(b)) || m.quality !== 'DIRECT' || val(m) === null || val(m) < 0) return null;
    const pair = sortedBy(bits, (b) => parseInt(b, 10));
    const pk = pair.join(',');
    if (seen.has(pk)) return null;
    seen.add(pk);
    for (const r of pair) { sums[r] += val(m) / 2; edges[r].push(val(m)); }
  }
  if (seen.size !== Math.floor((ids.length * (ids.length - 1)) / 2)) return null;
  const total = val(get(pool, 'total'));
  if (total === null || Math.abs(sum(ids.map((r) => sums[r])) - total) > Math.max(1, total * 0.000001)) return null;
  const concentration: Dict = {}; const amounts: Dict = {};
  for (const r of ids) {
    const s = sum(edges[r]);
    concentration[r] = metric(s ? sum(edges[r].map((v) => (v / s) ** 2)) : null, 'DERIVED', 'HHI of cumulative incident investment; not added to WIN Pressure');
  }
  for (const r of ids) amounts[r] = metric(sums[r]);
  return { ...pool, amounts, concentration };
}
export function forecastAttribution(pool: Any, runners: Any[]): Dict | null {
  if (!truthy(pool) || !truthy(get(pool, 'complete'))) return null;
  const combos: Dict = get(pool, 'combinations', {}) || {};
  let ids = [...new Set(runners.map((r) => String(r)))];
  if (get(pool, 'activeRunners') !== null && get(pool, 'activeRunners') !== undefined) {
    const active = [...new Set((pool.activeRunners as Any[]).map((r) => String(r)))];
    const idset0 = new Set(ids);
    if (!active.length || !active.every((a) => idset0.has(a))) return null;
    ids = active;
  }
  const idset = new Set(ids);
  const n = ids.length;
  if (n < 2) return null;
  const first: Dict = {}, second: Dict = {};
  for (const r of ids) { first[r] = 0.0; second[r] = 0.0; }
  const seen = new Set<string>();
  for (const [key, m] of Object.entries(combos)) {
    const bits = key.split(',');
    if (bits.length !== 2 || bits[0] === bits[1] || !bits.every((b) => idset.has(b))) return null;
    if (get(m, 'quality') !== 'DIRECT' || val(m) === null || val(m) < 0) return null;
    const ok = bits[0] + ',' + bits[1];
    if (seen.has(ok)) return null;
    seen.add(ok);
    const v = val(m);
    first[bits[0]] += v; second[bits[1]] += v;
  }
  if (seen.size !== n * (n - 1)) return null;
  const sums: Dict = {};
  for (const r of ids) sums[r] = 0.5 * (first[r] + second[r]);
  const attributed = sum(ids.map((r) => sums[r]));
  const total = val(get(pool, 'total'));
  if (total === null || Math.abs(attributed - total) > Math.max(1, total * 0.000001)) return null;
  const amounts: Dict = {}, fm: Dict = {}, sm: Dict = {};
  for (const r of ids) amounts[r] = metric(sums[r], 'DIRECT', 'FCT half-role from DIRECT ordered matrix', 'FCT DIRECT matrix');
  for (const r of ids) fm[r] = metric(first[r], 'DIRECT', '', 'FCT First marginal');
  for (const r of ids) sm[r] = metric(second[r], 'DIRECT', '', 'FCT Second marginal');
  return { ...pool, amounts, first: fm, second: sm };
}
export function dblPressure(snapshot: Dict, runners: string[]): Dict {
  const matrix: Dict = get(snapshot, 'outgoingDouble', {}) || {};
  const result: Dict = {};
  for (const r of runners) { const e: Dict = {}; for (const k of ['pressure', 'actual', 'expected', 'excess']) e[k] = metric(null, 'DERIVED', '完整 DBL 組合 investment 未提供'); result[String(r)] = e; }
  if (!truthy(get(matrix, 'complete')) || !truthy(get(matrix, 'secondLegRunners'))) return result;
  const combos: Dict = get(matrix, 'combinations', {}) || {};
  const keys = new Set<string>();
  for (const r of runners) for (const j of matrix.secondLegRunners) keys.add(`${r},${j}`);
  const ck = Object.keys(combos);
  if (ck.length !== keys.size || !ck.every((k) => keys.has(k)) || Object.values(combos).some((m: Any) => m.quality !== 'DIRECT' || val(m) === null || val(m) < 0)) return result;
  const total = sum(Object.values(combos).map((m) => val(m)));
  if (total <= 0) return result;
  const declared = val(get(matrix, 'total'));
  if (declared !== null && Math.abs(declared - total) > Math.max(1, total * 0.000001)) return result;
  const win: Dict = get(get(snapshot, 'pools', {}), 'WIN', {}) || {};
  if (get(matrix, 'updatedAt') !== null && get(win, 'updatedAt') !== null) {
    if (Math.abs(matrix.updatedAt - win.updatedAt) > 15 || Math.abs(snapshot.timestamp - matrix.updatedAt) > 15) return result;
  }
  const wp = get(win, 'total', metric());
  for (const r0 of runners) {
    const r = String(r0);
    const b = get(get(win, 'amounts', {}), r, metric());
    if (val(b) === null || val(wp) === null || val(wp) <= 0 || val(b) <= 0) continue;
    const actual = sum(matrix.secondLegRunners.map((j: Any) => val(combos[`${r},${j}`])));
    const expected = (total * val(b)) / val(wp);
    const q = quality(wp, b);
    result[r] = { pressure: metric(actual / expected, q), actual: metric(actual), expected: metric(expected, q), excess: metric(actual - expected, q) };
  }
  return result;
}
const hasWinOdds = (s: Dict): boolean => Object.values(s.runners as Dict).some((r: Any) => val(get(r, 'winOdds')) !== null);
export function baseline(race: Dict, snapshots: Dict[], minutes = 15): Dict {
  const target = race.postTime - minutes * 60;
  const eligible = snapshots.filter((s) => s.timestamp <= target && target - s.timestamp <= 30 && hasWinOdds(s));
  let selected: Dict | null, status: string;
  if (eligible.length) { selected = eligible[eligible.length - 1]; status = 'LOCKED'; }
  else {
    const later = snapshots.filter((s) => s.timestamp > target && hasWinOdds(s));
    selected = later.length ? later[0] : null;
    status = selected ? 'LATE' : 'WAITING';
  }
  let order = (race.runners as Dict[]).map((r) => String(r.no));
  if (selected) {
    const sel = selected;
    order = sortedBy(order, (r) => [val(get(get(sel.runners, r, {}), 'winOdds')) || Infinity, parseInt(r, 10)]);
  }
  const winOdds: Dict = {};
  for (const runner of order) {
    if (status === 'LOCKED' && selected) {
      const quoted = get(get(selected.runners, runner, {}), 'winOdds');
      winOdds[runner] = val(quoted) !== null ? quoted : metric(null, 'DERIVED', 'T−15 切片未有此馬獨贏');
    } else winOdds[runner] = metric(null, 'DERIVED', '未捕捉到開跑前15分鐘獨贏');
  }
  return { order, status, timestamp: selected ? selected.timestamp : null, target, winOdds };
}
export function median(values: Any[]): number | null {
  const xs = values.filter((v) => isFiniteNum(v)).sort((a, b) => a - b);
  if (!xs.length) return null;
  const mid = Math.floor(xs.length / 2);
  return xs.length % 2 ? xs[mid] : (xs[mid - 1] + xs[mid]) / 2;
}
/** Shares are Maps to preserve Python dict insertion order for integer-like runner ids. */
export type Shares = Map<string, number>;
export function normalizeShares(shares: Shares | null): Shares | null {
  const clean = new Map<string, number>();
  for (const [k, v] of shares || []) if (isFiniteNum(v) && v >= 0) clean.set(String(k), v);
  const total = sum(clean.values());
  if (total <= 0 || clean.size < 1) return null;
  return new Map([...clean].map(([k, v]) => [k, v / total]));
}
export function impliedSharesFromOdds(runners: Dict, ids: string[]): Shares | null {
  const inv = new Map<string, number>();
  for (const runner of ids) {
    const odds = val(get(get(runners || {}, String(runner), {}), 'winOdds'));
    if (isFiniteNum(odds) && odds > 0) inv.set(String(runner), 1.0 / odds);
  }
  const total = sum(inv.values());
  if (total <= 0 || inv.size < 2) return null;
  return new Map([...inv].map(([k, v]) => [k, v / total]));
}
export function impliedSharesFromDirectAmounts(pool: Any, ids: string[]): Shares | null {
  if (!truthy(pool) || !truthy(get(pool, 'amounts'))) return null;
  const amounts = new Map<string, number>();
  for (const runner of ids) {
    const item = get(pool.amounts, String(runner));
    if (!truthy(item) || item.quality !== 'DIRECT') return null;
    const amount = val(item);
    if (amount === null || amount < 0) return null;
    amounts.set(String(runner), amount);
  }
  const total = sum(amounts.values());
  if (total <= 0 || amounts.size < 2) return null;
  return new Map([...amounts].map(([k, v]) => [k, v / total]));
}
export function sharesFromPoolAmounts(pool: Any, ids: string[], accept = ['DIRECT', 'DERIVED']): [Shares | null, string | null] {
  if (!truthy(pool) || !truthy(get(pool, 'amounts'))) return [null, null];
  const amounts = new Map<string, number>(); const qualities = new Set<string>();
  for (const runner of ids) {
    const item = get(pool.amounts, String(runner));
    if (!truthy(item)) continue;
    const q = item.quality;
    if (!accept.includes(q)) continue;
    const amount = val(item);
    if (amount === null || amount < 0 || !Number.isFinite(amount)) continue;
    amounts.set(String(runner), amount); qualities.add(q);
  }
  if (amounts.size < 2) return [null, null];
  const total = sum(amounts.values());
  if (total <= 0) return [null, null];
  const shares = new Map([...amounts].map(([k, v]) => [k, v / total]));
  return [shares, qualities.size === 1 && qualities.has('DIRECT') ? 'DIRECT' : 'DERIVED'];
}
export function sharesFromComboOdds(oddsMap: Any, ids: string[]): Shares | null {
  if (!truthy(oddsMap)) return null;
  const idset = new Set(ids.map(String));
  const invEdges: [string, string, number][] = [];
  for (const [key, item] of Object.entries(oddsMap as Dict)) {
    const bits = String(key).replace(/-/g, ',').split(',');
    if (bits.length !== 2 || bits[0] === bits[1]) continue;
    if (!idset.has(bits[0]) || !idset.has(bits[1])) continue;
    const odds = isDict(item) ? val(item) : item;
    if (!isFiniteNum(odds) || odds <= 0) continue;
    invEdges.push([bits[0], bits[1], 1.0 / odds]);
  }
  if (invEdges.length < 2) return null;
  const totals = new Map<string, number>(ids.map((r) => [String(r), 0.0]));
  for (const [a, b, inv] of invEdges) { totals.set(a, totals.get(a)! + 0.5 * inv); totals.set(b, totals.get(b)! + 0.5 * inv); }
  return normalizeShares(totals);
}
function normalizePoolForShares(pool: Any, ids: string[], name: string): Any {
  if (!truthy(pool)) return null;
  if (name === 'QIN' || name === 'QPL') return pairAttribution(pool, ids) || pool;
  if (name === 'FCT') return forecastAttribution(pool, ids) || pool;
  return pool;
}
export function poolRunnerShares(name: string, pool: Any, runners: Dict, ids0: string[]): [Shares | null, string | null] {
  const ids = ids0.map(String);
  const p = normalizePoolForShares(pool, ids, name);
  if (!truthy(p)) return [null, null];
  const [shares, q] = sharesFromPoolAmounts(p, ids);
  if (shares) return [shares, q];
  if (name === 'WIN') { const s = impliedSharesFromOdds(runners || {}, ids); return s ? [s, 'ESTIMATED'] : [null, null]; }
  const oddsMap = get(p, 'odds') || {};
  if (truthy(oddsMap)) { const s = sharesFromComboOdds(oddsMap, ids); return s ? [s, 'ESTIMATED'] : [null, null]; }
  return [null, null];
}
export type Parts = Map<string, { weight: number; quality: string; shares: Shares }>;
export function combinedShareMap(runners: Dict, pools: Dict, ids0: string[]): [Shares | null, string | null, Parts | null] {
  const ids = ids0.map(String);
  const raw = new Map<string, number>(ids.map((r) => [r, 0.0]));
  let weightUsed = 0.0; const qualities: string[] = []; const parts: Parts = new Map();
  for (const [name, weight] of COMBINED_SHARE_WEIGHTS) {
    const [shares, q] = poolRunnerShares(name, get(pools || {}, name), runners, ids);
    if (!shares || !shares.size) continue;
    weightUsed += weight; qualities.push(q as string);
    parts.set(name, { weight, quality: q as string, shares });
    for (const [r, s] of shares) if (raw.has(r)) raw.set(r, raw.get(r)! + weight * s);
  }
  if (weightUsed <= 0) return [null, null, null];
  const combined = normalizeShares(raw);
  if (!combined || !combined.size) return [null, null, null];
  let overall: string;
  if (qualities.some((q) => q === 'ESTIMATED')) overall = 'ESTIMATED';
  else if (qualities.every((q) => q === 'DIRECT') && qualities.length === 1) overall = 'DIRECT';
  else overall = 'DERIVED';
  return [combined, overall, parts];
}
export function barHeightFromShares(cur: number | null, base: number | null, eps = SHARE_EPS): number | null {
  if (cur === null || base === null || cur === undefined || base === undefined) return null;
  if (!(Number.isFinite(cur) && Number.isFinite(base))) return null;
  if (base + eps <= 0) return null;
  return (100.0 * (cur + eps)) / (base + eps);
}
export function displayBarHeight(raw: number | null): number | null {
  if (raw === null || !Number.isFinite(raw)) return null;
  return Math.max(BAR_DISPLAY_FLOOR, Math.min(BAR_DISPLAY_CAP, raw));
}
function medianShareMap(maps: Shares[], ids: string[]): Shares | null {
  const med = new Map<string, number>();
  for (const runner of ids) {
    const vals = maps.filter((m) => m.has(String(runner))).map((m) => m.get(String(runner)));
    const m = median(vals);
    if (m !== null) med.set(String(runner), m);
  }
  return normalizeShares(med);
}
const sharesToObj = (s: Shares | null): Dict => { const o: Dict = {}; for (const [k, v] of s || []) o[k] = v; return o; };
const partsToObj = (p: Parts | null): Dict => { const o: Dict = {}; for (const [k, v] of p || []) o[k] = { weight: v.weight, quality: v.quality, shares: sharesToObj(v.shares) }; return o; };
type CombinedFn = (snap: Dict, ids: string[]) => [Shares | null, string | null, Parts | null];
const snapshotCombinedShares: CombinedFn = (snap, ids) => combinedShareMap(get(snap || {}, 'runners') || {}, get(snap || {}, 'pools') || {}, ids);
/** Internal form keeps Maps; `sharesObj` for JSON. */
export function freezeShareBaseline(race: Dict, snapshots: Dict[], ids0: string[], combinedFn: CombinedFn = snapshotCombinedShares): Dict {
  const ids = ids0.map(String);
  const post = get(race, 'postTime');
  const empty: Dict = { shares: new Map(), provisional: true, status: 'WAITING', sampleCount: 0, window: null, timestamp: null, reason: '未有有效綜合份額可凍結基準', poolParts: new Map() };
  if (post === null || post === undefined || !ids.length) return empty;
  const lo = post - BASELINE_SHARE_EARLY_MIN * 60;
  const hi = post - BASELINE_SHARE_LATE_MIN * 60;
  const officialMaps: Shares[] = [], officialParts: Parts[] = [];
  for (const snap of snapshots || []) {
    const ts = get(snap, 'timestamp');
    if (ts === null || ts < lo || ts > hi) continue;
    const [combined, , parts] = combinedFn(snap, ids);
    if (combined && combined.size >= 2) { officialMaps.push(combined); officialParts.push(parts || new Map()); }
  }
  if (officialMaps.length) {
    const shares = medianShareMap(officialMaps, ids);
    if (shares && shares.size) {
      const tss = snapshots.filter((s) => get(s, 'timestamp') !== null && lo <= s.timestamp && s.timestamp <= hi).map((s) => s.timestamp);
      return { shares, provisional: false, status: 'OFFICIAL', sampleCount: officialMaps.length, window: [lo, hi], timestamp: Math.max(...tss),
        reason: 'T−17…T−13 窗口 median CombinedShare 凍結（B+D）', poolParts: officialParts.length ? officialParts[officialParts.length - 1] : new Map() };
    }
  }
  const fullMaps: Shares[] = [], partialMaps: Shares[] = []; let lastParts: Parts = new Map();
  for (const snap of snapshots || []) {
    const [combined, , parts] = combinedFn(snap, ids);
    if (!combined || !combined.size) continue;
    lastParts = parts || new Map();
    if (ids.every((r) => combined.has(r))) {
      fullMaps.push(combined);
      if (fullMaps.length >= PROVISIONAL_STABLE_FRAMES) break;
    } else if (combined.size >= 2 && !fullMaps.length) {
      partialMaps.push(combined);
      if (partialMaps.length >= PROVISIONAL_STABLE_FRAMES) break;
    }
  }
  const use = fullMaps.length ? fullMaps.slice(0, PROVISIONAL_STABLE_FRAMES) : partialMaps.slice(0, 1);
  if (!use.length) return empty;
  const shares = use.length > 1 ? medianShareMap(use, ids) : normalizeShares(use[0]);
  if (!shares || !shares.size) return empty;
  return { shares, provisional: true, status: 'PROVISIONAL', sampleCount: use.length, window: null,
    timestamp: get((snapshots && snapshots.length ? snapshots : [{}])[0], 'timestamp'),
    reason: '臨時基準 · 開盤後首批穩定綜合份額（待 T−15 窗口升級）', poolParts: lastParts };
}
export function shareBaselineToJson(b: Dict | null): Dict | null {
  if (!b) return b;
  return { ...b, shares: sharesToObj(b.shares), poolParts: partsToObj(b.poolParts) };
}
export function computeShareBars(runners: Dict, pools: Dict, shareBaseline: Dict | null, ids0: string[], order0: string[] | null, current3?: [Shares | null, string | null, Parts | null]): Dict {
  const ids = ids0.map(String);
  const order = (order0 && order0.length ? order0 : ids).map(String);
  const baselineShares: Shares = get(shareBaseline || {}, 'shares') || new Map();
  const provisional = Boolean(has(shareBaseline, 'provisional') ? shareBaseline!.provisional : true);
  const status = get(shareBaseline || {}, 'status') || 'WAITING';
  const [current, curQuality, parts] = current3 || combinedShareMap(runners || {}, pools || {}, ids);
  const curReason = curQuality === 'ESTIMATED' ? 'CurrentCombinedShare = 多池加權份額（含 ƒ 賠率推算）'
    : curQuality === 'DIRECT' ? 'CurrentCombinedShare = DIRECT 投資／矩陣份額'
    : 'CurrentCombinedShare = Σ w_p·Share_p / Σ（缺池省略重計權；PLA 除外）';
  const out: Dict = {};
  for (const runner of order) {
    const base = baselineShares.has(runner) ? baselineShares.get(runner)! : null;
    const cur = current && current.has(runner) ? current.get(runner)! : null;
    const baseM = base !== null
      ? metric(base, provisional ? 'ESTIMATED' : 'DERIVED', provisional ? '臨時 BaselineCombinedShare' : '凍結 BaselineCombinedShare · T−17…T−13 median', 'Combined share baseline')
      : metric(null, 'DERIVED', '未有 BaselineCombinedShare（缺份額或基準）', 'Combined share baseline');
    const curM = cur !== null ? metric(cur, curQuality || 'ESTIMATED', curReason, 'Combined share current') : metric(null, 'DERIVED', '未有此馬有效綜合份額', 'Combined share current');
    const raw = cur !== null && base !== null ? barHeightFromShares(cur, base) : null;
    const disp = displayBarHeight(raw);
    let heightM: Dict, dispM: Dict;
    if (raw === null) {
      heightM = metric(null, 'DERIVED', cur === null ? '未有此馬有效綜合份額' : base === null ? '未有 BaselineCombinedShare' : '無法計算棒高', 'Combined share bar');
      dispM = metric(null, 'DERIVED', heightM.reason, 'Combined share bar');
    } else {
      const q = curQuality === 'DIRECT' ? curQuality : curQuality === 'ESTIMATED' ? 'ESTIMATED' : 'DERIVED';
      heightM = metric(raw, q || 'DERIVED', 'BarHeight = 100×(CurrentCombined+ε)/(BaselineCombined+ε) · ε=0.0025 · uncapped', 'Combined share bar');
      dispM = metric(disp, heightM.quality, '顯示高度 clamp 50–200；tooltip 用 uncapped', 'Combined share bar');
    }
    const runnerParts: Dict = {};
    for (const [pname, meta] of parts || []) {
      if (!meta.shares.has(runner)) continue;
      const sh = meta.shares.get(runner)!;
      runnerParts[pname] = { weight: meta.weight, quality: meta.quality, share: metric(sh, meta.quality, `${pname} share`, 'Combined share part') };
    }
    out[runner] = { currentShare: curM, baselineShare: baseM, barHeight: heightM, barHeightDisplay: dispM, provisional, baselineStatus: status, poolParts: runnerParts };
  }
  return out;
}
export const KEEP_LAST_SHARE_REASON = '保留上次有效棒高（本切片未計出）';
export function keepLastShareBars(shareBars: Dict | null, prior: Dict | null): Dict {
  if (!truthy(shareBars)) return shareBars || {};
  const p = prior || {};
  const out: Dict = {};
  for (const [runner, bar0] of Object.entries(shareBars as Dict)) {
    const bar = bar0 || {};
    if (val(get(bar, 'barHeight')) !== null) { const entry = { ...bar }; delete entry.keptFromPrior; out[runner] = entry; continue; }
    const prev = get(p, runner) || {};
    if (val(get(prev, 'barHeight')) === null) { out[runner] = bar; continue; }
    const kept: Dict = { ...prev };
    for (const key of ['barHeight', 'barHeightDisplay', 'currentShare', 'baselineShare']) {
      let m = kept[key];
      if (!isDict(m)) continue;
      m = { ...m };
      const priorReason = String(m.reason || '').trim();
      if (!priorReason.includes(KEEP_LAST_SHARE_REASON)) m.reason = (KEEP_LAST_SHARE_REASON + (priorReason ? ' · ' + priorReason : '')).trim();
      kept[key] = m;
    }
    kept.keptFromPrior = true;
    out[runner] = kept;
  }
  return out;
}
export function poolClock(pool: Any, snapshot: Dict): Any {
  if (!truthy(pool)) return null;
  return has(pool, 'flowUpdatedAt') ? pool.flowUpdatedAt : has(pool, 'updatedAt') ? pool.updatedAt : snapshot.timestamp;
}
export function moneyFlowStatus(snapshot: Dict, flows: Dict, order: string[], snapshots: Dict[], config: Dict): Dict {
  const win: Dict = get(get(snapshot, 'pools', {}), 'WIN') || {};
  const active: Any[] = truthy(get(win, 'activeRunners')) ? win.activeRunners : order;
  const values = active.filter((r) => has(flows, String(r))).map((r) => flows[String(r)].WIN);
  const ready = values.filter((f) => val(f.pressure) !== null).length;
  const clock = poolClock(win, snapshot);
  let validClocks = snapshots.filter((s) => truthy(get(get(get(s, 'pools', {}), 'WIN', {}) || {}, 'amounts'))).map((s) => poolClock(get(get(s, 'pools', {}), 'WIN'), s));
  validClocks = validClocks.filter((t) => t !== null && t !== undefined && clock !== null && clock !== undefined && t <= clock);
  const progress = validClocks.length ? Math.min(config.window, Math.max(0, clock - Math.min(...validClocks))) : 0;
  let status: string, message: string;
  if (ready) { status = 'READY'; message = `WIN 熱錢計算就緒 · ${ready} 匹馬可計算`; }
  else if (!truthy(get(win, 'amounts')) || val(get(win, 'total')) === null) { status = 'SOURCE_GAP'; message = get(get(win, 'total', {}) || {}, 'reason') || '等待可配對的 WIN 彩池與賠率'; }
  else if (progress < config.window) { status = 'WARMING'; message = `正在累積 WIN 資料 · ${Math.trunc(progress)} / ${config.window} 秒`; }
  else { status = 'UNAVAILABLE'; const f = values.find((f) => truthy(f.reason)); message = f ? f.reason : '等待有效 WIN 更新'; }
  const oddsTime = get(win, 'oddsUpdatedAt');
  const investmentTime = get(win, 'investmentUpdatedAt');
  if (status === 'SOURCE_GAP' && oddsTime !== null && investmentTime !== null && Math.abs(oddsTime - investmentTime) > 15)
    message = `WIN 賠率與彩池時間相差 ${fmtF(Math.abs(oddsTime - investmentTime), 1)} 秒（上限 15 秒），暫不能計算 Pressure（熱錢比棒仍可按獨贏賠率顯示）`;
  return { status, message, readyRunners: ready, windowSeconds: config.window, collectedSeconds: progress, calculationTime: clock ?? null,
    oddsTime: has(win, 'amountOddsUpdatedAt') ? win.amountOddsUpdatedAt : get(win, 'oddsUpdatedAt'),
    quoteTime: oddsTime, investmentTime, alignment: get(win, 'alignment'),
    quality: values.some((f) => f.pressure.quality === 'ESTIMATED') ? 'ESTIMATED' : ready ? 'DERIVED' : 'UNAVAILABLE' };
}
function anchorFor(clocks: (Any)[], has_: boolean[], index: number, clock: Any, windowSec: number): number | null {
  // max((t,j)) over j<index with pool amounts and t<=clock-window  (Python tuple max)
  let bestT: Any = null, bestJ: number | null = null;
  if (clock === null || clock === undefined) return null;
  const lim = clock - windowSec;
  for (let j = 0; j < index; j++) {
    if (!has_[j]) continue;
    const t = clocks[j];
    if (t === null || t === undefined || !(t <= lim)) continue;
    if (bestJ === null || t > bestT || (t === bestT && j > bestJ)) { bestT = t; bestJ = j; }
  }
  return bestJ;
}
export function analyze(race: Dict, snapshots0: Dict[], config: Dict | null = null): Dict {
  const c = { ...DEFAULTS, ...(config || {}) };
  const snapshots = sortedBy(snapshots0, (s) => s.timestamp);
  const lock = baseline(race, snapshots, c.baseline_minutes);
  const frames: Dict[] = [];
  const ids = (race.runners as Dict[]).filter((r) => !truthy(get(r, 'scratched'))).map((r) => String(r.no));
  let shareBaseline: Dict | null = null;
  const normalized: Dict[] = [];
  for (const s of snapshots) {
    const pools: Dict = { ...(get(s, 'pools', {}) || {}) };
    for (const name of ['QIN', 'QPL']) pools[name] = pairAttribution(get(pools, name), ids);
    pools.FCT = forecastAttribution(get(pools, 'FCT'), ids);
    normalized.push(pools);
  }
  // Pure per-snapshot memo (identical results; avoids O(n²) recomputation of combined shares).
  const memo = new Map<Dict, [Shares | null, string | null, Parts | null]>();
  const memoFn: CombinedFn = (snap, idl) => { let r = memo.get(snap); if (!r) { r = snapshotCombinedShares(snap, idl); memo.set(snap, r); } return r; };
  // Precompute clocks/availability per pool (same values Python recomputes per index).
  const clocksBy: Record<string, Any[]> = {}, hasBy: Record<string, boolean[]> = {};
  for (const name of POOL_NAMES) {
    clocksBy[name] = snapshots.map((s, j) => poolClock(get(normalized[j], name), s));
    hasBy[name] = snapshots.map((_s, j) => truthy(get(normalized[j], name)) && truthy(get(normalized[j][name], 'amounts')));
  }
  const order: string[] = lock.order;
  for (let index = 0; index < snapshots.length; index++) {
    const s = snapshots[index];
    const anchors: Record<string, [Any, number | null]> = {};
    for (const name of POOL_NAMES) {
      const clock = clocksBy[name][index];
      anchors[name] = [clock, anchorFor(clocksBy[name], hasBy[name], index, clock, c.window)];
    }
    const winClock3m = anchors.WIN[0];
    const winOld180 = anchorFor(clocksBy.WIN, hasBy.WIN, index, winClock3m, HOT_MONEY_3M_WINDOW);
    const skewInvalid = sourceReceivedSkewInvalid(s);
    const flows: Dict = {};
    for (const r of order) {
      flows[r] = {};
      for (const name of POOL_NAMES) {
        const p = get(normalized[index], name);
        const [clock, old] = anchors[name];
        const p0 = old !== null ? get(normalized[old], name) : null;
        const elapsed = old !== null && clock !== null && clock !== undefined ? clock - poolClock(p0, snapshots[old]) : 0;
        let f: Dict;
        if (old === null || elapsed < c.window) f = emptyFlow('等待完整 rolling window / 來源更新間隔過長', 'missing_window');
        else f = flow(p0, p, r, elapsed, c);
        if (['WIN', 'QIN', 'QPL', 'FCT'].includes(name) && clock !== null && clock !== undefined) {
          if (s.timestamp - clock > 45 || clock > s.timestamp) f = emptyFlow('彩池更新不同步／過期');
        }
        if (name === 'DBL_UP' || name === 'DBL_DOWN') {
          f = { ...f };
          const amt = val(get(get(p || {}, 'amounts', {}), r));
          const tot = val(get(p || {}, 'total'));
          const actual = val(get(f, 'actual'));
          const delta = val(get(f, 'deltaPool'));
          let pct: number | null = null; let reason = '';
          if (actual !== null && delta !== null && delta > 0) { pct = (100 * Math.max(0.0, actual)) / delta; reason = '呢段時間新入孖寶資金佔該腿彩池增量'; }
          else if (amt !== null && truthy(tot) && tot > 0) { pct = (100 * Math.max(0.0, amt)) / tot; reason = '當下該腿佔孖寶彩池份額（非相對獨贏）'; }
          f.legPct = pct !== null ? metric(pct, 'ESTIMATED', reason, 'DBL leg share') : metric(null, 'DERIVED', '未有孖寶腿金額');
        }
        if (name === 'WIN') {
          f = { ...f };
          if (val(get(f, 'pressure')) === null) { f.state = 'UNAVAILABLE'; f.health = healthError(reasonCodeFor(get(f, 'reason'))); f.estimated_equal = false; }
          else {
            if (!has(f, 'state')) f.state = get(f, 'state') || 'VALID';
            if (!has(f, 'estimated_equal')) f.estimated_equal = false;
            if (!has(f, 'health')) f.health = healthOk();
          }
          f.snapshot_id = get(s, 'id');
          f.calculation_id = `${get(s, 'id') ?? 'None'}:${name}:${r}`;
          f.source_timestamp = has(s, 'sourceTimestamp') ? s.sourceTimestamp : get(s, 'timestamp');
          f.received_timestamp = get(s, 'receivedAt');
          f.window_seconds = val(get(f, 'windowSeconds'));
          if (skewInvalid) f.hot_money_baseline = metric(null, 'DERIVED', '來源／接收時間相差超過 15 秒');
          else if (old === null || clock === null || clock === undefined) f.hot_money_baseline = metric(null, 'DERIVED', '無 60–90s anchor snapshot');
          else if (!(c.window <= elapsed && elapsed <= c.window + c.max_gap)) f.hot_money_baseline = metric(null, 'DERIVED', 'anchor 不在 60–90s 範圍');
          else if (s.timestamp - clock > 45 || clock > s.timestamp) f.hot_money_baseline = metric(null, 'DERIVED', '彩池更新不同步／過期');
          else f.hot_money_baseline = anchorBaselineShare(p0, r);
          if (skewInvalid) f.hot_money_3m = metric(null, 'DERIVED', '來源／接收時間相差超過 15 秒');
          else if (winOld180 === null || winClock3m === null || winClock3m === undefined) f.hot_money_3m = metric(null, 'DERIVED', '等待完整 180s rolling window', 'hot_money_3m');
          else if (s.timestamp - winClock3m > 45 || winClock3m > s.timestamp) f.hot_money_3m = metric(null, 'DERIVED', '彩池更新不同步／過期');
          else {
            const p0180 = get(normalized[winOld180], 'WIN');
            const elapsed180 = winClock3m - poolClock(p0180, snapshots[winOld180]);
            const cfg180 = { ...c, window: HOT_MONEY_3M_WINDOW };
            if (elapsed180 < HOT_MONEY_3M_WINDOW || elapsed180 > HOT_MONEY_3M_WINDOW + c.max_gap) f.hot_money_3m = metric(null, 'DERIVED', '等待完整 180s rolling window', 'hot_money_3m');
            else f.hot_money_3m = hotMoney3mFromFlow(flow(p0180, p, r, elapsed180, cfg180));
          }
        }
        if (name === 'DBL_UP' || name === 'DBL_DOWN') {
          f = { ...f };
          f.dbl_state = val(get(get(p || {}, 'amounts', {}), r)) !== null ? 'ESTIMATED' : 'UNAVAILABLE';
        }
        const conc = get(p || {}, 'concentration', {}) || {};
        f.concentration = has(conc, r) ? conc[r] : metric(null, 'DERIVED', '沒有可靠組合矩陣');
        flows[r][name] = f;
      }
    }
    // Pool conservation / active-runner integrity.
    const winPool: Dict = get(normalized[index], 'WIN') || {};
    const winQualities = order.map((r) => get(get(winPool, 'amounts') || {}, String(r), {}));
    const estimatedWindow = winQualities.some((q) => truthy(q) && get(q, 'quality') === 'ESTIMATED');
    let broken = false;
    if (estimatedWindow) {
      for (const r of order) {
        const w = flows[r].WIN || {};
        const a = val(get(w, 'actual')), d = val(get(w, 'deltaPool'));
        if (a !== null && d !== null && (a < -0.01 || a > d + 0.01)) { broken = true; break; }
      }
    }
    const active = get(winPool, 'activeRunners');
    const amounts = get(winPool, 'amounts') || {};
    const totalV = val(get(winPool, 'total'));
    if (active !== null && active !== undefined && totalV !== null && truthy(amounts)) {
      const present: number[] = []; let brk = false;
      for (const r of active) {
        const item = get(amounts, String(r));
        if (!truthy(item) || val(item) === null) { broken = true; brk = true; break; }
        present.push(val(item));
      }
      if (!brk && Math.abs(sum(present) - totalV) > Math.max(1, totalV * 0.000001)) broken = true;
    }
    if (broken) {
      for (const r of order) {
        const w = flows[r].WIN || {};
        if (estimatedWindow || (active !== null && active !== undefined)) {
          const note = '彩池流量不一致';
          w.pressure = metric(null, 'DERIVED', note); w.lift = metric(null, 'DERIVED', note);
          w.hot_money_3m = metric(null, 'DERIVED', note); w.hot_money_baseline = metric(null, 'DERIVED', note);
          w.eligible = false; w.grade = 'unavailable'; w.reason = note; w.state = 'UNAVAILABLE';
          w.health = healthError('calculation_failed'); w.estimated_equal = false;
        }
      }
    }
    const groups = new Map<number, string[]>();
    for (const r of order) {
      const w = flows[r].WIN || {};
      const p = val(get(w, 'pressure'));
      if (p === null || w.state === 'UNAVAILABLE' || w.state === 'STALE') continue;
      if (get(w.pressure || {}, 'quality') !== 'ESTIMATED') continue;
      const key = pyRound(p, 9);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(r);
    }
    for (const members of groups.values()) if (members.length >= 2) for (const r of members) {
      const w = flows[r].WIN;
      w.estimated_equal = true;
      if (w.state !== 'VALID_UNCHANGED') w.state = 'ESTIMATED_EQUAL';
    }
    for (const r of order) {
      const upNow = get(normalized[index], 'DBL_UP');
      const downNow = get(normalized[index], 'DBL_DOWN');
      const upOld = anchors.DBL_UP[1], downOld = anchors.DBL_DOWN[1];
      const upAnchor = upOld !== null ? get(normalized[upOld], 'DBL_UP') : null;
      const downAnchor = downOld !== null ? get(normalized[downOld], 'DBL_DOWN') : null;
      const upC = val(get(get(upNow || {}, 'amounts', {}), r)), upA = val(get(get(upAnchor || {}, 'amounts', {}), r));
      const downC = val(get(get(downNow || {}, 'amounts', {}), r)), downA = val(get(get(downAnchor || {}, 'amounts', {}), r));
      let momentum: number | null = null; let dblState = 'UNAVAILABLE'; let coverage: number | null = null;
      if (upC !== null && upA !== null && downC !== null && downA !== null) { momentum = upC - upA - (downC - downA); dblState = 'ESTIMATED'; }
      else if (upC !== null || downC !== null) dblState = 'ESTIMATED';
      const matrix: Dict = get(s, 'outgoingDouble') || {};
      if (truthy(get(matrix, 'complete')) && truthy(get(matrix, 'secondLegRunners'))) {
        const keys = new Set<string>();
        for (const rr of ids) for (const j of matrix.secondLegRunners) keys.add(`${rr},${j}`);
        const combos: Dict = get(matrix, 'combinations') || {};
        coverage = keys.size ? Object.keys(combos).filter((k) => keys.has(k)).length / keys.size : 0.0;
        if (coverage >= 1.0 && [...keys].every((k) => get(get(combos, k) || {}, 'quality') === 'DIRECT')) dblState = momentum === null ? 'DIRECT' : dblState;
      }
      const w = flows[r].WIN;
      w.dbl_signed_momentum = momentum; w.dbl_state = dblState; w.dbl_matrix_coverage = coverage;
      w.dbl_up_percent = val(get(flows[r].DBL_UP || {}, 'legPct'));
      w.dbl_down_percent = val(get(flows[r].DBL_DOWN || {}, 'legPct'));
    }
    const tags: Dict = {};
    const [winClock, winOld] = anchors.WIN;
    const winNow = get(normalized[index], 'WIN');
    const winStart = winOld !== null ? get(normalized[winOld], 'WIN') : null;
    let winPrev: Any = null;
    if (winOld !== null && winClock !== null && winClock !== undefined) {
      const startClock = poolClock(winStart, snapshots[winOld]);
      const j = startClock === null || startClock === undefined ? null : anchorFor(clocksBy.WIN, hasBy.WIN, winOld, startClock, c.window);
      if (j !== null) winPrev = get(normalized[j], 'WIN');
    }
    const research = researchFromPools(winPrev, winStart, winNow, ids);
    const fctSrc: Dict = get(get(s, 'pools') || {}, 'FCT') || {};
    const fctDiag: Dict = get(fctSrc, 'diagnostics') || {};
    const fctHealth = {
      quality: get(fctSrc, 'sourceQuality') || get(fctSrc, 'quality') || (truthy(get(fctSrc, 'complete')) ? 'DIRECT' : 'UNAVAILABLE'),
      reason: get(fctSrc, 'unavailableReason') || get(fctSrc, 'reason'),
      sourceSeen: truthy(fctSrc) || truthy(get(fctDiag, 'sourceSeen')),
      directMatrixSeen: truthy(get(fctDiag, 'directMatrixSeen') || (truthy(get(fctSrc, 'complete')) ? get(fctSrc, 'combinations') : get(fctSrc, 'complete'))),
      matrixComplete: truthy(get(fctSrc, 'complete')),
      edgeCount: Math.trunc(get(fctDiag, 'edgeCount') || get(fctSrc, 'edgeCount') || Object.keys(get(fctSrc, 'combinations') || {}).length),
      expectedEdgeCount: Math.trunc(get(fctDiag, 'expectedEdgeCount') || get(fctSrc, 'expectedEdgeCount') || 0),
      totalConserved: has(fctDiag, 'totalConserved') ? truthy(fctDiag.totalConserved) : truthy(get(fctSrc, 'complete')),
      syncSeconds: get(fctDiag, 'syncSeconds'),
      pressureCalculable: order.some((rr) => val(get(get(flows[rr] || {}, 'FCT', {}) || {}, 'pressure')) !== null),
    };
    shareBaseline = freezeShareBaseline(race, snapshots.slice(0, index + 1), ids, memoFn);
    let shareBars = computeShareBars(get(s, 'runners') || {}, normalized[index], shareBaseline, ids, order);
    const priorShareBars = frames.length ? get(frames[frames.length - 1], 'shareBars') : null;
    shareBars = keepLastShareBars(shareBars, priorShareBars);
    frames.push({
      id: s.id, timestamp: s.timestamp, runners: s.runners, pools: get(s, 'pools', {}), flows, tags, double: dblPressure(s, ids),
      moneyFlow: moneyFlowStatus(s, flows, order, snapshots.slice(0, index + 1), c),
      incomingDouble: get(s, 'incomingDouble', {}), source: get(s, 'source'), sourceTimestamp: get(s, 'sourceTimestamp'),
      receivedAt: get(s, 'receivedAt'), latency: get(s, 'latency'), research, fctHealth, shareBars,
      raceTotalInvestment: get(s, 'raceTotalInvestment') || metric(null, 'DERIVED', '未有彩池投注總額'),
    });
  }
  const spectrum: Dict = {};
  for (const r of order) spectrum[r] = [];
  const gIdx = (g: string) => GRADES.indexOf(g);
  for (const minute of range(-15, 2)) {
    const start = race.postTime + minute * 60;
    const group = frames.filter((f) => (start <= f.timestamp && f.timestamp < start + 60) || (minute === 1 && f.timestamp === start + 60));
    for (const r of order) {
      const layers: Dict = {};
      for (const name of ['WIN', 'QIN', 'QPL']) {
        const available = group.filter((f) => val(f.flows[r][name].pressure) !== null);
        const peak = maxBy(available, (f) => [gIdx(f.flows[r][name].grade), val(f.flows[r][name].pressure)]);
        layers[name] = { grade: peak ? peak.flows[r][name].grade : 'unavailable', timestamp: peak ? peak.timestamp : null, frameId: peak ? peak.id : null, pressure: peak ? peak.flows[r][name].pressure : metric() };
      }
      const peaks = Object.values(layers).filter((x: Any) => x.timestamp !== null);
      const peak = maxBy(peaks, (x: Any) => [gIdx(x.grade), val(x.pressure)]);
      spectrum[r].push({ minute, start, layers, peakId: peak ? peak.frameId : null });
    }
  }
  return { frames, baseline: lock, shareBaseline: shareBaselineToJson(shareBaseline), spectrum, config: c };
}
export function sourceHealth(lastUpdate: Any = null, lastReceived: Any = null, latency: Any = null, error: Any = null, now = 0, threshold = 45): Dict {
  if (lastUpdate !== null && lastUpdate !== undefined && (!Number.isFinite(lastUpdate) || lastUpdate > now + 5)) error = error || '來源時間無效／超前本地時鐘';
  const status = truthy(error) ? 'ERROR' : lastUpdate === null || lastUpdate === undefined || now - lastUpdate > threshold ? 'STALE' : 'LIVE';
  return { status, lastUpdate: metric(lastUpdate ?? null, 'DIRECT', '', 'HKJC lastUpdateTime'), lastReceived: metric(lastReceived ?? null, 'DIRECT', '', 'local receipt clock'),
    latency: metric(latency ?? null, 'DIRECT', '', 'HTTP request duration (ms)'), error: error ?? null };
}
