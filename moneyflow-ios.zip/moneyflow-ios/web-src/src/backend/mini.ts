// Faithful TypeScript port of backend/mini.py (/api/mini, 2026-09-28 mini2): 馬、獨贏、獨贏前、孖寶冠／亞／全.
// NO new formula: 獨贏 = latest snapshot winOdds; 獨贏前 = engine.baseline(); 孖寶 = latest incomingDouble.
import { type Any, type Dict, get, isDict, sortedBy, sum, pyInt, truthy } from './py';
import { metric, val, baseline as engineBaseline } from './engine';

export const WIN_MONEY_SOURCE = 'HKJC WIN pool × normalized reciprocal odds（工具現有估算，FORMULAS §1）';
export const FRESH_SECONDS = 45;

const num = (v: Any): number | null => (typeof v === 'number' ? v : null);
const runnerIds = (race: Dict | null, activeOnly: boolean): string[] =>
  ((race || {}).runners || []).filter((r: Dict) => !activeOnly || !truthy(get(r, 'scratched'))).map((r: Dict) => String(r.no));

/** Per-runner 獨贏錢 from the snapshot's existing WIN amounts → [byRunner, reason|null]. Kept as a tested helper
 * (not shown on the mini page since mini2), exactly like mini.win_money(). */
export function winMoney(snapshot: Dict | null, race: Dict | null): [Dict, string | null] {
  const ids = runnerIds(race, true);
  const fill = (why: string, source?: string): [Dict, string] => {
    const out: Dict = {};
    for (const r of ids) out[r] = source ? metric(null, 'DERIVED', why, source) : metric(null, 'DERIVED', why);
    return [out, why];
  };
  if (!snapshot || !Object.keys(snapshot).length) return fill('未有快照');
  const win = get(get(snapshot, 'pools') || {}, 'WIN') || {};
  const amounts = get(win, 'amounts') || {};
  const total = val(get(win, 'total'));
  const blank = (why: string) => fill(why, WIN_MONEY_SOURCE);
  if (!Object.keys(win).length) return blank('未有 WIN 彩池');
  if (!Object.keys(amounts).length) return blank(get(get(win, 'total') || {}, 'reason') || '未有可配對嘅 WIN 彩池總額／賠率');
  const activeRaw = get(win, 'activeRunners');
  const active = (activeRaw && activeRaw.length ? activeRaw : ids).map((r: Any) => String(r));
  const present = new Map<string, number>();
  for (const r of active) {
    const v = val(get(amounts, r));
    if (v === null || v < 0) return blank('WIN 逐馬估算唔齊（有馬匹缺賠率）');
    present.set(r, v);
  }
  if (total !== null && Math.abs(sum(present.values()) - total) > Math.max(1.0, total * 0.000001)) return blank('彩池流量不一致（Σ逐馬 ≠ 彩池總額）');
  const clock = 'flowUpdatedAt' in win ? win.flowUpdatedAt : ('updatedAt' in win ? win.updatedAt : get(snapshot, 'timestamp'));
  const ts = num(get(snapshot, 'timestamp'));
  const c = num(clock);
  if (c !== null && ts !== null && (ts - c > FRESH_SECONDS || c > ts)) return blank('WIN 彩池更新不同步／過期（>45 秒）');
  const out: Dict = {};
  for (const r of ids) {
    const item = get(amounts, r);
    out[r] = present.has(r) && isDict(item)
      ? metric(present.get(r)!, item.quality || 'ESTIMATED', item.reason || '', item.source || WIN_MONEY_SOURCE)
      : metric(null, 'DERIVED', '此馬未有 WIN 估算', WIN_MONEY_SOURCE);
  }
  return [out, null];
}

function dbl(snapshot: Dict | null, runner: string, field: string): Dict {
  const item = get(get(snapshot || {}, 'incomingDouble') || {}, runner) || {};
  const m = get(item, field);
  if (isDict(m)) return m;
  return metric(null, 'DERIVED', '未有孖寶資料（快照冇上一關×本關孖寶）', 'HKJC DBL odds');
}

/** Same predicate engine.baseline() uses to accept a snapshot. */
export function hasWinOdds(snapshot: Dict | null): boolean {
  return Object.values(get(snapshot || {}, 'runners') || {}).some((r: Any) => val(get(r, 'winOdds')) !== null);
}

/** 獨贏前 = engine.baseline() on the candidate snapshots (see Store.baselineCandidates). */
export function winBefore(race: Dict | null, candidates: Dict[] | null, minutes: number): Dict {
  const post = get(race || {}, 'postTime');
  if (num(post) === null) {
    const winOdds: Dict = {};
    for (const r of runnerIds(race, false)) winOdds[r] = metric(null, 'DERIVED', '未有開跑時間');
    return { status: 'WAITING', timestamp: null, target: null, minutes, winOdds };
  }
  const lock = engineBaseline(race!, sortedBy(candidates || [], (s) => s.timestamp), minutes);
  return { status: lock.status, timestamp: lock.timestamp, target: lock.target, minutes, winOdds: lock.winOdds };
}

/** Rows sorted by current WIN odds low→high (missing last, ties by horse no.); scratched last. */
export function rows(race: Dict | null, snapshot: Dict | null, before: Dict | null = null): Dict[] {
  const beforeOdds = get(before || {}, 'winOdds') || {};
  const out: Dict[] = [];
  for (const horse of (race || {}).runners || []) {
    const r = String(horse.no);
    const scratched = truthy(get(horse, 'scratched'));
    let odds = get(get(get(snapshot || {}, 'runners') || {}, r, {}), 'winOdds');
    if (!isDict(odds)) odds = metric(null, 'DERIVED', '未有獨贏賠率', 'HKJC oddsNodes.oddsValue');
    let pre = get(beforeOdds, r);
    if (!isDict(pre)) pre = metric(null, 'DERIVED', '未有獨贏前');
    out.push({ no: horse.no, name: horse.name || '', scratched,
      winOdds: !scratched ? odds : metric(null, 'DERIVED', '退出'),
      winOddsBefore: pre,
      dblWinner: dbl(snapshot, r, 'winner'), dblRunnerUp: dbl(snapshot, r, 'runnerUp'), dblAll: dbl(snapshot, r, 'all') });
  }
  return sortedBy(out, (row) => {
    const o = val(row.winOdds);
    return [row.scratched ? 1 : 0, o === null ? 1 : 0, o !== null ? o : 0, pyInt(row.no)];
  });
}

const SUMMARY_KEYS = ['id', 'date', 'venue', 'venueKind', 'venueLabel', 'no', 'name', 'raceClass', 'distance', 'postTime', 'track', 'course'];
export function raceSummary(race: Dict | null): Dict | null {
  if (!race || !Object.keys(race).length) return null;
  const out: Dict = {};
  for (const k of SUMMARY_KEYS) if (k in race) out[k] = race[k];
  return out;
}

export function view(sel: Dict | null, snapshot: Dict | null, snapshotCount: number, health: Dict, collection: Dict, before: Dict | null = null): Dict {
  const race = get(sel || {}, 'race');
  let frame: Dict | null = null;
  if (snapshot && Object.keys(snapshot).length) {
    frame = { id: get(snapshot, 'id'), timestamp: get(snapshot, 'timestamp'),
      sourceTimestamp: 'sourceTimestamp' in snapshot ? snapshot.sourceTimestamp : get(snapshot, 'timestamp'),
      receivedAt: get(snapshot, 'receivedAt'), source: get(snapshot, 'source') };
  }
  let base: Dict | null = null;
  if (before && Object.keys(before).length) {
    base = {};
    for (const k of ['status', 'timestamp', 'target', 'minutes']) base[k] = get(before, k);
  }
  return { mode: get(sel || {}, 'mode', 'live'), key: get(sel || {}, 'key'), race: raceSummary(race),
    health, collection, snapshotCount, frame, baseline: base, freshSeconds: FRESH_SECONDS,
    rows: race && Object.keys(race).length ? rows(race, snapshot, before) : [] };
}
