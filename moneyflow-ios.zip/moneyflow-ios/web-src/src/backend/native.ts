// Bridge to the native host. In the iOS app: WKScriptMessageHandlerWithReply "native" (Swift, URLSession + files).
// In a desktop browser (box testing): the same JSON ops are served by devserver.mjs at POST /__native.
/* eslint-disable @typescript-eslint/no-explicit-any */
type Handler = { postMessage: (msg: unknown) => Promise<any> };
function handler(): Handler | null {
  const w = globalThis as any;
  return w?.webkit?.messageHandlers?.native ?? null;
}
export const isNativeApp = (): boolean => handler() !== null;
export async function callNative<T = any>(msg: Record<string, unknown>): Promise<T> {
  const h = handler();
  if (h) return (await h.postMessage(msg)) as T;
  const res = await fetch('/__native', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(msg) });
  const data = await res.json();
  if (!res.ok || (data && data.__error)) throw new Error((data && data.__error) || 'native bridge HTTP ' + res.status);
  return data as T;
}
export type HttpResult = { status: number; body: string; setCookies?: string[]; error?: string };
export class OSError extends Error {}
export async function httpRequest(url: string, method: string, headers: Record<string, string>, body: string | null, timeoutSec: number): Promise<HttpResult> {
  let r: HttpResult;
  try {
    r = await callNative<HttpResult>({ op: 'http', url, method, headers, body, timeout: timeoutSec });
  } catch (e) {
    throw new OSError((e as Error).message || 'native HTTP bridge failed');
  }
  if (!r || r.error) throw new OSError(r?.error || 'HTTP request failed');
  return r;
}
