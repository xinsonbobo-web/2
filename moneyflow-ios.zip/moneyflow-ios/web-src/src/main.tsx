import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './app/globals.css';
import './app/terminal.css';
import './app/ios.css';
import Terminal from './app/terminal';
import { flushStore, getService } from './backend/client';

void getService();
// Persist pending writes when the app is backgrounded (iOS may suspend the WebView right after).
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void flushStore(); });
window.addEventListener('pagehide', () => { void flushStore(); });

createRoot(document.getElementById('root')!).render(<StrictMode><Terminal /></StrictMode>);
