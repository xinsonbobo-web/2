import { StrictMode, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './app/globals.css';
import './app/money-flow.css';
import './app/mini/mini.css';
import './app/ios.css';
import MoneyFlowApp from './components/money-flow/money-flow-app';
import Mini from './components/mini/mini-app';
import { flushStore, getService } from './backend/client';

void getService();
// Persist pending writes when the app is backgrounded (iOS may suspend the WebView right after).
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void flushStore(); });
window.addEventListener('pagehide', () => { void flushStore(); });

// ---- In-app views (single-file bundle → hash routes): #/ = 主頁 (terminal), #/mini[?base=N] = Mini ----
type View = 'main' | 'mini';
const VIEW_KEY = 'mf-view';        // last chosen view: 'main' | '#/mini?base=N'
const MINI_KEY = 'mf-mini-hash';   // last Mini route (keeps ?base=N from the settings link)
const viewOf = (hash: string): View | null => (hash.startsWith('#/mini') ? 'mini' : hash === '#/' || hash === '#' ? 'main' : null);
function readSaved(): string | null { try { return localStorage.getItem(VIEW_KEY); } catch { return null; } }
function remember(hash: string) {
  const value = viewOf(hash) === 'mini' ? hash : 'main';
  try { localStorage.setItem(VIEW_KEY, value); if (value !== 'main') localStorage.setItem(MINI_KEY, value); } catch { /* also kept in the native store below */ }
  void getService().then((s) => { if (s.store.setting('uiView') !== value) s.store.setSetting('uiView', value); }).catch(() => undefined);
}
const hashFor = (saved: string | null) => (saved && saved.startsWith('#/mini') ? saved : '#/');
// Start where the user left off (hash wins if present, e.g. after a reload).
const hashGiven = viewOf(location.hash) !== null;
if (!hashGiven) history.replaceState(null, '', hashFor(readSaved()));

function App() {
  const [hash, setHash] = useState(location.hash);
  useEffect(() => {
    const onHash = () => { setHash(location.hash); remember(location.hash); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', onHash);
    // localStorage may be unavailable under the app's custom scheme → fall back to the native store's setting.
    if (!hashGiven && readSaved() === null) {
      void getService().then((s) => {
        const saved = s.store.setting('uiView');
        if (typeof saved === 'string' && viewOf(location.hash) === 'main' && saved.startsWith('#/mini')) location.hash = saved.slice(1);
      });
    }
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const view: View = viewOf(hash) ?? 'main';
  useEffect(() => {
    document.body.classList.toggle('view-mini', view === 'mini');
    document.body.classList.toggle('view-main', view === 'main');
    document.title = view === 'mini' ? '資金流 Mini · 獨贏・孖寶' : '資金流 · HKJC Money Flow v0.7';
  }, [view]);
  const go = (next: View) => {
    if (next === view) return;
    let saved: string | null = null;
    try { saved = localStorage.getItem(MINI_KEY); } catch { saved = null; }
    location.hash = next === 'mini' ? (saved && saved.startsWith('#/mini') ? saved.slice(1) : '/mini') : '/';
  };
  return <>
    {view === 'mini' ? <Mini /> : <MoneyFlowApp />}
    <nav className="mf-view-switch" aria-label="切換版面" data-testid="view-switch">
      <button type="button" className={view === 'main' ? 'on' : ''} aria-pressed={view === 'main'} onClick={() => go('main')}>主頁</button>
      <button type="button" className={view === 'mini' ? 'on' : ''} aria-pressed={view === 'mini'} onClick={() => go('mini')}>Mini</button>
    </nav>
  </>;
}

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
