'use client';

import { useRef } from 'react';
import { TooltipProvider } from '@/components/ui/tooltip';
import { FlowChart } from './flow-chart';
import { HeaderRail } from './header-rail';
import { RunnerTable } from './runner-table';
import { SideDrawer } from './side-drawer';
import { SpectrumPanel } from './spectrum-panel';
import { TransportBar } from './transport-bar';
import { countRender } from './memo-slot';
import { useMoneyFlow } from './use-money-flow';

/** Race-day timing board: header rail, dense table, transport rail, chart + spectrum; docked drawer on the right. */
export default function MoneyFlowApp() {
  const mf = useMoneyFlow();
  countRender('app');   // v0.7.3 render probe: an unchanged 1 s poll must not re-render the board
  const chartRef = useRef<HTMLElement>(null);
  return (
    <TooltipProvider>
      <main className="mf" data-drawer={mf.drawer || 'none'}>
        <HeaderRail mf={mf} />
        {mf.error && <div className="mf-alert" role="alert">{mf.error}</div>}
        <div className="mf-body">
          <div className="mf-main live-surface" data-testid="live-surface" onContextMenu={e => { e.preventDefault(); if (!mf.busy) mf.connectLive(); }}>
            <RunnerTable mf={mf} />
            <TransportBar mf={mf} />
            <section className="workspace mf-workspace" style={{ zoom: mf.zoom / 100 }} data-zoom={mf.zoom}>
              <FlowChart mf={mf} chartRef={chartRef} />
              <SpectrumPanel mf={mf} onSeek={() => chartRef.current?.scrollIntoView({ block: 'nearest' })} />
            </section>
          </div>
          <SideDrawer mf={mf} />
        </div>
      </main>
    </TooltipProvider>
  );
}
