'use client';

import { spectrumTarget } from '@/lib/view-state';
import { fmt, tm } from './format';
import type { MoneyFlow } from './use-money-flow';

const POOL_LABEL: Record<string, string> = { WIN: 'W', QIN: 'Q', QPL: 'QP' };
const MINUTES = Array.from({ length: 17 }, (_, d) => d - 1);

/** WQQP%頻譜: minute × runner grid, three bands (W/Q/QP) per cell coloured by anomaly grade only. */
export function SpectrumPanel({ mf, onSeek }: { mf: MoneyFlow; onSeek: () => void }) {
  const { state, frame, race, order, highlights, focus } = mf;
  return (
    <aside className="mf-panel mf-spectrum spectrum-panel" aria-label="WQQP%頻譜">
      <div className="mf-panel-head">
        <h2 className="mf-h">WQQP%頻譜</h2><span className="mf-sub">T −1 至 15 分鐘</span>
        <span className="mf-head-fill" />
        <div className="mf-tabs spectrum-tabs" role="tablist" aria-label="頻譜分頁">
          <button role="tab" type="button" aria-selected={true} className="mf-tab is-on spectrum-tab active">WQQP%</button>
        </div>
      </div>
      <div className="mf-spectrum-grid" aria-label="頻譜格">
        <div className="mf-spec-corner">#</div>
        {MINUTES.map(m => <div key={m} className="mf-spec-minute minute">{m}</div>)}
        {order.flatMap(r => {
          const horse = race?.runners.find(h => String(h.no) === r);
          const hl = highlights[r];
          return [
            <button type="button" key={r + 'name'} className={['mf-spec-horse horse-row', focus === r ? 'is-focus' : '', hl ? `is-hl hl-${hl}` : ''].filter(Boolean).join(' ')}
              aria-label={`Horse ${r}${hl ? `, ${hl} highlight` : ''}${focus === r ? ', focused' : ''}`} title={`${r}號：click 循環高亮`}
              onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }} onMouseEnter={() => mf.setFocus(r)}><b className="mf-cloth is-sm">{r}</b></button>,
            ...MINUTES.map((m, d) => {
              const engineIndex = 16 - d;
              const cell = state.spectrum[r]?.[engineIndex];
              const selected = !!frame && !!cell && frame.timestamp >= cell.start && frame.timestamp < cell.start + 60;
              return (
                <div key={r + '-' + m} className={'mf-spec-cell spectrum-cell' + (selected ? ' is-selected' : '') + (hl ? ` is-hl hl-${hl}` : '')}>
                  {['WIN', 'QIN', 'QPL'].map(p => {
                    const layer = cell?.layers[p];
                    const grade = layer?.grade || 'unavailable';
                    return (
                      <button key={p} type="button" className={'band ' + grade} disabled={!layer?.frameId}
                        aria-label={`${r}號 T${m} ${POOL_LABEL[p]} ${grade}${hl ? ` · ${hl} highlight` : ''}`}
                        title={`${horse?.name || r} · T${m} · ${POOL_LABEL[p]} ${layer?.grade || 'UNAVAILABLE'}\nPressure ${fmt(layer?.pressure)} · ${tm(layer?.timestamp)}`}
                        onClick={() => { const t = spectrumTarget(state.spectrum, r, engineIndex, p); if (t) { mf.seek(t.id, t.runner); onSeek(); } }}>
                        <span className="sr-only">{POOL_LABEL[p]}</span>
                      </button>
                    );
                  })}
                </div>
              );
            }),
          ];
        })}
      </div>
      {!race && <div className="mf-empty is-compact">先選擇賽事，再開始接收分鐘切片。</div>}
      <div className="mf-legend mf-spec-legend density-legend" data-testid="spectrum-grade-legend" aria-label="頻譜異常級別圖例（非百分比濃度）" title="異常級別，唔代表投注概率">
        <span className="mf-band-key"><i className="k-w" />W<i className="k-q" />Q<i className="k-qp" />QP</span>
        <span><i className="sw-unavailable" />缺資料</span>
        <span><i className="sw-normal" />正常</span>
        <span><i className="sw-green" />輕微異常</span>
        <span><i className="sw-red" />異常</span>
        <span><i className="sw-brown" />非常異常</span>
      </div>
    </aside>
  );
}
