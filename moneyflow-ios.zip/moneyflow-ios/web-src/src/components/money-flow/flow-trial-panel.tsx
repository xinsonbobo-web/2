'use client';

import { useEffect, useState } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { FlowTrial } from '@/lib/types';
import { apiIfChanged } from './api';
import { AxisLines } from './axis-lines';
import { fmt, tm } from './format';
import { poolMarkerShown, PG_INSIDE_MIN_PX, PG_WIDE_BAR_PX } from './model';
import { useBarBox } from './post-gate';
import { RunnerSlot, sigOf } from './memo-slot';
import type { MoneyFlow, PollBus } from './use-money-flow';

const TOP = 200;

/** 007式流向（試驗） data: fetched only while `enabled` (toggle ON). OFF → no request, state cleared.
 *  Values come from /api/flow-trial as-is; missing → "--", never copied forward. */
/*  v0.7.3: refetched when the viewed frame / tip changes (effect deps) and, in between, on every 1 s state poll
 *  (PollBus) as a conditional GET: 304 → keep the current object, no setState, no re-render. */
export function useFlowTrial(enabled: boolean, frameId: string | null, stateKey: string | undefined, framesLen: number, tipId: string | undefined, bus?: PollBus) {
  const [trial, setTrial] = useState<FlowTrial | null>(null);
  useEffect(() => {
    if (!enabled) { setTrial(null); return; }
    let alive = true, pending = false, etag: string | null = null;
    const path = 'flow-trial' + (frameId ? `?frame=${encodeURIComponent(frameId)}` : '');
    const load = async () => {
      if (pending) return; pending = true;
      const t0 = performance.now();
      try {
        const res = await apiIfChanged<FlowTrial>(path, etag);
        if (!alive || !res || (res.etag && res.etag === etag)) return;
        etag = res.etag; setTrial(res.data);
        (window as unknown as { __flowTrialFetchMs?: number }).__flowTrialFetchMs = performance.now() - t0;
      } catch { if (alive) { etag = null; setTrial(null); } }
      finally { pending = false; }
    };
    void load();
    const off = bus?.on(() => void load());
    return () => { alive = false; off?.(); };
  }, [enabled, frameId, stateKey, framesLen, tipId, bus]);
  return trial;
}

export function trialPhaseText(trial: FlowTrial | null) {
  return !trial ? '載入中' : trial.phase === 'PRE_CUT' ? `截點前（T−${trial.cutMin}），流向＝累積` : trial.phase === 'POST_CUT' ? `截點 ${tm(trial.cutTs)} 後，流向＝截點後新資金` : trial.phase === 'NO_CUT' ? '截點前冇有效快照，顯示 --' : '未有快照';
}

const paramsText = (trial: FlowTrial | null) =>
  `${trial?.version || 'V1'} A_new · lnK ${trial?.params?.lnK ?? 6.238} · α ${trial?.params?.alpha ?? 0.805} · κ ${trial?.params?.kappa ?? 0.55} · w ${trial?.params?.w ?? 0.65}`;

/** Status line content while 007式 is ON: replaces the WIN readiness text in the same single-line row (no extra row). */
export function FlowTrialMeta({ trial, stale, historic }: { trial: FlowTrial | null; stale: boolean; historic: string | null }) {
  const cut = `截點 T−${trial?.cutMin ?? 16.5}${trial?.cutKind === 'overseas' ? '（海外，ESTIMATED）' : '（本地）'}`;
  return (
    <>
      <span className="mf-trial-badge" data-testid="flow-trial-badge">試驗 · ESTIMATED · 未鎖定</span>
      {stale && <strong className="mf-trial-stale" data-testid="flow-trial-stale">STALE</strong>}
      {historic && <strong className="mf-historic" data-testid="historical-label">{historic}</strong>}
      <span className="mf-trial-cut">{cut}</span>
      <span className="mf-trial-phase">{trialPhaseText(trial)}</span>
      <span className="mf-trial-param" title={paramsText(trial)}>{paramsText(trial)}</span>
    </>
  );
}

const halfUp = (x: number) => Math.sign(x) * Math.floor(Math.abs(x) + 0.5);

/** v0.7.6 007 bar split. Height stays the flow value. Light share = pre/flow (capped at the bar). Darker share =
 *  max(flow−pre, 0)/flow. Third colour recolours the top by max(flow−flowAtGate, 0), never past the bar, never
 *  negative, and nothing when the flow did not rise versus the gate. A missing flow is the old missing bar. A missing
 *  pre (截點前) keeps the flow bar as one light fill and invents no second number. */
export function trialTone(flow: number | null | undefined, pre: number | null | undefined, rebound: number | null | undefined) {
  if (flow == null) return null;
  if (pre == null || !(flow > 0)) return { solid: true as const, preShare: 1, afterShare: 0, sliceShare: 0, afterShown: 0, rebShown: 0 };
  const preShare = Math.min(1, Math.max(0, pre / flow));
  const afterShown = Math.max(0, halfUp(flow) - halfUp(pre));
  const reb = rebound != null && rebound > 0 ? rebound : 0;
  const rebShown = reb > 0 ? Math.max(0, halfUp(flow) - halfUp(flow - reb)) : 0;
  const barUnits = Math.min(flow, 200);
  const sliceShare = rebShown > 0 && barUnits > 0 ? Math.min(1, rebShown / barUnits) : 0;
  return { solid: false as const, preShare, afterShare: 1 - preShare, sliceShare, afterShown, rebShown };
}

/** 007式流向（試驗）bars: drawn in the chart slot in place of the B+D bars (same grid, same size; default view since v0.7.2).
 *  Bar height = max(5, min(flow, 200) / 200 × 100)% of the zone; missing flow → 0px. v0.7.6 draws the split above
 *  inside that height. The B+D bars (toggle off) keep the magenta 入閘後 segment; these bars do not. */
export function FlowTrialChart({ mf, trial, stale }: { mf: MoneyFlow; trial: FlowTrial | null; stale: boolean }) {
  const { state, frame, race, order, highlights, focus, selectedId, flowStale, dblPctView } = mf;
  const liveStale = flowStale && !selectedId;
  const stateText = stale ? 'STALE' : state.mode === 'replay' || selectedId ? 'REPLAY' : 'LIVE';
  const phase = trialPhaseText(trial);
  const [barsRef, barBox] = useBarBox();
  return (
    <div className="chart mf-chart mf-chart-view is-trial" style={{ minWidth: order.length * 36 + 48 }} data-testid="flow-trial-panel"
      data-frame-id={trial?.frameId ?? 'tip'} data-phase={trial?.phase ?? 'LOADING'} data-stale={stale ? '1' : '0'} role="region"
      aria-label={`${race ? `R${race.no} ` : ''}007式流向（試驗）棒形圖`}>
      <div className="mf-scale" aria-hidden="true">
        <span className="mf-scale-head" />
        <span className="mf-scale-zone"><i style={{ bottom: '100%' }}>{TOP}</i><i style={{ bottom: '50%' }}>100</i><i style={{ bottom: '0%' }}>0</i></span>
        <span className="mf-scale-foot"><i>獨贏</i><i>孖上</i><i>孖下</i></span>
      </div>
      <div className="bars mf-bars" ref={barsRef}>
        {order.map(r => {
          const h = race?.runners.find(x => String(x.no) === r);
          const x = trial?.runners?.[r];
          const v = x?.flow?.value;
          const preV = x?.pre?.value;
          const pct = v == null ? 0 : Math.max(5, Math.min(v, TOP) / TOP * 100);
          const tone = trialTone(v, preV, x?.rebound?.value);
          const barPx = pct / 100 * barBox.zoneH;
          const font: 9 | 10 = barBox.barW >= PG_WIDE_BAR_PX ? 10 : 9;
          const fits = (t: string) => t.length * 0.6 * font + 4 <= barBox.barW;
          const afterPx = tone && !tone.solid ? barPx * Math.max(0, tone.afterShare - tone.sliceShare) : 0;
          const slicePx = tone && !tone.solid ? barPx * tone.sliceShare : 0;
          const showAfter = !!tone && !tone.solid && tone.afterShown > 0 && afterPx >= PG_INSIDE_MIN_PX && fits(String(tone.afterShown));
          const showReb = !!tone && !tone.solid && tone.rebShown > 0 && slicePx >= PG_INSIDE_MIN_PX && fits(String(tone.rebShown));
          const hl = highlights[r];
          const marker = poolMarkerShown(frame, r, liveStale);
          const winOdds = frame?.runners[r]?.winOdds, dblDown = dblPctView?.down?.[r], dblUp = dblPctView?.up?.[r];
          const sig = sigOf(h?.name, x, pct, tone, showAfter, showReb, font, hl, focus === r, stale, stateText, phase, marker, winOdds, dblDown, dblUp, flowStale);
          return (
            <RunnerSlot key={r} sig={sig} probe="trial-bar" render={() => (
            <div className={['runner', 'mf-trial-runner', focus === r ? 'is-focus' : '', hl ? `is-hl hl-${hl}` : '', stale ? 'runner-stale' : ''].filter(Boolean).join(' ')}
              data-testid={'flow-trial-' + r} data-runner-trial={r} onMouseEnter={() => mf.setFocus(r)}>
              <div className="mf-bar-head">
                <span className="bar-number ft-val">{fmt(x?.flow, 0)}{v != null && v > TOP ? ' ↑' : ''}</span>
                <small className="ft-sub">前 {fmt(x?.pre, 0)}</small>
                <small className="ft-sub">3′ {fmt(x?.three, 0)}</small>
              </div>
              <div className="bar-zone">
                <Tooltip>
                  <TooltipTrigger render={
                    <button type="button" className={'ft-bar' + (v == null ? ' missing' : '') + (stale ? ' stale' : '') + (font === 9 ? ' is-narrow' : '')}
                      aria-label={`Horse ${r}, 007式流向 ${fmt(x?.flow, 0)}, 熱錢前 ${fmt(x?.pre, 0)}, 熱錢3′ ${fmt(x?.three, 0)}${tone && !tone.solid ? `, 截點後 ${tone.afterShown}, 閘後 ${tone.rebShown}` : ''}, ${stateText}, ESTIMATED trial${hl ? `, ${hl} highlight` : ''}`}
                      data-testid={'flow-trial-bar-' + r} data-stale={stale ? '1' : '0'} data-tone={tone == null ? 'missing' : tone.solid ? 'solid' : 'split'}
                      style={{ height: v == null ? '0px' : `${pct.toFixed(1)}%` }}
                      onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }} onFocus={() => mf.setFocus(r)}>
                      {tone && !tone.solid && tone.afterShare > 0 && (
                        <span className="ft-after" data-testid={'ft-after-' + r} style={{ height: `${(tone.afterShare * 100).toFixed(2)}%` }}>
                          <span className="ft-after-body" style={{ height: `${(Math.max(0, tone.afterShare - tone.sliceShare) / tone.afterShare * 100).toFixed(2)}%` }}>
                            {showAfter && <b className="ft-cap-num" data-testid={'ft-after-num-' + r}>{tone.afterShown}</b>}
                          </span>
                        </span>
                      )}
                      {tone && !tone.solid && tone.sliceShare > 0 && (
                        <span className="ft-rebound" data-testid={'ft-rebound-' + r} style={{ height: `${(tone.sliceShare * 100).toFixed(2)}%` }}>
                          {showReb && <b className="ft-cap-num" data-testid={'ft-rebound-num-' + r}>{tone.rebShown}</b>}
                        </span>
                      )}
                    </button>
                  } />
                  <TooltipContent className="mf-tip">
                    <strong>#{r} {h?.name}：007式流向（試驗），ESTIMATED，{stateText}</strong>
                    <p>流向 {fmt(x?.flow, 0)} · 熱錢前 {fmt(x?.pre, 0)} · 熱錢3′ {fmt(x?.three, 0)}</p>
                    {tone && !tone.solid && <p>截點後 {tone.afterShown}（流向減熱錢前，少過 0 就當 0，深色）· 閘後 {tone.rebShown}（而家減入閘嗰下，少過 0 就當 0，第三色貼棒頂，唔加高度）</p>}
                    <p>{phase}</p>
                    {v == null && <p>{x?.flow?.reason || '--'}</p>}
                    <p>刻度 0-200，棒高封頂 200；試驗未鎖定，唔係勝出機率或投注建議</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="mf-bar-foot">
                <span className="ft-foot-id">
                  <b className="mf-cloth is-sm">{r}</b>
                  {marker && <span className="pool-marker" title={`${marker} 異常／偏離`}>{marker}</span>}
                </span>
                <AxisLines win={winOdds} dblDown={dblDown} dblUp={dblUp} flowStale={flowStale} />
              </div>
            </div>
            )} />
          );
        })}
        {!order.length && <div className="mf-empty">連接真實賽事，或者揀「MOCK · 模擬測試」核對完整操作。</div>}
      </div>
    </div>
  );
}
