'use client';

import { useEffect, useState } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { FlowTrial } from '@/lib/types';
import { apiIfChanged } from './api';
import { AxisLines } from './axis-lines';
import { fmt, tm } from './format';
import { poolMarkerShown, postGateGeometry, postGatePlacement } from './model';
import { PostGateBarParts, postGateTip, useBarBox } from './post-gate';
import { RunnerSlot, sigOf } from './memo-slot';
import type { MoneyFlow, PollBus } from './use-money-flow';

const TOP = 200;

/** 007式流向（試驗） data: fetched only while `enabled` (toggle ON). OFF → no request, state cleared.
 *  Values come from /api/flow-trial as-is; missing → "--", never copied forward. */
/*  v0.7.3: refetched when the viewed frame / tip changes (effect deps) and, in between, on every 1 s state poll
 *  (PollBus) as a conditional GET: 304 → keep the current object, no setState, no re-render. */
export function useFlowTrial(enabled: boolean, frameId: string | null, stateKey: string | undefined, framesLen: number, tipId: string | undefined, bus?: PollBus) {
  const [trial, setTrial] = useState<FlowTrial | null>(null);
  useEffect(() => {
    if (!enabled) { setTrial(null); return; }
    let alive = true, pending = false, etag: string | null = null;
    const path = 'flow-trial' + (frameId ? `?frame=${encodeURIComponent(frameId)}` : '');
    const load = async () => {
      if (pending) return; pending = true;
      const t0 = performance.now();
      try {
        const res = await apiIfChanged<FlowTrial>(path, etag);
        if (!alive || !res || (res.etag && res.etag === etag)) return;
        etag = res.etag; setTrial(res.data);
        (window as unknown as { __flowTrialFetchMs?: number }).__flowTrialFetchMs = performance.now() - t0;
      } catch { if (alive) { etag = null; setTrial(null); } }
      finally { pending = false; }
    };
    void load();
    const off = bus?.on(() => void load());
    return () => { alive = false; off?.(); };
  }, [enabled, frameId, stateKey, framesLen, tipId, bus]);
  return trial;
}

export function trialPhaseText(trial: FlowTrial | null) {
  return !trial ? '載入中' : trial.phase === 'PRE_CUT' ? `截點前（T−${trial.cutMin}），流向＝累積` : trial.phase === 'POST_CUT' ? `截點 ${tm(trial.cutTs)} 後，流向＝截點後新資金` : trial.phase === 'NO_CUT' ? '截點前冇有效快照，顯示 --' : '未有快照';
}

const paramsText = (trial: FlowTrial | null) =>
  `${trial?.version || 'V1'} A_new · lnK ${trial?.params?.lnK ?? 6.238} · α ${trial?.params?.alpha ?? 0.805} · κ ${trial?.params?.kappa ?? 0.55} · w ${trial?.params?.w ?? 0.65}`;

/** Status line content while 007式 is ON: replaces the WIN readiness text in the same single-line row (no extra row). */
export function FlowTrialMeta({ trial, stale, historic }: { trial: FlowTrial | null; stale: boolean; historic: string | null }) {
  const cut = `截點 T−${trial?.cutMin ?? 16.5}${trial?.cutKind === 'overseas' ? '（海外，ESTIMATED）' : '（本地）'}`;
  return (
    <>
      <span className="mf-trial-badge" data-testid="flow-trial-badge">試驗 · ESTIMATED · 未鎖定</span>
      {stale && <strong className="mf-trial-stale" data-testid="flow-trial-stale">STALE</strong>}
      {historic && <strong className="mf-historic" data-testid="historical-label">{historic}</strong>}
      <span className="mf-trial-cut">{cut}</span>
      <span className="mf-trial-phase">{trialPhaseText(trial)}</span>
      <span className="mf-trial-param" title={paramsText(trial)}>{paramsText(trial)}</span>
    </>
  );
}

/** 007式流向（試驗）bars: drawn in the chart slot in place of the B+D bars (same grid, same size; default view since v0.7.2).
 *  Bar height = max(5, min(flow, 200) / 200 × 100)% of the zone (unchanged from the v0.7 panel); missing → 0px.
 *  v0.7.2 入閘後: after the split the top (flow − gate value) of the bar is drawn in the 入閘後 colour with a
 *  "gate+Δ" label; the bar's own height (the flow value) is unchanged. Segment values come from /api/flow-trial. */
export function FlowTrialChart({ mf, trial, stale }: { mf: MoneyFlow; trial: FlowTrial | null; stale: boolean }) {
  const { state, frame, race, order, highlights, focus, selectedId, flowStale, dblPctView } = mf;
  const liveStale = flowStale && !selectedId;
  const stateText = stale ? 'STALE' : state.mode === 'replay' || selectedId ? 'REPLAY' : 'LIVE';
  const phase = trialPhaseText(trial);
  const [barsRef, barBox] = useBarBox();
  return (
    <div className="chart mf-chart mf-chart-view is-trial" style={{ minWidth: order.length * 36 + 48 }} data-testid="flow-trial-panel"
      data-frame-id={trial?.frameId ?? 'tip'} data-phase={trial?.phase ?? 'LOADING'} data-stale={stale ? '1' : '0'} role="region"
      aria-label={`${race ? `R${race.no} ` : ''}007式流向（試驗）棒形圖`}>
      <div className="mf-scale" aria-hidden="true">
        <span className="mf-scale-head" />
        <span className="mf-scale-zone"><i style={{ bottom: '100%' }}>{TOP}</i><i style={{ bottom: '50%' }}>100</i><i style={{ bottom: '0%' }}>0</i></span>
        <span className="mf-scale-foot"><i>獨贏</i><i>孖上</i><i>孖下</i></span>
      </div>
      <div className="bars mf-bars" ref={barsRef}>
        {order.map(r => {
          const h = race?.runners.find(x => String(x.no) === r);
          const x = trial?.runners?.[r];
          const v = x?.flow?.value;
          const pct = v == null ? 0 : Math.max(5, Math.min(v, TOP) / TOP * 100);
          const seg = v == null ? null : x?.postGate ?? null;
          const gatePct = seg ? Math.max(5, Math.min(seg.base, TOP) / TOP * 100) : 0;
          const geo = postGateGeometry(seg, gatePct, pct);
          const place = seg ? postGatePlacement(seg, geo, pct, barBox) : null;
          const pgTip = postGateTip(trial?.postGate, seg, frame?.timestamp, x?.gate?.reason);
          const hl = highlights[r];
          const marker = poolMarkerShown(frame, r, liveStale);
          const winOdds = frame?.runners[r]?.winOdds, dblDown = dblPctView?.down?.[r], dblUp = dblPctView?.up?.[r];
          const sig = sigOf(h?.name, x, pct, seg, geo, place, pgTip, hl, focus === r, stale, stateText, phase, marker, winOdds, dblDown, dblUp, flowStale);
          return (
            <RunnerSlot key={r} sig={sig} probe="trial-bar" render={() => (
            <div className={['runner', 'mf-trial-runner', focus === r ? 'is-focus' : '', hl ? `is-hl hl-${hl}` : '', stale ? 'runner-stale' : ''].filter(Boolean).join(' ')}
              data-testid={'flow-trial-' + r} data-runner-trial={r} onMouseEnter={() => mf.setFocus(r)}>
              <div className="mf-bar-head">
                <span className="bar-number ft-val">{fmt(x?.flow, 0)}{v != null && v > TOP ? ' ↑' : ''}</span>
                <small className="ft-sub">前 {fmt(x?.pre, 0)}</small>
                <small className="ft-sub">3′ {fmt(x?.three, 0)}</small>
              </div>
              <div className="bar-zone">
                <Tooltip>
                  <TooltipTrigger render={
                    <button type="button" className={'ft-bar' + (v == null ? ' missing' : '') + (stale ? ' stale' : '') + (seg ? ' has-pg' : '')}
                      aria-label={`Horse ${r}, 007式流向 ${fmt(x?.flow, 0)}, 熱錢前 ${fmt(x?.pre, 0)}, 熱錢3′ ${fmt(x?.three, 0)}${seg ? `, 入閘後 ${seg.label}` : ''}, ${stateText}, ESTIMATED trial${hl ? `, ${hl} highlight` : ''}`}
                      data-testid={'flow-trial-bar-' + r} data-stale={stale ? '1' : '0'} data-pg={seg ? seg.kind : 'none'} data-pg-label={seg?.label ?? undefined}
                      style={{ height: v == null ? '0px' : `${pct.toFixed(1)}%` }}
                      onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }} onFocus={() => mf.setFocus(r)}>
                      <PostGateBarParts seg={seg} geo={geo} place={place} runner={r} />
                    </button>
                  } />
                  <TooltipContent className="mf-tip">
                    <strong>#{r} {h?.name}：007式流向（試驗），ESTIMATED，{stateText}</strong>
                    <p>流向 {fmt(x?.flow, 0)} · 熱錢前 {fmt(x?.pre, 0)} · 熱錢3′ {fmt(x?.three, 0)}</p>
                    <p>{phase}</p>
                    {v == null && <p>{x?.flow?.reason || '--'}</p>}
                    {pgTip && <p>{pgTip}</p>}
                    <p>刻度 0-200，棒高封頂 200；試驗未鎖定，唔係勝出機率或投注建議</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="mf-bar-foot">
                <span className="ft-foot-id">
                  <b className="mf-cloth is-sm">{r}</b>
                  {marker && <span className="pool-marker" title={`${marker} 異常／偏離`}>{marker}</span>}
                </span>
                <AxisLines win={winOdds} dblDown={dblDown} dblUp={dblUp} flowStale={flowStale} />
              </div>
            </div>
            )} />
          );
        })}
        {!order.length && <div className="mf-empty">連接真實賽事，或者揀「MOCK · 模擬測試」核對完整操作。</div>}
      </div>
    </div>
  );
}
