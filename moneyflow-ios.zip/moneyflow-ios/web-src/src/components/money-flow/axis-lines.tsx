import type { Metric } from '@/lib/types';
import { NumberValue } from './format';

const DBL_TIP = 'ƒ Estimated exposure from inverse-odds; NOT stake %';

/** Axis rows under a bar column: 獨贏 · 孖上 · 孖下. Shared by the B+D bars and the 007式 bars so both views read the same values. */
export function AxisLines({ win, dblDown, dblUp, flowStale }: { win?: Metric; dblDown?: Metric; dblUp?: Metric; flowStale: boolean }) {
  return (
    <>
      <div className="odds-line axis-win" title="獨贏"><small>獨贏</small><NumberValue m={win} /></div>
      <div className={'dbl-line axis-dbl-down' + (flowStale ? ' is-stale-cell' : '')} data-testid="axis-dbl-down" title={`${DBL_TIP}。孖上＝本場做第二關（上一場×本場孖寶池）`}>
        <small>孖上{flowStale && dblDown?.value != null ? ' STALE' : ''}</small><NumberValue m={dblDown} suffix="%" digits={0} title={DBL_TIP} />
      </div>
      <div className={'dbl-line axis-dbl-up' + (flowStale ? ' is-stale-cell' : '')} data-testid="axis-dbl-up" title={`${DBL_TIP}。孖下＝第一關（本場×下一場孖寶池）`}>
        <small>孖下{flowStale && dblUp?.value != null ? ' STALE' : ''}</small><NumberValue m={dblUp} suffix="%" digits={0} title={DBL_TIP} />
      </div>
    </>
  );
}
