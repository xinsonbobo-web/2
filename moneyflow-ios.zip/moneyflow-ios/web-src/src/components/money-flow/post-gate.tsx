'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { PostGateInfo, PostGateSegment } from '@/lib/types';
import { fmt, tm } from './format';
import { postGateSplitText, type PostGateBox, type PostGatePlace } from './model';

type Geo = { seg: number; ghost: number; top: number };
const n0 = (v: number) => v.toLocaleString('en-HK', { maximumFractionDigits: 0 });

/** Measures the bar zone (height) and one bar (width) of a chart so the 入閘後 numbers can decide inside vs chip
 *  (postGatePlacement). Re-reads on resize and after each render; state only changes when a size changes. */
export function useBarBox(): [(el: HTMLElement | null) => void, PostGateBox] {
  const [box, setBox] = useState<PostGateBox>({ zoneH: 260, barW: 30 });
  const elRef = useRef<HTMLElement | null>(null);
  const roRef = useRef<ResizeObserver | null>(null);
  const read = useCallback(() => {
    const zone = elRef.current?.querySelector<HTMLElement>('.bar-zone');
    if (!zone || zone.clientHeight <= 0) return;
    const bar = zone.querySelector<HTMLElement>('.bar, .ft-bar');
    const zoneH = zone.clientHeight, barW = bar?.offsetWidth || Math.min(zone.clientWidth * 0.62, 30);
    setBox(p => (p.zoneH === zoneH && p.barW === barW ? p : { zoneH, barW }));
  }, []);
  const ref = useCallback((el: HTMLElement | null) => {
    roRef.current?.disconnect(); roRef.current = null; elRef.current = el;
    if (!el || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(read); ro.observe(el); roRef.current = ro; read();
  }, [read]);
  useEffect(() => { read(); });
  return [ref, box];
}

/** 入閘後 parts drawn inside a bar button. Heights and positions are % of the bar, so everything settles with the bar's
 *  240 ms height transition. UP: magenta top segment above a 1px seam, delta number inside it; DOWN: dashed outline
 *  above the bar up to the gate level, delta inside the outline. The gate (base) number sits on a plate in the bar's
 *  own top colour just below the seam. Anything that does not fit (postGatePlacement) becomes a chip hugging the bar. */
export function PostGateBarParts({ seg, geo, place, runner }: { seg: PostGateSegment | null; geo: Geo; place: PostGatePlace | null; runner: string }) {
  if (!seg || !place) return null;
  const deltaWhere = place.deltaIn ? 'in' : place.stack;
  const baseWhere = place.baseIn ? 'in' : place.stack;
  const delta = (
    <b className={'pg-num is-delta is-' + seg.kind.toLowerCase()} data-testid={'pg-delta-' + runner} data-place={deltaWhere} data-kind={seg.kind} aria-hidden="true">{place.deltaText}</b>
  );
  const base = (
    <b className={'pg-num is-base' + (place.baseIn ? ' is-in' : '')} data-testid={'pg-base-' + runner} data-place={baseWhere} aria-hidden="true"
      style={place.baseIn ? { top: `calc(${(seg.kind === 'UP' ? geo.seg : 0).toFixed(2)}% + ${2 + Math.round(place.baseOffsetPx)}px)` } : undefined}>{place.baseText}</b>
  );
  return (
    <span className={'pg-parts' + (place.font === 9 ? ' is-f9' : '')} aria-hidden="true">
      {seg.kind === 'UP' && geo.seg > 0 && <span className="pg-seg" data-testid={'pg-seg-' + runner} style={{ height: `${geo.seg.toFixed(2)}%` }}>{place.deltaIn && delta}</span>}
      {seg.kind === 'DOWN' && geo.ghost > 0 && <span className="pg-ghost" data-testid={'pg-ghost-' + runner} style={{ height: `${geo.ghost.toFixed(2)}%` }}>{place.deltaIn && delta}</span>}
      {place.baseIn && base}
      {place.stack !== 'none' && (
        <span className={'pg-out is-' + place.stack} data-testid={'pg-out-' + runner}
          style={place.stack === 'above' ? { bottom: `calc(${(100 + (seg.kind === 'DOWN' ? geo.ghost : 0)).toFixed(2)}% + 2px)` } : undefined}>
          {!place.baseIn && base}
          {!place.deltaIn && delta}
        </span>
      )}
    </span>
  );
}

/** Tooltip line. Pre-split / unavailable states say so; never shows an invented number. */
export function postGateTip(pg: PostGateInfo | null | undefined, seg: PostGateSegment | null, viewedTs: number | null | undefined, reason?: string) {
  if (!pg || pg.splitTs == null) return null;
  const at = `${postGateSplitText(pg)} ${tm(pg.splitTs)}`;
  if (viewedTs == null || !(viewedTs > pg.splitTs)) return `入閘後：未到入閘時間（${at}），唔拆分`;
  if (!seg) return `入閘後：冇基準（${reason || pg.reason || '入閘快照冇數值'}；入閘 ${at}）`;
  const what = seg.kind === 'UP' ? `入閘後新增 ${n0(seg.deltaShown)}（${fmt({ value: seg.delta, quality: 'DERIVED' }, 1)}）`
    : seg.kind === 'DOWN' ? `比入閘時少 ${n0(-seg.deltaShown)}（棒畫而家值，虛線框 = 入閘時高度）` : '同入閘時一樣';
  return `入閘後（${at}；基準快照 ${tm(pg.timestamp)}）：入閘 ${fmt({ value: seg.base, quality: 'DERIVED' }, 1)} → 而家 ${fmt({ value: seg.cur, quality: 'DERIVED' }, 1)} · ${seg.label} · ${what}`;
}
