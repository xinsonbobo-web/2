// Pure view-model helpers for the money-flow board. Every number here is read
// from API fields; the only arithmetic is the documented display rules
// (clamp 50–200 fallback, combined Pressure weights, keep-last merge).
import type { Flow, Metric, PoolKey, PostGateInfo, PostGateSegment, PressureState, ShareBar, State } from '@/lib/types';

export type Frame = State['frames'][number];
export type HighlightColor = 'red' | 'yellow' | 'blue' | 'green';
export type SortMode = 'number' | 'odds' | 'baseline';

export const BLANK_STATE: State = { mode: 'live', race: null, frames: [], marks: [], spectrum: {}, health: { status: 'ERROR', error: null } };
export const CHART_TOP = 200;
export const STALE_AFTER_SEC = 45;
/** v0.7.3: the board polls /api/state every 1 s (conditional GET; unchanged data → 304, no re-render). */
export const STATE_REFRESH_MS = 1000;
export const ZOOM_STEPS = [60, 70, 80, 90, 100, 110, 120];
export const ZOOM_DEFAULT = 100;
export const ZOOM_KEY = 'hkjc-chart-zoom';

const HIGHLIGHT_ORDER: HighlightColor[] = ['red', 'yellow', 'blue', 'green'];
export function cycleHighlight(prev: Record<string, HighlightColor>, runner: string): Record<string, HighlightColor> {
  const current = prev[runner];
  const next = HIGHLIGHT_ORDER[(current ? HIGHLIGHT_ORDER.indexOf(current) : -1) + 1];
  const out = { ...prev };
  if (next) out[runner] = next; else delete out[runner];
  return out;
}

export function pressureStateOf(f?: Flow, flowStale?: boolean): PressureState {
  if (flowStale) return 'STALE';
  const s = f?.state;
  if (s === 'VALID' || s === 'VALID_UNCHANGED' || s === 'ESTIMATED_EQUAL' || s === 'STALE' || s === 'UNAVAILABLE') return s;
  return f?.pressure?.value == null ? 'UNAVAILABLE' : 'VALID';
}

/** Combined Pressure weights (PLA excluded until validated). Missing pool omitted + renormalised. */
const COMBINED_WEIGHTS: Partial<Record<PoolKey, number>> = { WIN: 1.0, QIN: 0.75, QPL: 0.75, FCT: 0.75 };
const GRADE_RANK = ['normal', 'green', 'red', 'brown'];
export type Combined = { pressure?: Metric; badge: '≈' | 'ƒ' | '—'; grade: string; state: PressureState };

export function combinedPressureOf(frame: Frame | undefined, runner: string, flowStale?: boolean): Combined {
  const empty: Combined = { badge: '—', grade: 'unavailable', state: flowStale ? 'STALE' : 'UNAVAILABLE' };
  if (!frame) return empty;
  let weighted = 0, weightSum = 0, sawEstimated = false, sawUsable = false;
  let allUnchanged = true, allEstimatedEqual = true, anyValid = false;
  const grades: string[] = [];
  for (const pool of Object.keys(COMBINED_WEIGHTS) as PoolKey[]) {
    const w = COMBINED_WEIGHTS[pool]!;
    const f = frame.flows[runner]?.[pool];
    const s = pressureStateOf(f, false);
    if (!f || f.pressure?.value == null || s === 'UNAVAILABLE') continue;
    weighted += w * f.pressure.value; weightSum += w; sawUsable = true;
    if (f.pressure.quality === 'ESTIMATED' || s === 'ESTIMATED_EQUAL') sawEstimated = true;
    if (f.grade && f.grade !== 'unavailable') grades.push(f.grade);
    if (s !== 'VALID_UNCHANGED' && s !== 'STALE') allUnchanged = false;
    if (s !== 'ESTIMATED_EQUAL') allEstimatedEqual = false;
    anyValid = true;
  }
  if (!sawUsable || weightSum <= 0) return empty;
  const liveGrade = grades.reduce((best, g) => (GRADE_RANK.indexOf(g) > GRADE_RANK.indexOf(best) ? g : best), 'normal');
  return {
    pressure: { value: weighted / weightSum, quality: sawEstimated ? 'ESTIMATED' : 'DERIVED', source: 'combined' },
    badge: sawEstimated ? 'ƒ' : '≈',
    grade: flowStale ? 'unavailable' : liveGrade,
    state: flowStale ? 'STALE' : allUnchanged && anyValid ? 'VALID_UNCHANGED' : allEstimatedEqual && anyValid ? 'ESTIMATED_EQUAL' : anyValid ? 'VALID' : 'UNAVAILABLE',
  };
}

export function combinedBadgeOf(frame: Frame | undefined, runners: string[], flowStale?: boolean): '≈' | 'ƒ' | '—' {
  if (!frame || !runners.length) return '—';
  let saw = false, sawEstimated = false;
  for (const r of runners) {
    const c = combinedPressureOf(frame, r, flowStale);
    if (c.badge === '—') continue;
    saw = true; if (c.badge === 'ƒ') sawEstimated = true;
  }
  return !saw ? '—' : sawEstimated ? 'ƒ' : '≈';
}

export type Overlay = { text: string; ready: boolean; value: number | null; state: PressureState; grade: string };
export function pressureOverlayOf(frame: Frame | undefined, runner: string, flowStale?: boolean): Overlay {
  const c = combinedPressureOf(frame, runner, flowStale);
  const v = c.pressure?.value ?? null;
  if (c.state === 'STALE') return { text: 'STALE', ready: v != null, value: v, state: 'STALE', grade: c.grade };
  if (v == null || c.state === 'UNAVAILABLE') return { text: '—', ready: false, value: null, state: 'UNAVAILABLE', grade: c.grade };
  if (c.state === 'VALID_UNCHANGED') return { text: 'P≈100', ready: true, value: v, state: c.state, grade: c.grade };
  if (c.state === 'ESTIMATED_EQUAL') return { text: `P ${v.toFixed(0)} ƒ`, ready: true, value: v, state: c.state, grade: c.grade };
  return { text: `P ${v.toFixed(0)}`, ready: true, value: v, state: c.state, grade: c.grade };
}

/** Structure (B+D) bar height: engine display value, else raw clamped 50–200, else null. */
export function shareBarHeight(share?: ShareBar): number | null {
  const display = share?.barHeightDisplay?.value;
  if (display != null && Number.isFinite(display)) return display;
  const raw = share?.barHeight?.value;
  if (raw != null && Number.isFinite(raw)) return Math.max(50, Math.min(200, raw));
  return null;
}
export function shareBarBadge(share?: ShareBar): '≈' | 'ƒ' | '—' {
  if (!share || share.barHeight?.value == null) return '—';
  const q = share.currentShare?.quality || share.barHeight?.quality;
  if (q === 'ESTIMATED') return 'ƒ';
  if (q === 'DIRECT' || q === 'DERIVED') return '≈'; // combined aggregate never shows D
  return '—';
}
export function structureMetric(share?: ShareBar): Metric {
  const h = shareBarHeight(share);
  return h == null
    ? { value: null, quality: 'UNAVAILABLE', reason: share?.barHeight?.reason || '未有結構位移' }
    : { value: h, quality: (share?.barHeightDisplay?.quality || share?.barHeight?.quality || 'DERIVED') as Metric['quality'], reason: share?.barHeight?.reason, source: share?.barHeight?.source };
}
export function frameHasShareHeights(f?: Frame): boolean {
  return !!f && Object.values(f.shareBars || {}).some(b => b?.barHeight?.value != null);
}
/** Defence in depth: LIVE tip without heights borrows the last frame that had them (engine keep-last is primary). */
export function mergeKeepLastShareBars(tip: Frame, frames: Frame[]): Frame {
  if (frameHasShareHeights(tip)) return tip;
  const prior = [...frames].reverse().find(f => f.id !== tip.id && frameHasShareHeights(f));
  if (!prior?.shareBars) return tip;
  const merged: Record<string, ShareBar> = { ...(tip.shareBars || {}) };
  let any = false;
  for (const [r, prev] of Object.entries(prior.shareBars)) {
    if (prev?.barHeight?.value == null || merged[r]?.barHeight?.value != null) continue;
    const reason = prev.barHeight?.reason || '';
    const keepReason = reason.includes('保留上次有效棒高') ? reason : `保留上次有效棒高（本切片未計出）${reason ? ' · ' + reason : ''}`;
    merged[r] = { ...prev, keptFromPrior: true, barHeight: { ...prev.barHeight, reason: keepReason }, barHeightDisplay: prev.barHeightDisplay ? { ...prev.barHeightDisplay, reason: keepReason } : prev.barHeightDisplay };
    any = true;
  }
  return any ? { ...tip, shareBars: merged } : tip;
}

export function drawMetric(h?: { draw?: Metric | number | null }): Metric | undefined {
  const d = h?.draw as Metric | number | null | undefined;
  if (d == null) return undefined;
  return typeof d === 'object' ? d : { value: Number(d), quality: 'DIRECT', source: 'card' };
}

/** Q / QP marker: QIN/QPL anomaly grade or |Pressure−100| ≥ 20. */
export function poolMarker(frame: Frame | undefined, r: string): 'Q' | 'QP' | null {
  const qin = frame?.flows[r]?.QIN, qpl = frame?.flows[r]?.QPL;
  const hot = (g?: string) => !!g && g !== 'normal' && g !== 'unavailable';
  const off = (p?: number | null) => p != null && Math.abs(p - 100) >= 20;
  if (hot(qin?.grade) || off(qin?.pressure?.value)) return 'Q';
  if (hot(qpl?.grade) || off(qpl?.pressure?.value)) return 'QP';
  return null;
}

/** Q/QP marker exactly as the B+D bar shows it: only when that runner's structure bar is present and not stale. */
export function poolMarkerShown(frame: Frame | undefined, r: string, liveStale: boolean): 'Q' | 'QP' | null {
  const share = frame?.shareBars?.[r];
  const cleared = shareBarHeight(share) == null;
  const isStale = liveStale || pressureOverlayOf(frame, r, liveStale).state === 'STALE' || !!share?.keptFromPrior;
  return !cleared && !isStale ? poolMarker(frame, r) : null;
}

/** Frozen order: re-computed only when the sort mode or race identity changes, never on odds ticks. */
export function computeOrder(mode: SortMode, numberOrder: string[], state: State, frame?: Frame): string[] {
  const base = numberOrder.slice();
  if (mode === 'number') return base.sort((a, b) => Number(a) - Number(b));
  const oddsOf = (r: string) => (mode === 'baseline' ? state.baseline?.winOdds?.[r]?.value : frame?.runners[r]?.winOdds?.value);
  return base.sort((a, b) => {
    const oa = oddsOf(a), ob = oddsOf(b);
    if (oa == null && ob == null) return Number(a) - Number(b);
    if (oa == null) return 1;
    if (ob == null) return -1;
    return oa - ob || Number(a) - Number(b);
  });
}

export const SORT_INFO: Record<SortMode, string> = {
  number: '馬號 小至大',
  odds: '獨贏 小至大（凍結，唔跟即時賠率重排）',
  baseline: '獨贏前 小至大（凍結）',
};

/** 入閘後 (v0.7.2): same rule as backend/postgate.py `segment`. The label uses the displayed (rounded, half away
 *  from zero like toLocaleString) numbers so base + delta equals the bar-head number. Shrink → DOWN, no positive segment. */
const halfUp = (x: number) => Math.sign(x) * Math.floor(Math.abs(x) + 0.5);
export function postGateSegment(base?: number | null, cur?: number | null): PostGateSegment | null {
  if (base == null || cur == null || !Number.isFinite(base) || !Number.isFinite(cur)) return null;
  const b = halfUp(base), c = halfUp(cur), d = c - b;
  return { base, cur, delta: cur - base, baseShown: b, deltaShown: d, kind: d > 0 ? 'UP' : d < 0 ? 'DOWN' : 'FLAT', label: d >= 0 ? `${b}+${d}` : `${b}−${-d}` };
}
/** Main B+D bars: segment only when the viewed frame is after the split and that runner has a frozen gate value. */
export function mainPostGate(pg: PostGateInfo | undefined, frame: Frame | undefined, runner: string, cur: number | null): PostGateSegment | null {
  if (!pg || pg.status !== 'FROZEN' || pg.splitTs == null || !frame || !(frame.timestamp > pg.splitTs)) return null;
  return postGateSegment(pg.values?.[runner], cur);
}
/** Geometry inside a bar whose height is `curPct` of the zone: `seg` = top part in 入閘後 colour (% of the bar),
 *  `ghost` = dashed outline above the bar up to the gate level on shrink (% of the bar), `top` = label anchor (% of zone). */
export function postGateGeometry(seg: PostGateSegment | null, gatePct: number, curPct: number) {
  if (!seg || !(curPct > 0)) return { seg: 0, ghost: 0, top: curPct };
  const up = seg.kind === 'UP' ? Math.max(0, Math.min(1, (curPct - gatePct) / curPct)) * 100 : 0;
  const ghost = seg.kind === 'DOWN' ? Math.max(0, (gatePct - curPct) / curPct) * 100 : 0;
  return { seg: up, ghost, top: Math.max(curPct, seg.kind === 'DOWN' ? gatePct : curPct) };
}
/** v0.7.3 入閘後 numbers inside the bar. Thin-segment rule (px, from the measured bar zone):
 *  - a number goes INSIDE its region (base → the gate part below the seam; delta → the magenta segment, or the dashed
 *    outline when the bar shrank) only if that region is at least PG_INSIDE_MIN_PX tall and the text fits the bar width;
 *  - otherwise it moves OUT into a chip stack hugging the top of the drawn bar (panel fill), one PG_CHIP_PX row each;
 *  - if the zone has no room above the bar for that stack (bar near the 200 top), the stack sits just inside the bar top
 *    ('cap') and an inside base number moves down to clear it (or out, when it no longer fits);
 *  - FLAT (+0) has no region, so its delta is always a chip.
 *  Type steps down to 9px when the bar is narrower than PG_WIDE_BAR_PX. Mono advance is 0.6em; chips pad 2px a side. */
export const PG_INSIDE_MIN_PX = 14;
export const PG_CHIP_PX = 14;
export const PG_WIDE_BAR_PX = 24;
export type PostGateBox = { zoneH: number; barW: number };
export type PostGatePlace = { font: 9 | 10; baseIn: boolean; deltaIn: boolean; stack: 'none' | 'above' | 'cap'; baseOffsetPx: number; baseText: string; deltaText: string };
const pgNum = (v: number) => Math.abs(v).toLocaleString('en-HK', { maximumFractionDigits: 0 });
export function postGatePlacement(seg: PostGateSegment, geo: { seg: number; ghost: number }, barPct: number, box: PostGateBox, minBarPx = 0): PostGatePlace {
  const font: 9 | 10 = box.barW >= PG_WIDE_BAR_PX ? 10 : 9;
  const baseText = (seg.baseShown < 0 ? '−' : '') + pgNum(seg.baseShown);
  const deltaText = (seg.deltaShown < 0 ? '−' : '+') + pgNum(seg.deltaShown);
  const fits = (t: string) => t.length * 0.6 * font + 4 <= box.barW;
  const barPx = Math.max(minBarPx, barPct / 100 * box.zoneH);
  const segPx = seg.kind === 'UP' ? barPx * geo.seg / 100 : 0;
  const ghostPx = seg.kind === 'DOWN' ? barPx * geo.ghost / 100 : 0;
  const bodyPx = barPx - segPx;
  const deltaIn = seg.kind === 'UP' ? segPx >= PG_INSIDE_MIN_PX && fits(deltaText) : seg.kind === 'DOWN' ? ghostPx >= PG_INSIDE_MIN_PX && fits(deltaText) : false;
  let baseIn = bodyPx >= PG_INSIDE_MIN_PX && fits(baseText);
  const count = (n: number) => n * PG_CHIP_PX;
  let out = (deltaIn ? 0 : 1) + (baseIn ? 0 : 1);
  const room = box.zoneH - (barPx + ghostPx);
  let stack: PostGatePlace['stack'] = out === 0 ? 'none' : room >= count(out) + 2 ? 'above' : 'cap';
  let baseOffsetPx = 0;
  if (stack === 'cap' && baseIn) {
    baseOffsetPx = Math.max(0, count(out) + 2 - segPx);
    if (bodyPx - baseOffsetPx < PG_INSIDE_MIN_PX) { baseIn = false; out += 1; baseOffsetPx = 0; stack = room >= count(out) + 2 ? 'above' : 'cap'; }
  }
  return { font, baseIn, deltaIn, stack, baseOffsetPx, baseText, deltaText };
}
export const postGateSplitText = (pg?: PostGateInfo | null) => (pg?.offsetMin ? `表定開跑前 ${pg.offsetMin} 分鐘` : '表定開跑');
