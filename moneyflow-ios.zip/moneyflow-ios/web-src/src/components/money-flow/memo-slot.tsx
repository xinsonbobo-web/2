'use client';

import { memo, type ReactNode } from 'react';

type Probe = Record<string, number>;
/** v0.7.3 render probe: counts renders per component family on window.__mfRenders (read by the Playwright sync test). */
export function countRender(name: string) {
  if (typeof window === 'undefined') return;
  const w = window as unknown as { __mfRenders?: Probe };
  const p = (w.__mfRenders ||= {});
  p[name] = (p[name] || 0) + 1;
}

/** One horse's cell group / bar. Re-renders only when `sig` (a serialisation of everything `render` reads) changes,
 *  so a poll that changes one horse repaints that horse only; unchanged data never re-renders it. Keyed by horse by
 *  the caller, so it is never remounted (hover, focus and open tooltips survive updates). */
export const RunnerSlot = memo(function RunnerSlot({ probe, render }: { sig: string; probe: string; render: () => ReactNode }) {
  countRender(probe);
  return <>{render()}</>;
}, (a, b) => a.sig === b.sig && a.probe === b.probe);

/** Stable, compact signature of plain data (undefined → null). */
export const sigOf = (...parts: unknown[]) => JSON.stringify(parts, (_k, v) => (v === undefined ? null : v));
