'use client';

import { ArrowDownToLine, X } from 'lucide-react';
import type { Metric } from '@/lib/types';
import { NumberValue } from './format';
import type { DrawerTab, MoneyFlow } from './use-money-flow';
import { saveApiJson } from '@/backend/client';

const DBL_TIP = 'ƒ Estimated exposure from inverse-odds; NOT stake %';
const AUDIT_COLS = ['馬匹', '獨贏前', 'WIN', 'PLA', '孖寶冠軍', '孖寶亞軍', '孖寶全部', '孖下%', '孖上%', '孖寶動量', 'Share baseline', 'Actual', 'Expected', 'Excess', 'Lift', 'Pressure', 'A 份額點', 'B log2', 'H ln(1+B)', 'C tilt', 'Self', 'Cross', 'DBL Structure Ratio'];

/** Docked right drawer (never overlays the chart or transport): 公式與設定 and 數值核對 tabs. */
export function SideDrawer({ mf }: { mf: MoneyFlow }) {
  const tab = mf.drawer;
  if (!tab) return null;
  const tabBtn = (t: DrawerTab, label: string) => (
    <button type="button" role="tab" aria-selected={tab === t} className={'mf-tab' + (tab === t ? ' is-on' : '')} onClick={() => mf.setDrawer(t)}>{label}</button>
  );
  return (
    <aside className={'mf-drawer is-' + tab} aria-label={tab === 'settings' ? '公式與資料設定' : '數值核對'}>
      <div className="mf-drawer-head">
        <div className="mf-tabs" role="tablist" aria-label="側欄分頁">{tabBtn('settings', '公式與設定')}{tabBtn('audit', '數值核對')}</div>
        <button type="button" className="mf-icon" aria-label="關閉側欄" onClick={() => mf.setDrawer(null)}><X size={15} strokeWidth={1.75} /></button>
      </div>
      <div className="mf-drawer-body">{tab === 'settings' ? <Settings mf={mf} /> : <Audit mf={mf} />}</div>
    </aside>
  );
}

function Settings({ mf }: { mf: MoneyFlow }) {
  return (
    <section className="mf-settings settings" aria-label="公式與資料設定">
      <h3 className="mf-h">公式與資料設定</h3>
      <div className="mf-fields">
        <label className="mf-field"><span>Rolling window（秒）</span>
          <input aria-label="Rolling window 秒" type="number" min="10" max="300" value={mf.windowSeconds} onChange={e => mf.setWindowSeconds(Math.min(300, Math.max(10, Number(e.target.value))))} />
          <small>10 至 300，預設 15；影響 Pressure 窗口（唔影響棒高）。</small>
        </label>
        <label className="mf-field"><span>排序基準（開跑前分鐘）</span>
          <input aria-label="排序基準分鐘" type="number" min="1" max="30" value={mf.baselineMinutes} onChange={e => mf.setBaselineMinutes(Math.min(30, Math.max(1, Number(e.target.value))))} />
          <small>1 至 30，預設 15；決定「獨贏前」欄同 Mini 版嘅 T−N。唔會儲存，重新整理返 15。</small>
        </label>
        <label className="mf-field"><span>指定其他日期</span>
          <input type="date" aria-label="指定其他日期" onChange={e => mf.pickDate(e.target.value)} />
          <small>揀日期會暫停自動跟隨。</small>
        </label>
      </div>
      <div className="mf-links">
        <a className="mf-btn" href="#" role="button" onClick={e => { e.preventDefault(); void saveApiJson('raw', 'hkjc-raw-source.json').catch(err => alert((err as Error).message)); }}><ArrowDownToLine size={15} strokeWidth={1.75} />Raw source</a>
        <a className="mf-btn" href={`#/mini?base=${mf.baselineMinutes}`} data-testid="mini-link" title="Mini 版：只有獨贏、獨贏前、孖寶冠／亞／全（手機直向；獨贏前沿用此排序基準分鐘）">Mini 版（手機）</a>
      </div>
      <div className="mf-help">
        <h4>棒圖（即時熱錢分佈）</h4>
        <p>棒高係 B+D 結構位移：BarHeight = 100 × (而家綜合份額 + ε) ÷ (凍結基準綜合份額 + ε)，ε = 0.0025。綜合份額權重 WIN 1.0、QIN／QPL／FCT 0.75（PLA 唔計），缺池省略再重新歸一。顯示夾 50 至 200，標尺 0 至 200，100 有基準線；超過 200 標「↑」。100 係「同基準一樣」，唔等於「有熱錢」，亦唔係總投注。</p>
        <p>Pressure = 100 × Lift 只做棒頂嘅次要徽章（P 數值）同 grade 斜紋；Pressure 未就緒唔會清棒。本切片未計出棒高時保留上次有效高度（LIVE tip 唔使回帶），來源超過 45 秒標 STALE 並淡化；從未有有效份額先顯示 --。</p>
        <h4>估算同質素</h4>
        <p>WIN 只有總彩池同賠率時：Bᵢ = Pool × (1/oddsᵢ) ÷ Σ(1/odds)，全部資金計算標 ESTIMATED（ƒ）。Q／QP 只接受完整直接組合金額，每對各分一半，唔以 QP 賠率反推金額。質素符號：D 直接、ƒ 估算、≈ 衍生、— 缺；綜合數值永不顯示 D。</p>
        <h4>異常門檻（v0.5 固定規則，未經歷史校準）</h4>
        <p>ΔPool ≥ $10,000、Expected ≥ $1,000；綠（輕微異常）Excess ≥ $10,000 且 Lift ≥ 1.2；紅（異常）≥ $50,000／1.5；啡（非常異常）≥ $150,000／2。低流動性保留 Pressure 原值但唔觸發異常。</p>
        <h4>孖寶</h4>
        <p>孖下%＝本場做第一關（本場×下一場孖寶池），孖上%＝本場做第二關（上一場×本場孖寶池）：隱含賠率自 T−17（007 切點）起縮短嘅百分比，屬 ƒ 估算曝險，唔係投注額；變長或不變顯示 --，孖下縮短少過 3% 亦顯示 --。孖寶冠／亞＝DBL(上一關冠／亞軍, i) ÷ 上一關冠／亞軍 WIN，少過 10 取 0.1、10 或以上取整；孖寶全＝1 ÷ Σ(1/DBL)，少過 100 向上取 0.1；「≥」表示 DBL 999 封頂，真值更長。</p>
        <p>DBL Structure Ratio（內部別名 DBLPressure）＝下一孖寶第一關份額 ÷ 同一切片 WIN 份額（1.00× 為中性），只喺「數值核對」顯示。</p>
        <h4>唔喺主表嘅指標</h4>
        <p>熱錢前、熱錢3′、熱錢流向、連贏、位置Q、獨贏%、連贏%、位置Q% 公式未確認，唔放主表。007式流向（試驗）預設關閉，喺棒圖右上角開。</p>
        <p className="mf-foot-note">HKJC Money Flow Tool v0.7。本地記錄，香港時間，無自動下注。</p>
      </div>
    </section>
  );
}

function Audit({ mf }: { mf: MoneyFlow }) {
  const { state, frame, race, numberOrder, highlights, focus, dblPctView } = mf;
  return (
    <section className="mf-audit details-panel" aria-label="數值核對">
      <div className="mf-audit-head">
        <h3 className="mf-h">數值核對 <span className="mf-sub">ADVANCED AUDIT</span></h3>
        <p>進階公式欄（Share、Actual、Expected、Lift、Research），唔影響主表。按馬號排序。</p>
        <span className="mf-qkey quality-key"><span><b>D</b> Direct</span><span><b>ƒ</b> Estimated</span><span><b>≈</b> Derived</span><span><b>—</b> Unavailable</span></span>
      </div>
      <div className="mf-audit-scroll">
        <table className="mf-table is-audit">
          <thead><tr>{AUDIT_COLS.map(c => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>
            {numberOrder.map(r => {
              const h = race?.runners.find(x => String(x.no) === r);
              const f = frame?.flows[r]?.WIN;
              const research = frame?.research?.[r];
              const hl = highlights[r];
              return (
                <tr key={r} className={[focus === r ? 'is-focus' : '', hl ? `is-hl hl-${hl}` : ''].filter(Boolean).join(' ')} aria-label={`Horse ${r}${hl ? `, ${hl} highlight` : ''}`} onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }}>
                  <td className="c-name"><b className="mf-cloth is-sm">{r}</b> {h?.name}{h?.scratched ? '（退出）' : ''}</td>
                  <td className="c-num"><NumberValue m={state.baseline?.winOdds?.[r]} /></td>
                  <td className="c-num"><NumberValue m={frame?.runners[r]?.winOdds} /></td>
                  <td className="c-num"><NumberValue m={frame?.runners[r]?.placeOdds} /></td>
                  <td className="c-num"><NumberValue m={frame?.incomingDouble?.[r]?.winner} digits={1} /></td>
                  <td className="c-num"><NumberValue m={frame?.incomingDouble?.[r]?.runnerUp} digits={1} /></td>
                  <td className="c-num"><NumberValue m={frame?.incomingDouble?.[r]?.all} digits={1} /></td>
                  <td className="c-num" title={DBL_TIP}><NumberValue m={dblPctView?.up?.[r]} suffix="%" digits={1} title={DBL_TIP} /></td>
                  <td className="c-num" title={DBL_TIP}><NumberValue m={dblPctView?.down?.[r]} suffix="%" digits={1} title={DBL_TIP} /></td>
                  <td className="c-num" data-testid="dbl-momentum" title={f?.dbl_matrix_coverage != null ? `DBL coverage ${(f.dbl_matrix_coverage * 100).toFixed(0)}%，Derived exposure change (not HKD)` : 'Derived exposure change (not HKD)'}>
                    <NumberValue m={f?.dbl_signed_momentum == null ? { value: null, quality: 'UNAVAILABLE', reason: '未有孖寶 exposure' } : { value: f.dbl_signed_momentum, quality: 'DERIVED', reason: 'signed momentum', source: 'DBL UP−DOWN Δ' }} digits={0} />
                  </td>
                  <td className="c-num"><NumberValue m={f?.share ? { ...f.share, value: f.share.value == null ? null : f.share.value * 100 } : undefined} suffix="%" digits={2} /></td>
                  {(['actual', 'expected', 'excess', 'lift', 'pressure'] as const).map(k => <td key={k} className="c-num"><NumberValue m={f?.[k] as Metric} digits={k === 'lift' ? 3 : 0} /></td>)}
                  <td className="c-num"><NumberValue m={research?.A} digits={2} /></td>
                  <td className="c-num"><NumberValue m={research?.B} digits={3} /></td>
                  <td className="c-num"><NumberValue m={research?.H} digits={3} /></td>
                  <td className="c-num"><NumberValue m={research?.C} digits={3} /></td>
                  <td className="c-num"><NumberValue m={research?.Self} digits={3} /></td>
                  <td className="c-num"><NumberValue m={research?.Cross} digits={1} /></td>
                  <td className="c-num"><NumberValue m={frame?.double[r]?.pressure} suffix="×" digits={2} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
