'use client';

import { Check } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { Metric } from '@/lib/types';
import { NumberValue, fmt, tm } from './format';
import { CHART_TOP, combinedBadgeOf, poolMarker, pressureOverlayOf, shareBarBadge, shareBarHeight } from './model';
import { AxisLines } from './axis-lines';
import { FlowTrialChart, FlowTrialMeta, useFlowTrial } from './flow-trial-panel';
import type { MoneyFlow } from './use-money-flow';

const HATCH: Record<string, string> = { brown: 'hatch-strong', red: 'hatch-mid', green: 'hatch-soft' };

/** 即時熱錢分佈: B+D structure bars (combined share ÷ frozen baseline), Pressure as a secondary badge.
 *  007式流向（試驗）ON swaps the bars in place: same slot, same grid, no extra row; OFF restores the B+D bars. */
export function FlowChart({ mf, chartRef }: { mf: MoneyFlow; chartRef: React.RefObject<HTMLElement | null> }) {
  const { state, frame, race, order, highlights, focus, flowStale, selectedId, staleAgeSec, flowStatus, dblPctView } = mf;
  const liveStale = flowStale && !selectedId;
  const showLatest = !!mf.latestReady && (mf.latestReady.id !== frame?.id || flowStale);
  const trialOn = mf.flowTrialOn;
  const trial = useFlowTrial(trialOn, selectedId ? frame?.id ?? null : null, state.key, state.frames.length, state.frames.at(-1)?.id);
  const trialStale = !!trial?.stale || liveStale;
  return (
    <section className="mf-panel mf-chart-panel" ref={chartRef} aria-label="熱錢棒形圖" data-mode={trialOn ? '007' : 'main'}>
      <div className="mf-panel-head mf-chart-head">
        <h2 className="mf-h" data-testid="hotmoney-title">{race ? `R${race.no} 即時熱錢分佈` : '即時熱錢分佈'}</h2>
        {/* Subtitle and 007 state tag share one grid cell, so the head keeps the same width (and wrap) in both modes. */}
        <span className="mf-sub-slot" data-on={trialOn ? '1' : '0'}>
          <span className="mf-sub" aria-hidden={trialOn || undefined}>100 = 基準結構（凍結綜合份額）</span>
          {trialOn && <span className="mf-mode-tag" data-testid="flow-trial-label" title="而家顯示 007式流向（試驗）棒（刻度 0-200），唔係 B+D 主棒；關咗開關就返主棒">007式（試驗）</span>}
        </span>
        <span className="mf-head-fill" />
        <span className="mf-stat" data-testid="combined-badge" title="綜合質素：≈ 衍生／ƒ 估算／— 缺；綜合數值永不顯示 D">資料質素 <strong>{combinedBadgeOf(frame, mf.numberOrder, liveStale)}</strong></span>
        <span className="mf-stat" data-testid="race-total-investment" title="真正總投注金額 = 本場所有 race-scoped poolInvs.investment 之和（含 TCE/TRI/FF/QTT/CWA 等；多關池於本場在 leg list 時計入）。缺則省略；全缺顯示 --。">
          真正總投注金額 <strong><NumberValue m={frame?.raceTotalInvestment ?? { value: null, quality: 'UNAVAILABLE', reason: '未有彩池投注總額' }} digits={0} /></strong>
        </span>
        <span className="mf-stat is-plain" title="Rolling window（秒），喺「公式與設定」改">{mf.windowSeconds}s</span>
        <button type="button" className={'mf-btn is-toggle flow-trial-toggle' + (mf.flowTrialOn ? ' is-on' : '')} data-testid="flow-trial-toggle" aria-pressed={mf.flowTrialOn}
          title="007式流向（試驗）：V1 A_new，ESTIMATED，未鎖定。開＝喺同一格用 007 棒取代主棒；關＝返 B+D 主棒（預設關；關閉時唔計算、唔請求）" onClick={() => mf.setFlowTrialOn(v => !v)}>
          <span className="mf-switch" aria-hidden="true" />007式流向（試驗）
        </button>
      </div>

      {trialOn ? (
        <div className={'mf-readiness is-trial' + (trialStale ? ' is-stale' : '')} role="status" data-testid="flow-trial-meta">
          <FlowTrialMeta trial={trial} stale={trialStale} historic={selectedId ? `歷史切片 · 非即時 · ${tm(frame?.timestamp)}` : null} />
        </div>
      ) : (
      <div className={'mf-readiness ' + (flowStale ? 'is-waiting' : flowStatus?.status === 'READY' ? 'is-ready' : 'is-waiting')} role="status" data-testid="flow-readiness">
        <strong>{flowStale ? 'WIN 計算資料已過期，等待新更新' : flowStatus?.message || (race ? '已連接賽事，等待首個有效 WIN 更新' : '等待連接賽事')}</strong>
        {selectedId && <strong className="mf-historic" data-testid="historical-label">歷史切片 · 非即時 · {tm(frame?.timestamp)}</strong>}
        <span className="mf-readiness-meta" title={[
          flowStatus?.quality === 'ESTIMATED' ? '逐馬金額由彩池與賠率估算；賠率變化比例相同可令多匹馬棒高相同。棒高按綜合份額相對凍結基準，唔等 Pressure READY。本切片未計出時保留上次有效棒高；STALE 同樣保留並標 STALE；從未有有效份額時先顯示 --。' : '',
          flowStatus?.alignment === 'OBSERVED_HISTORY' ? `已配對之前收到的真賠率（${tm(flowStatus.oddsTime)}）；棒下保留本切片最新 WIN 報價。` : '',
          flowStatus?.quoteTime != null ? `WIN 報價 ${tm(flowStatus.quoteTime)}，WIN 彩池 ${tm(flowStatus.investmentTime)}；有公布彩池總額不代表已有有效資金流。` : '',
          state.mode === 'live' ? 'Q / QP / DBL 熱錢等待可靠組合金額；目前顯示 --。' : '',
        ].filter(Boolean).join('\n')}>
          {frame ? `切片 ${tm(frame.timestamp)}` : ''}{flowStatus?.calculationTime ? `，WIN 計算 ${tm(flowStatus.calculationTime)}` : ''}{flowStatus?.quality === 'ESTIMATED' ? '，ESTIMATED 由真彩池與賠率推算' : ''}
        </span>
        {showLatest && <button type="button" className="mf-link ready-replay" onClick={() => { mf.seek(mf.latestReady!.id); chartRef.current?.scrollIntoView({ block: 'nearest' }); }}>回看上次有效棒圖 {tm(mf.latestReady!.timestamp)}</button>}
      </div>
      )}

      <div className="mf-chart-body" data-trial={trialOn ? 'on' : 'off'}>
        <div className="mf-chart-scroll" data-testid="chart-slot">
          {trialOn ? <FlowTrialChart mf={mf} trial={trial} stale={trialStale} /> : (
          <div className="chart mf-chart mf-chart-view" style={{ minWidth: order.length * 36 + 48 }}>
            <div className="mf-scale" aria-hidden="true">
              <span className="mf-scale-head" />
              <span className="mf-scale-zone"><i style={{ bottom: '100%' }}>{CHART_TOP}</i><i style={{ bottom: '50%' }}>100</i><i style={{ bottom: '0%' }}>0</i></span>
              <span className="mf-scale-foot"><i>獨贏</i><i>孖上</i><i>孖下</i></span>
            </div>
            <div className="bars mf-bars" data-testid="bars-measure">
              {order.map(r => {
                const h = race?.runners.find(x => String(x.no) === r);
                const share = frame?.shareBars?.[r];
                const height = shareBarHeight(share);
                const overlay = pressureOverlayOf(frame, r, liveStale);
                const research = frame?.research?.[r];
                const marked = state.marks.includes(r);
                const isStale = liveStale || overlay.state === 'STALE' || !!share?.keptFromPrior;
                const cleared = height == null;
                const overflow = height != null && height > CHART_TOP;
                const qBadge = shareBarBadge(share);
                const baselineStatus = share?.baselineStatus || state.shareBaseline?.status || 'WAITING';
                const stateText = isStale ? (staleAgeSec != null ? `STALE ${staleAgeSec}s` : 'STALE')
                  : cleared ? `-- ${baselineStatus === 'WAITING' ? 'NO BASELINE' : 'UNAVAILABLE'}`
                    : share?.provisional || baselineStatus === 'PROVISIONAL' ? 'PROVISIONAL BASELINE'
                      : state.mode === 'replay' || selectedId ? 'REPLAY' : 'LIVE';
                const qualityWord = qBadge === 'ƒ' ? 'Estimated combined share' : qBadge === '≈' ? 'Derived combined share' : 'Unavailable';
                const marker = !cleared && !isStale ? poolMarker(frame, r) : null;
                const gradeOn = !cleared && !isStale && overlay.ready;
                const hatch = gradeOn ? HATCH[overlay.grade] || '' : '';
                const partsTip = Object.entries(share?.poolParts || {}).map(([pool, meta]) => {
                  const part = meta as { weight?: number; quality?: string; share?: Metric };
                  const sv = part.share?.value;
                  return `${pool}${sv != null ? ` ${(sv * 100).toFixed(1)}%` : ''}×${part.weight ?? '?'}${part.quality === 'ESTIMATED' ? ' ƒ' : ''}`;
                }).join(' · ') || '--';
                const heightMetric: Metric = cleared ? { value: null, quality: 'UNAVAILABLE', reason: stateText }
                  : { value: height, quality: (share?.barHeightDisplay?.quality || share?.barHeight?.quality || 'DERIVED') as Metric['quality'], reason: share?.barHeight?.reason, source: share?.barHeight?.source };
                const uncapped = share?.barHeight?.value;
                const hl = highlights[r];
                const pct = cleared ? 0 : Math.min(height!, CHART_TOP) / CHART_TOP * 100;
                return (
                  <div key={r} className={['runner', focus === r ? 'is-focus' : '', hl ? `is-hl hl-${hl}` : '', isStale ? 'runner-stale' : ''].filter(Boolean).join(' ')}
                    data-runner={r} data-testid={'combined-bar-' + r} data-stale={isStale ? '1' : '0'} data-baseline={baselineStatus} onMouseEnter={() => mf.setFocus(r)}>
                    <div className="mf-bar-head">
                      <span className="bar-number"><NumberValue m={heightMetric} digits={0} glyph={false} />{overflow ? ' ↑' : ''}</span>
                      <span className="mf-bar-tags">
                        <span className="quality-badge" data-testid="quality-badge" title={qualityWord}>{qBadge}</span>
                        <span className="pressure-overlay" data-testid="pressure-overlay" title={overlay.ready ? `Pressure ${overlay.value?.toFixed(1)}（次要）` : 'Pressure 未就緒（棒高仍顯示）'}>{overlay.text}</span>
                        {marker && <span className="pool-marker" title={`${marker} 異常／偏離`}>{marker}</span>}
                      </span>
                      <span className={'pressure-state is-' + stateText.split(' ')[0].toLowerCase().replace('--', 'none')} data-testid="pressure-state" title={stateText}>{stateText}</span>
                    </div>
                    <div className="bar-zone" data-testid="win-pressure-bar" data-pool-bar={'combined-bar-' + r} data-active-pool="COMBINED">
                      <Tooltip>
                        <TooltipTrigger render={
                          <button type="button"
                            aria-label={`Horse ${r}, Structure bar ${height ?? '--'}, baseline ${baselineStatus}, Pressure ${overlay.text}, Quality ${qualityWord}${hl ? `, ${hl} highlight` : ''}`}
                            className={['bar', marked ? 'marked' : '', cleared ? 'missing' : '', isStale ? 'stale' : '', hatch].filter(Boolean).join(' ')}
                            data-grade={gradeOn ? overlay.grade || 'none' : 'none'} data-hatch={hatch || 'none'} data-stale={isStale ? '1' : '0'}
                            data-testid={'bar-' + r} data-pool-bar={'combined-bar-' + r}
                            style={{ height: cleared ? '0px' : `max(5px, ${pct.toFixed(2)}%)` }}
                            onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }} onFocus={() => mf.setFocus(r)} />
                        } />
                        <TooltipContent className="mf-tip">
                          <strong>#{r} {h?.name}：即時熱錢分佈（綜合份額÷基準），{stateText}，{share?.barHeight?.quality || 'UNAVAILABLE'}</strong>
                          <p>BarHeight {cleared ? '--' : uncapped != null ? uncapped.toFixed(1) : fmt(heightMetric, 1)} · 顯示 {cleared ? '--' : height!.toFixed(0)}（clamp 50–200）；100 = 凍結基準綜合份額（結構位移，唔係「有熱錢」，唔係總投注）{isStale ? '；保留上次有效高度（非即時）' : ''}</p>
                          <p>Current {share?.currentShare?.value != null ? (share.currentShare.value * 100).toFixed(2) + '%' : '--'} · Baseline {share?.baselineShare?.value != null ? (share.baselineShare.value * 100).toFixed(2) + '%' : '--'} · ε=0.0025</p>
                          <p>池份額：{partsTip}</p>
                          <p>Pressure（次要）{overlay.ready ? fmt({ value: overlay.value, quality: 'DERIVED' }, 1) : '--'}（{overlay.text}）</p>
                          <p>B {fmt(research?.B, 3)} · H ln(1+B) {fmt(research?.H, 3)}</p>
                          <p>{share?.barHeight?.reason || '未有綜合份額棒高'}</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="mf-bar-foot">
                      <button type="button" className={'mark-button' + (marked ? ' is-on' : '')} aria-label={`${marked ? '取消' : '新增'} ${r}號 +1 標記`} aria-pressed={marked} onClick={() => void mf.mark(r)}>
                        <b className="mf-cloth is-sm">{r}</b><span>{marked && <Check size={10} strokeWidth={2.25} aria-hidden="true" />}+1</span>
                      </button>
                      <AxisLines win={frame?.runners[r]?.winOdds} dblDown={dblPctView?.down?.[r]} dblUp={dblPctView?.up?.[r]} flowStale={flowStale} />
                    </div>
                  </div>
                );
              })}
              {!order.length && <div className="mf-empty">連接真實賽事，或者揀「MOCK · 模擬測試」核對完整操作。</div>}
            </div>
          </div>
          )}
        </div>
      </div>
    </section>
  );
}
