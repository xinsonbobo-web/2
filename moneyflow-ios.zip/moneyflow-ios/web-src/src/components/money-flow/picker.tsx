'use client';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

/** Compact select; `label` is the accessible name (tests address comboboxes by it). */
export function Picker({ label, value, options, onChange, className }: { label: string; value: string; options: { value: string; label: string }[]; onChange: (v: string) => void; className?: string }) {
  return (
    <Select value={value} onValueChange={v => v != null && onChange(String(v))} items={options}>
      <SelectTrigger size="sm" aria-label={label} title={label} className={'mf-select ' + (className || '')}>
        <SelectValue placeholder="選擇" />
      </SelectTrigger>
      <SelectContent className="mf-select-menu">
        {options.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}
