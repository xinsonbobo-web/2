import type { Metric } from '@/lib/types';

export const QUALITY_GLYPH: Record<string, string> = { DIRECT: 'D', ESTIMATED: 'ƒ', DERIVED: '≈', UNAVAILABLE: '—' };

/** API metric → display text. null → "--", unbounded reasons → ∞. No rounding beyond `digits`. */
export const fmt = (m?: Metric, digits = 1) =>
  m?.reason === 'POSITIVE_UNBOUNDED' ? '∞'
    : m?.reason === 'NEGATIVE_UNBOUNDED' ? '-∞'
      : m?.value == null ? '--'
        : Number(m.value).toLocaleString('en-HK', { maximumFractionDigits: digits });

/** HKT 24 h clock. */
export const tm = (t?: number | null) => (t == null ? '--' : new Date(t * 1000).toLocaleTimeString('en-GB', { timeZone: 'Asia/Hong_Kong', hour12: false }));

export const venueName = (item?: { venue?: string; venueLabel?: string }) =>
  item?.venueLabel || (item?.venue === 'ST' ? '沙田 ST' : item?.venue === 'HV' ? '跑馬地 HV' : item?.venue || '--');

/** One API metric with its quality glyph. `≥` when the API marks the value as a lower bound (bound GE). */
export function NumberValue({ m, digits = 1, suffix = '', title, glyph = true }: { m?: Metric; digits?: number; suffix?: string; title?: string; glyph?: boolean }) {
  const q = m?.quality || 'UNAVAILABLE';
  const tip = title ?? `${q} · ${m?.source || ''} ${m?.reason || ''}`.trim();
  return (
    <span className={'value ' + q.toLowerCase()} title={tip}>
      {m?.value != null && m?.bound === 'GE' ? '≥' : ''}{fmt(m, digits)}{m?.value != null ? suffix : ''}
      {glyph && <small className="quality">{QUALITY_GLYPH[q]}</small>}
    </span>
  );
}
