'use client';

import { useRef } from 'react';
import { ArrowDownToLine, ChevronLeft, ChevronRight, CircleHelp, ListChecks, Radio, RefreshCw, Upload } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { fmt, tm, venueName } from './format';
import { Picker } from './picker';
import type { MoneyFlow } from './use-money-flow';
import { saveApiJson } from '@/backend/client';

const ICON = { size: 15, strokeWidth: 1.75 } as const;

export function HeaderRail({ mf }: { mf: MoneyFlow }) {
  const file = useRef<HTMLInputElement>(null);
  const { race, state, frame, healthStatus, mode } = mf;
  const hp = state.health;
  const raceParts = race
    ? [venueName(race), `R${race.no}`, race.distance?.value != null ? `${Math.round(Number(race.distance.value))}m` : '--', race.raceClass || '--', [race.track, race.course].filter(Boolean).join(' ') || null].filter(Boolean) as string[]
    : null;
  const raceTip = race
    ? `${race.date} / ${venueName(race)}${race.venueKind === 'overseas' ? '（海外）' : race.venueKind === 'local' ? '（本地）' : ''} / 第 ${race.no} 場 / ${race.name} / ${race.raceClass} / ${fmt(race.distance, 0)}m / ${race.track} ${race.course} / ${race.going} / 開跑 ${tm(race.postTime)} / 切片 ${tm(frame?.timestamp)} / ${state.frames.length} snapshots`
    : '選擇賽事開始監察';
  const c = mf.collection;
  const sourceTip = [
    `狀態 ${healthStatus}`,
    'flowVerified 需真 probe Exit 0（UI 不宣稱）',
    mf.flowStale ? 'WIN 計算 STALE' : mf.flowStatus?.status === 'READY' ? 'WIN 計算 READY' : 'WIN 計算等待',
    `來源更新 ${tm(hp.lastUpdate?.value)}`,
    `延遲 ${fmt(hp.latency, 0)} ms`,
    `資料年齡 ${mf.sourceAge}`,
    hp.error || (!frame && race ? '等待有效 WIN 更新；未有賠率／彩池時顯示 --' : state.mode === 'live' ? 'HKJC public feed，畫面每 3 秒更新，右鍵圖表區連接 LIVE' : '已保存資料，不更新 source clock'),
    c?.status === 'ERROR' ? `收集失敗：${c.error}` : c?.status === 'COLLECTING' ? `收集中 ${c.race?.venue} R${c.race?.no}` : c?.status === 'WAITING' ? '等待下一場賽事' : null,
    mf.catalog?.message || null,
  ].filter(Boolean).join('\n');
  const dates = [...new Set(mf.meetings.map(m => m.date))];
  const venues = [...new Set(mf.meetings.filter(m => m.date === mf.date).map(m => m.venue))];

  return (
    <header className="mf-rail" data-testid="compact-header">
      <h1 className="mf-brand" title="HKJC Money Flow · Formula-First"><span className="mf-brand-mark" aria-hidden="true" />Money Flow</h1>
      <Tooltip>
        <TooltipTrigger render={
          <button type="button" className="mf-race" data-testid="race-inline" aria-label="賽事摘要">
            {raceParts ? raceParts.map((p, i) => <span key={i} className={i === 1 ? 'mf-race-no' : undefined}>{p}</span>) : <span>選擇賽事開始監察</span>}
          </button>} />
        <TooltipContent className="mf-tip"><p>{raceTip}</p></TooltipContent>
      </Tooltip>
      <Tooltip>
        <TooltipTrigger render={
          <button type="button" className={'mf-status is-' + healthStatus.toLowerCase()} data-testid="chrome-status" aria-label={`來源狀態 ${healthStatus}`}>
            <i aria-hidden="true" />{healthStatus}
          </button>} />
        <TooltipContent className="mf-tip"><p className="mf-tip-lines">{sourceTip}</p></TooltipContent>
      </Tooltip>
      {state.mode === 'mock' && <span className="mf-chip is-mock" data-testid="mock-banner" title="MOCK：全部數據為合成測試資料，只用於核對公式同操作。">MOCK</span>}
      {state.mode === 'replay' && <span className="mf-chip is-replay chrome-chip replay" title={`REPLAY：已保存切片，原始來源 ${(frame?.source || '--').toUpperCase()}，唔代表即時更新`}>來源 {(frame?.source || '--').toUpperCase()}</span>}

      <nav className="mf-race-nav" data-testid="race-nav" aria-label="場次導航">
        <button type="button" className="mf-icon" aria-label="上一場" disabled={!mf.prevRace || mf.busy} onClick={() => mf.prevRace && mf.chooseRace(mf.prevRace)}><ChevronLeft {...ICON} /></button>
        {mode === 'replay'
          ? <Picker label="已保存賽事" value={mf.raceId} options={mf.recordings.map(r => ({ value: r.key, label: `${r.race.date} ${venueName(r.race)} R${r.race.no}（${r.mode}）` }))} onChange={mf.setRaceId} className="is-wide" />
          : <Picker label="場次" value={mf.raceId} options={mf.races.map(r => ({ value: r.id, label: `R${r.no}  ${tm(r.postTime).slice(0, 5)}` }))} onChange={v => mf.chooseRace(mf.races.find(r => r.id === v))} />}
        <button type="button" className="mf-icon" aria-label="下一場" disabled={!mf.nextRace || mf.busy} onClick={() => mf.nextRace && mf.chooseRace(mf.nextRace)}><ChevronRight {...ICON} /></button>
      </nav>

      <div className="mf-rail-controls" data-testid="chrome-controls">
        <Picker label="數據來源" value={mode} onChange={mf.changeMode} options={[{ value: 'live', label: 'HKJC LIVE' }, { value: 'mock', label: 'MOCK · 模擬測試' }, { value: 'replay', label: 'REPLAY · 已保存' }]} />
        {mode !== 'replay' && <>
          <Picker label="賽馬日" value={mf.date} options={dates.map(d => ({ value: d, label: d }))} onChange={mf.selectDate} />
          <Picker label="場地" value={mf.venue} options={venues.map(v => ({ value: v, label: venueName(mf.meetings.find(m => m.date === mf.date && m.venue === v)) }))} onChange={mf.selectVenue} />
        </>}
        {mode !== 'live' && (
          <button type="button" className="mf-btn is-primary" disabled={mf.busy || !mf.raceId} aria-busy={mf.busy} onClick={() => void mf.connect()}>
            {mf.busy ? <RefreshCw className="mf-spin" {...ICON} /> : <Radio {...ICON} />}{mode === 'mock' ? '開啟模擬測試' : '載入 REPLAY'}
          </button>
        )}
        {mode === 'live' && (
          <button type="button" className={'mf-btn mf-follow' + (mf.autoFollow ? ' is-on' : '')} aria-label="自動跟隨賽事" aria-pressed={mf.autoFollow} onClick={() => void mf.toggleFollowing()}>
            <i aria-hidden="true" />{mf.autoFollow ? '跟隨' : '手動'}
          </button>
        )}
        <span className="mf-rail-sep" aria-hidden="true" />
        <button type="button" className="mf-icon" title="刷新可用賽事" aria-label="刷新可用賽事" disabled={mf.busy} onClick={() => void mf.loadChoices(mode)}><RefreshCw {...ICON} /></button>
        <button type="button" className="mf-icon" title="匯入切片 JSON" aria-label="匯入" onClick={() => file.current?.click()}><Upload {...ICON} /></button>
        <a className={'mf-icon' + (!race ? ' is-disabled' : '')} aria-disabled={!race} href="#" role="button" onClick={e => { e.preventDefault(); if (race) void saveApiJson('export', 'hkjc-replay.json').catch(err => alert((err as Error).message)); }} aria-label="匯出切片" title="匯出切片"><ArrowDownToLine {...ICON} /></a>
        <button type="button" className={'mf-icon' + (mf.drawer === 'audit' ? ' is-on' : '')} title="數值核對" aria-label="數值核對" aria-pressed={mf.drawer === 'audit'} onClick={() => mf.toggleDrawer('audit')}><ListChecks {...ICON} /></button>
        <button type="button" className={'mf-icon' + (mf.drawer === 'settings' ? ' is-on' : '')} title="公式與設定" aria-label="公式與設定" aria-pressed={mf.drawer === 'settings'} onClick={() => mf.toggleDrawer('settings')}><CircleHelp {...ICON} /></button>
      </div>
      <input ref={file} type="file" accept="application/json,.json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) void mf.importReplay(f); e.target.value = ''; }} />
    </header>
  );
}
