'use client';

// All board state, polling and actions (same request cadence and API contract as v0.6).
import { useEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { currentFrame, visibleFrame } from '@/lib/view-state';
import type { Catalog, Collection, Meeting, Race, State } from '@/lib/types';
import { registerMoneyFlowTools } from '@/lib/webmcp';
import { api } from './api';
import {
  BLANK_STATE, STALE_AFTER_SEC, STATE_REFRESH_MS, ZOOM_DEFAULT, ZOOM_KEY, ZOOM_STEPS,
  computeOrder, cycleHighlight, frameHasShareHeights, mergeKeepLastShareBars,
  type HighlightColor, type SortMode,
} from './model';

export type Recording = { key: string; mode: string; race: Race };
export type DrawerTab = 'settings' | 'audit';

export function useMoneyFlow() {
  const [state, setState] = useState<State>(BLANK_STATE);
  const [mode, setMode] = useState('live');
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [autoFollow, setAutoFollow] = useState(true);
  const followRef = useRef(true);
  const busyRef = useRef(false);
  const [date, setDate] = useState('');
  const [venue, setVenue] = useState('ST');
  const [raceId, setRaceId] = useState('');
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [highlights, setHighlights] = useState<Record<string, HighlightColor>>({});
  const [focus, setFocus] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [windowSeconds, setWindowSeconds] = useState(15);
  const [baselineMinutes, setBaselineMinutes] = useState(15);
  const [drawer, setDrawer] = useState<DrawerTab | null>(null);
  const [zoom, setZoom] = useState(ZOOM_DEFAULT);
  const [collection, setCollection] = useState<Collection | null>(null);
  const [, setTick] = useState(0);
  const [sortMode, setSortMode] = useState<SortMode>('odds');
  const [frozenOrder, setFrozenOrder] = useState<string[]>([]);
  // 007式流向（試驗）: default OFF, not persisted. While OFF nothing is fetched or rendered.
  const [flowTrialOn, setFlowTrialOn] = useState(false);
  const generation = useRef(0);
  const controlsRef = useRef({ mode, date, venue, raceId });
  controlsRef.current = { mode, date, venue, raceId };
  const viewRef = useRef({ state, selectedId });
  viewRef.current = { state, selectedId };

  useEffect(() => registerMoneyFlowTools(() => viewRef.current, id => flushSync(() => setSelectedId(id))), []);

  const now = Date.now() / 1000;
  const rawFrame = visibleFrame(currentFrame(state.frames, selectedId), state.mode, selectedId, now);
  const frame = !selectedId && rawFrame && !frameHasShareHeights(rawFrame) ? mergeKeepLastShareBars(rawFrame, state.frames) : rawFrame;
  const race = state.race;
  const races = meetings.find(m => m.date === date && m.venue === venue)?.races || [];
  const numberOrder = (state.baseline?.order || race?.runners.map(r => String(r.no)) || []).slice().sort((a, b) => Number(a) - Number(b));
  const baselineOddsReady = numberOrder.some(r => state.baseline?.winOdds?.[r]?.value != null);

  function applySort(next: SortMode) {
    if (next === 'baseline' && !baselineOddsReady) return;
    setSortMode(next);
    setFrozenOrder(computeOrder(next, numberOrder, state, frame));
  }
  const raceKey = race?.id || state.key || '';
  const baselineStamp = state.baseline?.timestamp ?? null;
  useEffect(() => {
    if (!numberOrder.length) { setFrozenOrder([]); return; }
    setFrozenOrder(computeOrder(sortMode === 'baseline' && !baselineOddsReady ? 'odds' : sortMode, numberOrder, state, frame));
    // Re-seed only on race identity / baseline change, never on live odds ticks.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [raceKey, baselineStamp, numberOrder.join('|')]);
  const order = frozenOrder.length ? frozenOrder : numberOrder;

  const hp = state.health;
  const healthStatus = state.mode === 'live' && hp.status === 'LIVE' && hp.lastUpdate?.value != null && now - hp.lastUpdate.value > STALE_AFTER_SEC ? 'STALE' : hp.status;
  const flowStatus = frame?.moneyFlow;
  const flowStale = !selectedId && state.mode === 'live' && flowStatus?.calculationTime != null && now - flowStatus.calculationTime > STALE_AFTER_SEC;
  const staleAgeSec = flowStale && flowStatus?.calculationTime != null ? Math.round(now - flowStatus.calculationTime) : null;
  // Scrub reads the selected frame's dblPct; the LIVE tip reads server keep-last state.dblPct.
  const dblPctView = selectedId ? frame?.dblPct ?? undefined : state.dblPct;
  const hotCircle = order.filter(r => {
    if (flowStale) return state.marks.includes(r);
    const f = frame?.flows[r]?.WIN, g = f?.grade, p = f?.pressure?.value;
    return state.marks.includes(r) || (g != null && g !== 'normal' && g !== 'unavailable') || (p != null && p >= 120);
  });
  const lateFrames = race ? state.frames.filter(f => f.timestamp >= race.postTime - 300) : [];
  const replayFrames = lateFrames.length ? lateFrames : state.frames;
  const latestReady = state.frames.findLast(f => frameHasShareHeights(f));
  const sliderIndex = frame ? replayFrames.findIndex(f => f.id === frame.id) : -1;
  const sourceAge = state.mode === 'live' && hp.lastUpdate?.value != null ? Math.max(0, Math.floor(now - hp.lastUpdate.value)) + 's' : '--';

  function working(v: boolean) { busyRef.current = v; setBusy(v); }
  function following(v: boolean) { followRef.current = v; setAutoFollow(v); }
  async function toggleFollowing() {
    const next = !followRef.current; following(next);
    try { setCollection(await api<Collection>('follow', { autoFollow: next })); if (next) await loadChoices('live'); }
    catch (e) { following(!next); setError((e as Error).message); }
  }
  function changeZoom(v: string) { setZoom(Number(v)); try { localStorage.setItem(ZOOM_KEY, v); } catch { /* optional preference */ } }
  function clearView(nextMode: string) { setState({ ...BLANK_STATE, mode: nextMode }); setSelectedId(null); setHighlights({}); setFocus(null); }

  async function loadChoices(nextMode: string, filterDate?: string, background = false) {
    if (background && busyRef.current) return;
    setError(''); working(true); const gen = ++generation.current;
    try {
      if (nextMode === 'replay') {
        const data = await api<{ recordings: Recording[] }>('recordings'); if (gen !== generation.current) return;
        setRecordings(data.recordings); setRaceId(data.recordings[0]?.key || '');
      } else {
        const data = await api<Catalog>('meetings?mode=' + nextMode + (filterDate ? '&date=' + encodeURIComponent(filterDate) : ''));
        if (gen !== generation.current) return;
        if (nextMode === 'live') setCatalog(data);
        const previous = controlsRef.current;
        setMeetings(old => {
          // A manually selected meeting stays selectable while discovery moves on; auto mode follows fresh cards only.
          const retained = old.filter(m => (filterDate ? m.date !== filterDate : !followRef.current && m.date === previous.date && m.venue === previous.venue));
          const merged = [...data.meetings];
          for (const m of retained) if (!merged.some(n => n.date === m.date && n.venue === m.venue)) merged.push(m);
          return merged.sort((a, b) => a.date.localeCompare(b.date) || a.venue.localeCompare(b.venue));
        });
        if (nextMode === 'live' && followRef.current && !filterDate) {
          const suggested = data.meetings.flatMap(m => m.races).find(r => r.id === data.recommendedRaceId);
          if (suggested) {
            setDate(suggested.date); setVenue(suggested.venue); setRaceId(suggested.id);
            const visible = viewRef.current.state;
            if (visible.mode !== 'live' || visible.race?.id !== suggested.id) await connect(suggested.id, 'live', suggested);
          } else {
            const m = data.meetings[0]; setDate(m?.date || ''); setVenue(m?.venue || 'ST'); setRaceId(m?.races[0]?.id || '');
            clearView('live');
          }
        } else if (filterDate || nextMode !== 'live' || !previous.raceId) {
          const m = data.meetings[0]; setDate(m?.date || filterDate || ''); setVenue(m?.venue || 'ST'); setRaceId(m?.races[0]?.id || '');
          if (filterDate && m?.races[0]) await connect(m.races[0].id, 'live', m.races[0]);
        }
        if (!data.meetings.length && filterDate) setError('HKJC 未提供此日期賽事。已保存資料可用 REPLAY 查看。');
      }
    } catch (e) { if (gen === generation.current) setError(String((e as Error).message)); }
    finally { if (gen === generation.current) working(false); }
  }

  useEffect(() => {
    let active = true;
    void (async () => { try { await api<Collection>('follow', { autoFollow: true }); } catch (e) { if (active) setError((e as Error).message); } if (active) void loadChoices('live'); })();
    const timer = setInterval(() => { if (controlsRef.current.mode === 'live') void loadChoices('live', undefined, true); }, 60000);
    return () => { active = false; clearInterval(timer); ++generation.current; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    try { const n = Number(localStorage.getItem(ZOOM_KEY)); if (ZOOM_STEPS.includes(n)) setZoom(n); } catch { /* keep default */ }
    let active = true, pending = false;
    const heartbeat = async () => {
      if (pending) return; pending = true;
      try { const data = await api<Collection>('collection'); if (active) setCollection(data); }
      catch (e) { if (active) setError((e as Error).message); }
      finally { pending = false; }
    };
    void heartbeat(); const timer = setInterval(heartbeat, 25000);
    window.addEventListener('focus', heartbeat); document.addEventListener('visibilitychange', heartbeat);
    return () => { active = false; clearInterval(timer); window.removeEventListener('focus', heartbeat); document.removeEventListener('visibilitychange', heartbeat); };
  }, []);
  // 1 s clock so STALE ages and source age advance between polls.
  useEffect(() => { const t = setInterval(() => setTick(x => x + 1), 1000); return () => clearInterval(t); }, []);
  useEffect(() => {
    if (!race || !state.key) return;
    let active = true, pending = false;
    const refresh = async () => {
      if (pending) return; pending = true;
      try {
        const data = await api(`state?window=${windowSeconds}&baseline_minutes=${baselineMinutes}`);
        if (active && data.collection) setCollection(data.collection);
        if (active && data.key === state.key) setState(data);
        else if (active && !busyRef.current && followRef.current && controlsRef.current.mode === 'live' && data.mode === 'live' && data.race) {
          setState(data); setDate(data.race.date); setVenue(data.race.venue); setRaceId(data.race.id); setSelectedId(null); setHighlights({}); setFocus(null);
        }
      } catch (e) { if (active) setError((e as Error).message); }
      finally { pending = false; }
    };
    void refresh(); const t = setInterval(refresh, STATE_REFRESH_MS);
    return () => { active = false; clearInterval(t); };
  }, [state.key, race?.id, race?.postTime, state.mode, windowSeconds, baselineMinutes]);

  async function connect(id = raceId, nextMode = mode, identity?: Race) {
    if (!id) return; working(true); setError(''); const gen = ++generation.current;
    const chosen = identity || meetings.flatMap(m => m.races).find(r => r.id === id);
    if (chosen) { setDate(chosen.date); setVenue(chosen.venue); setRaceId(chosen.id); }
    if (viewRef.current.state.mode !== nextMode || viewRef.current.state.race?.id !== id) clearView(nextMode);
    try {
      const data = await api('select', { mode: nextMode, raceId: id, date: chosen?.date || date || undefined, venue: nextMode === 'live' ? chosen?.venue || venue : undefined, autoFollow: nextMode === 'live' ? followRef.current : undefined, window: windowSeconds, baseline_minutes: baselineMinutes });
      if (gen !== generation.current) return;
      setState(data); setSelectedId(null); setHighlights({}); setFocus(null);
    } catch (e) { if (gen === generation.current) setError((e as Error).message); }
    finally { if (gen === generation.current) working(false); }
  }
  async function mark(r: string) {
    try { const data = await api<{ marks: string[] }>('mark', { runner: r, key: state.key }); setState(prev => ({ ...prev, marks: data.marks })); }
    catch (e) { setError((e as Error).message); }
  }
  function toggleHighlight(r: string) { setHighlights(prev => cycleHighlight(prev, r)); }
  function seek(id: string | null, r?: string) { setSelectedId(id); if (r) toggleHighlight(r); }
  function backToTip() { setSelectedId(null); setHighlights({}); }
  async function importReplay(f: File) {
    working(true); following(false); setError(''); const gen = ++generation.current;
    try { const data = await api('import', JSON.parse(await f.text())); if (gen !== generation.current) return; setState(data); setMode('replay'); setSelectedId(null); setHighlights({}); }
    catch (e) { if (gen === generation.current) setError((e as Error).message); }
    finally { if (gen === generation.current) working(false); }
  }
  function chooseRace(r?: Race) { following(false); if (r) void connect(r.id, mode, r); }
  const selectDate = (v: string) => chooseRace(meetings.find(m => m.date === v)?.races[0]);
  const selectVenue = (v: string) => chooseRace(meetings.find(m => m.date === date && m.venue === v)?.races[0]);
  function changeMode(v: string) { following(v === 'live'); setMode(v); setRaceId(''); setMeetings([]); clearView(v); void loadChoices(v); }
  function connectLive() {
    following(true); setMode('live');
    const id = controlsRef.current.raceId || raceId;
    if (id) void connect(id, 'live'); else void loadChoices('live');
  }
  function pickDate(v: string) { if (v) { following(false); setMode('live'); void loadChoices('live', v); } }
  function toggleDrawer(tab: DrawerTab) { setDrawer(d => (d === tab ? null : tab)); }

  const raceIndex = races.findIndex(r => r.id === raceId);
  const prevRace = raceIndex > 0 ? races[raceIndex - 1] : undefined;
  const nextRace = raceIndex >= 0 && raceIndex < races.length - 1 ? races[raceIndex + 1] : undefined;

  return {
    state, mode, meetings, catalog, autoFollow, date, venue, raceId, recordings, selectedId, highlights, focus, error, busy,
    windowSeconds, baselineMinutes, drawer, zoom, collection, sortMode, flowTrialOn,
    frame, race, races, numberOrder, baselineOddsReady, order, healthStatus, flowStatus, flowStale, staleAgeSec,
    dblPctView, hotCircle, lateFrames, replayFrames, latestReady, sliderIndex, sourceAge, prevRace, nextRace,
    setRaceId, setFocus, setHighlights, setWindowSeconds, setBaselineMinutes, setDrawer, setFlowTrialOn,
    applySort, toggleFollowing, changeZoom, loadChoices, connect, mark, toggleHighlight, seek, backToTip, importReplay,
    chooseRace, selectDate, selectVenue, changeMode, connectLive, pickDate, toggleDrawer,
  };
}
export type MoneyFlow = ReturnType<typeof useMoneyFlow>;
