'use client';

import { Check } from 'lucide-react';
import { NumberValue, fmt } from './format';
import { drawMetric, pressureStateOf } from './model';
import { RunnerSlot, sigOf } from './memo-slot';
import type { MoneyFlow } from './use-money-flow';

const DBL_TIP = 'ƒ Estimated exposure from inverse-odds; NOT stake %';

/** Saddle-cloth horse number tile (shared by table, chart and spectrum). */
export function Cloth({ no, className }: { no: string; className?: string }) {
  return <b className={'mf-cloth ' + (className || '')}>{no}</b>;
}

export function RunnerTable({ mf }: { mf: MoneyFlow }) {
  const { state, frame, race, order, highlights, focus, flowStale, selectedId, dblPctView } = mf;
  const circle = mf.hotCircle.length ? mf.hotCircle : mf.numberOrder;
  return (
    <section className="mf-panel mf-table-panel" data-testid="ideal-table" aria-label="馬匹數據表">
      <div className="mf-panel-head">
        <h2 className="mf-h">大戶投注賽圈</h2>
        <ol className="mf-circle" aria-label="大戶投注賽圈馬號">
          {circle.length ? circle.map(r => <li key={r}>{r}</li>) : <li className="is-empty">--</li>}
        </ol>
        <span className="mf-qkey quality-key" aria-label="質素圖例">
          <span><b>D</b> Direct</span><span><b>ƒ</b> Estimated</span><span><b>≈</b> Derived</span><span><b>—</b> Unavailable</span>
        </span>
      </div>
      <div className="mf-table-scroll ideal-table-scroll">
        <table className="mf-table">
          <thead>
            {/* v0.7.3: 結構、熱錢強度、位置 columns removed from the table (UI only; API fields, bars and the audit drawer keep
                them). 檯 joins the horse group; 獨贏前 (frozen T−15) sits beside live 獨贏 as one odds pair.
                v0.7.4: inside 孖寶 Double the 孖寶冠／亞／全 odds come first (next to 獨贏), 孖上%／孖下% at the right end. */}
            <tr className="mf-group-row" aria-hidden="true">
              <th colSpan={6} className="g-end">馬匹</th>
              <th colSpan={1} className="g-end">筆記</th>
              <th colSpan={2} className="g-end is-odds">賠率 Odds</th>
              <th colSpan={5}>孖寶 Double</th>
            </tr>
            <tr className="mf-col-row">
              <th className="c-rank">名次</th><th className="c-no">馬號</th><th className="c-name">馬名</th><th className="c-sec">練馬師</th><th className="c-sec">騎師</th>
              <th className="c-num c-draw g-end">檯</th>
              <th className="c-note g-end">筆記</th>
              <th className="c-num c-odds" title="獨贏前：T−15 凍結嘅獨贏賠率（排序「獨贏前」用佢）">獨贏前</th>
              <th className="c-num c-odds g-end" title="獨贏：而家切片嘅獨贏賠率">獨贏</th>
              <th className="c-num c-dbl" title="≈ DBL(上一關冠軍,i) ÷ 上一關冠軍WIN；<10 取 0.1、≥10 取整（對齊 007）；≥ = DBL 999 封頂">孖寶冠</th>
              <th className="c-num c-dbl" title="≈ DBL(上一關亞軍,i) ÷ 上一關亞軍WIN；<10 取 0.1、≥10 取整；≥ = DBL 999 封頂">孖寶亞</th>
              <th className="c-num c-dbl" title="≈ 1 ÷ Σⱼ(1/DBL(j,i))（全部上一關馬，含孖寶扣數，對齊 007）；<100 向上取 0.1、≥100 向上取整；≥ = 999 封頂令真值更長">孖寶全</th>
              <th className="c-num c-dbl" title={`${DBL_TIP}。孖上＝本場做第二關（上一場×本場孖寶池），隱含賠率自上一場 T−17 起縮短 %；變長／不變 = --`}>孖上%</th>
              <th className="c-num c-dbl" title={`${DBL_TIP}。孖下＝第一關（本場×下一場孖寶池），隱含賠率自本場 T−17（007 切點）起縮短 %；變長／不變／縮短 <3% = --`}>孖下%</th>
            </tr>
          </thead>
          <tbody>
            {order.map((r, idx) => {
              const h = race?.runners.find(x => String(x.no) === r);
              const win = frame?.flows[r]?.WIN;
              const marked = state.marks.includes(r);
              const pState = pressureStateOf(win, flowStale && !selectedId);
              const up = dblPctView?.up?.[r], down = dblPctView?.down?.[r];
              const hl = highlights[r];
              const baseOdds = state.baseline?.winOdds?.[r], liveOdds = frame?.runners[r]?.winOdds, dbl = frame?.incomingDouble?.[r];
              const cls = [focus === r ? 'is-focus debug-row' : '', hl ? `is-hl hl-${hl}` : '', marked ? 'is-marked' : '', pState === 'STALE' ? 'is-stale' : ''].filter(Boolean).join(' ');
              // v0.7.3: the row re-renders only when one of its own inputs changes (RunnerSlot), never on an unchanged poll.
              const sig = sigOf(idx, h?.name, h?.scratched, h?.trainer, h?.jockey, drawMetric(h), marked, state.key, cls, hl, focus === r, baseOdds, liveOdds, up, down, dbl, flowStale);
              return (
                <RunnerSlot key={r} sig={sig} probe="table-row" render={() => (
                <tr data-runner={r} className={cls} aria-label={`Horse ${r}${hl ? `, ${hl} highlight` : ''}${focus === r ? ', focused' : ''}`}
                  onClick={() => { mf.setFocus(r); mf.toggleHighlight(r); }} onMouseEnter={() => mf.setFocus(r)}>
                  <td className="c-rank">{idx + 1}</td>
                  <td className="c-no"><Cloth no={r} /></td>
                  <td className="c-name">{h?.name || '--'}{h?.scratched ? '（退出）' : ''}</td>
                  <td className="c-sec">{h?.trainer || '--'}</td>
                  <td className="c-sec">{h?.jockey || '--'}</td>
                  <td className="c-num c-draw g-end"><NumberValue m={drawMetric(h)} digits={0} /></td>
                  <td className="c-note g-end">
                    <button type="button" className={'mf-note' + (marked ? ' is-on' : '')} aria-label={`${marked ? '取消筆記' : '筆記標記'} ${r}號`} aria-pressed={marked}
                      onClick={e => { e.stopPropagation(); void mf.mark(r); }}>{marked ? <Check size={12} strokeWidth={2.25} /> : null}<span className="sr-only">{marked ? '✓' : ''}</span></button>
                  </td>
                  <td className="c-num c-odds is-primary"><NumberValue m={baseOdds} /></td>
                  <td className="c-num c-odds is-primary g-end"><NumberValue m={liveOdds} /></td>
                  <td className="c-num c-dbl"><NumberValue m={dbl?.winner} digits={1} /></td>
                  <td className="c-num c-dbl"><NumberValue m={dbl?.runnerUp} digits={1} /></td>
                  <td className="c-num c-dbl"><NumberValue m={dbl?.all} digits={1} /></td>
                  <td className={'c-num c-dbl' + (flowStale && down?.value != null ? ' is-stale-cell' : '')} data-testid="dbl-down" title={DBL_TIP}>
                    <NumberValue m={down} suffix="%" digits={1} title={DBL_TIP} />
                    {flowStale && down?.value != null && <small className="mf-stale-mark stale-mark"> STALE</small>}
                  </td>
                  <td className={'c-num c-dbl' + (flowStale && up?.value != null ? ' is-stale-cell' : '')} data-testid="dbl-up" title={DBL_TIP}>
                    <NumberValue m={up} suffix="%" digits={1} title={DBL_TIP} />
                    {flowStale && up?.value != null && <small className="mf-stale-mark stale-mark"> STALE</small>}
                  </td>
                </tr>
                )} />
              );
            })}
            {!order.length && <tr><td colSpan={14} className="mf-empty-row">連接真實賽事，或者揀「MOCK · 模擬測試」核對完整操作。</td></tr>}
          </tbody>
        </table>
      </div>
      {focus && (
        <p className="mf-focus-line debug-summary">
          <Cloth no={focus} className="is-sm" />
          <span>{frame?.flows[focus]?.WIN?.pressure?.quality || 'UNAVAILABLE'}</span>
          <span>Window {fmt(frame?.flows[focus]?.WIN?.windowSeconds, 0)}s</span>
          <span className="mf-focus-reason">{frame?.flows[focus]?.WIN?.reason || 'Expected = rolling baseline share × ΔPool；Pressure = 100 × Actual / Expected'}</span>
        </p>
      )}
    </section>
  );
}
