'use client';

import { ChevronLeft, ChevronRight, Radio, RefreshCw, Trash2 } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { replayAt } from '@/lib/view-state';
import { tm } from './format';
import { SORT_INFO, ZOOM_STEPS, type SortMode } from './model';
import { Picker } from './picker';
import type { MoneyFlow } from './use-money-flow';

const ICON = { size: 15, strokeWidth: 1.75 } as const;

/** Middle rail: replay transport (row 1) and sort / tools / legend (row 2). */
export function TransportBar({ mf }: { mf: MoneyFlow }) {
  const { frame, race, state, selectedId, replayFrames, lateFrames, sliderIndex } = mf;
  const isReplay = !!selectedId || state.mode === 'replay';
  const c = mf.collection;
  const hlCount = Object.keys(mf.highlights).length;
  const sortBtn = (m: SortMode, label: string, extra?: { disabled?: boolean; title?: string }) => (
    <button type="button" className={'mf-seg' + (mf.sortMode === m ? ' is-on' : '')} aria-pressed={mf.sortMode === m} data-testid={'sort-' + m}
      disabled={extra?.disabled} title={extra?.title} onClick={() => mf.applySort(m)}>{label}</button>
  );
  return (
    <section className="mf-toolbar ideal-toolbar" aria-label="功能列" data-testid="ideal-toolbar">
      <div className="mf-transport replay-control">
        <div className="replay-heading">
          <strong className={'mf-clock' + (isReplay ? ' is-replay' : ' is-live')}>
            {isReplay ? <span className="mf-clock-tag" data-testid="replay-badge">REPLAY</span> : <span className="mf-clock-tag">即時</span>}
            <span data-testid="snapshot-time">{tm(frame?.timestamp)}</span>
          </strong>
        </div>
        <button type="button" className="mf-btn is-primary chart-connect" disabled={mf.busy} aria-busy={mf.busy} onClick={mf.connectLive}>
          {mf.busy ? <RefreshCw className="mf-spin" {...ICON} /> : <Radio {...ICON} />}連接 LIVE
        </button>
        <button type="button" className="mf-icon" aria-label="上一切片" disabled={sliderIndex <= 0} onClick={() => mf.seek(replayFrames[sliderIndex - 1]?.id)}><ChevronLeft {...ICON} /></button>
        <div className="mf-scrub timeline-label">
          <span className="mf-scrub-end">{lateFrames.length ? 'T−5' : '已收集'} · {lateFrames.length && race ? tm(race.postTime - 300) : tm(replayFrames[0]?.timestamp)}</span>
          <Slider aria-label="時間切片" className="mf-slider" min={0} max={Math.max(1, replayFrames.length - 1)} value={[Math.max(0, sliderIndex)]} disabled={!replayFrames.length}
            onValueChange={v => { const t = replayAt(replayFrames, Array.isArray(v) ? v[0] : v); if (t) mf.seek(t.id); }} />
          <span className="mf-scrub-end">{lateFrames.length ? 'OFF' : tm(replayFrames.at(-1)?.timestamp)}</span>
        </div>
        <button type="button" className="mf-icon" aria-label="下一切片" disabled={sliderIndex < 0 || sliderIndex >= replayFrames.length - 1} onClick={() => mf.seek(replayFrames[sliderIndex + 1]?.id)}><ChevronRight {...ICON} /></button>
        <button type="button" className={'mf-btn mf-tip-btn' + (!selectedId ? ' is-on' : '')} onClick={mf.backToTip}><i aria-hidden="true" />{state.mode === 'live' ? 'LIVE' : '最新'}</button>
        <span className="mf-count">{sliderIndex < 0 && selectedId ? '歷史切片 · 早於 slider 範圍' : `${replayFrames.length} 個已保存切片`}</span>
      </div>
      <div className="mf-tools">
        <div className="mf-seg-group" role="group" aria-label="排序">
          <span className="mf-label">排序</span>
          {sortBtn('number', '馬號')}
          {sortBtn('odds', '獨贏')}
          {sortBtn('baseline', '獨贏前', { disabled: !mf.baselineOddsReady, title: mf.baselineOddsReady ? `按獨贏前（T−${mf.baselineMinutes}）賠率由低至高` : '未有獨贏前基準，唔可用' })}
          <span className="mf-sort-info sort-info" data-testid="sort-info" title="棒高 = 綜合份額 ÷ 凍結基準（WIN 1.0，QIN/QPL/FCT 0.75）；Pressure 只做徽章">{SORT_INFO[mf.sortMode]}</span>
        </div>
        <button type="button" className="mf-icon" data-testid="clear-highlights" disabled={hlCount === 0} aria-label="清除全部高亮"
          title={hlCount === 0 ? '冇高亮可清除' : '清除全部馬匹高亮（唔刪賽事、重播、筆記或數據）'} onClick={() => mf.setHighlights({})}><Trash2 {...ICON} /></button>
        <label className="mf-inline-field"><span className="mf-label">比例</span>
          <Picker label="圖表比例" value={String(mf.zoom)} options={ZOOM_STEPS.map(n => ({ value: String(n), label: `${n}%` }))} onChange={mf.changeZoom} />
        </label>
        <span className={'mf-collect' + (c?.status === 'ERROR' ? ' is-error' : c?.status === 'COLLECTING' ? ' is-on' : '')} data-testid="collection-status">
          {c?.status === 'ERROR' ? `連接失敗：${c.error}` : c?.status === 'COLLECTING' ? `收集中 ${c.race?.venue} R${c.race?.no}` : c?.status === 'WAITING' ? '等待下一場賽事' : '待機'}
        </span>
        <span className="mf-head-fill" />
        <div className="mf-legend hatch-legend" data-testid="hatch-legend" aria-label="異常級別圖例" title="固定異常級別，唔代表投注概率">
          <span><i className="sw-normal" />正常</span>
          <span><i className="sw-green" />輕微異常</span>
          <span><i className="sw-red" />異常</span>
          <span><i className="sw-brown" />非常異常</span>
        </div>
        {mf.flowTrialOn ? (
          <span className="mf-legend pg-legend" data-testid="flow-tone-legend" aria-label="007式流向棒圖例"
            title="007棒：淺色＝熱錢前；深色＝max(流向−熱錢前, 0)，唔會負；第三色＝max(而家流向−入閘嗰下流向, 0)，冇升就唔畫，貼喺棒頂，唔加高度。B+D 主棒先至有入閘後洋紅分段。">
            <span><i className="sw-ft-pre" />熱錢前</span>
            <span><i className="sw-ft-after" />截點後</span>
            <span><i className="sw-ft-rebound" />閘後</span>
          </span>
        ) : (
          <span className="mf-legend pg-legend" data-testid="postgate-legend" aria-label="入閘後圖例"
            title={`入閘後：${state.postGate?.offsetMin ? `表定開跑前 ${state.postGate.offsetMin} 分鐘` : '表定開跑時間'}之後新增嘅部分（HKJC 冇入閘時間）。棒標「入閘值+新增」，例 120+10；比入閘時少就標 120−3（虛線框＝入閘時高度）。未到時間唔拆分。只適用於 B+D 主棒。`}>
            <span><i className="sw-postgate" />入閘後</span>
          </span>
        )}
        <span className="mf-quality-strip quality-strip" title="資料質素（唔係異常級別）；綜合數值唔顯示 D">ƒ 估算　≈ 衍生　— 缺</span>
      </div>
    </section>
  );
}
