import type { State } from '@/lib/types';
import { apiCall } from '@/backend/client';

/** Local backend call (same contract as v0.6). GET is uncached; body → POST JSON. */
export async function api<T = State>(path: string, body?: unknown): Promise<T> {
  // iOS app: the former Python /api is served in-page (src/backend); HKJC requests go through the native bridge.
  return apiCall<T>(path, body);
}
