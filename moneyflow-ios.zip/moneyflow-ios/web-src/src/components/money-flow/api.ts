import type { State } from '@/lib/types';
import { apiCall, apiCallIfChanged } from '@/backend/client';

/** Local backend call (same contract as v0.6). GET is uncached; body → POST JSON. */
export async function api<T = State>(path: string, body?: unknown): Promise<T> {
  // iOS app: the former Python /api is served in-page (src/backend); HKJC requests go through the native bridge.
  return apiCall<T>(path, body);
}

/** v0.7.3 conditional GET for the 1 s poll: sends If-None-Match with the last ETag; 304 → null (nothing changed,
 *  caller keeps its state and skips setState). iOS app: the in-page backend answers the same ETag / 304 contract
 *  (and skips building the response body on a match). */
export async function apiIfChanged<T>(path: string, etag: string | null): Promise<{ data: T; etag: string | null } | null> {
  return apiCallIfChanged<T>(path, etag);
}
