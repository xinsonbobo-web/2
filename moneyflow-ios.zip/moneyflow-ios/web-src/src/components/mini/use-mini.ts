'use client';

// /mini data: GET /api/mini every 3 s, catalog every 60 s, POST /api/select to switch race (shared backend target).
import { useCallback, useEffect, useRef, useState } from 'react';
import type { Catalog, Collection, Meeting, Metric, Race } from '@/lib/types';
import { hkTime, shortDate, venueName } from './format';
import { apiCall } from '@/backend/client';

export type MiniRow = { no: number; name: string; scratched: boolean; winOdds: Metric; winOddsBefore: Metric; dblWinner: Metric; dblRunnerUp: Metric; dblAll: Metric };
export type MiniRace = { id: string; date: string; venue: string; venueKind?: string; venueLabel?: string; no: number; name?: string; raceClass?: string; distance?: Metric; postTime?: number };
export type MiniState = {
  mode: string; key?: string | null; race: MiniRace | null;
  health: { status: string; error?: string | null; lastUpdate?: Metric; lastReceived?: Metric; latency?: Metric };
  collection?: Collection; snapshotCount: number;
  frame: { id: string; timestamp: number; sourceTimestamp?: number; receivedAt?: number; source?: string } | null;
  baseline?: { status: string; timestamp?: number | null; target?: number | null; minutes: number } | null;
  freshSeconds: number; rows: MiniRow[];
};
type Recording = { key: string; mode: string; race: Race };
export type MeetingOption = { value: string; label: string; mode: 'live' | 'replay'; date: string; venue: string; races: { id: string; no: number; label: string }[] };

export const REFRESH_MS = 3000;
export const CATALOG_MS = 60000;
export const STALE_SECONDS = 45;
export const DEFAULT_BASE_MINUTES = 15;

/** /mini?base=N (1–30, one or two digits; the main page's settings link passes its value); otherwise 15. */
export function baseMinutes() {
  if (typeof window === 'undefined') return DEFAULT_BASE_MINUTES;
  // iOS app: hash route #/mini?base=N (single-file bundle); plain ?base=N still accepted.
  const hash = window.location.hash;
  const raw = new URLSearchParams(hash.includes('?') ? hash.slice(hash.indexOf('?') + 1) : '').get('base') ?? new URLSearchParams(window.location.search).get('base');
  const n = raw != null && /^\d{1,2}$/.test(raw) ? Number(raw) : NaN;
  return n >= 1 && n <= 30 ? n : DEFAULT_BASE_MINUTES;
}

async function api<T>(path: string, body?: unknown): Promise<T> {
  // iOS app: the former Python /api is served in-page (src/backend); HKJC requests go through the native bridge.
  return apiCall<T>(path, body);
}

export function useMini() {
  const [state, setState] = useState<MiniState | null>(null);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [recommended, setRecommended] = useState<string | null>(null);
  const [catalogMessage, setCatalogMessage] = useState('');
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [, setTick] = useState(0);
  const booted = useRef(false);
  const busyRef = useRef(false);

  const refresh = useCallback(async () => {
    try { const data = await api<MiniState>(`mini?baseline_minutes=${baseMinutes()}`); setState(data); setError(''); return data; }
    catch (e) { setError((e as Error).message); return null; }
  }, []);
  const loadCatalog = useCallback(async () => {
    try { const data = await api<Catalog>('meetings?mode=live'); setMeetings(data.meetings || []); setRecommended(data.recommendedRaceId || null); setCatalogMessage(data.message || ''); return data; }
    catch { return null; }
  }, []);
  const loadRecordings = useCallback(async () => {
    try { const data = await api<{ recordings: Recording[] }>('recordings'); setRecordings(data.recordings || []); } catch { /* optional list */ }
  }, []);

  useEffect(() => {
    let active = true;
    void (async () => {
      const [first, catalog] = await Promise.all([refresh(), loadCatalog()]);
      void loadRecordings();
      // Nothing selected yet: follow the recommended race like the main page.
      if (active && !booted.current && first && !first.race) {
        booted.current = true;
        try {
          const id = catalog?.recommendedRaceId;
          const race = catalog?.meetings.flatMap(m => m.races).find(r => r.id === id);
          if (race) await api('select', { mode: 'live', raceId: race.id, date: race.date, venue: race.venue, autoFollow: true });
          else await api('follow', { autoFollow: true });
          await refresh();
        } catch (e) { setError((e as Error).message); }
      }
      booted.current = true;
    })();
    const timer = setInterval(() => { if (!busyRef.current) void refresh(); }, REFRESH_MS);
    const cat = setInterval(() => void loadCatalog(), CATALOG_MS);
    const clock = setInterval(() => setTick(x => x + 1), 1000);
    const wake = () => { if (document.visibilityState === 'visible') void refresh(); };
    document.addEventListener('visibilitychange', wake);
    return () => { active = false; clearInterval(timer); clearInterval(cat); clearInterval(clock); document.removeEventListener('visibilitychange', wake); };
  }, [refresh, loadCatalog, loadRecordings]);

  async function select(body: Record<string, unknown>) {
    busyRef.current = true; setBusy(true); setError('');
    try { await api('select', body); await refresh(); }
    catch (e) { setError((e as Error).message); }
    finally { busyRef.current = false; setBusy(false); }
  }

  // Meeting options: live catalog first, then saved REPLAY recordings grouped by date + venue.
  const options: MeetingOption[] = meetings.map(m => ({
    value: `live|${m.date}|${m.venue}`, label: `${shortDate(m.date)} ${venueName(m)}`, mode: 'live', date: m.date, venue: m.venue,
    races: m.races.map(r => ({ id: r.id, no: r.no, label: `R${r.no}  ${hkTime(r.postTime, false)}` })),
  }));
  const groups = new Map<string, MeetingOption>();
  for (const rec of recordings) {
    const value = `replay|${rec.race.date}|${rec.race.venue}`;
    if (!groups.has(value)) groups.set(value, { value, label: `${shortDate(rec.race.date)} ${venueName(rec.race)}（已保存）`, mode: 'replay', date: rec.race.date, venue: rec.race.venue, races: [] });
    groups.get(value)!.races.push({ id: rec.key, no: rec.race.no, label: `R${rec.race.no}  ${rec.mode === 'live' ? 'LIVE 記錄' : rec.mode === 'imported' ? '匯入' : rec.mode.toUpperCase()}` });
  }
  const replayOptions = [...groups.values()].sort((a, b) => b.date.localeCompare(a.date) || a.venue.localeCompare(b.venue));
  for (const g of replayOptions) g.races.sort((a, b) => a.no - b.no || a.label.localeCompare(b.label));

  const race = state?.race || null;
  const mode = state?.mode || 'live';
  const isLiveLike = mode === 'live' || mode === 'mock';
  const currentMeeting = race ? `${isLiveLike ? 'live' : 'replay'}|${race.date}|${race.venue}` : '';
  const currentRaceId = isLiveLike ? race?.id || '' : state?.key || '';
  const allOptions = [...options, ...replayOptions];
  const meeting = allOptions.find(o => o.value === currentMeeting);
  const raceChoices = meeting?.races || [];
  const raceIndex = raceChoices.findIndex(r => r.id === currentRaceId);

  function chooseRace(opt: MeetingOption | undefined, id: string | undefined) {
    if (!opt || !id) return;
    if (opt.mode === 'live') void select({ mode: 'live', raceId: id, date: opt.date, venue: opt.venue, autoFollow: false });
    else void select({ mode: 'replay', raceId: id });
  }
  function chooseMeeting(value: string) { const opt = allOptions.find(o => o.value === value); chooseRace(opt, opt?.races[0]?.id); }
  async function follow() {
    const target = meetings.flatMap(m => m.races).find(r => r.id === recommended);
    if (target) await select({ mode: 'live', raceId: target.id, date: target.date, venue: target.venue, autoFollow: true });
    else {
      busyRef.current = true; setBusy(true);
      try { await api('follow', { autoFollow: true }); await refresh(); } catch (e) { setError((e as Error).message); }
      finally { busyRef.current = false; setBusy(false); }
    }
  }

  const now = Date.now() / 1000;
  const hp = state?.health;
  const lastUpdate = hp?.lastUpdate?.value ?? null;
  const age = lastUpdate != null ? Math.max(0, Math.floor(now - lastUpdate)) : null;
  // LIVE turns STALE when the source clock is older than 45 s; no race selected is idle, not an error.
  const status = !state ? 'CONNECTING' : !state.race && !error ? 'IDLE' : mode === 'live' && hp?.status === 'LIVE' && age != null && age > STALE_SECONDS ? 'STALE' : hp?.status || 'ERROR';

  return {
    state, error, busy, race, mode, status, age, now, lastUpdate, catalogMessage, options, replayOptions, meeting, currentMeeting, currentRaceId,
    raceChoices, raceIndex, chooseRace, chooseMeeting, follow,
  };
}
