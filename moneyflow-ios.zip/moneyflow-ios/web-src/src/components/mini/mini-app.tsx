'use client';

// /mini: 馬、獨贏、獨贏前、孖寶冠／亞／全 only, phone portrait first. Values from GET /api/mini
// (backend/mini.py, FORMULAS §14). Missing → "--"; nothing copied forward; STALE after 45 s.
import { useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Metric } from '@/lib/types';
import { ageText, hkDate, hkTime, metricTip, oddsText, shortDate, venueName } from './format';
import { DEFAULT_BASE_MINUTES, useMini } from './use-mini';

function Cell({ m, kind, testid }: { m?: Metric; kind: 'odds' | 'before' | 'dbl'; testid: string }) {
  const missing = !m || m.value == null;
  const ge = !missing && m?.bound === 'GE';
  return (
    <td className={`mini-num mini-${kind}${missing ? ' is-missing' : ''}`} data-testid={testid} title={metricTip(m, ge ? '≥：HKJC DBL 999 封頂，真值可能更長' : '')}>
      {ge && <span className="mini-ge">≥</span>}{missing ? '--' : oddsText(m!.value)}
    </td>
  );
}

export default function MiniApp() {
  const v = useMini();
  const rootRef = useRef<HTMLDivElement>(null);
  const headRef = useRef<HTMLElement>(null);
  // The sticky table header sits right under the sticky page header, whose height varies with the banner.
  useEffect(() => {
    const head = headRef.current, root = rootRef.current;
    if (!head || !root) return;
    const set = () => root.style.setProperty('--mini-head-h', `${Math.round(head.getBoundingClientRect().height)}px`);
    set(); const ro = new ResizeObserver(set); ro.observe(head);
    return () => ro.disconnect();
  }, []);
  const { state, race, mode, status, age, now, lastUpdate } = v;
  const stale = status === 'STALE';
  const following = !!state?.collection?.autoFollow && mode === 'live';
  const rows = state?.rows || [];
  const statusText = status === 'IDLE' ? '等待' : status === 'CONNECTING' ? '連接中' : status;
  const bl = state?.baseline;
  const beforeMinutes = bl?.minutes ?? DEFAULT_BASE_MINUTES;
  const beforeTitle = `獨贏前：開跑前 ${beforeMinutes} 分鐘凍結嘅獨贏（同完整版「排序基準（開跑前分鐘）」）` +
    (bl?.status === 'LOCKED' && bl.timestamp ? `，已鎖定 ${hkTime(bl.timestamp)}` : bl?.status === 'LATE' ? '，目標時間附近冇快照，顯示 --' : '，未到時間，顯示 --');

  let banner: { kind: string; text: string } | null = null;
  if (v.error) banner = { kind: 'error', text: v.error };
  else if (!state) banner = { kind: 'info', text: '連接中…' };
  else if (!race) banner = { kind: 'info', text: `等待可用賽事${v.catalogMessage ? `：${v.catalogMessage}` : ''}。可喺上面揀已公布或已保存嘅場次。` };
  else if (status === 'ERROR') banner = { kind: 'error', text: `來源錯誤：${state.health?.error || '未知'}（顯示最後收到數值；缺資料顯示 --）` };
  else if (stale) banner = { kind: 'stale', text: `STALE · 來源 ${ageText(age ?? 0)} 未更新（>45s）· 以下係最後收到數值，唔係即時` };
  else if (!state.frame) banner = { kind: 'info', text: '未有賠率快照（未開售或等待更新），全部顯示 --' };
  else if (mode === 'replay') banner = { kind: 'replay', text: `REPLAY · 已保存切片 ${hkTime(state.frame.timestamp)} · 非即時` };
  else if (mode === 'mock') banner = { kind: 'replay', text: 'MOCK：合成測試資料，唔係 HKJC 真數' };

  return (
    <div ref={rootRef} className={`mini-root${stale ? ' is-stale' : ''}`} data-testid="mini-root" data-status={status}>
      <header ref={headRef} className="mini-head" data-testid="mini-head">
        <div className="mini-bar">
          <h1 className="mini-h1"><a className="mini-brand" href="#/" title="返回完整版"><span className="mini-brand-mark" aria-hidden="true" />獨贏 孖寶</a></h1>
          <span className={`mini-status st-${status.toLowerCase()}`} data-testid="mini-status"><i aria-hidden="true" />{statusText}</span>
          <span className="mini-updated" data-testid="mini-updated" title={`來源時間（香港）${hkTime(lastUpdate)}，收到 ${hkTime(state?.health?.lastReceived?.value)}，${state?.snapshotCount ?? 0} 個快照`}>
            {lastUpdate != null && hkDate(lastUpdate) !== hkDate(now) && <small>{shortDate(hkDate(lastUpdate))}</small>}
            <b>{hkTime(lastUpdate)}</b>
            {age != null && mode === 'live' && <small>{ageText(age)}</small>}
          </span>
        </div>
        <div className="mini-pick">
          <button type="button" className="mini-step" aria-label="上一場" disabled={v.busy || v.raceIndex <= 0} onClick={() => v.chooseRace(v.meeting, v.raceChoices[v.raceIndex - 1]?.id)}><ChevronLeft size={20} strokeWidth={1.75} aria-hidden="true" /></button>
          <select aria-label="賽馬日／場地" data-testid="mini-meeting" value={v.meeting ? v.currentMeeting : ''} disabled={v.busy} onChange={e => v.chooseMeeting(e.target.value)}>
            {!v.meeting && <option value="">{race ? `${shortDate(race.date)} ${venueName(race)}` : '賽馬日'}</option>}
            {v.options.length > 0 && <optgroup label="HKJC LIVE">{v.options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</optgroup>}
            {v.replayOptions.length > 0 && <optgroup label="REPLAY 已保存">{v.replayOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</optgroup>}
          </select>
          <select aria-label="場次" data-testid="mini-race" value={v.raceIndex >= 0 ? v.currentRaceId : ''} disabled={v.busy || !v.raceChoices.length} onChange={e => v.chooseRace(v.meeting, e.target.value)}>
            {v.raceIndex < 0 && <option value="">{race ? `R${race.no}` : '場次'}</option>}
            {v.raceChoices.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}
          </select>
          <button type="button" className="mini-step" aria-label="下一場" disabled={v.busy || v.raceIndex < 0 || v.raceIndex >= v.raceChoices.length - 1} onClick={() => v.chooseRace(v.meeting, v.raceChoices[v.raceIndex + 1]?.id)}><ChevronRight size={20} strokeWidth={1.75} aria-hidden="true" /></button>
          <button type="button" className={`mini-follow${following ? ' is-on' : ''}`} data-testid="mini-follow" aria-pressed={following} disabled={v.busy} onClick={() => void v.follow()} title="自動跟隨今日／下一場賽事">{following ? '跟隨中' : '跟隨'}</button>
        </div>
        {race && (
          <div className="mini-race-line" data-testid="mini-race-line">
            <b>R{race.no}</b><span>{venueName(race)}</span><span>開跑 {hkTime(race.postTime, false)}</span>
            {race.distance?.value != null && <span>{Math.round(race.distance.value)}m</span>}
            {race.raceClass && <span>{race.raceClass}</span>}
          </div>
        )}
        {banner && <div className={`mini-banner b-${banner.kind}`} data-testid={banner.kind === 'stale' ? 'mini-stale-banner' : 'mini-banner'} role="status">{banner.text}</div>}
      </header>
      <table className="mini-table" data-testid="mini-table">
        <thead>
          <tr className="mini-group">
            <th rowSpan={2} className="mini-h-horse">馬</th>
            <th rowSpan={2}>獨贏</th>
            <th rowSpan={2} className="mini-h-before" data-testid="mini-before-head" data-status={bl?.status || ''} title={beforeTitle}>獨贏前<small>T−{beforeMinutes}</small></th>
            <th colSpan={3} className="mini-h-dbl" title="≈ 由 HKJC 孖寶組合賠率推算（上一關×本關）">孖寶 <small>≈</small></th>
          </tr>
          <tr className="mini-sub"><th>冠</th><th>亞</th><th>全</th></tr>
        </thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.no} data-testid="mini-row" data-runner={row.no} className={row.scratched ? 'is-scratched' : ''}>
              <td className="mini-horse"><b>{row.no}</b><span>{row.scratched ? '退出' : row.name}</span></td>
              <Cell m={row.winOdds} kind="odds" testid="mini-odds" />
              <Cell m={row.winOddsBefore} kind="before" testid="mini-before" />
              <Cell m={row.dblWinner} kind="dbl" testid="mini-dbl-w" />
              <Cell m={row.dblRunnerUp} kind="dbl" testid="mini-dbl-r" />
              <Cell m={row.dblAll} kind="dbl" testid="mini-dbl-a" />
            </tr>
          ))}
          {!rows.length && <tr><td colSpan={6} className="mini-empty">--</td></tr>}
        </tbody>
      </table>
      <footer className="mini-foot">
        <p data-testid="mini-foot-note">獨贏前＝開跑前 {beforeMinutes} 分鐘凍結嘅獨贏（同完整版「排序基準」；冇合適快照顯示 --）。孖寶冠／亞／全 ≈ 由組合賠率推算；≥＝999 封頂下限。按獨贏由低至高排，每 3 秒更新，香港時間。</p>
        <a href="#/">完整版</a>
      </footer>
    </div>
  );
}
