import type { Metric } from '@/lib/types';

export const venueName = (v?: { venue?: string; venueLabel?: string }) => v?.venueLabel || (v?.venue === 'ST' ? '沙田' : v?.venue === 'HV' ? '跑馬地' : v?.venue || '--');
export const hkTime = (t?: number | null, withSeconds = true) => t == null ? '--' : new Date(t * 1000).toLocaleTimeString('en-GB', { timeZone: 'Asia/Hong_Kong', hour12: false, ...(withSeconds ? {} : { hour: '2-digit', minute: '2-digit' }) });
export const shortDate = (d?: string) => (d ? d.slice(5).replace('-', '/') : '--');
export const hkDate = (t: number) => new Date(t * 1000).toLocaleDateString('en-CA', { timeZone: 'Asia/Hong_Kong' });
/** Source-clock age: 45s / 12分 / 9小時 / 2日 (display only). */
export const ageText = (s: number) => (s < 120 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}分` : s < 172800 ? `${Math.floor(s / 3600)}小時` : `${Math.floor(s / 86400)}日`);

/** Odds display (value untouched): below 10 always one decimal like HKJC (7 → 7.0); 10+ integer when whole, else ≤1 decimal. */
export function oddsText(value?: number | null) {
  if (value == null || !Number.isFinite(value)) return '--';
  return value < 10
    ? value.toLocaleString('en-HK', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
    : value.toLocaleString('en-HK', { maximumFractionDigits: 1 });
}
export const metricTip = (m?: Metric, extra = '') => [m?.quality || 'UNAVAILABLE', m?.source, m?.reason, extra].filter(Boolean).join(' · ');
