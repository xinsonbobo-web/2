// Node implementation of the native bridge ops (mirrors ios/MoneyFlow/Sources/NativeBridge.swift).
// Used by devserver.mjs (browser testing on the box) and by node verification scripts.
import { mkdir, readFile, writeFile, appendFile, rm, readdir, rename } from 'node:fs/promises';
import { dirname, join, normalize } from 'node:path';

export function makeNativeHandler(dataDir) {
  const safe = (p) => {
    const n = normalize(String(p || '')).replace(/^([/\\])+/, '');
    if (!n || n.startsWith('..')) throw new Error('bad path');
    return join(dataDir, n);
  };
  return async function handle(msg) {
    if (msg.op === 'http') {
      const headers = { ...(msg.headers || {}) };
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), (msg.timeout || 12) * 1000);
      try {
        const res = await fetch(msg.url, { method: msg.method || 'GET', headers, body: msg.body ?? undefined, signal: ctl.signal, redirect: 'follow' });
        const body = await res.text();
        return { status: res.status, body, setCookies: res.headers.getSetCookie ? res.headers.getSetCookie() : [] };
      } catch (e) {
        return { status: 0, body: '', error: (e && e.name === 'AbortError') ? 'timed out' : String(e && e.message || e) };
      } finally { clearTimeout(timer); }
    }
    if (msg.op === 'file') {
      const p = safe(msg.path);
      switch (msg.action) {
        case 'read': try { return { data: await readFile(p, 'utf8') }; } catch { return { data: null }; }
        case 'write': await mkdir(dirname(p), { recursive: true }); await writeFile(p + '.tmp', msg.data ?? ''); await rename(p + '.tmp', p); return { ok: true };
        case 'append': await mkdir(dirname(p), { recursive: true }); await appendFile(p, msg.data ?? ''); return { ok: true };
        case 'delete': await rm(p, { force: true }); return { ok: true };
        case 'list': try { return { names: await readdir(p) }; } catch { return { names: [] }; }
      }
    }
    if (msg.op === 'share') return { ok: false, error: 'share is only available in the iOS app' };
    if (msg.op === 'info') return { platform: 'node-dev', version: '0.6.0' };
    throw new Error('unknown op ' + msg.op);
  };
}
