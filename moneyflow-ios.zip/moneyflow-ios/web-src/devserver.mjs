// Box/desktop test server: serves the built single-file app and emulates the iOS native bridge at POST /__native
// (HTTP to HKJC via node fetch, file storage under .devdata/). Not shipped in the iOS app.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join, extname } from 'node:path';
import { makeNativeHandler } from './native-node.mjs';

const port = Number(process.env.PORT || 8795);
const root = join(process.cwd(), 'dist');
const handle = makeNativeHandler(process.env.MF_DATA_DIR || join(process.cwd(), '.devdata'));
const types = { '.html': 'text/html; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' };
createServer(async (req, res) => {
  try {
    if (req.method === 'POST' && req.url === '/__native') {
      const chunks = []; for await (const c of req) chunks.push(c);
      const out = await handle(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(out)); return;
    }
    const path = decodeURIComponent((req.url || '/').split('?')[0]);
    const file = join(root, path === '/' ? 'index.html' : path.replace(/\.\.+/g, ''));
    const data = await readFile(file);
    res.writeHead(200, { 'Content-Type': types[extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(data);
  } catch (e) {
    res.writeHead(req.url === '/__native' ? 500 : 404, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ __error: String(e && e.message || e) }));
  }
}).listen(port, '127.0.0.1', () => console.log(`Money Flow dev: http://127.0.0.1:${port}`));
