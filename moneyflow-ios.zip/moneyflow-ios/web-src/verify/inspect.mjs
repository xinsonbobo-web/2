import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await page.goto('http://127.0.0.1:8795/');
await page.waitForTimeout(5000);
const trig = page.locator('[data-slot=select-trigger]');
await trig.filter({hasText:/S2|沙田|跑馬地/}).first().click(); await page.waitForTimeout(400);
await page.getByRole('option',{name:/沙田/}).first().click(); await page.waitForTimeout(1500);
await trig.filter({hasText:/^R\d/}).first().click(); await page.waitForTimeout(400);
await page.getByRole('option',{name:/^R5/}).first().click(); await page.waitForTimeout(Number(process.env.WAIT2||6000));
const r = await page.evaluate(() => {
  const out = [];
  for (const sel of ['.workspace', '.chart-panel', '.chart-scroll', '.chart', '.bars', '.runner', '.bar-zone', '.chart-scale']) {
    const e = document.querySelector(sel); if (!e) { out.push(sel + ' missing'); continue; }
    const cs = getComputedStyle(e);
    out.push(`${sel} rect=${Math.round(e.getBoundingClientRect().height)} h=${cs.height} minh=${cs.minHeight} disp=${cs.display} flex=${cs.flex} pos=${cs.position} style=${e.getAttribute('style')}`);
  }
  // matched rules for .chart
  const hits = [];
  const chart = document.querySelector('.chart');
  const bz = document.querySelector('.bar-zone');
  for (const sh of document.styleSheets) { let rules; try { rules = sh.cssRules } catch { continue }
    const walk = (rs, media) => { for (const ru of rs) { if (ru.cssRules && !ru.selectorText) { walk(ru.cssRules, ru.conditionText || media); continue; }
      if (!ru.selectorText) continue;
      try { if ([chart,bz,document.querySelector('.runner'),document.querySelector('.bars'),document.querySelector('.chart-scroll'),document.querySelector('.chart-panel')].some(x=>x&&x.matches(ru.selectorText)) && /height|flex/.test(ru.style.cssText)) hits.push((media||'') + ' | ' + ru.selectorText + ' {' + ru.style.cssText + '}'); } catch {} } };
    walk(rules, ''); }
  return out.concat(hits);
});
console.log(r.join('\n'));
await browser.close();
