// Mini screenshot with live HKJC data for a given race (default 2026-09-27 ST R5, via the backend's select — same as POST /api/select).
import { chromium } from 'playwright';
const base = process.env.URL || 'http://127.0.0.1:8795/';
const out = process.env.OUT || '/workspace/moneyflow-mini-shot.png';
const [date, venue, no] = (process.env.RACE || '2026-09-27,ST,5').split(',');
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
await page.goto(base + '#/mini'); await page.waitForTimeout(3000);
console.log('before', await page.evaluate(() => document.querySelector('[data-testid=mini-banner]')?.textContent));
const r = await page.evaluate(async ([d, v, n]) => { const s = globalThis.__moneyflow; const x = await s.select('live', `${d}_${v}_${n}`, d, v, false); return x?.race?.id || JSON.stringify(x).slice(0, 200); }, [date, venue, no]);
console.log('selected', r);
await page.waitForTimeout(Number(process.env.WAIT || 10000));
const info = await page.evaluate(() => ({ status: document.querySelector('[data-testid=mini-status]')?.textContent, rows: document.querySelectorAll('[data-testid=mini-row]').length,
  banner: document.querySelector('[data-testid=mini-banner],[data-testid=mini-stale-banner]')?.textContent, before: document.querySelector('[data-testid=mini-before-head]')?.getAttribute('data-status'),
  first: [...document.querySelectorAll('[data-testid=mini-row]')].slice(0, 4).map((x) => [...x.querySelectorAll('td')].map((td) => td.textContent).join(' ')) }));
console.log(JSON.stringify(info, null, 1));
await page.screenshot({ path: out });
await page.screenshot({ path: out.replace('.png', '-full.png'), fullPage: true });
await browser.close();
