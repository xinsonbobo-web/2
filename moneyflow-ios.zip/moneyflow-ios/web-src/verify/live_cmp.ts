/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-ignore
import { makeNativeHandler } from '../native-node.mjs';
import { writeFileSync } from 'node:fs';
import { LiveAdapter } from '../src/backend/sources';
const handle = makeNativeHandler('/tmp/mf-live-test');
(globalThis as any).webkit = { messageHandlers: { native: { postMessage: (m: any) => handle(m) } } };
(globalThis as any).__MF_SNAPSHOT_ID__ = () => 'X';
(async () => {
  const ad = new LiveAdapter();
  const cat = await ad.catalog();
  const race = cat.meetings.flatMap((m: any) => m.races).find((r: any) => r.id === '2026-09-27_ST_5');
  const s = await ad.fetch(race);
  writeFileSync('/tmp/live_js.json', JSON.stringify({ catalog: cat, snap: s }));
  console.log('js ok');
})();
