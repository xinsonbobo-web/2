/* eslint-disable @typescript-eslint/no-explicit-any */
import { readFileSync, writeFileSync } from 'node:fs';
(globalThis as any).__MF_SNAPSHOT_ID__ = (s: any) => 'T' + String(s.timestamp);
import * as S from '../src/backend/sources';
import { analyze } from '../src/backend/engine';
import * as FT from '../src/backend/flow007';
import * as PG from '../src/backend/postgate';
import { Service } from '../src/backend/service';

const dec = (x: any): any => {
  if (Array.isArray(x)) return x.map(dec);
  if (x && typeof x === 'object') {
    if (Object.keys(x).length === 1 && '__f' in x) return x.__f === 'nan' ? NaN : x.__f === 'inf' ? Infinity : -Infinity;
    return Object.fromEntries(Object.entries(x).map(([k, v]) => [k, dec(v)]));
  }
  return x;
};
const enc = (x: any): any => {
  if (typeof x === 'number') return Number.isNaN(x) ? { __f: 'nan' } : x === Infinity ? { __f: 'inf' } : x === -Infinity ? { __f: '-inf' } : x;
  if (x instanceof Map) return Object.fromEntries([...x].map(([k, v]) => [String(k), enc(v)]));
  if (x instanceof Set) return [...x].map(enc);
  if (Array.isArray(x)) return x.map(enc);
  if (x && typeof x === 'object') return Object.fromEntries(Object.entries(x).filter(([, v]) => v !== undefined).map(([k, v]) => [k, enc(v)]));
  return x === undefined ? null : x;
};
const run = (fn: () => any) => { try { return enc(fn()); } catch (e) { return { __error__: (e as Error).constructor.name + ': ' + (e as Error).message }; } };
const clone = (x: any) => structuredClone(x);
const cases = dec(JSON.parse(readFileSync((process.env.MF_VERIFY_DIR || '/workspace/mf-verify') + '/inputs.json', 'utf8')));
const outs: any[] = [];
let clock = 0;
(globalThis as any).__MF_NOW__ = () => (clock ? clock : Date.now() / 1000);
const t0 = Date.now();
const timing: Record<string, number> = {};
async function main() {
for (const c of cases) {
  const t1 = Date.now();
  let o: any;
  switch (c.kind) {
    case 'validate': o = run(() => S.ReplayAdapter.validate(clone(c.doc))); break;
    case 'analyze': o = run(() => analyze(clone(c.race), clone(c.snaps), c.config)); break;
    case 'mock': o = run(() => S.MockAdapter.snapshots(S.MockAdapter.race(c.no))); break;
    case 'cards': o = run(() => S.normalizeCards(clone(c.payload))); break;
    case 'recommend': o = run(() => S.recommendRace(clone(c.meetings), c.now)); break;
    case 'snapseq': o = run(() => {
      const ad = new S.LiveAdapter(); const out: any[] = [];
      for (const it of c.seq) {
        try { out.push(ad.alignWin(S.normalizeSnapshot(clone(it.race), clone(it.card), clone(it.odds), it.receivedAt, it.latency))); }
        catch (e) { out.push({ __error__: 'ValueError: ' + (e as Error).message }); }
      }
      return out;
    }); break;
    case 'flow007': o = run(() => {
      const snaps = c.lines.map((d: any) => FT.fromRecorderLine(d, d.epoch));
      const res: any = {};
      const cut = FT.cutMinutes(c.overseas ? 'overseas' : 'local');
      for (const ver of ['V0', 'V1', 'V2']) {
        const step = Math.max(1, Math.floor(snaps.length / 12));
        const pick = snaps.filter((_: any, i: number) => i % step === 0).concat([snaps[snaps.length - 1]]);
        for (const s of pick) res[`${ver}@${reprFloat(s.ts)}`] = FT.evaluateAsof(snaps, c.post, cut, FT.PARAMS[ver], s.ts);
      }
      res.conv = snaps.map((s: any) => ({ ts: s.ts, horses: s.horses, valid: s.valid, reason: s.reason, qt: s.qin_total }));
      return res;
    }); break;
    case 'fttool': o = run(() => {
      const canon = c.snaps.map((x: any) => FT.fromToolSnapshot(x, c.race));
      const cut = FT.cutMinutes(c.race.venueKind ?? null, c.race.venue ?? null);
      return { conv: canon.map((k: any) => ({ ts: k.ts, horses: k.horses, valid: k.valid, reason: k.reason, alignWarn: k.alignWarn, qt: k.qin_total, qpt: k.qpl_total })),
        ev: canon.map((k: any) => FT.evaluateAsof(canon, c.race.postTime, cut, FT.PARAMS.V1, k.ts)) };
    }); break;
    case 'dblfit': o = run(() => ({ fit: c.vals.map(S.fitDblOdds), all: c.vals.map(S.fitDblAll), price: c.cols.map(S.dblAllPrice) })); break;
    case 'fct': o = run(() => c.cases.map((x: any) => S.parseFctDirectMatrix(clone(x.payload), x.active, x.total, x.mts, x.pts))); break;
    case 'postgate': o = run(() => ({
      seg: c.seg.map(([a, b]: any) => PG.segment(a, b)), half: c.half.map(PG.halfUp),
      split: [c.post, null, 'x', NaN, 0].flatMap((p) => [0.0, 1.0, 2.5].map((off) => PG.splitTs(p, off))),
      pick: c.picks.map((k: any) => PG.pickGate(k.points.map((p: any) => [p[0], p[1]]), k.split, k.maxAge)),
      bar: c.bars.map(PG.barDisplay),
      main: c.mv.map((k: any) => PG.mainView(clone(k.frames), k.post, k.offset, k.maxAge)) })); break;
    case 'pgsvc': o = await runAsync(async () => {
      clock = c.clock;
      const svc = new Service(null); await svc.ready;
      const key = 'imported:pg:' + c.doc.race.id;
      svc.store.saveRace(key, 'imported', clone(c.doc.race));
      for (const s of clone(c.doc.snapshots)) svc.store.add(key, s);
      svc.selected = { mode: 'replay', key, race: clone(c.doc.race) };
      if (!svc.sessions.has(key)) svc.sessions.set(key, { error: null, lastReceived: null, latency: null, polling: false });
      const ids = (await svc.store.snapshots(key)).map((x: any) => x.id);
      const fts: any = {};
      for (const fid of [null, ...ids, 'nope']) { const ft = await svc.flowTrial(fid); delete ft.computeMs; fts[fid === null ? 'None' : String(fid)] = ft; }
      const out: any = { ft: fts, settings: Object.fromEntries(['postGatePost:', 'flowTrialPost:'].map((k) => [k, svc.store.setting(k + key)])) };
      if (c.doc.race.postTime !== null && c.doc.race.postTime !== undefined) {
        const st = await svc.state(); const st2 = await svc.state({ window: 30, baseline_minutes: 10 });
        Object.assign(out, { postGate: st.postGate, postGate2: st2.postGate, frameTs: st.frames.map((f: any) => f.timestamp) });
      }
      return out;
    }); break;
    default: o = { __error__: 'unknown kind ' + c.kind };
  }
  outs.push(o);
  timing[c.kind] = (timing[c.kind] || 0) + (Date.now() - t1);
}
}
async function runAsync(fn: () => Promise<any>) { try { return enc(await fn()); } catch (e) { return { __error__: (e as Error).constructor.name + ': ' + (e as Error).message }; } }
function reprFloat(x: number) { return Number.isInteger(x) ? x.toFixed(1) : String(x); }
void 0;
function finish() {
writeFileSync((process.env.MF_VERIFY_DIR || '/workspace/mf-verify') + '/js_out.json', JSON.stringify(outs));
console.log('done', cases.length, 'cases in', Date.now() - t0, 'ms', JSON.stringify(timing));
}
main().then(finish);
