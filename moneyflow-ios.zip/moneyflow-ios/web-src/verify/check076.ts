/** v0.7.6: TS rebound + trialTone vs the Python formula. Gate 90, later min 85, now 98 → 8, not 13. */
import { rebound } from '../src/backend/postgate';
import { trialTone } from '../src/components/money-flow/flow-trial-panel';

function assert(cond: unknown, msg: string) {
  if (!cond) { console.error('FAIL', msg); process.exitCode = 1; }
  else console.log('ok', msg);
}

assert(rebound(98, 90) === 8, 'rebound(98, 90) === 8');
assert(rebound(98, 90) !== 13, 'rebound is not the later-minimum rise 13');
assert(rebound(90, 90) === 0, 'flat vs gate is 0');
assert(rebound(85, 90) === 0, 'below gate is 0, never negative');
assert(rebound(25, 20) === 5, 'rebound(25, 20) === 5');
assert(rebound(20, null) === null, 'missing gate');
assert(rebound(null, 90) === null, 'missing current');

const tone = trialTone(98, 70, rebound(98, 90));
assert(tone && !tone.solid && tone.rebShown === 8, `rebShown is 8 (got ${tone && !tone.solid ? tone.rebShown : tone})`);
const wrong = trialTone(98, 70, Math.max(0, 98 - 85));
assert(wrong && !wrong.solid && wrong.rebShown === 13, 'v0.7.5 min formula would have shown 13');
assert(tone && !tone.solid && tone.sliceShare > 0 && tone.sliceShare < 1, 'third colour sits inside the bar');
const flat = trialTone(90, 70, rebound(90, 90));
assert(flat && !flat.solid && flat.rebShown === 0 && flat.sliceShare === 0, 'no increase → sliceShare 0, do not draw');
const down = trialTone(85, 70, rebound(85, 90));
assert(down && !down.solid && down.sliceShare === 0, 'below gate → no third colour');
// height input is the flow, not flow+rebound
assert(Math.max(5, Math.min(98, 200) / 200 * 100) === 49, 'bar height still flow/200');

if (process.exitCode) process.exit(process.exitCode);
console.log('ALL PASS');
