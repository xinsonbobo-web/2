// Simulate the iOS WKScriptMessageHandlerWithReply bridge in Chrome: page served by a plain static server
// (no /__native), window.webkit.messageHandlers.native.postMessage → Promise backed by native-node.mjs.
import { chromium } from 'playwright';
import { makeNativeHandler } from '../native-node.mjs';
import { mkdtempSync, readdirSync } from 'node:fs';
const dir = mkdtempSync('/tmp/mf-bridge-');
const handle = makeNativeHandler(dir);
const ops = {};
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
const logs = [];
page.on('console', (m) => logs.push(m.type() + ': ' + m.text()));
page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
await page.exposeFunction('__nativeCall', async (json) => {
  const msg = JSON.parse(json); const k = msg.op + (msg.action ? ':' + msg.action : ''); ops[k] = (ops[k] || 0) + 1;
  return JSON.stringify(await handle(msg));
});
await page.addInitScript(() => {
  window.webkit = { messageHandlers: { native: { postMessage: async (m) => JSON.parse(await window.__nativeCall(JSON.stringify(m))) } } };
});
await page.goto('http://127.0.0.1:8796/index.html');
await page.waitForTimeout(6000);
const trig = page.locator('[data-slot=select-trigger]');
await trig.filter({hasText:/S2|沙田|跑馬地/}).first().click(); await page.waitForTimeout(400);
await page.getByRole('option',{name:/沙田/}).first().click(); await page.waitForTimeout(1500);
await trig.filter({hasText:/^R\d/}).first().click(); await page.waitForTimeout(400);
await page.getByRole('option',{name:/^R5/}).first().click(); await page.waitForTimeout(8000);
const st = await page.evaluate(async () => { const mf = globalThis.__moneyflow; return mf ? JSON.stringify({selected: mf.selected, err: mf.collectionError, sessions: Object.keys(mf.sessions||{})}).slice(0,800) : 'none'; });
console.log('mf keys', st);
const info = await page.evaluate(async () => { const r = await fetch('/api/health').catch(() => null); return { apiViaNetwork: r ? r.status : 'fail', text: document.body.innerText.slice(0, 300) }; });
console.log(JSON.stringify(ops));
console.log('files', readdirSync(dir), readdirSync(dir).includes('snaps') ? readdirSync(dir + '/snaps') : []);
console.log(info.text.replace(/\n/g, ' | '));
console.log(logs.filter(l => !/favicon/.test(l)).slice(0, 10).join('\n'));
await browser.close();
