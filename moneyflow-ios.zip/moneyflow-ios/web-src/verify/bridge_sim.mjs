// Simulate the iOS WKScriptMessageHandlerWithReply bridge in Chrome: page served by a plain static server
// (no /__native), window.webkit.messageHandlers.native.postMessage → Promise backed by native-node.mjs.
// Seeds the store with a saved replay (SEED dir) so replay, export and Mini can be exercised offline.
import { chromium } from 'playwright';
import { makeNativeHandler } from '../native-node.mjs';
import { mkdtempSync, readdirSync, cpSync } from 'node:fs';
const dir = mkdtempSync('/tmp/mf-bridge-');
if (process.env.SEED) cpSync(process.env.SEED, dir, { recursive: true });
const handle = makeNativeHandler(dir);
const ops = {};
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
const logs = [];
page.on('console', (m) => logs.push(m.type() + ': ' + m.text()));
page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
page.on('dialog', (d) => { logs.push('DIALOG: ' + d.message()); d.dismiss(); });
await page.exposeFunction('__nativeCall', async (json) => {
  const msg = JSON.parse(json); const k = msg.op + (msg.action ? ':' + msg.action : ''); ops[k] = (ops[k] || 0) + 1;
  if (msg.op === 'share') return JSON.stringify({ ok: true, bytes: String(msg.content || msg.data || '').length });
  return JSON.stringify(await handle(msg));
});
await page.addInitScript(() => {
  window.webkit = { messageHandlers: { native: { postMessage: async (m) => JSON.parse(await window.__nativeCall(JSON.stringify(m))) } } };
});
await page.goto('http://127.0.0.1:8796/index.html' + (process.env.HASH || ''));
await page.waitForTimeout(6000);
console.log('boot status', await page.locator('[data-testid=chrome-status]').textContent());
const pick = async (label, re) => { await page.locator(`[data-slot=select-trigger][aria-label="${label}"]`).first().click(); await page.waitForTimeout(400); await page.getByRole('option', { name: re }).first().click(); await page.waitForTimeout(1500); };
if (process.env.SEED) {
  await pick('數據來源', /REPLAY/); await pick('已保存賽事', /2026-09-27.*R5/);
  await page.getByRole('button', { name: /載入 REPLAY/ }).click(); await page.waitForTimeout(6000);
  console.log('replay status', await page.locator('[data-testid=chrome-status]').textContent(), 'rows', await page.locator('.mf-table tbody tr').count());
  await page.locator('[aria-label="匯出切片"]').click(); await page.waitForTimeout(2000);
  await page.getByRole('button', { name: 'Mini', exact: true }).click(); await page.waitForTimeout(3000);
  await page.selectOption('[data-testid=mini-meeting]', 'replay|2026-09-27|ST').catch(() => {}); await page.waitForTimeout(1500);
  await page.selectOption('[data-testid=mini-race]', 'live:2026-09-27_ST_5').catch(() => {}); await page.waitForTimeout(4000);
  console.log('mini', page.url().split('#')[1], 'rows', await page.locator('[data-testid=mini-row]').count(), await page.locator('[data-testid=mini-status]').textContent());
}
const info = await page.evaluate(async () => { const r = await fetch('/api/health').catch(() => null); return { apiViaNetwork: r ? r.status : 'fail' }; });
console.log('ops', JSON.stringify(ops), 'static /api/health →', info.apiViaNetwork, '(API must not use network)');
console.log('files', readdirSync(dir));
console.log(logs.filter(l => !/favicon|404/.test(l)).slice(0, 12).join('\n') || 'no console errors / page errors');
await browser.close();
