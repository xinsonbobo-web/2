/* eslint-disable @typescript-eslint/no-explicit-any */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { handleApi, Service } from '../src/backend/service';
import { MemoryDriver } from '../src/backend/storage';
import { PyValueError } from '../src/backend/py';
import { OSError } from '../src/backend/native';

let clock = 0;
(globalThis as any).__MF_NOW__ = () => clock;
(globalThis as any).__MF_SNAPSHOT_ID__ = (s: any) => 'T' + String(s.timestamp).replace('.', '_');
const TAG = process.env.E2E_TAG ? '_' + process.env.E2E_TAG : '';
const RACE = process.env.E2E_RACE || '5';
const script = JSON.parse(readFileSync(`/workspace/mf-verify/e2e${TAG}_script.json`, 'utf8'));
const sortKeys = (x: any): any => Array.isArray(x) ? x.map(sortKeys) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, sortKeys(x[k])])) : x;
const qkey = (name: string, vars: any) => name + '|' + JSON.stringify(sortKeys(vars));

async function main() {
  const driver = new MemoryDriver();
  const svc = new Service(driver);
  const install = (s: Service) => {
    s.adapter.query = async (name: string, variables: any) => {
      let best: any = null;
      for (const [t, p] of script.transport[qkey(name, variables)] || []) if (t <= clock + 5) best = p;
      if (best === null) throw new OSError('HKJC HTTP 503');
      const result = structuredClone(best);
      const received = clock, latency = 100.0;
      s.adapter.lastReceived = received; s.adapter.lastLatency = latency;
      s.adapter.rawSink!({ query: name, variables, receivedAt: received, latency, payload: result });
      if (result.errors) throw new PyValueError('HKJC GraphQL: ' + JSON.stringify(result.errors).slice(0, 500));
      return [result, latency];
    };
  };
  install(svc);
  const outs: any[] = []; let first: string | null = null; let exportDoc: any = null;
  const t0 = Date.now(); let stateMs = 0, stateN = 0;
  for (const st of script.steps) {
    if (st.op === 'clock') { clock = st.t; continue; }
    if (st.op === 'poll') { await svc.poll(true); continue; }
    if (st.op === 'import_export') { const r = await handleApi(svc, 'POST', 'import', JSON.parse(JSON.stringify(exportDoc))); outs.push({ step: 'import', status: r.status, body: r.body }); continue; }
    const path = st.path.replace('@FIRST', first || '');
    const t1 = Date.now();
    const r = await handleApi(svc, st.method, path, st.body === undefined ? undefined : JSON.parse(JSON.stringify(st.body)));
    if (st.path.startsWith('state')) { stateMs += Date.now() - t1; stateN++; }
    if (st.path.startsWith('state') && r.body.frames?.length && first === null) first = r.body.frames[0].id;
    if (st.path === 'export') exportDoc = r.body;
    outs.push({ step: st.method + ' ' + path, status: r.status, body: r.body });
  }
  writeFileSync(`/workspace/mf-verify/e2e${TAG}_js_out.json`, JSON.stringify(outs));
  console.log('responses', outs.length, 'in', Date.now() - t0, 'ms; avg state', (stateMs / stateN).toFixed(1), 'ms');
  if (process.env.E2E_DUMP) { // write the stored recording (same files the app keeps) to a directory, e.g. for devserver MF_DATA_DIR
    await svc.store.flush();
    for (const [name, text] of driver.files) { const p = process.env.E2E_DUMP + '/' + name; mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, text); }
    console.log('dumped', [...driver.files.keys()].join(' '));
  }
  // persistence round-trip: a fresh Service over the same files must render the same replay state
  await svc.store.flush();
  const svc2 = new Service(driver); install(svc2); await svc2.ready;
  const a = await handleApi(svc, 'POST', 'select', { mode: 'replay', raceId: `live:2026-09-27_ST_${RACE}`, window: 60, baseline_minutes: 15 });
  const b = await handleApi(svc2, 'POST', 'select', { mode: 'replay', raceId: `live:2026-09-27_ST_${RACE}`, window: 60, baseline_minutes: 15 });
  const strip = (x: any) => JSON.stringify(x, (k, v) => (k === 'collection' || k === 'health' ? undefined : v));
  const diffs: string[] = [];
  const walk = (x: any, y: any, path: string) => {
    if (diffs.length > 12) return;
    if (x && y && typeof x === 'object' && typeof y === 'object') { for (const k of new Set([...Object.keys(x), ...Object.keys(y)])) if (k !== 'collection' && k !== 'health') walk(x[k], y[k], path + '.' + k); return; }
    if (JSON.stringify(x) !== JSON.stringify(y)) diffs.push(path + ' ' + JSON.stringify(x)?.slice(0, 120) + ' | ' + JSON.stringify(y)?.slice(0, 120));
  };
  walk(a.body, b.body, '');
  console.log(diffs.join('\n'));
  console.log('reload equal:', strip(a.body) === strip(b.body), 'frames', a.body.frames?.length, b.body.frames?.length, 'marks', JSON.stringify(b.body.marks), 'files', [...driver.files.keys()].join(' '), 'bytes', [...driver.files.values()].reduce((n, s) => n + s.length, 0));
}
main();
