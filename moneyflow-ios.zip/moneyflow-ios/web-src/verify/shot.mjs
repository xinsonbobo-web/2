import { chromium } from 'playwright';
const url = process.env.URL || 'http://127.0.0.1:8795/';
const w = Number(process.env.W || 1440), h = Number(process.env.H || 1000);
const out = process.env.OUT || '/workspace/mf-shots/initial.png';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: Number(process.env.DPR || 1), isMobile: w < 700, hasTouch: w < 700 });
const logs = [];
page.on('console', (m) => logs.push(m.type() + ': ' + m.text()));
page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
await page.goto(url);
await page.waitForTimeout(Number(process.env.WAIT || 6000));
if (process.env.SCRIPT) { const fn = new Function('page', 'return (async()=>{' + process.env.SCRIPT + '})()'); await fn(page); }
await page.screenshot({ path: out, fullPage: process.env.FULL === '1' });
console.log(logs.slice(0, 30).join('\n'));
console.log('title', await page.title());
await browser.close();
