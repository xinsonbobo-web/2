// v0.7.3 1 s conditional poll in-app: an unchanged replay must not re-render (in-page ETag/304), and state is read every ~1 s.
import { chromium } from 'playwright';
const base = process.env.URL || 'http://127.0.0.1:8795/';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
await page.goto(base + '#/'); await page.waitForTimeout(3000);
const pick = async (label, re) => { await page.locator(`[data-slot=select-trigger][aria-label="${label}"]`).first().click(); await page.waitForTimeout(400); await page.getByRole('option', { name: re }).first().click(); await page.waitForTimeout(1200); };
await pick('數據來源', /REPLAY/); await pick('已保存賽事', /2026-09-27.*R5/);
await page.getByRole('button', { name: /載入 REPLAY/ }).click(); await page.waitForTimeout(5000);
await page.evaluate(() => {
  const s = globalThis.__moneyflow; const orig = s.stateWithEtag.bind(s); const origFt = s.flowTrialWithEtag.bind(s);
  globalThis.__calls = { state: 0, ft: 0, ft304: 0 };
  s.stateWithEtag = async (...a) => { globalThis.__calls.state++; return orig(...a); };
  s.flowTrialWithEtag = async (f, inm) => { globalThis.__calls.ft++; const r = await origFt(f, inm); if (r[0] === null) globalThis.__calls.ft304++; return r; };
});
const r0 = await page.evaluate(() => ({ ...globalThis.__mfRenders }));
await page.waitForTimeout(6000);
const r1 = await page.evaluate(() => ({ renders: { ...globalThis.__mfRenders }, calls: globalThis.__calls }));
console.log('renders before', JSON.stringify(r0));
console.log('renders after 6 s', JSON.stringify(r1.renders), 'backend calls in 6 s', JSON.stringify(r1.calls));
await browser.close();
