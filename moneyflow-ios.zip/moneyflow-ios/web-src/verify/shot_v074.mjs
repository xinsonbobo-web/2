// v0.7.4 UI on a phone (390 px): main board on the saved 09-27 ST R5 replay, layout sanity, Mini, navigation.
import { chromium } from 'playwright';
const base = process.env.URL || 'http://127.0.0.1:8795/';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const logs = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); });
page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
page.on('response', (r) => { if (r.status() >= 400) logs.push('HTTP ' + r.status() + ' ' + r.url()); });
page.on('requestfailed', (r) => logs.push('REQFAIL ' + r.url()));
await page.goto(base + '#/'); await page.waitForTimeout(4000);
const pick = async (label, re) => { await page.locator(`[data-slot=select-trigger][aria-label="${label}"]`).first().click(); await page.waitForTimeout(400); await page.getByRole('option', { name: re }).first().click(); await page.waitForTimeout(1500); };
await pick('數據來源', /REPLAY/);
await pick('已保存賽事', /2026-09-27.*R5/);
await page.getByRole('button', { name: /載入 REPLAY/ }).click(); await page.waitForTimeout(1500);
await page.waitForTimeout(Number(process.env.WAIT || 6000));
const errText = await page.locator('.mf-error, [role=alert]').allTextContents().catch(() => []); console.log('alerts', JSON.stringify(errText));
const m = await page.evaluate(() => {
  const h = (s) => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().height) : null; };
  return { docH: document.documentElement.scrollHeight, rail: h('.mf-rail'), table: h('.mf-table-panel'), transport: h('.mf-transport'), chartScroll: h('.mf-chart-scroll'), chart: h('.mf-chart'), spectrum: h('.mf-spectrum'), drawer: h('.mf-drawer'),
    status: document.querySelector('[data-testid=chrome-status]')?.textContent, race: document.querySelector('[data-testid=race-inline]')?.textContent, rows: document.querySelectorAll('.mf-table tbody tr').length,
    fonts: [...document.fonts].filter((f) => f.status === 'loaded').map((f) => f.family + ' ' + f.weight), bodyPad: getComputedStyle(document.body).paddingBottom, overflowX: document.documentElement.scrollWidth };
});
console.log('main', JSON.stringify(m));
const pg = await page.evaluate(() => ({ segs: document.querySelectorAll('[class*=pg], [data-testid*=post-gate], [class*=post-gate]').length,
  legend: [...document.querySelectorAll('*')].filter((e) => e.children.length === 0 && /入閘後/.test(e.textContent || '')).length,
  headers: [...document.querySelectorAll('.mf-table thead tr:last-child th')].map((t) => t.textContent.trim()).join('|'),
  wide: [...document.querySelectorAll('body *')].filter((e) => { const r = e.getBoundingClientRect(); return r.right > window.innerWidth + 1 && getComputedStyle(e).position !== 'fixed'; }).slice(0, 8).map((e) => e.className + ':' + Math.round(e.getBoundingClientRect().right)),
  renders: window.__mfRenders }));
console.log('postgate/layout', JSON.stringify(pg));
await page.screenshot({ path: '/workspace/mf4-main.png' });
await page.screenshot({ path: '/workspace/mf4-main-full.png', fullPage: true });
// Mini via the floating switch
await page.getByRole('button', { name: 'Mini', exact: true }).click(); await page.waitForTimeout(2500);
console.log('after Mini click', await page.evaluate(() => location.hash));
const opts = await page.locator('[data-testid=mini-meeting] option').evaluateAll((os) => os.map((o) => o.value));
console.log('mini meetings', opts.join(' | '));
if (opts.includes('replay|2026-09-27|ST')) { await page.selectOption('[data-testid=mini-meeting]', 'replay|2026-09-27|ST'); await page.waitForTimeout(1500); await page.selectOption('[data-testid=mini-race]', 'live:2026-09-27_ST_5'); }
await page.waitForTimeout(5000);
const mi = await page.evaluate(() => ({ status: document.querySelector('[data-testid=mini-status]')?.textContent, rows: document.querySelectorAll('[data-testid=mini-row]').length,
  before: document.querySelector('[data-testid=mini-before-head]')?.getAttribute('data-status'), docH: document.documentElement.scrollHeight,
  first: [...document.querySelectorAll('[data-testid=mini-row]')].slice(0, 3).map((x) => [...x.querySelectorAll('td')].map((td) => td.textContent).join(' ')) }));
console.log('mini', JSON.stringify(mi));
await page.screenshot({ path: '/workspace/mf4-mini.png' });
await page.screenshot({ path: '/workspace/mf4-mini-full.png', fullPage: true });
await page.reload(); await page.waitForTimeout(2500);
console.log('after reload', await page.evaluate(() => location.hash), 'mini-root', await page.locator('[data-testid=mini-root]').count());
await page.getByRole('button', { name: '主頁', exact: true }).click(); await page.waitForTimeout(2500);
console.log('after 主頁 click', await page.evaluate(() => location.hash), 'main', await page.locator('main.mf').count());
await page.locator('button[aria-label="公式與設定"]').click(); await page.waitForTimeout(800);
const link = page.locator('[data-testid=mini-link]');
console.log('settings mini-link', await link.getAttribute('href'));
await link.click(); await page.waitForTimeout(2500);
console.log('via settings', await page.evaluate(() => location.hash), (await page.locator('[data-testid=mini-before-head]').textContent())?.trim());
const p2 = await ctx.newPage(); await p2.goto(base); await p2.waitForTimeout(2000);
console.log('new tab (no hash) opens', await p2.evaluate(() => location.hash));
console.log(logs.filter((l) => !/favicon/.test(l)).slice(0, 15).join('\n') || 'no page errors');
await browser.close();
