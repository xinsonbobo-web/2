// Phone-width Mini screenshot + view-switch checks (devserver on :8795 must be running).
import { chromium } from 'playwright';
const base = process.env.URL || 'http://127.0.0.1:8795/';
const out = process.env.OUT || '/workspace/moneyflow-mini-shot.png';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const logs = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); });
page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
await page.goto(base);
await page.waitForTimeout(4000);
console.log('start hash', await page.evaluate(() => location.hash), 'switch visible', await page.locator('[data-testid=view-switch]').isVisible());
await page.getByRole('button', { name: 'Mini', exact: true }).click();
await page.waitForTimeout(3000);
console.log('after Mini click', await page.evaluate(() => location.hash), 'mini-root', await page.locator('[data-testid=mini-root]').count());
const meetings = await page.locator('[data-testid=mini-meeting] option').evaluateAll((os) => os.map((o) => o.value + '=' + o.textContent));
console.log('meeting options', meetings.join(' | '));
const want = process.env.MEETING || meetings.map((m) => m.split('=')[0]).find((v) => v.includes('|ST')) || meetings[0].split('=')[0];
await page.selectOption('[data-testid=mini-meeting]', want);
await page.waitForTimeout(2500);
const races = await page.locator('[data-testid=mini-race] option').evaluateAll((os) => os.map((o) => o.value));
const raceId = process.env.RACE_ID || races.find((r) => /_5$/.test(r)) || races[0];
await page.selectOption('[data-testid=mini-race]', raceId);
await page.waitForTimeout(Number(process.env.WAIT || 9000));
const info = await page.evaluate(() => ({ status: document.querySelector('[data-testid=mini-status]')?.textContent, rows: document.querySelectorAll('[data-testid=mini-row]').length,
  line: document.querySelector('[data-testid=mini-race-line]')?.textContent, first: [...document.querySelectorAll('[data-testid=mini-row]')].slice(0, 3).map((r) => r.textContent) }));
console.log('mini', JSON.stringify(info));
await page.screenshot({ path: out });
await page.screenshot({ path: out.replace('.png', '-full.png'), fullPage: true });
await page.reload(); await page.waitForTimeout(2500);
console.log('after reload hash', await page.evaluate(() => location.hash), 'mini-root', await page.locator('[data-testid=mini-root]').count());
await page.getByRole('button', { name: '主頁', exact: true }).click(); await page.waitForTimeout(2500);
console.log('after 主頁 click', await page.evaluate(() => location.hash), 'mini-root', await page.locator('[data-testid=mini-root]').count());
const p2 = await ctx.newPage(); await p2.goto(base); await p2.waitForTimeout(2000);
console.log('new tab opens', await p2.evaluate(() => location.hash));
// settings link → Mini with base
await p2.locator('button[aria-label*="設定"], button[title*="設定"]').first().click().catch(() => {});
await p2.waitForTimeout(800);
const link = p2.locator('[data-testid=mini-link]');
console.log('mini-link', await link.count(), await link.getAttribute('href').catch(() => null));
if (await link.count()) { await link.click(); await p2.waitForTimeout(3000); console.log('via settings', await p2.evaluate(() => location.hash), await p2.locator('[data-testid=mini-before-head]').textContent()); }
console.log(logs.slice(0, 10).join('\n'));
await browser.close();
