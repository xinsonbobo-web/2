/* eslint-disable @typescript-eslint/no-explicit-any */
// Live read-only sanity test of the TS sources against HKJC (node fetch plays the native bridge).
// @ts-ignore
import { makeNativeHandler } from '../native-node.mjs';
import { LiveAdapter } from '../src/backend/sources';
import { analyze } from '../src/backend/engine';
const handle = makeNativeHandler('/tmp/mf-live-test');
(globalThis as any).webkit = { messageHandlers: { native: { postMessage: (m: any) => handle(m) } } };
async function main() {
  const raws: any[] = [];
  const ad = new LiveAdapter((r) => raws.push(r));
  const t0 = Date.now();
  const cat = await ad.catalog();
  console.log('catalog', Date.now() - t0, 'ms', cat.status, cat.message, 'meetings', cat.meetings.map((m: any) => `${m.date} ${m.venue} ${m.races.length}R`).join(', '), 'errors', JSON.stringify(cat.errors));
  console.log('cookies after warm-up:', ad.client.cookie ? ad.client.cookie.split('; ').map((c) => c.split('=')[0]).join(',') : '(none)');
  const meeting = cat.meetings.find((m: any) => m.venueKind === 'local') || cat.meetings[0];
  const pick = cat.recommendedRaceId ? cat.meetings.flatMap((m: any) => m.races).find((r: any) => r.id === cat.recommendedRaceId) : meeting.races[Math.min(4, meeting.races.length - 1)];
  console.log('fetching', pick.id, pick.name, 'status', pick.status, 'runners', pick.runners.length);
  const snaps: any[] = [];
  for (let i = 0; i < 2; i++) {
    try { const s = await ad.fetch(pick); snaps.push(s); console.log('snapshot', i, 'ts', new Date(s.timestamp * 1000).toISOString(), 'pools', Object.keys(s.pools).join(','), 'WIN total', s.pools.WIN?.reportedTotal?.value, 'alignment', s.pools.WIN?.alignment, 'latency', Math.round(s.latency), 'ms'); }
    catch (e) { console.log('fetch error', (e as Error).message); }
  }
  if (snaps.length) {
    const res = analyze(pick, snaps.slice(0, 1));
    const f = res.frames[res.frames.length - 1];
    console.log('analyze ok: frames', res.frames.length, 'runner1 winOdds', f.runners['1']?.winOdds?.value, 'dbl winner r1', f.incomingDouble?.['1']?.winner?.value, 'raceTotal', f.raceTotalInvestment?.value);
  }
  console.log('raw records', raws.length, raws.map((r) => r.query + (r.variables.raceNo !== undefined ? '#' + r.variables.raceNo : '')).join(' '));
}
main().catch((e) => { console.error('FAILED', e); process.exit(1); });
