/* eslint-disable @typescript-eslint/no-explicit-any */
// tests/test_mini.py translated to the TypeScript port (+ a parity dump compared against the Python output).
// Build: npx esbuild verify/test_mini.ts --bundle --platform=node --format=esm --outfile=/workspace/mf-verify/mini/js_mini.mjs
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import * as mini from '../src/backend/mini';
import { baseline as engineBaseline } from '../src/backend/engine';
import { MockAdapter, normalizeSnapshot, timestamp } from '../src/backend/sources';
import { Service, handleApi } from '../src/backend/service';

(globalThis as any).__MF_NOW__ = () => 1790000000.0;
(globalThis as any).__MF_SNAPSHOT_ID__ = (s: any) => 'T' + String(s.timestamp).replace('.', '_');
const clone = <T>(x: T): T => structuredClone(x);
let passed = 0; const failed: string[] = [];
function check(name: string, cond: boolean) { if (cond) passed++; else failed.push(name); }
const eq = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b);
const close = (a: number, b: number, places: number) => Math.round(Math.abs(a - b) * 10 ** places) === 0;

function cardOdds(race: any, dblNodes: Record<string, string>, prevWin: Record<string, string>) {
  const runners = [{ no: 5, finalPosition: 1, deadHeat: false }, { no: 3, finalPosition: 2, deadHeat: false }];
  const card = { data: { raceMeetings: [{ date: race.date, venueCode: race.venue, races: [{ no: 1, runners }, { no: 2 }],
    poolInvs: [{ id: 'WIN2', oddsType: 'WIN', investment: '1000000', lastUpdateTime: '2026-01-01T13:30:00+08:00', leg: { races: [2] } }] }] } };
  const odds = { data: { raceMeetings: [{ pmPools: [
    { id: 'WIN2', oddsType: 'WIN', leg: { races: [2] }, lastUpdateTime: '2026-01-01T13:30:00+08:00', oddsNodes: Array.from({ length: 8 }, (_, k) => ({ combString: String(k + 1), oddsValue: String(k + 2) })) },
    { id: 'WIN1', oddsType: 'WIN', leg: { races: [1] }, lastUpdateTime: '2026-01-01T13:00:00+08:00', oddsNodes: Object.entries(prevWin).map(([k, v]) => ({ combString: k, oddsValue: String(v) })) },
    { id: 'DBL1', oddsType: 'DBL', leg: { races: [1, 2] }, lastUpdateTime: '2026-01-01T13:30:00+08:00', oddsNodes: Object.entries(dblNodes).map(([k, v]) => ({ combString: k, oddsValue: String(v) })) }] }] } };
  return [card, odds];
}
function liveSnapshot(received = '2026-01-01T13:30:10+08:00'): [any, any] {
  const race = MockAdapter.race(2);
  const [card, odds] = cardOdds(race, { '05/01': '999', '03/01': '8', '07/01': '30', '05/02': '400', '03/02': '999', '07/02': '999' }, { 5: '35', 3: '4.0', 7: '6.0' });
  return [race, normalizeSnapshot(race, card, odds, timestamp(received)!, 100)];
}
const newService = () => new Service(null);

async function main() {
  const out: Record<string, any> = {};
  // ---- WinMoneyTests ----
  const [race, s] = liveSnapshot();
  out.live_snapshot = s;
  out.wm_base = mini.winMoney(s, race);
  {
    const [money, reason] = out.wm_base;
    check('win_money: available', reason === null);
    const inv: Record<string, number> = {}; for (const r of Object.keys(money)) inv[r] = 1 / s.runners[r].winOdds.value;
    const tot = Object.values(inv).reduce((a, b) => a + b, 0);
    check('win_money: pool × normalized reciprocal', Object.keys(money).every((r) => close(money[r].value, 1_000_000 * inv[r] / tot, 6) && money[r].quality === 'ESTIMATED'));
    check('win_money: sums to pool', close(Object.values(money).reduce((a: number, m: any) => a + m.value, 0), 1_000_000, 4));
    check('win_money: equals stored estimate', Object.keys(money).every((r) => money[r].value === s.pools.WIN.amounts[r].value));
  }
  let v = clone(s); v.pools.WIN.amounts = {}; v.pools.WIN.total = { value: null, quality: 'UNAVAILABLE', reason: '賠率／彩池時間缺失或差距超過15秒' };
  out.wm_total_unavail = mini.winMoney(v, race);
  check('win_money: unusable total', String(out.wm_total_unavail[1]).includes('15') && Object.values(out.wm_total_unavail[0]).every((m: any) => m.value === null));
  v = clone(s); delete v.pools.WIN.amounts['3']; out.wm_partial = mini.winMoney(v, race);
  check('win_money: partial', out.wm_partial[1] !== null && Object.values(out.wm_partial[0]).every((m: any) => m.value === null));
  v = clone(s); v.pools.WIN.amounts['1'].value += 5000; out.wm_conservation = mini.winMoney(v, race);
  check('win_money: conservation', String(out.wm_conservation[1]).includes('不一致') && Object.values(out.wm_conservation[0]).every((m: any) => m.value === null));
  v = clone(s); v.timestamp = v.pools.WIN.updatedAt + 46; out.wm_old = mini.winMoney(v, race);
  check('win_money: >45 s', String(out.wm_old[1]).includes('45') && Object.values(out.wm_old[0]).every((m: any) => m.value === null));
  out.wm_none = mini.winMoney(null, race);
  check('win_money: no snapshot', out.wm_none[1] === '未有快照' && Object.values(out.wm_none[0]).every((m: any) => m.value === null));
  // ---- RowsTests ----
  const r2 = clone(race); r2.runners[0].scratched = true;
  v = clone(s); v.runners['4'].winOdds = { value: null, quality: 'UNAVAILABLE', reason: 'x' }; v.runners['6'].winOdds.value = 3.0;
  out.rows_sort = mini.rows(r2, v);
  { const order = out.rows_sort.map((r: any) => r.no);
    check('rows: sorted, tie by no.', eq(order.slice(0, 2), [2, 6]));
    check('rows: missing then scratched last', eq(order.slice(-2), [4, 1]) && out.rows_sort.at(-1).scratched && out.rows_sort.at(-1).winOdds.value === null); }
  out.wm_scratched = mini.winMoney(v, r2);
  out.rows_dbl = mini.rows(race, s);
  { const rows: Record<string, any> = {}; for (const r of out.rows_dbl) rows[String(r.no)] = r;
    check('rows: dbl pass-through', Object.entries(s.incomingDouble as Record<string, any>).every(([r, d]) => eq(rows[r].dblWinner, d.winner) && eq(rows[r].dblRunnerUp, d.runnerUp) && eq(rows[r].dblAll, d.all)));
    check('rows: dblfix3 values', rows['1'].dblWinner.value === 28.0 && rows['1'].dblWinner.bound === 'GE' && rows['2'].dblAll.value === 223.0 && rows['2'].dblAll.bound === 'GE' && rows['1'].dblAll.value === 6.3); }
  v = clone(s); v.incomingDouble = {}; out.rows_nodbl = mini.rows(race, v);
  check('rows: missing dbl is dash', ['dblWinner', 'dblRunnerUp', 'dblAll'].every((f) => out.rows_nodbl[0][f].value === null));
  out.has_odds = [mini.hasWinOdds(s), mini.hasWinOdds(null), mini.hasWinOdds({ runners: {} })];
  out.wb_nopost = mini.winBefore({ ...race, postTime: null }, [s], 15);
  out.view_none = mini.view(null, null, 0, { status: 'X' }, {}, null);
  // ---- ServiceMiniTests ----
  let S = newService(); await S.ready; out.svc_nothing = await S.mini();
  check('service: nothing selected', out.svc_nothing.race === null && eq(out.svc_nothing.rows, []) && out.svc_nothing.health.status === 'ERROR');
  S = newService(); await S.ready; await S.select('mock', MockAdapter.race(1).id);
  out.svc_mock = await S.mini(); out.svc_mock_default_minutes = (await S.mini()).baseline.minutes;
  { const key = S.selected.key; const snaps = await S.store.snapshots(key); const latest = snaps.at(-1);
    check('service: mock latest', out.svc_mock.health.status === 'MOCK' && out.svc_mock.frame.id === latest.id && out.svc_mock.snapshotCount === snaps.length);
    check('service: winOdds from latest, no winMoney', out.svc_mock.rows.every((row: any) => eq(row.winOdds, latest.runners[String(row.no)].winOdds) && !('winMoney' in row)));
    const odds = out.svc_mock.rows.map((r: any) => r.winOdds.value); check('service: sorted by odds', eq(odds, [...odds].sort((a: number, b: number) => a - b))); }
  for (const m of [15, 17, 5, 1, 30]) {
    out[`svc_mock_m${m}`] = await S.mini(m); const main = (await S.state({ baseline_minutes: m })).baseline; out[`svc_mock_state_baseline_m${m}`] = main;
    const o = out[`svc_mock_m${m}`];
    check(`service: 獨贏前 = main baseline (m=${m})`, o.baseline.status === main.status && o.baseline.timestamp === main.timestamp && o.baseline.minutes === m && o.rows.every((row: any) => eq(row.winOddsBefore, main.winOdds[String(row.no)])));
  }
  check('service: default 15', out.svc_mock_default_minutes === 15);
  { const key = S.selected.key; const r = S.selected.race; const snaps = await S.store.snapshots(key); const scan: any[] = []; let ok = true;
    for (let offset = -3600; offset < 1200; offset += 97) {
      const target = r.postTime + offset; const minutes = (r.postTime - target) / 60;
      const full = engineBaseline(r, snaps, minutes);
      const cands = await S.store.baselineCandidates(key, target, mini.hasWinOdds);
      const part = mini.winBefore(r, cands, minutes);
      scan.push({ n: cands.length, part, full: { status: full.status, timestamp: full.timestamp, winOdds: full.winOdds } });
      ok = ok && eq([part.status, part.timestamp, part.winOdds], [full.status, full.timestamp, full.winOdds]);
    }
    out.svc_scan = scan; check('service: candidates = all snapshots', ok); }
  const S2 = newService(); await S2.ready; await S2.select('mock', MockAdapter.race(2).id); out.svc_mock2 = await S2.mini(); out.svc_mock2_m3 = await S2.mini(3);
  {
    S = newService(); await S.ready; let [race1, s1] = liveSnapshot('2026-01-01T13:30:10+08:00');
    race1 = { ...race1, postTime: s1.timestamp + 15 * 60 + 10 }; const k = 'imported:test:' + race1.id;
    S.store.saveRace(k, 'imported', race1); await S.store.ensureLoaded(k); S.store.add(k, s1);
    S.selected = { mode: 'replay', key: k, race: race1 }; S.sessions.set(k, { error: null, lastReceived: null, latency: null, polling: false });
    out.frozen_first = await S.mini(15); check('frozen: LOCKED', out.frozen_first.baseline.status === 'LOCKED');
    const s2 = clone(s1); s2.timestamp = s2.sourceTimestamp = s1.timestamp + 120;
    for (const x of Object.values(s2.runners) as any[]) if (x.winOdds.value) x.winOdds.value += 1;
    s2.id = 'later'; S.store.add(k, s2);
    out.frozen_again = await S.mini(15); out.frozen_late = await S.mini(14); out.frozen_early = await S.mini(30);
    const bf = (o: any) => Object.fromEntries(o.rows.map((r: any) => [r.no, r.winOddsBefore]));
    check('frozen: later snapshot changes nothing', eq(bf(out.frozen_again), bf(out.frozen_first)));
    check('frozen: value from T−15 snapshot', bf(out.frozen_again)[1].value === s1.runners['1'].winOdds.value);
    check('frozen: LATE → dashes', out.frozen_late.baseline.status === 'LATE' && out.frozen_late.rows.every((r: any) => r.winOddsBefore.value === null));
    check('frozen: early → dashes', out.frozen_early.rows.every((r: any) => r.winOddsBefore.value === null));
  }
  {
    S = newService(); await S.ready; const [race1, s1] = liveSnapshot('2026-01-01T13:30:10+08:00'); const k = 'imported:test:' + race1.id;
    S.store.saveRace(k, 'imported', race1); await S.store.ensureLoaded(k); S.store.add(k, s1);
    const s2 = clone(s1); s2.timestamp = s2.sourceTimestamp = s1.timestamp + 5; s2.incomingDouble = {};
    s2.runners['1'].winOdds = { value: null, quality: 'UNAVAILABLE', reason: 'x' }; s2.id = 'second'; S.store.add(k, s2);
    S.selected = { mode: 'replay', key: k, race: race1 }; S.sessions.set(k, { error: null, lastReceived: null, latency: null, polling: false });
    const o = out.no_copy_forward = await S.mini();
    check('no copy-forward', o.frame.id === 'second' && o.health.status === 'REPLAY' && o.rows.every((r: any) => r.dblAll.value === null && r.dblWinner.value === null) && o.rows.find((r: any) => r.no === 1).winOdds.value === null);
  }
  {
    S = newService(); await S.ready; const [race1, s1] = liveSnapshot(); const k = 'live:' + race1.id;
    S.store.saveRace(k, 'live', race1); await S.store.ensureLoaded(k); S.store.add(k, s1);
    S.selected = { mode: 'live', key: k, race: race1 }; S.sessions.set(k, { error: null, lastReceived: s1.receivedAt, latency: 100, polling: false });
    const o = out.live_stale = await S.mini();
    check('live STALE keeps last values', o.health.status === 'STALE' && o.rows[0].winOdds.value !== null);
  }
  // ---- /api/mini parameters (LanOriginTests' HTTP part; the LAN-origin rule itself has no equivalent in the app) ----
  {
    S = newService(); await S.ready;
    let r = await handleApi(S, 'GET', 'mini'); check('api: default 200/15', r.status === 200 && 'rows' in r.body && r.body.baseline.minutes === 15);
    r = await handleApi(S, 'GET', 'mini?baseline_minutes=5'); check('api: minutes=5', r.status === 200 && r.body.baseline.minutes === 5);
    for (const bad of ['0', '31', 'abc']) check(`api: bad ${bad} → 400`, (await handleApi(S, 'GET', 'mini?baseline_minutes=' + bad)).status === 400);
  }
  // ---- recorded 2026-09-27 ST races ----
  const py = existsSync((process.env.MF_MINI_DIR || '/workspace/mf-verify/mini') + '/py_mini_out.json') ? JSON.parse(readFileSync((process.env.MF_MINI_DIR || '/workspace/mf-verify/mini') + '/py_mini_out.json', 'utf8')) : null;
  if (py) {
    const rec: Record<string, any> = {};
    for (const tag of Object.keys(py.recorded)) {
      const rr = py.recorded[tag].race, ss = py.recorded[tag].snapshots;
      const before: Record<string, any> = {};
      for (const m of [1, 2, 5, 10, 13, 14, 15, 16, 17, 20, 25, 30]) before[String(m)] = mini.winBefore(rr, ss, m);
      rec[tag] = { race: rr, snapshots: ss, money: ss.map((x: any) => mini.winMoney(x, rr)),
        rows: ss.filter((_: any, i: number) => i % 3 === 0).map((x: any) => mini.rows(rr, x)), before,
        views: ss.filter((_: any, i: number) => i % 4 === 0).map((x: any, i: number) => mini.view({ mode: 'live', key: 'live:' + rr.id, race: rr }, x, i + 1, { status: 'LIVE' }, {}, mini.winBefore(rr, ss.slice(0, i + 1), 15))) };
    }
    out.recorded = rec;
  }
  writeFileSync((process.env.MF_MINI_DIR || '/workspace/mf-verify/mini') + '/js_mini_out.json', JSON.stringify(out));
  console.log(`test_mini (TS port): ${passed} checks passed, ${failed.length} failed${failed.length ? ': ' + failed.join('; ') : ''}`);
  if (failed.length) process.exitCode = 1;
}
main();
