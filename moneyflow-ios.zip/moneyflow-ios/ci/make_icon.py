"""Render the 1024x1024 資金流 app icon (no alpha, as App Store/iOS requires).

Already rendered into MoneyFlow/Assets.xcassets/AppIcon.appiconset/AppIcon.png; re-run only to change the design:
    python3 ci/make_icon.py MoneyFlow/Assets.xcassets/AppIcon.appiconset/AppIcon.png
Needs Pillow and a CJK font (Noto Sans CJK); override with FONT=/path/to/font.
"""
import os
import sys
from PIL import Image, ImageDraw, ImageFont

S = 1024
BG = (10, 16, 12)
GREEN = (125, 206, 106)
DIM = (46, 72, 52)
GOLD = (217, 185, 132)

out = sys.argv[1] if len(sys.argv) > 1 else 'AppIcon.png'
font_path = os.environ.get('FONT') or next((p for p in [
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/System/Library/Fonts/PingFang.ttc',
] if os.path.exists(p)), None)

img = Image.new('RGB', (S, S), BG)
d = ImageDraw.Draw(img)

# Heat bars (like the terminal's 熱錢圖): baseline + "100" reference line.
base_y, left, right = 890, 150, 874
heights = [250, 330, 205, 420, 300, 520]
n = len(heights)
gap = 26
w = (right - left - gap * (n - 1)) / n
ref_y = base_y - 330
for i, h in enumerate(heights):
    x0 = left + i * (w + gap)
    top = base_y - h
    hot = h > 330
    # vertical gradient
    for y in range(int(top), base_y):
        t = (y - top) / max(1, h)
        c0 = GREEN if hot else (92, 150, 84)
        col = tuple(int(c0[k] * (1 - 0.55 * t) + BG[k] * 0.55 * t) for k in range(3))
        d.line([(x0, y), (x0 + w, y)], fill=col)
d.line([(left - 20, ref_y), (right + 20, ref_y)], fill=GOLD, width=10)
d.line([(left - 20, base_y + 6), (right + 20, base_y + 6)], fill=DIM, width=8)

# Title
if font_path:
    font = ImageFont.truetype(font_path, 250, index=3 if font_path.endswith('.ttc') else 0)  # index 3 ≈ TC in Noto CJK ttc
    text = '資金流'
    bbox = d.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    x = (S - tw) / 2 - bbox[0]
    y = 120 - bbox[1]
    d.text((x + 6, y + 8), text, font=font, fill=(0, 0, 0))
    d.text((x, y), text, font=font, fill=(236, 244, 232))
img.save(out, 'PNG')
print('wrote', out, img.size, img.mode, 'font', font_path)
