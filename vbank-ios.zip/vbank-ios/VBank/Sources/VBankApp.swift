//
//  VBankApp.swift — App 入口
//  目标：iOS 16+ · 无第三方依赖 · SwiftUI 原生
//

import SwiftUI

@main
struct VBankApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)      // 马会是浅色界面，强制浅色
                .statusBarHidden(false)
        }
    }
}