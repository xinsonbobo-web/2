//
//  Views.swift — eWin 投注區界面复刻
//  配色 #00713d 主绿 · #c8a55b 金色 · #f5f3ed 米色
//

import SwiftUI

// MARK: - 品牌色

enum HK {
    static let green   = Color(red: 0/255, green: 113/255, blue: 61/255)
    static let greenD  = Color(red: 0/255, green: 90/255, blue: 48/255)
    static let greenL  = Color(red: 10/255, green: 138/255, blue: 78/255)
    static let gold    = Color(red: 200/255, green: 165/255, blue: 91/255)
    static let cream   = Color(red: 247/255, green: 245/255, blue: 239/255)
    static let bg      = Color(red: 244/255, green: 242/255, blue: 236/255)
    static let line    = Color(red: 227/255, green: 224/255, blue: 216/255)
    static let txt2    = Color(red: 90/255, green: 90/255, blue: 90/255)
    static let txt3    = Color(red: 140/255, green: 140/255, blue: 140/255)
    static let blue    = Color(red: 21/255, green: 83/255, blue: 125/255)
    static let red     = Color(red: 184/255, green: 53/255, blue: 42/255)
}

extension Double {
    var money: String {
        formatted(.number.precision(.fractionLength(2)).grouping(.automatic))
    }
}

// MARK: - 根视图

struct ContentView: View {
    @StateObject private var bank = Bankroll()
    @State private var meetings: [Meeting] = []
    @State private var loading = false
    @State private var err: String?
    @State private var day = Calendar.current.date(byAdding: .day, value: 1, to: Date())!
    @State private var showStats = false
    @State private var detail: Runner?
    @State private var pending: [String: Double] = [:]   // "raceNo-horseNo-TYPE" -> stake
    @State private var detailRace: Race?

    private let dateFmt: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "zh_HK")
        f.dateFormat = "d/M/yyyy"
        return f
    }()
    private let wk = ["日","一","二","三","四","五","六"]

    private var dateStr: String {
        let c = Calendar.current
        let dow = wk[c.component(.weekday, from: day) - 1]
        return "\(c.component(.day, from: day))/\(c.component(.month, from: day))/\(c.component(.year, from: day))(星期\(dow))"
    }
    private var iso: String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; return f.string(from: day)
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(.white).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 0) {
                    header
                    dateBar
                    poolBar
                    content
                }
            }
            .safeAreaInset(edge: .bottom) { if !pending.isEmpty { emptyHint } }

            if !pending.isEmpty { betslip }
            if showStats { StatsSheet(bank: bank, onClose: { showStats = false }) }
            if let d = detail, let r = detailRace {
                HorseSheet(runner: d, race: r, onClose: { detail = nil; detailRace = nil })
            }
        }
        .alert(alertMsg ?? "", isPresented: alertBinding) { Button("好", role: .cancel) {} }
        .task { await load() }
        .refreshable { await load() }
    }

    // MARK: 顶栏

    var header: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Text("eWin 投注區")
                    .font(.system(size: 15, weight: .bold))
                    .tracking(0.5)
                Text("繁").font(.system(size: 11)).opacity(0.7)
                Text("简").font(.system(size: 11)).opacity(0.7)
                Spacer()
                VStack(alignment: .trailing, spacing: 0) {
                    Text("虛擬本金").font(.system(size: 9)).opacity(0.8)
                    Text(bank.bankroll.money)
                        .font(.system(size: 15, weight: .bold))
                        .monospacedDigit()
                }
                .padding(.horizontal, 9).padding(.vertical, 3)
                .background(Color.black.opacity(0.18))
                .cornerRadius(3)
            }
            .padding(.horizontal, 14).padding(.vertical, 9)
            .foregroundStyle(.white)
            .background(HK.green)

            HStack(spacing: 0) {
                navItem("賽馬", true) { }
                navItem("足球", false) { }
                navItem("六合彩", false) { }
                navItem("我的", false) { showStats = true }
                navItem("歷史", false) { showStats = true }
            }
            .background(HK.greenD)
        }
    }

    func navItem(_ t: String, _ on: Bool, act: @escaping () -> Void) -> some View {
        Text(t)
            .font(.system(size: 14, weight: on ? .semibold : .regular))
            .foregroundStyle(on ? .white : Color.white.opacity(0.72))
            .frame(maxWidth: .infinity).padding(.vertical, 10)
            .background(alignment: .bottom) {
                if on { Rectangle().fill(HK.gold).frame(height: 3) }
            }
            .contentShape(Rectangle()).onTapGesture(perform: act)
    }

    // MARK: 日期条

    var dateBar: some View {
        HStack(spacing: 0) {
            Button {
                shift(-1)
            } label: {
                Text("‹").font(.system(size: 21))
                    .foregroundStyle(HK.green).padding(.horizontal, 16).padding(.vertical, 10)
            }
            VStack(spacing: 1) {
                Text(dateStr).font(.system(size: 15, weight: .semibold))
            }
            .frame(maxWidth: .infinity).padding(.vertical, 9)
            .background(HK.cream)
            Button {
                shift(1)
            } label: {
                Text("›").font(.system(size: 21))
                    .foregroundStyle(HK.green).padding(.horizontal, 16).padding(.vertical, 10)
            }
        }
        .overlay(alignment: .bottom) { Rectangle().fill(HK.line).frame(height: 1) }
    }

    func shift(_ n: Int) {
        day = Calendar.current.date(byAdding: .day, value: n, to: day)!
        Task { await load() }
    }

    // MARK: 彩池条

    @ViewBuilder var poolBar: some View {
        if let p = meetings.first?.poolTotal, p > 0 {
            HStack(spacing: 14) {
                Text("彩池").font(.system(size: 12, weight: .semibold))
                Text("WIN").font(.system(size: 11)).foregroundStyle(HK.txt2)
                Text(p.money).font(.system(size: 13, weight: .bold))
                    .foregroundStyle(HK.green).monospacedDigit()
                if let u = meetings.first?.poolUpdated, u.count >= 16 {
                    Text("更新 \(String(u.suffix(5).prefix(5)))")
                        .font(.system(size: 11)).foregroundStyle(HK.txt3)
                }
                Spacer()
            }
            .padding(.horizontal, 14).padding(.vertical, 7)
            .background(HK.cream)
            .overlay(alignment: .bottom) { Rectangle().fill(HK.line).frame(height: 1) }
        }
    }

    // MARK: 主体

    @ViewBuilder var content: some View {
        if loading && meetings.isEmpty {
            VStack { Spacer(); ProgressView(); Spacer() }.padding(.vertical, 60)
        } else if let err {
            VStack(spacing: 10) {
                Text(err).font(.system(size: 13)).foregroundStyle(HK.txt3)
                Button("重試") { Task { await load() } }
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.white).padding(.horizontal, 20).padding(.vertical, 8)
                    .background(HK.green).cornerRadius(4)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 44)
            .background(HK.cream).overlay(RoundedRectangle(cornerRadius: 4).stroke(HK.line))
                .padding(14)
        } else if meetings.isEmpty {
            Text("該日無賽事")
                .font(.system(size: 13)).foregroundStyle(HK.txt3)
                .frame(maxWidth: .infinity).padding(.vertical, 50)
                .background(HK.cream)
                .overlay(RoundedRectangle(cornerRadius: 4).stroke(HK.line))
                .padding(14)
        } else {
            ForEach(meetings) { m in
                VStack(spacing: 0) {
                    // 场地条
                    HStack(spacing: 9) {
                        Text(m.venue).font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.white).padding(.horizontal, 9).padding(.vertical, 2)
                            .background(HK.green).cornerRadius(2)
                        Text(m.status == "DEFINED" ? "賽事已定" : "進行中")
                            .font(.system(size: 13)).foregroundStyle(HK.txt2)
                        Spacer()
                        Text("共 \(m.total) 場 · 第 \(m.current) 場開跑")
                            .font(.system(size: 11)).foregroundStyle(HK.txt3)
                    }
                    .padding(.horizontal, 14).padding(.vertical, 8)

                    ForEach(m.races) { r in
                        raceCard(m, r)
                        Divider().overlay(Color(red: 0.96, green: 0.95, blue: 0.92))
                            .padding(.top, 6)
                    }
                }
            }
        }
    }

    func raceCard(_ m: Meeting, _ r: Race) -> some View {
        VStack(spacing: 0) {
            // 场次头（绿）
            HStack(spacing: 9) {
                Text("第 \(r.raceNo) 場").font(.system(size: 13, weight: .bold))
                Text(timeOnly(r.postTime)).font(.system(size: 13))
                Spacer()
                Text("\(r.runners.filter{ $0.type=="WIN" }.count) 匹")
                    .font(.system(size: 11)).opacity(0.9)
            }
            .foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 7)
            .background(HK.green)

            // 赛事名
            HStack(spacing: 9) {
                Text("R\(r.raceNo)").font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.white).padding(.horizontal, 8).padding(.vertical, 2)
                    .background(HK.green).cornerRadius(2)
                Text(r.raceName).font(.system(size: 14, weight: .semibold))
                Spacer()
                Text("\(r.distance) 米 · 草地").font(.system(size: 11)).foregroundStyle(HK.txt3)
            }
            .padding(.horizontal, 14).padding(.vertical, 8)
            .overlay(alignment: .bottom) { Rectangle().fill(HK.line).frame(height: 1) }

            // 赔率表
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Text("號").frame(width: 30)
                    Text("馬名").frame(maxWidth: .infinity, alignment: .leading)
                    Text("負重").frame(width: 42)
                    ForEach(OddsType.allCases, id: \.rawValue) { t in
                        Text(t.label).frame(width: 52)
                    }
                }
                .font(.system(size: 11))
                .foregroundStyle(HK.txt2)
                .padding(.vertical, 7).padding(.horizontal, 6)
                .background(Color(red: 0.98, green: 0.976, blue: 0.965))

                ForEach(winRows(r), id: \.id) { rn in
                    rowView(m, r, rn)
                    Divider().overlay(Color(red: 0.95, green: 0.94, blue: 0.92))
                }
            }
        }
    }

    /// 以独赢行为主，按 type 附上其他玩法
    func winRows(_ r: Race) -> [Runner] {
        r.runners.filter { $0.type == "WIN" }
    }

    func rowView(_ m: Meeting, _ r: Race, _ rn: Runner) -> some View {
        HStack(spacing: 0) {
            Text(rn.no).font(.system(size: 13, weight: .bold))
                .foregroundStyle(HK.green).frame(width: 30)

            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 3) {
                    Text(rn.nameCh).font(.system(size: 13.5, weight: .medium))
                        .foregroundStyle(HK.green)
                        .onTapGesture { detail = rn; detailRace = r }
                    if rn.isHot {
                        Text("熱").font(.system(size: 9.5))
                            .foregroundStyle(Color(red: 0.77, green: 0.48, blue: 0.11))
                            .padding(.horizontal, 4).padding(.vertical, 1)
                            .background(Color(red: 1, green: 0.95, blue: 0.84))
                            .cornerRadius(2)
                    }
                }
                let sub = [rn.rating.map { "\($0) 分" },
                           rn.jockey, rn.trainer].compactMap { $0 }.joined(separator: " · ")
                if !sub.isEmpty {
                    Text(sub).font(.system(size: 11)).foregroundStyle(HK.txt3)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 6)

            Text(rn.weight ?? "")
                .font(.system(size: 12)).foregroundStyle(HK.txt2)
                .frame(width: 42)

            ForEach(OddsType.allCases, id: \.rawValue) { t in
                let o = r.runners.first { $0.no == rn.no && $0.type == t.rawValue }
                oddsCell(m, r, o)
            }
        }
        .padding(.vertical, 2)
    }

    func oddsCell(_ m: Meeting, _ r: Race, _ o: Runner?) -> some View {
        let key = "\(r.raceNo)-\(o?.no ?? "-")-\(o?.type ?? "-")"
        let on = pending[key] != nil
        return Group {
            if let o, let v = o.odds, v > 1 {
                Button { toggle(m, r, o, key) } label: {
                    HStack(spacing: 1) {
                        Text(fmt(v)).font(.system(size: 13, weight: .bold))
                        if o.isHot {
                            Image(systemName: "flame.fill")
                                .font(.system(size: 8))
                                .foregroundStyle(Color(red: 0.77, green: 0.48, blue: 0.11))
                        }
                    }
                    .foregroundStyle(on ? .white : HK.green)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 5).padding(.horizontal, 2)
                    .background(on ? HK.gold : .white)
                    .overlay(RoundedRectangle(cornerRadius: 3)
                        .stroke(on ? Color(red: 0.61, green: 0.50, blue: 0.23) : HK.green, lineWidth: 1))
                }
                .buttonStyle(.plain)
            } else {
                Text("--")
                    .font(.system(size: 13))
                    .foregroundStyle(Color(red: 0.79, green: 0.77, blue: 0.73))
                    .frame(maxWidth: .infinity).padding(.vertical, 5)
            }
        }
        .frame(width: 52)
    }

    func toggle(_ m: Meeting, _ r: Race, _ o: Runner, _ key: String) {
        if pending[key] != nil { pending.removeValue(forKey: key) }
        else { pending[key] = 100 }
    }

    func fmt(_ v: Double) -> String {
        v == v.rounded() ? String(Int(v)) : String(format: "%.1f", v)
    }

    func timeOnly(_ iso: String) -> String {
        iso.count >= 16 ? String(iso.suffix(5).prefix(5)) : iso
    }

    // MARK: 投注单

    var betslip: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Text("投注單").font(.system(size: 13))
                Text("\(pending.count)").font(.system(size: 16, weight: .bold)).monospacedDigit()
                Text("項")
                Spacer()
                Text("共 \(bank.pendingStake.money) · 潛在 \(bank.pendingPotential.money)")
                    .font(.system(size: 11)).opacity(0.9)
            }
            .padding(.horizontal, 14).padding(.vertical, 8)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 5) {
                    ForEach(Array(pending.keys).sorted(), id: \.self) { k in
                        let p = k.split(separator: "-")
                        let race = meetings.flatMap(\.races).first { String($0.raceNo) == String(p[0]) }
                        let o = race?.runners.first { $0.no == String(p[1]) && $0.type == String(p[2]) }
                        HStack(spacing: 5) {
                            VStack(alignment: .leading, spacing: 0) {
                                Text("第\(p[0])場 \(p[1])號 \(o?.nameCh ?? "")")
                                    .font(.system(size: 12))
                                Text(OddsType(rawValue: String(p[2]))?.label ?? "")
                                    .font(.system(size: 9, weight: .bold)).opacity(0.65)
                            }
                            .lineLimit(1)
                            if let od = o?.odds {
                                Text(fmt(od)).font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(HK.gold)
                            }
                            Button { pending.removeValue(forKey: k) } label: {
                                Image(systemName: "xmark")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.white.opacity(0.7))
                            }
                        }
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Color.white.opacity(0.12)).cornerRadius(3)
                    }
                }
                .padding(.horizontal, 14).padding(.bottom, 6)
            }

            HStack(spacing: 8) {
                Button("清除") { pending = [:] }
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity).padding(.vertical, 11)
                    .background(Color.white.opacity(0.2)).cornerRadius(4)

                Button("確認投注") { Task { await submit() } }
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(Color(red: 0.23, green: 0.18, blue: 0.06))
                    .frame(maxWidth: .infinity).padding(.vertical, 11)
                    .background(HK.gold).cornerRadius(4)
            }
            .padding(.horizontal, 14).padding(.vertical, 9)
            .background(Color.black.opacity(0.16))
        }
        .foregroundStyle(.white)
        .background(HK.green)
        .shadow(color: .black.opacity(0.2), radius: 12, y: -3)
    }

    var emptyHint: some View { Color.clear.frame(height: 1) }

    func submit() async {
        let m = meetings.first
        guard let m else { return }
        var ok = 0, bad: [String] = []
        for (k, stake) in pending {
            let p = k.split(separator: "-")
            guard let race = m.races.first(where: { String($0.raceNo) == String(p[0]) }),
                  let o = race.runners.first(where: {
                      $0.no == String(p[1]) && $0.type == String(p[2]) }) else { continue }
            do {
                try bank.place(date: iso, venue: m.venue, race: race,
                               horse: o, stake: stake)
                ok += 1
            } catch {
                bad.append("\(o.no)號 \((error as? BankrollError)?.errorDescription ?? "失敗")")
            }
        }
        pending = [:]
        await MainActor.run {
            showAlert(bad.isEmpty ? "已投 \(ok) 項 · 全部進入投注單"
                              : "已投 \(ok) 項\n\n失敗 \(bad.count) 項：\n\(bad.prefix(4).joined(separator: "\n"))")
        }
    }

    @State private var alertMsg: String?
    func showAlert(_ s: String) { alertMsg = s }
    var alertBinding: Binding<Bool> {
        Binding(get: { alertMsg != nil },
                set: { if !$0 { alertMsg = nil } })
    }

    // MARK: 数据加载

    func load() async {
        loading = true; err = nil
        do {
            meetings = try await HKJCAPI.shared.fetchMeetings(date: iso, venue: "ST")
        } catch {
            err = (error as? NSError)?.localizedDescription ?? "載入失敗"
        }
        loading = false
    }
}

// MARK: - 马匹详情抽屉

struct HorseSheet: View {
    let runner: Runner
    let race: Race
    let onClose: () -> Void
    func d() { onClose() }

    private var all: [Runner] {
        Dictionary(grouping: race.runners, by: \.no)
            .compactMap { $0.value.first }
            .sorted { (Int($0.no) ?? 0) < (Int($1.no) ?? 0) }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { d() }
            VStack(spacing: 0) {
                HStack {
                    Text("馬匹詳情")
                        .font(.system(size: 15, weight: .semibold))
                    Spacer()
                    Button { d() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .padding(14).foregroundStyle(.white).background(HK.green)

                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("\(runner.no)號 \(runner.nameCh)")
                            .font(.system(size: 18, weight: .bold))
                        if let e = runner.nameEn, !e.isEmpty {
                            Text(e).font(.system(size: 12)).foregroundStyle(HK.txt3).padding(.top, 2)
                        }

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())],
                                  spacing: 1) {
                            kv("評分", runner.rating ?? "--")
                            kv("國際評分", runner.intlRating ?? "--")
                            kv("負重", runner.weight ?? "--")
                            kv("騎師", runner.jockey ?? "--")
                            kv("練馬師", runner.trainer ?? "--")
                            kv("場次", "第 \(race.raceNo) 場 \(race.distance)米")
                        }
                        .background(HK.line)
                        .clipShape(RoundedRectangle(cornerRadius: 3))
                        .padding(.top, 12)

                        Text("即時賠率")
                            .font(.system(size: 13, weight: .semibold))
                            .padding(.top, 16).padding(.bottom, 4)

                        ForEach(OddsType.allCases, id: \.rawValue) { t in
                            let o = all.first { $0.no == runner.no && $0.type == t.rawValue }
                            HStack {
                                Text(t.label).font(.system(size: 13))
                                Spacer()
                                Text(o?.odds.map { fmt($0) } ?? "--")
                                    .font(.system(size: 14, weight: .bold))
                                    .foregroundStyle(HK.blue)
                                if let u = o?.lastUpdate, u.count >= 16 {
                                    Text(String(u.suffix(5).prefix(5)))
                                        .font(.system(size: 11)).foregroundStyle(HK.txt3)
                                        .frame(width: 42, alignment: .trailing)
                                }
                            }
                            .padding(.vertical, 10)
                            .overlay(alignment: .bottom) { Divider() }
                        }

                        Text("馬會為浮動彩池，實際派彩以開賽前最後一刻的賠率計算，非下注當時的參考賠率")
                            .font(.system(size: 11)).foregroundStyle(HK.txt3)
                            .padding(.top, 10)
                    }
                    .padding(14)
                }
                .frame(maxHeight: 520)
                .background(.white)
            }
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    func kv(_ k: String, _ v: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(k).font(.system(size: 10.5)).foregroundStyle(HK.txt3)
            Text(v).font(.system(size: 14, weight: .semibold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(9).background(.white)
    }

    func fmt(_ v: Double) -> String {
        v == v.rounded() ? String(Int(v)) : String(format: "%.1f", v)
    }
}

// MARK: - 统计面板

struct StatsSheet: View {
    @ObservedObject var bank: Bankroll
    let onClose: () -> Void

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.4).ignoresSafeArea().onTapGesture(perform: onClose)
            VStack(spacing: 0) {
                HStack {
                    Text("虛擬倉結算表現")
                        .font(.system(size: 15, weight: .semibold))
                    Spacer()
                    Button(action: onClose) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .padding(14).foregroundStyle(.white).background(HK.green)

                ScrollView {
                    VStack(spacing: 14) {
                        let s = bank.stats
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3),
                                  spacing: 1) {
                            cell("結算", "\(s.n)", HK.green)
                            cell("勝率", "\(Int(s.winRate))%", HK.green)
                            cell("ROI", String(format: "%+.1f%%", s.roi),
                                 s.roi >= 0 ? HK.green : HK.red)
                            cell("淨利", String(format: "%+.2f", s.profit),
                                 s.profit >= 0 ? HK.green : HK.red)
                            cell("最大回撤", String(format: "%.2f", s.mdd), HK.green)
                            cell("本金", bank.bankroll.money, HK.green)
                        }
                        .background(HK.line).clipShape(RoundedRectangle(cornerRadius: 3))

                        if !s.byType.isEmpty {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("按玩法").font(.system(size: 13, weight: .semibold))
                                ForEach(s.byType.keys.sorted(), id: \.self) { k in
                                    let g = s.byType[k]!
                                    HStack {
                                        Text(OddsType(rawValue: k)?.label ?? k)
                                        Spacer()
                                        Text("\(g.n) 場").foregroundStyle(HK.txt3)
                                        Text(String(format: "%.0f%%", Double(g.win) / Double(max(g.n, 1)) * 100))
                                            .foregroundStyle(HK.txt3).frame(width: 52, alignment: .trailing)
                                        Text(String(format: "%+.1f%%", g.roi))
                                            .font(.system(size: 14, weight: .bold))
                                            .foregroundStyle(g.roi >= 0 ? HK.green : HK.red)
                                            .frame(width: 74, alignment: .trailing)
                                    }
                                    .font(.system(size: 13)).padding(.vertical, 7)
                                    .overlay(alignment: .bottom) { Divider() }
                                }
                            }
                            .padding(12).background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 3))
                            .overlay(RoundedRectangle(cornerRadius: 3).stroke(HK.line))
                        }

                        VStack(alignment: .leading, spacing: 6) {
                            Text("結算明細").font(.system(size: 13, weight: .semibold))
                            if bank.history.isEmpty {
                                Text("未有記錄").font(.system(size: 13))
                                    .foregroundStyle(HK.txt3).padding(.vertical, 18)
                                    .frame(maxWidth: .infinity)
                            } else {
                                ForEach(bank.history.prefix(30)) { b in
                                    HStack(spacing: 6) {
                                        Text("第\(b.raceNo)場").font(.system(size: 12))
                                            .frame(width: 46, alignment: .leading)
                                        Text("\(b.horseNo) \(b.horseName)")
                                            .font(.system(size: 12)).lineLimit(1)
                                        Text(OddsType(rawValue: b.oddsType)?.label ?? "")
                                            .font(.system(size: 9)).foregroundStyle(HK.txt3)
                                        Spacer()
                                        HStack(spacing: 2) {
                                            Text(String(format: "%.1f", b.oddsAtBet))
                                            if let d = b.drift {
                                                Text(String(format: "%@%.1f", d > 0 ? "+" : "", d))
                                                    .font(.system(size: 9, weight: .bold))
                                                    .foregroundStyle(d < 0 ? HK.red : HK.green)
                                            }
                                        }
                                        .font(.system(size: 11)).foregroundStyle(HK.blue)
                                        Text(b.net.map { String(format: "%+.2f", $0) } ?? "")
                                            .font(.system(size: 13, weight: .bold))
                                            .foregroundStyle((b.net ?? 0) >= 0 ? HK.green : HK.red)
                                            .frame(width: 76, alignment: .trailing)
                                    }
                                    .padding(.vertical, 7)
                                    .overlay(alignment: .bottom) { Divider() }
                                }
                            }
                        }
                        .padding(12).background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 3))
                        .overlay(RoundedRectangle(cornerRadius: 3).stroke(HK.line))

                        // 结算未结算
                        if !bank.slip.isEmpty {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("未結算 \(bank.slip.count) 筆")
                                    .font(.system(size: 13, weight: .semibold))
                                ForEach(bank.slip) { b in
                                    HStack(spacing: 8) {
                                        Text("第\(b.raceNo)場 \(b.horseNo)號 \(b.horseName)")
                                            .font(.system(size: 12)).lineLimit(1)
                                        Spacer()
                                        Button("贏") {
                                            Task { await bank.settle(b.id, win: true) }
                                        }.font(.system(size: 11, weight: .bold))
                                            .foregroundStyle(.white).padding(.horizontal, 10)
                                            .padding(.vertical, 4).background(HK.green).cornerRadius(3)
                                        Button("輸") {
                                            Task { await bank.settle(b.id, win: false) }
                                        }.font(.system(size: 11))
                                            .foregroundStyle(HK.txt2).padding(.horizontal, 10)
                                            .padding(.vertical, 4)
                                            .background(Color(red: 0.97, green: 0.96, blue: 0.94))
                                            .cornerRadius(3)
                                    }
                                    .padding(.vertical, 5)
                                    .overlay(alignment: .bottom) { Divider() }
                                }
                            }
                            .padding(12).background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 3))
                            .overlay(RoundedRectangle(cornerRadius: 3).stroke(HK.line))
                        }

                        VStack(spacing: 8) {
                            HStack(spacing: 8) {
                                Text("重設本金").font(.system(size: 12)).foregroundStyle(HK.txt2)
                                TextField("10000", value: Binding(
                                    get: { bank.start }, set: { _ in }), format: .number)
                                    .textFieldStyle(.roundedBorder)
                                    .frame(width: 110).multilineTextAlignment(.trailing)
                            }
                            Button("清空帳本") { bank.reset() }
                                .font(.system(size: 12))
                                .foregroundStyle(HK.red)
                        }
                        .padding(12)
                    }
                    .padding(14)
                }
                .frame(maxHeight: 620).background(.white)
            }
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    func cell(_ k: String, _ v: String, _ c: Color) -> some View {
        VStack(spacing: 2) {
            Text(k).font(.system(size: 10.5)).foregroundStyle(HK.txt3)
            Text(v).font(.system(size: 18, weight: .semibold))
                .foregroundStyle(c).monospacedDigit()
        }
        .frame(maxWidth: .infinity).padding(.vertical, 11).background(.white)
    }
}