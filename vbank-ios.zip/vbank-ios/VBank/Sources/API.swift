//
//  API.swift — 直连 HKJC 公开 GraphQL + 虚拟仓账本
//  与网页版 vb_server.py 完全同源：
//    端点 https://info.cld.hkjc.com/graphql/base/
//    机制 浮动彩池：下注记参考赔率，结算按开赛前最后赔率
//

import Foundation
import SwiftUI

// MARK: - 数据模型

struct Runner: Identifiable, Codable {
    var id: String { "\(raceNo)-\(no)-\(type)" }
    let raceNo: Int
    let no: String
    let nameCh: String
    let nameEn: String?
    let rating: String?
    let intlRating: String?
    let weight: String?
    let jockey: String?
    let trainer: String?
    let type: String            // WIN / PLA / QIN / QPL / DBL
    let odds: Double?
    let isHot: Bool
    let lastUpdate: String?
}

struct Race: Identifiable {
    var id: Int { raceNo }
    let raceNo: Int
    let raceName: String
    let postTime: String
    let distance: String
    var runners: [Runner]
}

struct Meeting: Identifiable {
    var id: String { "\(venue)-\(date)" }
    let venue: String
    let date: String
    let total: Int
    let current: Int
    let status: String
    var races: [Race]
    var poolTotal: Double?
    var poolUpdated: String?
}

// MARK: - 投注记录

struct Bet: Identifiable, Codable {
    let id: String
    let date: String
    let venue: String
    let raceNo: String
    let raceName: String
    let horseNo: String
    let horseName: String
    let oddsType: String
    let oddsAtBet: Double       // 下注瞬间的参考赔率
    let stake: Double
    let jockey: String?
    var status: String          // PENDING / SETTLED
    var payout: Double?
    var net: Double?
    var finalOdds: Double?      // 结算时的最终赔率
    var drift: Double?          // 最终 - 参考

    var potentialAtBet: Double { stake * oddsAtBet }
}

enum OddsType: String, CaseIterable {
    case win = "WIN", pla = "PLA", qin = "QIN", qpl = "QPL", dbl = "DBL"
    var label: String {
        switch self {
        case .win: return "獨贏"
        case .pla: return "位置"
        case .qin: return "連贏"
        case .qpl: return "位置Q"
        case .dbl: return "孖寶"
        }
    }
}

// MARK: - HKJC GraphQL 客户端

actor HKJCAPI {
    static let shared = HKJCAPI()
    private let endpoint = URL(string: "https://info.cld.hkjc.com/graphql/base/")!

    // 白名单内的完整赛事查询（字段集必须与官方一致，否则返回 WHITELIST_ERROR）
    private static let qCard = """
    query raceMeetings($date: String, $venueCode: String) {
      raceMeetings(date: $date, venueCode: $venueCode) {
        id venueCode date status totalNumberOfRace currentNumberOfRace
        races {
          no postTime status raceName_ch raceName_en distance
          runners {
            no name_ch name_en winOdds handicapWeight
            currentRating internationalRating
            jockey { name_ch } trainer { name_ch }
          }
        }
        pmPools(oddsTypes: [WIN]) {
          status lastUpdateTime investment
          oddsNodes { combString oddsValue hotFavourite }
        }
      }
    }
    """

    private static let qAll = """
    query raceMeetings($date: String, $venueCode: String) {
      raceMeetings(date: $date, venueCode: $venueCode) {
        id venueCode date status totalNumberOfRace currentNumberOfRace
        races {
          no postTime raceName_ch distance
          runners {
            no name_ch name_en currentRating internationalRating handicapWeight
            jockey { name_ch } trainer { name_ch }
          }
        }
        pmPools(oddsTypes: [WIN, PLA, QIN, QPL, DBL]) {
          oddsType lastUpdateTime
          oddsNodes { combString oddsValue hotFavourite }
        }
      }
    }
    """

    private var session: URLSession = {
        let c = URLSessionConfiguration.default
        c.httpAdditionalHeaders = [
            "Origin": "https://bet.hkjc.com",
            "Referer": "https://bet.hkjc.com/",
            "Accept": "application/json"
        ]
        c.timeoutIntervalForRequest = 20
        c.waitsForConnectivity = true
        return URLSession(configuration: c)
    }()

    private func gql(_ query: String, _ vars: [String: Any]) async throws -> [String: Any] {
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: [
            "query": query, "variables": vars
        ])
        let (data, _) = try await session.data(for: req)
        let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
        if let errs = obj["errors"] as? [[String: Any]], !errs.isEmpty {
            let m = errs.first?["message"] as? String ?? "upstream error"
            throw NSError(domain: "HKJC", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: m])
        }
        return obj["data"] as? [String: Any] ?? [:]
    }

    /// 拉赛事 + 5 玩法赔率
    func fetchMeetings(date: String, venue: String) async throws -> [Meeting] {
        let data = try await gql(Self.qAll, ["date": date, "venueCode": venue])
        let rms = data["raceMeetings"] as? [[String: Any]] ?? []

        return rms.map { m in
            var races: [Race] = []
            for r in (m["races"] as? [[String: Any]] ?? []) {
                let rno = r["no"] as? Int ?? 0
                // 按 oddsType + combString 归集赔率
                var oddsMap: [String: (Double, Bool, String)] = [:]
                for p in (m["pmPools"] as? [[String: Any]] ?? []) {
                    let t = p["oddsType"] as? String ?? "WIN"
                    let lu = p["lastUpdateTime"] as? String
                    for nd in (p["oddsNodes"] as? [[String: Any]] ?? []) {
                        guard let c = nd["combString"] as? String else { continue }
                        let parts = c.split(separator: "_").map(String.init)
                        guard parts.count >= 3, Int(parts[1]) == rno else { continue }
                        let v = nd["oddsValue"] as? Double
                        oddsMap["\(t)_\(parts[2])"] = (
                            v ?? 0, (nd["hotFavourite"] as? Bool) ?? false, lu ?? "")
                    }
                }
                var runners: [Runner] = []
                for rn in (r["runners"] as? [[String: Any]] ?? []) {
                    let no = rn["no"].map { "\($0)" } ?? ""
                    for t in OddsType.allCases {
                        let e = oddsMap["\(t.rawValue)_\(no)"]
                        // 没有该玩法赔率时不生成，避免整行空
                        guard let e, e.0 > 1 else { continue }
                        runners.append(Runner(
                            raceNo: rno, no: no,
                            nameCh: rn["name_ch"] as? String ?? "",
                            nameEn: rn["name_en"] as? String,
                            rating: rn["currentRating"].map { "\($0)" },
                            intlRating: rn["internationalRating"].map { "\($0)" },
                            weight: rn["handicapWeight"].map { "\($0)" },
                            jockey: (rn["jockey"] as? [String: Any])?["name_ch"] as? String,
                            trainer: (rn["trainer"] as? [String: Any])?["name_ch"] as? String,
                            type: t.rawValue, odds: e.0, isHot: e.1, lastUpdate: e.2))
                    }
                }
                races.append(Race(
                    raceNo: rno,
                    raceName: r["raceName_ch"] as? String ?? "",
                    postTime: r["postTime"] as? String ?? "",
                    distance: r["distance"].map { "\($0)" } ?? "",
                    runners: runners))
            }
            let winPool = (m["pmPools"] as? [[String: Any]] ?? [])
                .first { ($0["oddsType"] as? String) == "WIN" }
            return Meeting(
                venue: m["venueCode"] as? String ?? venue,
                date: m["date"] as? String ?? date,
                total: m["totalNumberOfRace"] as? Int ?? races.count,
                current: m["currentNumberOfRace"] as? Int ?? 0,
                status: m["status"] as? String ?? "",
                races: races,
                poolTotal: winPool?["investment"] as? Double,
                poolUpdated: winPool?["lastUpdateTime"] as? String)
        }
    }

    /// 抓某场某马的「最终赔率」—— 模拟开赛前最后定盘
    func finalOdds(date: String, venue: String,
                   raceNo: String, horseNo: String,
                   type: String) async -> Double? {
        guard let ms = try? await fetchMeetings(date: date, venue: venue) else { return nil }
        for m in ms {
            for r in m.races where String(r.raceNo) == raceNo {
                if let hit = r.runners.first(where: {
                    $0.no == horseNo && $0.type == type
                }) { return hit.odds }
            }
        }
        return nil
    }
}

// MARK: - 虚拟仓账本（本地持久化）

@MainActor
final class Bankroll: ObservableObject {
    @Published private(set) var slip: [Bet] = []
    @Published private(set) var history: [Bet] = []
    @Published private(set) var bankroll: Double = 10_000
    @Published private(set) var start: Double = 10_000
    private var seq = 0

    private let url: URL = {
        let d = FileManager.default.urls(for: .documentDirectory,
                                        in: .userDomainMask)[0]
        return d.appendingPathComponent("vbank.json")
    }()

    var pendingStake: Double { slip.reduce(0) { $0 + $1.stake } }
    var pendingPotential: Double { slip.reduce(0) { $0 + $1.potentialAtBet } }
    var profit: Double { bankroll - start }

    init() { load() }

    private func load() {
        guard let d = try? Data(contentsOf: url),
              let o = try? JSONDecoder().decode(Saved.self, from: d) else { return }
        slip = o.slip; history = o.history
        bankroll = o.bankroll; start = o.start; seq = o.seq
    }

    private func save() {
        let s = Saved(slip: slip, history: history,
                      bankroll: bankroll, start: start, seq: seq)
        if let d = try? JSONEncoder().encode(s) { try? d.write(to: url) }
    }

    struct Saved: Codable {
        var slip: [Bet]; var history: [Bet]
        var bankroll: Double; var start: Double; var seq: Int
    }

    // MARK: 下注

    func place(date: String, venue: String, race: Race, horse: Runner,
               stake: Double) throws {
        guard let odds = horse.odds, odds > 1 else {
            throw BankrollError.noOdds }
        guard stake > 0 else { throw BankrollError.badStake }
        guard stake <= bankroll else { throw BankrollError.insufficient(bankroll) }
        seq += 1
        let b = Bet(id: "vb\(seq)", date: date, venue: venue,
                    raceNo: String(race.raceNo), raceName: race.raceName,
                    horseNo: horse.no, horseName: horse.nameCh,
                    oddsType: horse.type, oddsAtBet: odds, stake: stake,
                    jockey: horse.jockey, status: "PENDING",
                    payout: nil, net: nil, finalOdds: nil, drift: nil)
        slip.append(b)
        bankroll -= stake          // 押注即扣
        save()
    }

    func remove(_ id: String) {
        if let i = slip.firstIndex(where: { $0.id == id }) {
            bankroll += slip[i].stake        // 撤销退本金
            slip.remove(at: i); save()
        }
    }

    // MARK: 结算（按最终赔率派彩 — 马会浮动彩池机制）

    func settle(_ id: String, win: Bool, officialDividend: Double? = nil) async {
        guard let i = slip.firstIndex(where: { $0.id == id }) else { return }
        var b = slip[i]

        var payout = 0.0
        var finalOdds: Double? = nil

        if let d = officialDividend, d > 0 {
            payout = d
        } else if win {
            // 自动抓当前最新赔率 = 最后一刻定盘
            finalOdds = await HKJCAPI.shared.finalOdds(
                date: b.date, venue: b.venue,
                raceNo: b.raceNo, horseNo: b.horseNo, type: b.oddsType)
            let fo = (finalOdds ?? b.oddsAtBet)
            payout = b.stake * fo
        }

        b.status = "SETTLED"
        b.payout = (payout * 100).rounded() / 100
        b.net = ((payout - b.stake) * 100).rounded() / 100
        b.finalOdds = finalOdds
        b.drift = finalOdds.map { (($0 - b.oddsAtBet) * 1000).rounded() / 1000 }

        bankroll += payout                      // 结算只返派彩
        slip.remove(at: i)
        history.insert(b, at: 0)
        save()
    }

    func settleRace(date: String, raceNo: String, winners: [String: Bool]) async {
        let ids = slip.filter { $0.date == date && $0.raceNo == raceNo }.map(\.id)
        for id in ids {
            let h = slip.first(where: { $0.id == id })?.horseNo ?? ""
            await settle(id, win: winners[h] ?? false)
        }
    }

    func setBankroll(_ v: Double) {
        bankroll = v; start = v; save()
    }

    func reset() {
        slip = []; history = []; bankroll = 10_000; start = 10_000; seq = 0; save()
    }

    // MARK: 统计

    struct Stats {
        var n = 0, win = 0
        var winRate = 0.0, roi = 0.0, profit = 0.0, mdd = 0.0
        var byType: [String: (n: Int, win: Int, net: Double, roi: Double)] = [:]
    }

    var stats: Stats {
        var s = Stats()
        guard !history.isEmpty else { return s }
        var peak = start, run = 0.0
        var grouped: [String: (Int, Int, Double, Double)] = [:]
        for b in history {
            s.n += 1
            let net = b.net ?? 0
            if net > 0 { s.win += 1 }
            s.profit += net
            run += net
            let eq = start + run
            peak = max(peak, eq)
            s.mdd = max(s.mdd, peak - eq)
            var g = grouped[b.oddsType] ?? (0, 0, 0, 0)
            g.0 += 1; g.1 += net > 0 ? 1 : 0; g.2 += net; g.3 += b.stake
            grouped[b.oddsType] = g
        }
        let totalStake = history.reduce(0) { $0 + $1.stake }
        s.winRate = Double(s.win) / Double(s.n) * 100
        s.roi = totalStake > 0 ? s.profit / totalStake * 100 : 0
        s.byType = grouped.mapValues { g in
            (g.0, g.1, g.2, g.2 / max(g.3, 0.0001) * 100)
        }
        return s
    }
}

enum BankrollError: LocalizedError {
    case noOdds, badStake, insufficient(Double)
    var errorDescription: String? {
        switch self {
        case .noOdds:      return "暫無賠率"
        case .badStake:    return "投注額必須大於 0"
        case .insufficient(let b): return "虛擬本金不足：餘 \(String(format: "%.2f", b))"
        }
    }
}