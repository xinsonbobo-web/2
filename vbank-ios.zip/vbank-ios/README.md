# VBank · 虛擬倉 iOS 原生 App

与马会同源的赛马数据 + 本地虚拟本金。SwiftUI 原生，无第三方依赖。

---

## 状态

| 项 | 状态 |
|---|---|
| SwiftUI 源码 | ✅ 完成（3 文件，语法已验证） |
| Xcode 工程 | ✅ 已生成（`make-project.py` 可重建） |
| 编译 `.ipa` | ⏳ **等 Xcode** |
| 签名侧载 | ⏳ 需要 AltStore / Sideloadly / 开发者账号 |

---

## 一、装 Xcode

App Store 显示「版本太低」的话，直接从官网下：

```
https://developer.apple.com/download/all/
```

找 **Xcode 16.x**（`.xip`），然后：

```bash
xip -x Xcode_16.xip
mv Xcode.app /Applications/
```

装完**打开一次 Xcode**（会装附加组件，约 10 分钟）。

---

## 二、编译

```bash
cd /Users/bobo/WorkBuddy/2026-10-14-00-04-51/VBankIOS
./build-ipa.sh
```

产物：`VBank.ipa`

---

## 三、装到 iPhone

| 方式 | 要求 | 有效期 |
|---|---|---|
| **Sideloadly** | Windows/Mac，免费，最简单 | 7 天重签 |
| **AltStore** | 电脑跑 AltStore | 7 天重签 |
| **开发者账号** | 688 港币/年 | 1 年 |
| **TrollStore** | iOS 15–16.x 才行 | 永久 |

> 你的 iPhone 14 Pro / iOS 26.0.1 — TrollStore 大概率不支持。

**推荐 Sideloadly**：Mac 上装好，直接拖 IPA 进去就行。

---

## 源码结构

```
Sources/
├── VBankApp.swift    入口（SwiftUI App，强制浅色）
├── API.swift         HKJC GraphQL + 账本 Bankroll
└── Views.swift       eWin 界面复刻
```

### API.swift
- `HKJCAPI` actor：直连 `info.cld.hkjc.com/graphql/base/`
  - `qCard` / `qAll` 两套查询（**字段集必须与官方一致**，否则 `WHITELIST_ERROR`）
  - `finalOdds()` 抓最终赔率
- `Bankroll` @MainActor：本地账本（`Document/vbank.json`）
  - `place()` 押注即扣
  - `settle()` 按**最终赔率**派彩，记录 `drift`
  - `stats()` ROI / 胜率 / 最大回撤 / 按玩法分组

### Views.swift
- eWin 配色：`#00713d` 主绿 · `#c8a55b` 金 · `#f5f3ed` 米
- 顶栏 → 日期条 → 彩池条 → 场地条 → 赔率表 → 底部投注单
- **点赔率进投注单**（再点取消）
- 点马名开详情抽屉
- 「我的」打开统计面板

---

## 核心机制：浮动彩池

**马会不是按下注时的赔率派彩**，而是按**开赛前最后一刻的赔率**。

本App 完整复刻：

```
下注     → 记录 oddsAtBet（参考赔率）
结算     → 自动抓 finalOdds（当前最新赔率）
         → payout = stake × finalOdds
         → drift = finalOdbs - oddsAtBet（红绿显示）
```

结算明细里会显示 `8.5 -2.3`，一眼看出「以为能赔 8.5 倍，最后只赔 6.2 倍」。

---

## 安全边界

**只读公开 GraphQL + 全本地记账**：

- ❌ 不碰 `txnapi.hkjc.com`（交易）
- ❌ 不碰 `checkEligible`（资格校验）
- ❌ 不碰 Glassbox（风控）
- ❌ 不碰 FIDO2（认证）
- ✅ 无任何真实下注，零财务风险